import UIKit
import Flutter
import Firebase

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    // بند 8 (Audit): Firebase.configure() هنا، مقابل Firebase.initializeApp()
    // بجهة Dart — كلاهما مطلوب فعليًا (iOS يحتاج تهيئة أصلية منفصلة).
    FirebaseApp.configure()
    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
