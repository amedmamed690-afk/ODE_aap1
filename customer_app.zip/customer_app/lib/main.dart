import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/providers/theme_provider.dart';
import 'core/providers/auth_provider.dart';
import 'core/config/app_config.dart';
import 'core/config/appearance_provider.dart';
import 'core/config/remote_settings_provider.dart';
import 'core/theme/app_theme.dart';
import 'features/cart/cart_provider.dart';
import 'features/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // بند 15: لازم قبل أي استخدام لـ FirebaseMessaging (fcm_service.dart).
  // ملفات الإعداد الفعلية (google-services.json / GoogleService-Info.plist)
  // تُضاف وقت الإطلاق عبر `flutterfire configure` — انظر PHASE2_REPORT.md.
  await Firebase.initializeApp();

  final themeProvider = ThemeProvider();
  await themeProvider.loadSavedTheme();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider(create: (_) => AuthProvider()..loadFromStorage()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
        // بند 9/10 (Audit): مصدر واحد للدولة/العملة بدل تكرار countryId=1
        // بكل شاشة — انظر التوثيق داخل app_config.dart.
        ChangeNotifierProvider(create: (_) => AppConfig()..loadFromStorage()),
        // طلب صريح: تحكّم الأدمن الكامل بالشعار/الألوان/حجم الخط/الوضع
        // الافتراضي بدون كود — يُحمَّل بالخلفية، لا يؤخّر إقلاع التطبيق.
        ChangeNotifierProvider(create: (_) => AppearanceProvider()..load()),
        // طلب صريح (نظام إعدادات مركزي): تفعيل/تعطيل الخدمات ووسائل الدفع
        // من لوحة الإدارة — يُقرأ فعليًا الآن، مو Boolean محلي بالتطبيق.
        ChangeNotifierProvider(create: (_) => RemoteSettingsProvider()..load()),
      ],
      child: const OdeApp(),
    ),
  );
}

class OdeApp extends StatelessWidget {
  const OdeApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final appearance = context.watch<AppearanceProvider>();

    // طلب صريح: تطبيق الوضع الافتراضي القادم من لوحة الإدارة أول ما يوصل،
    // بس فقط لو المستخدم ما اختار وضعًا بنفسه من قبل (منطق الأولوية
    // موجود جوه ThemeProvider.applyRemoteDefault نفسها).
    if (appearance.isLoaded) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        themeProvider.applyRemoteDefault(appearance.defaultThemeMode);
      });
    }

    return MaterialApp(
      title: 'ODE',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeProvider.themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      // طلب صريح: حجم الخط يتحكم فيه الأدمن على مستوى التطبيق بالكامل —
      // بدون لمس أي TextStyle بأي شاشة. MediaQuery.textScaler هو المكان
      // الرسمي بفلاتر لضرب كل أحجام الخطوط بعامل واحد مركزي.
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(appearance.fontScale)),
        child: child!,
      ),
      home: const SplashScreen(),
    );
  }
}
