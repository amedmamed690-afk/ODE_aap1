import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

/// موديل/خدمة العناوين — يسدّ فجوة كانت موجودة بالتقرير (بند D):
/// الجدول والـBackend (addresses.routes.ts) كانوا جاهزين، لكن ما كان
/// فيه أي شاشة أو service بتطبيق العميل تستخدمهم فعليًا.
class AddressModel {
  final String id;
  final String? label;
  final int? cityId;
  final String line1;
  final String? buildingNo;
  final double lat;
  final double lng;
  final bool isDefault;

  AddressModel({
    required this.id, this.label, this.cityId, required this.line1,
    this.buildingNo, required this.lat, required this.lng, required this.isDefault,
  });

  factory AddressModel.fromJson(Map<String, dynamic> j) => AddressModel(
        id: j['id'],
        label: j['label'],
        cityId: j['city_id'],
        line1: j['line1'],
        buildingNo: j['building_no'],
        lat: (j['lat'] as num).toDouble(),
        lng: (j['lng'] as num).toDouble(),
        isDefault: j['is_default'] == true,
      );
}

class AddressesService {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<AddressModel>> list(String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl/addresses'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response.statusCode != 200) throw Exception('failed_to_load_addresses');
    return (jsonDecode(response.body) as List).map((e) => AddressModel.fromJson(e)).toList();
  }

  Future<AddressModel> create({
    required String token, String? label, int? cityId, required String line1,
    String? buildingNo, required double lat, required double lng, bool isDefault = false,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/addresses'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({
        if (label != null) 'label': label,
        if (cityId != null) 'cityId': cityId,
        'line1': line1,
        if (buildingNo != null) 'buildingNo': buildingNo,
        'lat': lat, 'lng': lng, 'isDefault': isDefault,
      }),
    );
    if (response.statusCode != 201) throw Exception('failed_to_save_address');
    return AddressModel.fromJson(jsonDecode(response.body));
  }

  Future<void> delete(String token, String id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/addresses/$id'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response.statusCode != 200) throw Exception('failed_to_delete_address');
  }
}
