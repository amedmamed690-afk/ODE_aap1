import 'package:firebase_messaging/firebase_messaging.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

/// بند 15: يسجّل fcm_token فعليًا بعد تسجيل الدخول — بدونه، إشعارات
/// Push المبنية بالباك إند (notifications.service.ts) ما توصل أبدًا،
/// حتى لو FCM_SERVER_KEY مضبوط صح.
class FcmService {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  static Future<void> registerToken(String authToken) async {
    try {
      final messaging = FirebaseMessaging.instance;
      final settings = await messaging.requestPermission();
      if (settings.authorizationStatus == AuthorizationStatus.denied) return;

      final fcmToken = await messaging.getToken();
      if (fcmToken == null) return;

      await http.patch(
        Uri.parse('$baseUrl/users/me'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $authToken'},
        body: jsonEncode({'fcmToken': fcmToken}),
      );

      // التوكن يتجدد أحيانًا من طرف Firebase نفسه — نعيد رفعه كل مرة.
      FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
        http.patch(
          Uri.parse('$baseUrl/users/me'),
          headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $authToken'},
          body: jsonEncode({'fcmToken': newToken}),
        );
      });
    } catch (_) {
      // لا نمنع تسجيل الدخول لو فشل تسجيل الـFCM لأي سبب (صلاحية مرفوضة،
      // جهاز بدون خدمات Google...) — الإشعارات داخل التطبيق تفضل شغالة على أي حال.
    }
  }
}
