import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class PlacePrediction {
  final String placeId;
  final String description;
  PlacePrediction({required this.placeId, required this.description});
  factory PlacePrediction.fromJson(Map<String, dynamic> j) => PlacePrediction(placeId: j['placeId'], description: j['description']);
}

class PlaceLocation {
  final double lat;
  final double lng;
  final String? address;
  PlaceLocation({required this.lat, required this.lng, this.address});
  factory PlaceLocation.fromJson(Map<String, dynamic> j) =>
      PlaceLocation(lat: (j['lat'] as num).toDouble(), lng: (j['lng'] as num).toDouble(), address: j['address']);
}

/// كل نداءات خرائط جوجل الحساسة (Places/Directions/Geocoding) تمر عبر
/// الباك إند — مفتاح Google الحقيقي أبدًا ما يوصل لكود Flutter (بند 14).
class MapsService {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<PlacePrediction>> autocomplete(String token, String input, {String? sessionToken}) async {
    if (input.trim().isEmpty) return [];
    final uri = Uri.parse('$baseUrl/maps/autocomplete').replace(queryParameters: {
      'input': input, if (sessionToken != null) 'sessionToken': sessionToken,
    });
    final response = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) return [];
    return (jsonDecode(response.body) as List).map((e) => PlacePrediction.fromJson(e)).toList();
  }

  Future<PlaceLocation?> placeDetails(String token, String placeId) async {
    final uri = Uri.parse('$baseUrl/maps/place-details').replace(queryParameters: {'placeId': placeId});
    final response = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) return null;
    return PlaceLocation.fromJson(jsonDecode(response.body));
  }

  Future<String?> reverseGeocode(String token, double lat, double lng) async {
    final uri = Uri.parse('$baseUrl/maps/reverse-geocode').replace(queryParameters: {'lat': '$lat', 'lng': '$lng'});
    final response = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) return null;
    return jsonDecode(response.body)['address'];
  }

  Future<Map<String, dynamic>?> directions(String token, double originLat, double originLng, double destLat, double destLng) async {
    final uri = Uri.parse('$baseUrl/maps/directions').replace(queryParameters: {
      'originLat': '$originLat', 'originLng': '$originLng', 'destLat': '$destLat', 'destLng': '$destLng',
    });
    final response = await http.get(uri, headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) return null;
    return jsonDecode(response.body);
  }
}
