class UserModel {
  final String id;
  final String phone;
  final String? email;
  final String? fullName;
  final String role;
  final String preferredLanguage;
  final String? avatarUrl;

  UserModel({
    required this.id,
    required this.phone,
    this.email,
    this.fullName,
    required this.role,
    required this.preferredLanguage,
    this.avatarUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      phone: json['phone'],
      email: json['email'],
      fullName: json['full_name'],
      role: json['role'],
      preferredLanguage: json['preferred_language'] ?? 'ar',
      avatarUrl: json['avatar_url'],
    );
  }
}
