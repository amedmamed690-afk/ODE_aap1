import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

/// طلب صريح (بند 10 — تجربة المستخدم عند تعطيل خدمة): "لا أريد التطبيق أن
/// يتصرف بطريقة غريبة... يظهر له: [الخدمة] غير متوفرة حاليًا". يُستخدم
/// بكل شاشة خدمة (مطاعم/متاجر/خدمات منزلية/رحلات) بمكان المحتوى مباشرة —
/// الشاشة نفسها تُفتح بشكل طبيعي، هذا فقط ما يظهر بدل القائمة/المحتوى.
class ServiceUnavailableView extends StatelessWidget {
  final String serviceName;
  const ServiceUnavailableView({super.key, required this.serviceName});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.pause_circle_outline_rounded, size: 56, color: AppColors.darkTextSecondary),
            const SizedBox(height: 16),
            Text('$serviceName غير متوفرة حاليًا',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.darkTextPrimary),
                textAlign: TextAlign.center),
            const SizedBox(height: 8),
            const Text('نعمل على إعادة تفعيلها في أقرب وقت، برجاء المحاولة لاحقًا',
                style: TextStyle(fontSize: 13, color: AppColors.darkTextSecondary),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
