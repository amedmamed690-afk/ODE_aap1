import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/theme/app_colors.dart';
import 'package:ode_customer_app/core/config/env.dart';

/// بانر إعلاني ثابت (Sticky) أعلى أي شاشة قسم — يبقى مثبتاً بمكانه أثناء
/// التمرير لباقي محتوى الشاشة (SliverAppBar بدل Container عادي، عشان
/// "ثابت" فعلاً وليس مجرد أول عنصر بالقائمة). يجيب إعلاناته من
/// GET /marketing/ads?pageKey=... — نفس الجدول والـ endpoint اللي بنيناهم
/// بلوحة التحكم لاحقاً هيتحكموا في محتواه لحظياً بدون تحديث للتطبيق.
class TopAdBanner extends StatefulWidget {
  final String pageKey; // 'ode_brand', 'restaurants', 'home_services', 'rides'...
  final int countryId;
  final void Function(Map<String, dynamic> ad)? onTapAd;

  const TopAdBanner({super.key, required this.pageKey, required this.countryId, this.onTapAd});

  @override
  State<TopAdBanner> createState() => _TopAdBannerState();
}

class _TopAdBannerState extends State<TopAdBanner> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  List<Map<String, dynamic>> _ads = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/marketing/ads?pageKey=${widget.pageKey}&countryId=${widget.countryId}'));
      if (response.statusCode == 200 && mounted) {
        setState(() => _ads = List<Map<String, dynamic>>.from(jsonDecode(response.body)));
      }
    } catch (_) {
      // فشل التحميل لا يكسر الشاشة — البانر يختفي فقط
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ads.isEmpty) return const SizedBox.shrink();
    final ad = _ads.first;

    return GestureDetector(
      onTap: () => widget.onTapAd?.call(ad),
      child: Container(
        height: 72,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: AppColors.neonGlow.withOpacity(0.2), blurRadius: 12)],
        ),
        clipBehavior: Clip.hardEdge,
        child: Image.network(
          ad['image_url'],
          fit: BoxFit.cover,
          width: double.infinity,
          errorBuilder: (_, __, ___) => Container(color: AppColors.darkCardBackground),
        ),
      ),
    );
  }
}

/// Wrapper يجعل الشاشة كاملة تستخدم SliverAppBar عشان البانر يفضل مثبّت
/// بأعلى الشاشة أثناء تمرير باقي المحتوى تحته — استخدمه بدل Scaffold+body
/// العادي بأي شاشة قسم (ODE براند، المطاعم، الخدمات المنزلية...).
class ScreenWithPinnedAd extends StatelessWidget {
  final String title;
  final String pageKey;
  final int countryId;
  final Widget body; // المحتوى القابل للتمرير تحت البانر
  final Widget? searchBar; // اختياري: يوضع بين البانر والمحتوى

  const ScreenWithPinnedAd({
    super.key,
    required this.title,
    required this.pageKey,
    required this.countryId,
    required this.body,
    this.searchBar,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            title: Text(title),
            pinned: true, // العنوان يفضل ثابت
            expandedHeight: searchBar != null ? 150 : 90,
            flexibleSpace: FlexibleSpaceBar(
              background: Padding(
                padding: const EdgeInsets.only(top: 56),
                child: Column(
                  children: [
                    TopAdBanner(pageKey: pageKey, countryId: countryId),
                    if (searchBar != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: searchBar!),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(child: body),
        ],
      ),
    );
  }
}
