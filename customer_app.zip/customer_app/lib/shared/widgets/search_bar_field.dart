import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';

/// حقل بحث موحّد يُستخدم بكل الأقسام (ODE براند، المطاعم، الخدمات
/// المنزلية...) — لا يبحث فوراً مع كل ضغطة حرف، بل بعد توقف قصير
/// (Debounce) لتقليل عدد نداءات السيرفر أثناء الكتابة.
class SearchBarField extends StatefulWidget {
  final String hintText;
  final void Function(String query) onChanged;

  const SearchBarField({super.key, required this.hintText, required this.onChanged});

  @override
  State<SearchBarField> createState() => _SearchBarFieldState();
}

class _SearchBarFieldState extends State<SearchBarField> {
  final _controller = TextEditingController();
  DateTime? _lastKeystroke;

  void _onChanged(String value) {
    final now = DateTime.now();
    _lastKeystroke = now;
    Future.delayed(const Duration(milliseconds: 400), () {
      if (_lastKeystroke == now) widget.onChanged(value.trim());
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      borderRadius: 14,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Icon(Icons.search_rounded, color: AppColors.primaryPurpleLight, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _controller,
              onChanged: _onChanged,
              style: const TextStyle(color: AppColors.darkTextPrimary, fontSize: 13),
              decoration: InputDecoration(
                hintText: widget.hintText,
                hintStyle: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 13),
                border: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          if (_controller.text.isNotEmpty)
            GestureDetector(
              onTap: () { _controller.clear(); widget.onChanged(''); },
              child: const Icon(Icons.close_rounded, color: AppColors.darkTextSecondary, size: 16),
            ),
        ],
      ),
    );
  }
}
