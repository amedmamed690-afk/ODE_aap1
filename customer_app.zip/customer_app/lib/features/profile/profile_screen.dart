import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/providers/auth_provider.dart';
import '../../core/providers/theme_provider.dart';
import '../../core/config/appearance_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../shared/models/user_model.dart';
import '../ode_pay/ode_pay_screen.dart';
import '../points/points_screen.dart';
import '../invites/invites_screen.dart';
import '../subscriptions/subscriptions_screen.dart';
import '../addresses/addresses_screen.dart';
import 'package:ode_customer_app/core/config/env.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  UserModel? _user;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final token = context.read<AuthProvider>().token;
    try {
      final response = await http.get(Uri.parse('$baseUrl/users/me'), headers: {'Authorization': 'Bearer $token'});
      if (response.statusCode == 200 && mounted) {
        setState(() { _user = UserModel.fromJson(jsonDecode(response.body)); _isLoading = false; });
      } else if (mounted) {
        setState(() => _isLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // طلب صريح: رابط خدمة العملاء يُضبط بالكامل من لوحة الإدارة — فارغ
  // بالبداية عمدًا. لو ما زال فارغًا، رسالة واضحة بدل ما نفتح رابطًا وهميًا.
  Future<void> _openCustomerSupport() async {
    final url = context.read<AppearanceProvider>().customerSupportUrl;
    if (url == null || url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('خدمة العملاء غير مفعّلة حاليًا')),
      );
      return;
    }
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح رابط خدمة العملاء')));
    }
  }

  // طلب صريح: اختيار المستخدم بنفسه بين فاتح/داكن/حسب الجهاز.
  void _openThemePicker() {
    final themeProvider = context.read<ThemeProvider>();
    showModalBottomSheet(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('المظهر')),
          ListTile(leading: const Icon(Icons.dark_mode_rounded), title: const Text('داكن'),
            onTap: () { themeProvider.setMode(ThemeMode.dark); Navigator.pop(sheetContext); }),
          ListTile(leading: const Icon(Icons.light_mode_rounded), title: const Text('فاتح'),
            onTap: () { themeProvider.setMode(ThemeMode.light); Navigator.pop(sheetContext); }),
          ListTile(leading: const Icon(Icons.brightness_auto_rounded), title: const Text('حسب إعدادات الجهاز'),
            onTap: () { themeProvider.setMode(ThemeMode.system); Navigator.pop(sheetContext); }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('حسابي'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : _user == null
              ? const Center(child: Text('تعذر تحميل بياناتك', style: TextStyle(color: AppColors.darkTextSecondary)))
              : ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    GlassContainer(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 36,
                            backgroundColor: AppColors.darkCardBackground,
                            backgroundImage: _user!.avatarUrl != null ? NetworkImage(_user!.avatarUrl!) : null,
                            child: _user!.avatarUrl == null ? Icon(Icons.person_rounded, size: 36, color: AppColors.primaryPurpleLight) : null,
                          ),
                          const SizedBox(height: 12),
                          Text(_user!.fullName ?? 'مستخدم ODE', style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 4),
                          Text(_user!.phone, style: const TextStyle(color: AppColors.darkTextSecondary)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    // إصلاح: كان زرًا بلا وظيفة (onTap: () {}) — من ضمن أزرار
                    // "لا يعمل" اللي طلبت رصدها. الآن يفتح شاشة إدارة العناوين الحقيقية.
                    _buildTile(Icons.location_on_outlined, 'عناويني', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddressesScreen()))),
                    _buildTile(Icons.receipt_long_outlined, 'طلباتي', () {}),
                    _buildTile(Icons.account_balance_wallet_outlined, 'محفظتي', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OdePayScreen()))),
                    _buildTile(Icons.stars_rounded, 'نقاطي', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PointsScreen()))),
                    _buildTile(Icons.card_giftcard_rounded, 'ادعُ صديقًا', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvitesScreen()))),
                    _buildTile(Icons.workspace_premium_rounded, 'ODE Plus / Pro', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SubscriptionsScreen()))),
                    // إضافة (طلب صريح): خدمة العملاء — الرابط يُضبط من لوحة الإدارة فقط.
                    _buildTile(Icons.support_agent_rounded, 'خدمة العملاء', _openCustomerSupport),
                    // إضافة (طلب صريح): اختيار المظهر (فاتح/داكن/حسب الجهاز) بنفسه.
                    _buildTile(Icons.palette_outlined, 'المظهر', _openThemePicker),
                    _buildTile(Icons.language_rounded, 'اللغة', () {}),
                    _buildTile(Icons.logout_rounded, 'تسجيل الخروج', () async {
                      await context.read<AuthProvider>().logout();
                      if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                    }, isDestructive: true),
                  ],
                ),
    );
  }

  Widget _buildTile(IconData icon, String label, VoidCallback onTap, {bool isDestructive = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: GlassContainer(
          child: Row(children: [
            Icon(icon, color: isDestructive ? AppColors.error : AppColors.primaryPurpleLight),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: TextStyle(color: isDestructive ? AppColors.error : AppColors.darkTextPrimary))),
            if (!isDestructive) const Icon(Icons.arrow_back_ios_rounded, size: 14, color: AppColors.darkTextSecondary),
          ]),
        ),
      ),
    );
  }
}
