import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_logo.dart';
import '../../core/config/app_config.dart';
import '../home/home_screen.dart';
import '../auth/login_screen.dart';
import 'splash_controller.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  final SplashController _controller = SplashController();

  late final AnimationController _fadeController;
  late final Animation<double> _fadeAnimation;

  late final AnimationController _pulseController;
  late final Animation<double> _pulseAnimation;

  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);

    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.55, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
    _initialize();
  }

  Future<void> _initialize() async {
    final results = await Future.wait([
      _controller.checkAuthStatus(),
      _controller.fetchSplashVideoUrl(countryId: context.read<AppConfig>().countryId), // بند 9: من AppConfig المركزي
    ]);

    final authResult = results[0] as SplashResult;
    final videoUrl = results[1] as String?;

    if (videoUrl != null) {
      await _initVideo(videoUrl);
    }

    await Future.delayed(const Duration(milliseconds: 2200));
    _navigateNext(authResult);
  }

  Future<void> _initVideo(String url) async {
    try {
      final controller = VideoPlayerController.networkUrl(Uri.parse(url));
      await controller.initialize().timeout(const Duration(seconds: 5));
      controller.setLooping(false);
      controller.play();
      if (mounted) {
        setState(() {
          _videoController = controller;
          _videoReady = true;
        });
      }
    } catch (_) {
      _videoController = null;
      _videoReady = false;
    }
  }

  void _navigateNext(SplashResult result) {
    if (_navigated || !mounted) return;
    _navigated = true;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: result.isAuthenticated ? const HomeScreen() : const LoginScreen(),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: Center(
        child: _videoReady && _videoController != null ? _buildVideoSplash() : _buildLogoSplash(),
      ),
    );
  }

  Widget _buildVideoSplash() {
    return AspectRatio(
      aspectRatio: _videoController!.value.aspectRatio,
      child: VideoPlayer(_videoController!),
    );
  }

  Widget _buildLogoSplash() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: AnimatedBuilder(
        animation: _pulseAnimation,
        builder: (context, child) {
          return Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: AppColors.neonGlow.withOpacity(_pulseAnimation.value * 0.6), blurRadius: 50, spreadRadius: 10),
                BoxShadow(color: AppColors.neonGlow.withOpacity(_pulseAnimation.value * 0.3), blurRadius: 90, spreadRadius: 20),
              ],
            ),
            child: child,
          );
        },
        child: const AppLogo(size: 140), // إصلاح: كان يشاور على asset غير موجود إطلاقًا (crash مؤكد) — الآن شعار حقيقي قابل للتعديل من لوحة الإدارة
      ),
    );
  }
}
