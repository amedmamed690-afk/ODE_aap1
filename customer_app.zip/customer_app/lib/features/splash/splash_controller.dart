import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../shared/services/fcm_service.dart';
import 'package:ode_customer_app/core/config/env.dart';

class SplashController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<SplashResult> checkAuthStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');

    if (token == null || token.isEmpty) {
      return SplashResult(isAuthenticated: false);
    }

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/auth/verify'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        FcmService.registerToken(token); // بند 15 — لا تنتظره، ما يمنع الدخول لو تأخر
        return SplashResult(
          isAuthenticated: true,
          userId: data['userId'],
          role: data['role'],
        );
      } else {
        await prefs.remove('auth_token');
        return SplashResult(isAuthenticated: false);
      }
    } catch (_) {
      return SplashResult(isAuthenticated: false, hadNetworkError: true);
    }
  }

  Future<String?> fetchSplashVideoUrl({required int countryId}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/marketing/splash?countryId=$countryId'),
      ).timeout(const Duration(seconds: 4));

      if (response.statusCode == 200 && response.body != 'null') {
        final data = jsonDecode(response.body);
        return data['video_url'] as String?;
      }
    } catch (_) {}
    return null;
  }
}

class SplashResult {
  final bool isAuthenticated;
  final String? userId;
  final String? role;
  final bool hadNetworkError;

  SplashResult({
    required this.isAuthenticated,
    this.userId,
    this.role,
    this.hadNetworkError = false,
  });
}
