import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

/// بند 19: كود دعوة ثابت لكل مستخدم، والمكافأة لا تُحتسب إلا بعد
/// إكمال أول طلب توصيل للمدعو (يتحقق منه order-flow.service.ts بالباك إند).
class InvitesController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<String> fetchMyCode(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/invites/my-code'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل كود الدعوة');
    return jsonDecode(response.body)['code'];
  }

  Future<void> redeemCode(String token, String code) async {
    final response = await http.post(
      Uri.parse('$baseUrl/invites/redeem'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode({'code': code}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode != 201) throw Exception(_arabicError(data['error']));
  }

  String _arabicError(String? code) {
    switch (code) {
      case 'invalid_code': return 'كود الدعوة غير صحيح';
      case 'cannot_use_own_code': return 'لا يمكنك استخدام كودك الخاص';
      case 'already_redeemed_a_code': return 'استخدمت كود دعوة من قبل';
      case 'invite_code_must_be_entered_before_first_delivered_order':
        return 'لازم تدخل كود الدعوة قبل إكمال أول طلب توصيل لك';
      default: return 'تعذر تفعيل الكود';
    }
  }
}
