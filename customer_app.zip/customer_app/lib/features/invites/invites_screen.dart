import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'invites_controller.dart';

/// بند 19: نظام الدعوات.
class InvitesScreen extends StatefulWidget {
  const InvitesScreen({super.key});

  @override
  State<InvitesScreen> createState() => _InvitesScreenState();
}

class _InvitesScreenState extends State<InvitesScreen> {
  final InvitesController _controller = InvitesController();
  final TextEditingController _codeController = TextEditingController();
  String? _myCode;
  bool _isLoading = true;
  bool _isRedeeming = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthProvider>().token!;
    try {
      final code = await _controller.fetchMyCode(token);
      if (mounted) setState(() { _myCode = code; _isLoading = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _redeem() async {
    if (_codeController.text.trim().isEmpty) return;
    setState(() { _isRedeeming = true; _error = null; });
    try {
      final token = context.read<AuthProvider>().token!;
      await _controller.redeemCode(token, _codeController.text.trim());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تفعيل الكود 🎉')));
        _codeController.clear();
      }
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isRedeeming = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('ادعُ صديقًا'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  GlassContainer(
                    padding: const EdgeInsets.all(24),
                    child: Column(children: [
                      Icon(Icons.card_giftcard_rounded, size: 40, color: AppColors.primaryPurpleLight),
                      const SizedBox(height: 12),
                      const Text('كودك الخاص', style: TextStyle(color: AppColors.darkTextSecondary)),
                      const SizedBox(height: 8),
                      Text(_myCode ?? '—', style: Theme.of(context).textTheme.headlineSmall?.copyWith(letterSpacing: 4)),
                      const SizedBox(height: 16),
                      NeonButton(
                        label: 'شارك الكود',
                        onPressed: () => Share.share('انضم لـ ODE واستخدم كودي $_myCode عشان تحصلوا على مكافأة!'),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 20),
                  Text('عندك كود من صديق؟', style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 10),
                  GlassContainer(
                    child: TextField(
                      controller: _codeController,
                      textAlign: TextAlign.center,
                      style: const TextStyle(letterSpacing: 4),
                      decoration: const InputDecoration(hintText: 'أدخل الكود هنا', border: InputBorder.none),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Text(_error!, style: const TextStyle(color: AppColors.error), textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 12),
                  NeonButton(label: 'تفعيل الكود', isLoading: _isRedeeming, onPressed: _redeem),
                ],
              ),
            ),
    );
  }
}
