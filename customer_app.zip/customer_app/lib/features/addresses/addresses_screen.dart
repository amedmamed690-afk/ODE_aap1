import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/addresses_service.dart';
import 'add_address_screen.dart';

/// شاشة العناوين — كانت مفقودة بالكامل (بند D بالتقرير) رغم أن السلة
/// وشاشة حجز الخدمات المنزلية كلتاهما تحتاجان addressId حقيقي.
///
/// وضعان:
/// - selectMode = true: تُستخدم من السلة/الحجز، وتُرجع الـAddressModel
///   المختار عبر Navigator.pop عند الضغط عليه.
/// - selectMode = false: إدارة كاملة (عرض/إضافة/حذف) من صفحة الحساب.
class AddressesScreen extends StatefulWidget {
  final bool selectMode;
  const AddressesScreen({super.key, this.selectMode = false});

  @override
  State<AddressesScreen> createState() => _AddressesScreenState();
}

class _AddressesScreenState extends State<AddressesScreen> {
  final _service = AddressesService();
  List<AddressModel> _addresses = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final token = context.read<AuthProvider>().token;
      if (token == null) throw Exception('not_authenticated');
      final addresses = await _service.list(token);
      if (mounted) setState(() { _addresses = addresses; _isLoading = false; });
    } catch (_) {
      if (mounted) setState(() { _isLoading = false; _error = 'تعذر تحميل العناوين'; });
    }
  }

  Future<void> _addNew() async {
    final created = await Navigator.push<AddressModel>(
      context, MaterialPageRoute(builder: (_) => const AddAddressScreen()),
    );
    if (created == null) return;
    if (!mounted) return;
    if (widget.selectMode) {
      Navigator.pop(context, created);
    } else {
      _load();
    }
  }

  Future<void> _delete(AddressModel address) async {
    try {
      final token = context.read<AuthProvider>().token;
      if (token == null) return;
      await _service.delete(token, address.id);
      _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(backgroundColor: AppColors.error, content: Text('تعذر حذف العنوان')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.selectMode ? 'اختر عنوان التوصيل' : 'عناويني')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primaryPurple,
        onPressed: _addNew,
        child: const Icon(Icons.add_location_alt_rounded, color: Colors.white),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : _error != null
              ? Center(child: Text(_error!, style: const TextStyle(color: AppColors.error)))
              : _addresses.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.location_off_rounded, color: AppColors.darkTextSecondary, size: 48),
                            const SizedBox(height: 12),
                            const Text('لا يوجد لديك أي عنوان محفوظ بعد'),
                            const SizedBox(height: 16),
                            NeonButton(label: 'إضافة عنوان جديد', onPressed: _addNew),
                          ],
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _addresses.length,
                      itemBuilder: (context, index) {
                        final address = _addresses[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: GlassContainer(
                            child: ListTile(
                              onTap: widget.selectMode ? () => Navigator.pop(context, address) : null,
                              leading: Icon(
                                address.isDefault ? Icons.star_rounded : Icons.location_on_rounded,
                                color: AppColors.primaryPurpleLight,
                              ),
                              title: Text(address.label?.isNotEmpty == true ? address.label! : 'عنوان'),
                              subtitle: Text(
                                address.buildingNo != null ? '${address.line1} — مبنى ${address.buildingNo}' : address.line1,
                              ),
                              trailing: widget.selectMode
                                  ? const Icon(Icons.chevron_left_rounded, color: AppColors.darkTextSecondary)
                                  : IconButton(
                                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error),
                                      onPressed: () => _delete(address),
                                    ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
