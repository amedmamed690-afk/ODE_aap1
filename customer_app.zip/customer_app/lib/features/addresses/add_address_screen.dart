import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/addresses_service.dart';
import '../../shared/services/maps_service.dart';

/// شاشة إضافة عنوان جديد — تحديد الموقع فعليًا على الخريطة (أو الموقع
/// الحالي عبر geolocator)، ثم تعبئة السطر الأول تلقائيًا عبر reverse-geocode
/// (موجود جاهزًا بـ MapsService، لم يكن مستخدمًا بأي مكان بالتطبيق قبل الآن).
class AddAddressScreen extends StatefulWidget {
  const AddAddressScreen({super.key});

  @override
  State<AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends State<AddAddressScreen> {
  final _addressesService = AddressesService();
  final _mapsService = MapsService();
  final _labelController = TextEditingController();
  final _line1Controller = TextEditingController();
  final _buildingController = TextEditingController();

  GoogleMapController? _mapController;
  LatLng _selected = const LatLng(24.7136, 46.6753); // مركز افتراضي (الرياض) لحد ما نجيب الموقع الفعلي
  bool _isLocating = true;
  bool _isSaving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _useCurrentLocation();
  }

  Future<void> _useCurrentLocation() async {
    setState(() => _isLocating = true);
    try {
      final permission = await Geolocator.checkPermission();
      var granted = permission;
      if (granted == LocationPermission.denied) {
        granted = await Geolocator.requestPermission();
      }
      if (granted == LocationPermission.denied || granted == LocationPermission.deniedForever) {
        setState(() => _isLocating = false);
        return; // المستخدم يقدر يحدد يدويًا بتحريك الخريطة
      }
      final position = await Geolocator.getCurrentPosition();
      final target = LatLng(position.latitude, position.longitude);
      setState(() => _selected = target);
      _mapController?.animateCamera(CameraUpdate.newLatLng(target));
      await _reverseGeocode(target);
    } catch (_) {
      // فشل تحديد الموقع ليس سببًا لمنع المستخدم من المتابعة يدويًا
    } finally {
      if (mounted) setState(() => _isLocating = false);
    }
  }

  Future<void> _reverseGeocode(LatLng point) async {
    final token = context.read<AuthProvider>().token;
    if (token == null) return;
    final address = await _mapsService.reverseGeocode(token, point.latitude, point.longitude);
    if (address != null && mounted && _line1Controller.text.trim().isEmpty) {
      _line1Controller.text = address;
    }
  }

  Future<void> _save() async {
    if (_line1Controller.text.trim().isEmpty) {
      setState(() => _error = 'أدخل تفاصيل العنوان (السطر الأول)');
      return;
    }
    setState(() { _isSaving = true; _error = null; });
    try {
      final token = context.read<AuthProvider>().token;
      if (token == null) throw Exception('not_authenticated');
      final created = await _addressesService.create(
        token: token,
        label: _labelController.text.trim().isEmpty ? null : _labelController.text.trim(),
        line1: _line1Controller.text.trim(),
        buildingNo: _buildingController.text.trim().isEmpty ? null : _buildingController.text.trim(),
        lat: _selected.latitude,
        lng: _selected.longitude,
      );
      if (!mounted) return;
      Navigator.pop(context, created);
    } catch (_) {
      setState(() => _error = 'تعذر حفظ العنوان، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  void dispose() {
    _labelController.dispose();
    _line1Controller.dispose();
    _buildingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عنوان جديد')),
      body: Column(
        children: [
          SizedBox(
            height: 260,
            child: Stack(
              children: [
                GoogleMap(
                  initialCameraPosition: CameraPosition(target: _selected, zoom: 15),
                  onMapCreated: (c) => _mapController = c,
                  onCameraMove: (position) => _selected = position.target,
                  onCameraIdle: () => _reverseGeocode(_selected),
                  markers: {},
                ),
                const Center(
                  child: Icon(Icons.location_on, color: AppColors.primaryPurple, size: 40),
                ),
                if (_isLocating)
                  const Positioned(
                    top: 12, right: 12,
                    child: CircularProgressIndicator(color: AppColors.primaryPurple),
                  ),
                Positioned(
                  bottom: 12, right: 12,
                  child: FloatingActionButton.small(
                    heroTag: 'use_current_location',
                    backgroundColor: AppColors.primaryPurple,
                    onPressed: _useCurrentLocation,
                    child: const Icon(Icons.my_location_rounded, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text('حرّك الخريطة لتحديد موقعك بدقة', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 16),
                _buildField(_labelController, 'تسمية العنوان (مثل: المنزل، العمل)', Icons.label_outline_rounded),
                const SizedBox(height: 12),
                _buildField(_line1Controller, 'تفاصيل العنوان (الحي، الشارع)', Icons.location_city_rounded),
                const SizedBox(height: 12),
                _buildField(_buildingController, 'رقم المبنى / الشقة (اختياري)', Icons.home_rounded),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(_error!, style: const TextStyle(color: AppColors.error)),
                ],
                const SizedBox(height: 20),
                NeonButton(label: 'حفظ العنوان', isLoading: _isSaving, onPressed: _save),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildField(TextEditingController controller, String hint, IconData icon) {
    return GlassContainer(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: TextField(
        controller: controller,
        style: const TextStyle(color: AppColors.darkTextPrimary),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: AppColors.darkTextSecondary),
          prefixIcon: Icon(icon, color: AppColors.primaryPurpleLight),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
