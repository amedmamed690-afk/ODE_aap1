import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../ode_brand_controller.dart';

class CategoryChip extends StatelessWidget {
  final OdeCategoryModel category;
  final bool isSelected;
  final VoidCallback onTap;

  const CategoryChip({super.key, required this.category, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        margin: const EdgeInsets.only(left: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: isSelected ? LinearGradient(colors: [AppColors.primaryPurple, AppColors.primaryPurpleLight]) : null,
          color: isSelected ? null : AppColors.darkCardBackground,
          boxShadow: isSelected ? [BoxShadow(color: AppColors.neonGlow.withOpacity(0.45), blurRadius: 14)] : null,
        ),
        child: Text(
          category.nameAr,
          style: TextStyle(color: isSelected ? Colors.white : AppColors.darkTextSecondary, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal, fontSize: 13),
        ),
      ),
    );
  }
}
