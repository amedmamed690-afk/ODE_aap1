import 'dart:convert';
import 'package:http/http.dart' as http;
import '../home/models/product_model.dart';
import 'package:ode_customer_app/core/config/env.dart';

class OdeCategoryModel {
  final String id;
  final String nameAr;
  OdeCategoryModel({required this.id, required this.nameAr});
  factory OdeCategoryModel.fromJson(Map<String, dynamic> j) => OdeCategoryModel(id: j['id'], nameAr: j['nameAr']);
}

class OdeBrandController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<OdeCategoryModel>> fetchCategories() async {
    final response = await http.get(Uri.parse('$baseUrl/ode-brand/categories'));
    if (response.statusCode != 200) throw Exception('failed_to_load_categories');
    return (jsonDecode(response.body) as List).map((e) => OdeCategoryModel.fromJson(e)).toList();
  }

  Future<List<ProductModel>> fetchProducts({String? categoryId, String? search, required int page}) async {
    final params = <String, String>{
      'page': '$page',
      if (categoryId != null) 'categoryId': categoryId,
      if (search != null) 'search': search,
    };
    final uri = Uri.parse('$baseUrl/ode-brand/products').replace(queryParameters: params);
    final response = await http.get(uri);
    if (response.statusCode != 200) throw Exception('failed_to_load_products');
    return (jsonDecode(response.body) as List).map((e) => ProductModel.fromJson(e, sourceType: 'ode_brand')).toList();
  }
}
