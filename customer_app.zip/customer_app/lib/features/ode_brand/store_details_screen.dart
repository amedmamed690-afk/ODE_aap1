import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../home/models/product_model.dart';
import '../home/widgets/product_card.dart';
import 'package:ode_customer_app/core/config/env.dart';

class BranchModel {
  final String id;
  final String? addressLine;
  final bool isOpenNow;

  BranchModel({required this.id, this.addressLine, required this.isOpenNow});

  factory BranchModel.fromJson(Map<String, dynamic> j) => BranchModel(
        id: j['id'],
        addressLine: j['address_line'],
        isOpenNow: j['is_open_now'] == true,
      );
}

/// إصلاح (بند D بالجولة الثالثة): كان `branchId` بالسلة ثابتًا
/// 'PLACEHOLDER_BRANCH_ID' لأن هذه الشاشة لم تكن تعرف بفروع الشريك
/// إطلاقًا (وBackend order-flow.service.ts يرفض أي طلب لا يحدد فرعًا
/// حقيقيًا مفتوحًا يخص نفس الشريك — بند 16). الآن تجيب فروع الشريك
/// فعليًا (GET /partners/:id/branches — أضفناه بهذه الجولة)، وتفلتر
/// منتجات الفرع المختار فقط (GET /partners/:id/products?branchId=).
class StoreDetailsScreen extends StatefulWidget {
  final String partnerId;
  final String partnerNameAr;

  const StoreDetailsScreen({super.key, required this.partnerId, required this.partnerNameAr});

  @override
  State<StoreDetailsScreen> createState() => _StoreDetailsScreenState();
}

class _StoreDetailsScreenState extends State<StoreDetailsScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  List<BranchModel> _branches = [];
  String? _selectedBranchId;
  bool _isLoadingBranches = true;
  Future<List<ProductModel>>? _productsFuture;

  @override
  void initState() {
    super.initState();
    _loadBranches();
  }

  Future<void> _loadBranches() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/partners/${widget.partnerId}/branches'));
      if (response.statusCode == 200) {
        final branches = (jsonDecode(response.body) as List).map((e) => BranchModel.fromJson(e)).toList();
        if (mounted) {
          setState(() {
            _branches = branches;
            // نفضّل تلقائيًا أول فرع مفتوح الآن — المستخدم يقدر يغيّره يدويًا
            _selectedBranchId = branches.isNotEmpty
                ? branches.firstWhere((b) => b.isOpenNow, orElse: () => branches.first).id
                : null;
            _isLoadingBranches = false;
            _productsFuture = _fetchStoreProducts();
          });
        }
      } else if (mounted) {
        setState(() { _isLoadingBranches = false; _productsFuture = _fetchStoreProducts(); });
      }
    } catch (_) {
      if (mounted) setState(() { _isLoadingBranches = false; _productsFuture = _fetchStoreProducts(); });
    }
  }

  Future<List<ProductModel>> _fetchStoreProducts() async {
    final uri = Uri.parse('$baseUrl/partners/${widget.partnerId}/products').replace(
      queryParameters: _selectedBranchId != null ? {'branchId': _selectedBranchId} : null,
    );
    final response = await http.get(uri);
    if (response.statusCode != 200) throw Exception('failed_to_load_store_products');
    return (jsonDecode(response.body) as List).map((e) => ProductModel.fromJson(e, sourceType: 'partner')).toList();
  }

  void _selectBranch(String branchId) {
    setState(() {
      _selectedBranchId = branchId;
      _productsFuture = _fetchStoreProducts();
    });
  }

  @override
  Widget build(BuildContext context) {
    final noOpenBranch = !_isLoadingBranches && _branches.isNotEmpty && _selectedBranchId == null;

    return Scaffold(
      appBar: AppBar(title: Text(widget.partnerNameAr)),
      body: Column(
        children: [
          if (_isLoadingBranches)
            Padding(padding: EdgeInsets.all(16), child: LinearProgressIndicator(color: AppColors.primaryPurple))
          else if (_branches.length > 1)
            // فرع واحد فقط = لا داعي لإظهار اختيار (تجربة أبسط)، أكثر من فرع = chips حقيقية
            SizedBox(
              height: 56,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: _branches.length,
                itemBuilder: (context, i) {
                  final b = _branches[i];
                  final selected = b.id == _selectedBranchId;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(b.addressLine ?? 'فرع ${i + 1}'),
                      avatar: Icon(b.isOpenNow ? Icons.check_circle : Icons.access_time_filled,
                          size: 14, color: b.isOpenNow ? AppColors.success : AppColors.darkTextSecondary),
                      selected: selected,
                      onSelected: (_) => _selectBranch(b.id),
                      selectedColor: AppColors.primaryPurple,
                    ),
                  );
                },
              ),
            )
          else if (_branches.isNotEmpty && _branches.first.addressLine != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: GlassContainer(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(children: [
                  Icon(Icons.storefront_rounded, size: 16, color: AppColors.primaryPurpleLight),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_branches.first.addressLine!, style: const TextStyle(fontSize: 12))),
                ]),
              ),
            ),
          Expanded(
            child: noOpenBranch
                ? const Center(child: Text('لا يوجد فرع مفتوح حاليًا لهذا المتجر'))
                : FutureBuilder<List<ProductModel>>(
                    future: _productsFuture,
                    builder: (context, snapshot) {
                      if (_productsFuture == null || snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator(color: AppColors.primaryPurple));
                      }
                      if (snapshot.hasError || !snapshot.hasData) {
                        return const Center(child: Text('تعذر تحميل منتجات المتجر'));
                      }
                      final products = snapshot.data!;
                      if (products.isEmpty) {
                        return const Center(child: Text('لا توجد منتجات متاحة بهذا الفرع حاليًا'));
                      }
                      return GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.68),
                        itemCount: products.length,
                        itemBuilder: (context, i) => ProductCard(product: products[i]),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
