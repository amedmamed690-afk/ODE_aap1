import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/glass_container.dart';
import '../../shared/widgets/search_bar_field.dart';
import '../../shared/widgets/top_ad_banner.dart';
import '../home/widgets/product_card.dart';
import '../../core/config/remote_settings_provider.dart';
import '../../shared/widgets/service_unavailable_view.dart';
import 'ode_brand_controller.dart';
import 'widgets/category_chip.dart';

class OdeBrandScreen extends StatefulWidget {
  final String? initialCategoryId;
  const OdeBrandScreen({super.key, this.initialCategoryId});

  @override
  State<OdeBrandScreen> createState() => _OdeBrandScreenState();
}

class _OdeBrandScreenState extends State<OdeBrandScreen> {
  final OdeBrandController _controller = OdeBrandController();
  final ScrollController _scrollController = ScrollController();

  List<OdeCategoryModel> _categories = [];
  String? _selectedCategoryId;
  String? _searchQuery;
  final List _products = [];
  bool _isLoadingProducts = true;
  bool _isLoadingMore = false;
  bool _hasMore = true;
  int _page = 1;

  @override
  void initState() {
    super.initState();
    _selectedCategoryId = widget.initialCategoryId;
    _loadCategories();
    _loadProducts(reset: true);
    _scrollController.addListener(() {
      if (_scrollController.position.pixels > _scrollController.position.maxScrollExtent - 300) {
        _loadMoreIfNeeded();
      }
    });
  }

  Future<void> _loadCategories() async {
    try {
      final cats = await _controller.fetchCategories();
      if (mounted) setState(() => _categories = cats);
    } catch (_) {}
  }

  Future<void> _loadProducts({required bool reset}) async {
    if (reset) {
      setState(() { _isLoadingProducts = true; _page = 1; _hasMore = true; _products.clear(); });
    }
    try {
      final results = await _controller.fetchProducts(categoryId: _selectedCategoryId, search: _searchQuery, page: _page);
      if (!mounted) return;
      setState(() {
        _products.addAll(results);
        _hasMore = results.length == 20;
        _isLoadingProducts = false;
        _isLoadingMore = false;
      });
    } catch (_) {
      if (mounted) setState(() { _isLoadingProducts = false; _isLoadingMore = false; });
    }
  }

  Future<void> _loadMoreIfNeeded() async {
    if (_isLoadingMore || !_hasMore) return;
    setState(() { _isLoadingMore = true; _page++; });
    await _loadProducts(reset: false);
  }

  void _onSelectCategory(String? categoryId) {
    setState(() => _selectedCategoryId = categoryId);
    _loadProducts(reset: true);
  }

  void _onSearch(String query) {
    _searchQuery = query.isEmpty ? null : query;
    _loadProducts(reset: true);
  }

  @override
  Widget build(BuildContext context) {
    // طلب صريح (بند 2/10): "المتاجر" بلوحة الإدارة تقابل ODE Brand هنا —
    // القسم/البانر يبقى ظاهرًا كما هو، لكن المحتوى الفعلي (بحث/تصنيفات/
    // منتجات) يُستبدل برسالة واضحة، مطابقًا تمامًا للمثال المطلوب.
    final storesEnabled = context.watch<RemoteSettingsProvider>().isEnabled('services.stores.enabled');
    return Scaffold(
      appBar: AppBar(title: const Text('ODE براند')),
      // البانر والبحث بره الجزء القابل للتمرير (Column ثابت)، فيفضلوا
      // ظاهرين دايماً فوق حتى وأنت بتمرر بالمنتجات تحتهم — نفس منطق
      // شريط التصنيفات اللي كان موجود من الأول.
      body: Column(
        children: [
          TopAdBanner(pageKey: 'ode_brand', countryId: context.watch<AppConfig>().countryId), // بند 9 (Audit)
          if (!storesEnabled)
            const Expanded(child: ServiceUnavailableView(serviceName: 'المتاجر'))
          else ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SearchBarField(hintText: 'ابحث عن منتج...', onChanged: _onSearch),
          ),
          const SizedBox(height: 8),
          if (_categories.isNotEmpty)
            SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  CategoryChip(category: OdeCategoryModel(id: '', nameAr: 'الكل'), isSelected: _selectedCategoryId == null, onTap: () => _onSelectCategory(null)),
                  ..._categories.map((cat) => CategoryChip(category: cat, isSelected: _selectedCategoryId == cat.id, onTap: () => _onSelectCategory(cat.id))),
                ],
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: _isLoadingProducts
                ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
                : _products.isEmpty
                    ? _buildEmptyState()
                    : GridView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(12),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.68),
                        itemCount: _products.length + (_hasMore ? 1 : 0),
                        itemBuilder: (context, index) {
                          if (index >= _products.length) {
                            return Center(child: CircularProgressIndicator(color: AppColors.primaryPurple));
                          }
                          return ProductCard(product: _products[index]);
                        },
                      ),
          ),
          ],
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: GlassContainer(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: const [
          Icon(Icons.inventory_2_outlined, color: AppColors.darkTextSecondary, size: 40),
          SizedBox(height: 12),
          Text('لا توجد منتجات في هذا التصنيف حالياً'),
        ]),
      ),
    );
  }
}
