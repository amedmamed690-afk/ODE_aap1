import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'rides_controller.dart';

/// بند 4: جهات اتصال الطوارئ — تُضاف مرة واحدة وتُستخدم تلقائياً بكل
/// رحلة ليلية (السيرفر هو اللي يقرر "ليلية" ويبعت لهم الرابط، مش التطبيق).
class EmergencyContactsScreen extends StatefulWidget {
  const EmergencyContactsScreen({super.key});

  @override
  State<EmergencyContactsScreen> createState() => _EmergencyContactsScreenState();
}

class _EmergencyContactsScreenState extends State<EmergencyContactsScreen> {
  final RidesController _controller = RidesController();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  bool _isSaving = false;

  Future<void> _add() async {
    if (_nameController.text.trim().isEmpty || _phoneController.text.trim().isEmpty) return;
    final token = context.read<AuthProvider>().token;
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انتهت الجلسة، الرجاء تسجيل الدخول من جديد')));
      return;
    }
    setState(() => _isSaving = true);
    try {
      await _controller.addEmergencyContact(token, _nameController.text.trim(), _phoneController.text.trim());
      _nameController.clear();
      _phoneController.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت إضافة جهة الاتصال')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر الحفظ')));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('جهات اتصال الطوارئ')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'سيصل رابط تتبع مباشر لجهات الاتصال هذي تلقائياً في أي رحلة ليلية (بين 9 مساءً و5 صباحاً)، بدون أي إجراء إضافي منك.',
              style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12),
            ),
            const SizedBox(height: 20),
            GlassContainer(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextField(
                controller: _nameController,
                style: const TextStyle(color: AppColors.darkTextPrimary),
                decoration: const InputDecoration(hintText: 'اسم جهة الاتصال', hintStyle: TextStyle(color: AppColors.darkTextSecondary), border: InputBorder.none),
              ),
            ),
            const SizedBox(height: 10),
            GlassContainer(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                style: const TextStyle(color: AppColors.darkTextPrimary),
                decoration: const InputDecoration(hintText: 'رقم الهاتف', hintStyle: TextStyle(color: AppColors.darkTextSecondary), border: InputBorder.none),
              ),
            ),
            const SizedBox(height: 16),
            NeonButton(label: 'إضافة', icon: Icons.person_add_alt_1_rounded, isLoading: _isSaving, onPressed: _add),
          ],
        ),
      ),
    );
  }
}
