import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class RideCategoryModel {
  final String id;
  final String nameAr;
  final String group; // 'passenger' | 'heavy_transport'
  final String? capacityHint;

  RideCategoryModel({required this.id, required this.nameAr, required this.group, this.capacityHint});
  factory RideCategoryModel.fromJson(Map<String, dynamic> j) => RideCategoryModel(
        id: j['id'], nameAr: j['name_ar'], group: j['group_type'], capacityHint: j['capacity_hint'],
      );
}

class RideOfferModel {
  final String id;
  final double offeredPrice;
  final String status;
  final double driverRating;
  final String vehicleType;
  final String driverName;

  RideOfferModel({required this.id, required this.offeredPrice, required this.status, required this.driverRating, required this.vehicleType, required this.driverName});
  factory RideOfferModel.fromJson(Map<String, dynamic> j) => RideOfferModel(
        id: j['id'],
        offeredPrice: double.parse(j['offered_price'].toString()),
        status: j['status'],
        driverRating: double.tryParse(j['rating_avg']?.toString() ?? '0') ?? 0,
        vehicleType: j['vehicle_type'] ?? '',
        driverName: j['driver_name'] ?? '',
      );
}

class RideEstimate {
  final double distanceKm;
  final double estimatedFare;
  RideEstimate({required this.distanceKm, required this.estimatedFare});
  factory RideEstimate.fromJson(Map<String, dynamic> j) => RideEstimate(
        distanceKm: double.parse(j['distanceKm'].toString()), estimatedFare: double.parse(j['estimatedFare'].toString()),
      );
}

class RidesController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<RideCategoryModel>> fetchCategories(String group) async {
    final response = await http.get(Uri.parse('$baseUrl/rides/categories?group=$group'));
    if (response.statusCode != 200) throw Exception('failed_to_load_categories');
    return (jsonDecode(response.body) as List).map((e) => RideCategoryModel.fromJson(e)).toList();
  }

  Future<RideEstimate> estimateFare(String token, Map<String, double> pickup, Map<String, double> dropoff, String categoryId, String routePreference) async {
    final response = await http.post(
      Uri.parse('$baseUrl/rides/estimate'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'pickup': pickup, 'dropoff': dropoff, 'categoryId': categoryId, 'routePreference': routePreference}),
    );
    if (response.statusCode != 200) throw Exception('failed_to_estimate_fare');
    return RideEstimate.fromJson(jsonDecode(response.body));
  }

  Future<String> requestRide(String token, {
    required Map<String, double> pickup, required Map<String, double> dropoff, required int currencyId,
    required String categoryId, required bool isFocusMode, required String routePreference, required String pricingMode,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/rides'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({
        'pickup': pickup, 'dropoff': dropoff, 'currencyId': currencyId, 'categoryId': categoryId,
        'isFocusMode': isFocusMode, 'routePreference': routePreference, 'pricingMode': pricingMode,
      }),
    );
    if (response.statusCode != 201) throw Exception('failed_to_request_ride');
    return jsonDecode(response.body)['id'];
  }

  // ---- أودي ماكس (التفاوض) ----
  Future<void> proposeOffer(String token, String rideId, double offeredPrice, String categoryId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/rides/negotiation/$rideId/offers'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'offeredPrice': offeredPrice, 'categoryId': categoryId}),
    );
    if (response.statusCode != 201) throw Exception('failed_to_propose_offer');
  }

  Future<List<RideOfferModel>> fetchOffers(String token, String rideId) async {
    final response = await http.get(Uri.parse('$baseUrl/rides/negotiation/$rideId/offers'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('failed_to_load_offers');
    return (jsonDecode(response.body) as List).map((e) => RideOfferModel.fromJson(e)).toList();
  }

  Future<void> selectOffer(String token, String rideId, String offerId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/rides/negotiation/$rideId/offers/$offerId/select'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response.statusCode != 204) throw Exception('failed_to_select_offer');
  }

  // ---- المشاركة اللحظية وجهات الطوارئ ----
  Future<String> generateShareLink(String token, String rideId) async {
    final response = await http.post(Uri.parse('$baseUrl/ride-sharing/$rideId/share-link'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('failed_to_generate_link');
    final data = jsonDecode(response.body);
    return 'https://track.ode-app.com/${data['token']}';
  }

  Future<void> addEmergencyContact(String token, String name, String phone) async {
    await http.post(
      Uri.parse('$baseUrl/ride-sharing/emergency-contacts'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'phone': phone}),
    );
  }

  /// بند: تجميع رحلات متعددة (عائلة/أصدقاء) مع تنبيه انحراف — يفترض
  /// المستخدم أن كل رحلة بالقافلة تم طلبها مسبقًا (requestRide) قبل تجميعها.
  Future<List<Map<String, dynamic>>> fetchMyActiveRides(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/rides'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) return [];
    return (jsonDecode(response.body) as List)
        .cast<Map<String, dynamic>>()
        .where((r) => !['completed', 'cancelled'].contains(r['status']))
        .toList();
  }

  Future<void> createConvoy(String token, List<String> rideIds, {int deviationThresholdMeters = 500}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/rides/convoy'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'rideIds': rideIds, 'deviationThresholdMeters': deviationThresholdMeters}),
    );
    if (response.statusCode != 201) throw Exception('تعذر تجميع الرحلات');
  }
}
