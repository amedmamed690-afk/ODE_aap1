import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'rides_controller.dart';
import 'live_tracking_screen.dart';

/// بند 3: أودي ماكس — العروض توصل من عدة سائقين، العميل يختار وحد.
/// Polling بسيط كل 3 ثوانٍ (بديل كافٍ عن Socket هنا لأن العروض قليلة
/// العدد ونادرة التكرار مقارنة بموقع السائق اللحظي).
class NegotiationOffersScreen extends StatefulWidget {
  final String rideId;
  const NegotiationOffersScreen({super.key, required this.rideId});

  @override
  State<NegotiationOffersScreen> createState() => _NegotiationOffersScreenState();
}

class _NegotiationOffersScreenState extends State<NegotiationOffersScreen> {
  final RidesController _controller = RidesController();
  Timer? _pollTimer;
  List<RideOfferModel> _offers = [];
  bool _isLoading = true;
  String? _selectingOfferId;

  @override
  void initState() {
    super.initState();
    _loadOffers();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _loadOffers(silent: true));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadOffers({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);
    try {
      final token = context.read<AuthProvider>().token!;
      final offers = await _controller.fetchOffers(token, widget.rideId);
      if (mounted) setState(() { _offers = offers; _isLoading = false; });
    } catch (_) {
      if (mounted && !silent) setState(() => _isLoading = false);
    }
  }

  Future<void> _select(RideOfferModel offer) async {
    setState(() => _selectingOfferId = offer.id);
    try {
      final token = context.read<AuthProvider>().token!;
      await _controller.selectOffer(token, widget.rideId, offer.id);
      _pollTimer?.cancel();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LiveTrackingScreen(rideId: widget.rideId)));
    } catch (_) {
      if (mounted) {
        setState(() => _selectingOfferId = null);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر اختيار هذا العرض')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عروض السائقين — أودي ماكس'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : _offers.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('بانتظار عروض من السائقين القريبين...', textAlign: TextAlign.center, style: TextStyle(color: AppColors.darkTextSecondary)),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _offers.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final offer = _offers[index];
                    return GlassContainer(
                      child: Row(children: [
                        CircleAvatar(backgroundColor: AppColors.darkCardBackground, child: Icon(Icons.person_rounded, color: AppColors.primaryPurpleLight)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(offer.driverName, style: Theme.of(context).textTheme.titleSmall),
                              Text('${offer.vehicleType} · ⭐ ${offer.driverRating.toStringAsFixed(1)}', style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('${offer.offeredPrice.toStringAsFixed(2)}', style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 6),
                            SizedBox(
                              height: 32,
                              child: NeonButton(
                                label: 'اختيار',
                                isLoading: _selectingOfferId == offer.id,
                                onPressed: () => _select(offer),
                              ),
                            ),
                          ],
                        ),
                      ]),
                    );
                  },
                ),
    );
  }
}
