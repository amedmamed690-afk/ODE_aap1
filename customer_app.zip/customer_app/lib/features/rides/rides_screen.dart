import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'rides_controller.dart';
import 'location_picker_screen.dart';
import 'live_tracking_screen.dart';
import 'convoy_screen.dart';
import 'negotiation_offers_screen.dart';
import 'emergency_contacts_screen.dart';
import '../../core/config/remote_settings_provider.dart';
import '../../shared/widgets/service_unavailable_view.dart';

/// شاشة الرحلات — الآن بتبويبين واضحين (بند 2): ركاب / نقل ثقيل،
/// بدل قائمة واحدة تخلط بين "ODE عادي" و"ODE رافعة" وتشتت الراكب.
class RidesScreen extends StatefulWidget {
  const RidesScreen({super.key});

  @override
  State<RidesScreen> createState() => _RidesScreenState();
}

class _RidesScreenState extends State<RidesScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    // طلب صريح (بند 2/10): "أي خدمة أخرى موجودة حاليًا داخل ODE" — الرحلات
    // (نقل الركاب/النقل الثقيل) مشمولة بنفس النظام.
    if (!context.watch<RemoteSettingsProvider>().isEnabled('services.rides.enabled')) {
      return Scaffold(
        appBar: AppBar(title: const Text('التوصيل والركاب')),
        body: const ServiceUnavailableView(serviceName: 'خدمة الرحلات'),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('التوصيل والركاب'),
        actions: [
          IconButton(
            icon: const Icon(Icons.groups_rounded),
            tooltip: 'سافروا معًا',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ConvoyScreen())),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primaryPurpleLight,
          tabs: const [Tab(text: 'الركاب'), Tab(text: 'النقل الثقيل')],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          RideBookingTab(group: 'passenger'),
          RideBookingTab(group: 'heavy_transport'),
        ],
      ),
    );
  }
}

class RideBookingTab extends StatefulWidget {
  final String group;
  const RideBookingTab({super.key, required this.group});

  @override
  State<RideBookingTab> createState() => _RideBookingTabState();
}

class _RideBookingTabState extends State<RideBookingTab> {
  final RidesController _controller = RidesController();

  List<RideCategoryModel> _categories = [];
  String? _selectedCategoryId;
  String _routePreference = 'fastest'; // 'fastest' | 'scenic'
  bool _isFocusMode = false;
  String _pricingMode = 'fixed'; // 'fixed' | 'negotiated'

  Map<String, double>? _pickup;
  Map<String, double>? _dropoff;
  RideEstimate? _estimate;
  double? _negotiatedPrice;

  bool _isLoadingCategories = true;
  bool _isEstimating = false;
  bool _isRequesting = false;

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    try {
      final cats = await _controller.fetchCategories(widget.group);
      if (mounted) {
        setState(() {
          _categories = cats;
          _selectedCategoryId = cats.isNotEmpty ? cats.first.id : null;
          _isLoadingCategories = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoadingCategories = false);
    }
  }

  Future<void> _pickPickupPoint() async {
    final result = await Navigator.push<PickedLocation>(context, MaterialPageRoute(builder: (_) => const LocationPickerScreen(title: 'نقطة الانطلاق')));
    if (result == null) return;
    setState(() => _pickup = {'lat': result.lat, 'lng': result.lng});
    if (_dropoff != null) await _estimateFare();
  }

  Future<void> _pickDropoffPoint() async {
    final result = await Navigator.push<PickedLocation>(context, MaterialPageRoute(builder: (_) => const LocationPickerScreen(title: 'الوجهة')));
    if (result == null) return;
    setState(() => _dropoff = {'lat': result.lat, 'lng': result.lng});
    if (_pickup != null) await _estimateFare();
  }

  Future<void> _estimateFare() async {
    if (_pickup == null || _dropoff == null || _selectedCategoryId == null) return;
    final token = context.read<AuthProvider>().token;
    if (token == null) return; // بند 11 (Audit): لا نرسل توكن وهمي — الشاشة أصلاً محمية بمصادقة، هذا فقط حارس دفاعي
    setState(() => _isEstimating = true);
    try {
      final estimate = await _controller.estimateFare(token, _pickup!, _dropoff!, _selectedCategoryId!, _routePreference);
      if (mounted) setState(() { _estimate = estimate; _negotiatedPrice = estimate.estimatedFare; _isEstimating = false; });
    } catch (_) {
      if (mounted) setState(() => _isEstimating = false);
    }
  }

  Future<void> _requestFixedRide() async {
    if (_pickup == null || _dropoff == null || _selectedCategoryId == null) return;
    final token = context.read<AuthProvider>().token;
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انتهت الجلسة، الرجاء تسجيل الدخول من جديد')));
      return;
    }
    setState(() => _isRequesting = true);
    try {
      final rideId = await _controller.requestRide(
        // بند 10 (Audit): currencyId من AppConfig المركزي بدل رقم ثابت.
        token, pickup: _pickup!, dropoff: _dropoff!, currencyId: context.read<AppConfig>().currencyId, categoryId: _selectedCategoryId!,
        isFocusMode: _isFocusMode, routePreference: _routePreference, pricingMode: 'fixed',
      );
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => LiveTrackingScreen(rideId: rideId)));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر طلب الرحلة، حاول مرة أخرى')));
    } finally {
      if (mounted) setState(() => _isRequesting = false);
    }
  }

  /// بند 3: أودي ماكس — بدل ما نبحث عن أقرب سائق تلقائياً، نبعث السعر
  /// المقترح لكل السائقين القريبين وننتقل لشاشة عرض العروض.
  Future<void> _requestNegotiatedRide() async {
    if (_pickup == null || _dropoff == null || _selectedCategoryId == null || _negotiatedPrice == null) return;
    final token = context.read<AuthProvider>().token;
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انتهت الجلسة، الرجاء تسجيل الدخول من جديد')));
      return;
    }
    setState(() => _isRequesting = true);
    try {
      final rideId = await _controller.requestRide(
        token, pickup: _pickup!, dropoff: _dropoff!, currencyId: context.read<AppConfig>().currencyId, categoryId: _selectedCategoryId!,
        isFocusMode: _isFocusMode, routePreference: _routePreference, pricingMode: 'negotiated',
      );
      await _controller.proposeOffer(token, rideId, _negotiatedPrice!, _selectedCategoryId!);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => NegotiationOffersScreen(rideId: rideId)));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر بدء التفاوض، حاول مرة أخرى')));
    } finally {
      if (mounted) setState(() => _isRequesting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoadingCategories) return Center(child: CircularProgressIndicator(color: AppColors.primaryPurple));

    return Stack(
      children: [
        Container(
          color: AppColors.darkSurface,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.map_rounded, size: 60, color: AppColors.darkTextSecondary),
                const SizedBox(height: 12),
                Text(_pickup == null ? 'حدد نقطة الانطلاق' : 'تم تحديد نقطة الانطلاق ✓', style: const TextStyle(color: AppColors.darkTextSecondary)),
                TextButton(onPressed: _pickPickupPoint, child: const Text('اختيار من الخريطة')),
                const SizedBox(height: 8),
                Text(_dropoff == null ? 'حدد الوجهة' : 'تم تحديد الوجهة ✓', style: const TextStyle(color: AppColors.darkTextSecondary)),
                TextButton(onPressed: _pickDropoffPoint, child: const Text('اختيار من الخريطة')),
              ],
            ),
          ),
        ),
        Positioned(
          bottom: 0, left: 0, right: 0,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: GlassContainer(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // اختيار فئة المركبة داخل التبويب الحالي
                    if (_categories.isNotEmpty)
                      SizedBox(
                        height: 40,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: _categories.map((c) => Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: ChoiceChip(
                              label: Text(c.nameAr),
                              selected: _selectedCategoryId == c.id,
                              onSelected: (_) { setState(() => _selectedCategoryId = c.id); _estimateFare(); },
                              selectedColor: AppColors.primaryPurple,
                            ),
                          )).toList(),
                        ),
                      ),
                    const SizedBox(height: 10),

                    // بند 1: وضع الهدوء (Focus Mode)
                    SwitchListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: const Text('وضع الهدوء (Focus Mode)', style: TextStyle(fontSize: 12)),
                      subtitle: const Text('بدون حديث أو موسيقى، وأقل توقفات ممكنة', style: TextStyle(fontSize: 10, color: AppColors.darkTextSecondary)),
                      value: _isFocusMode,
                      activeColor: AppColors.primaryPurple,
                      onChanged: (v) => setState(() => _isFocusMode = v),
                    ),

                    // بند 1: اختيار نوع الطريق
                    Row(children: [
                      const Text('نوع الطريق: ', style: TextStyle(fontSize: 12)),
                      ChoiceChip(label: const Text('الأسرع'), selected: _routePreference == 'fastest',
                          onSelected: (_) { setState(() => _routePreference = 'fastest'); _estimateFare(); }, selectedColor: AppColors.primaryPurple),
                      const SizedBox(width: 6),
                      ChoiceChip(label: const Text('ممتع ومريح'), selected: _routePreference == 'scenic',
                          onSelected: (_) { setState(() => _routePreference = 'scenic'); _estimateFare(); }, selectedColor: AppColors.primaryPurple),
                    ]),
                    const SizedBox(height: 10),

                    if (_isEstimating)
                      Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
                    else if (_estimate != null) ...[
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        const Text('المسافة المقدّرة'), Text('${_estimate!.distanceKm} كم'),
                      ]),
                      const SizedBox(height: 4),

                      // بند 3: أودي ماكس — تبديل بين السعر الثابت والتفاوض
                      Row(children: [
                        const Text('طريقة السعر: ', style: TextStyle(fontSize: 12)),
                        ChoiceChip(label: const Text('عادي'), selected: _pricingMode == 'fixed',
                            onSelected: (_) => setState(() => _pricingMode = 'fixed'), selectedColor: AppColors.primaryPurple),
                        const SizedBox(width: 6),
                        ChoiceChip(label: const Text('أودي ماكس (تفاوض)'), selected: _pricingMode == 'negotiated',
                            onSelected: (_) => setState(() => _pricingMode = 'negotiated'), selectedColor: AppColors.primaryPurple),
                      ]),

                      if (_pricingMode == 'fixed') ...[
                        const SizedBox(height: 4),
                        Text('${_estimate!.estimatedFare.toStringAsFixed(2)} — سعر ثابت', style: Theme.of(context).textTheme.titleMedium),
                      ] else ...[
                        const SizedBox(height: 8),
                        Row(children: [
                          const Text('سعرك المقترح:', style: TextStyle(fontSize: 12)),
                          Expanded(
                            child: Slider(
                              value: _negotiatedPrice ?? _estimate!.estimatedFare,
                              min: _estimate!.estimatedFare * 0.6,
                              max: _estimate!.estimatedFare * 1.5,
                              activeColor: AppColors.primaryPurple,
                              label: _negotiatedPrice?.toStringAsFixed(2),
                              onChanged: (v) => setState(() => _negotiatedPrice = v),
                            ),
                          ),
                          Text(_negotiatedPrice?.toStringAsFixed(0) ?? ''),
                        ]),
                      ],
                      const SizedBox(height: 12),
                    ],

                    NeonButton(
                      label: _pricingMode == 'negotiated' ? 'أرسل عرضك للسائقين' : 'اطلب رحلة الآن',
                      icon: Icons.local_taxi_rounded,
                      isLoading: _isRequesting,
                      onPressed: _pickup == null ? () {} : (_pricingMode == 'negotiated' ? _requestNegotiatedRide : _requestFixedRide),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        // اختصار سريع لإدارة جهات اتصال الطوارئ (بند 4)
        Positioned(
          top: 12, left: 12,
          child: IconButton(
            icon: Icon(Icons.emergency_share_rounded, color: AppColors.primaryPurpleLight),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EmergencyContactsScreen())),
            tooltip: 'جهات اتصال الطوارئ',
          ),
        ),
      ],
    );
  }
}
