import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/maps_service.dart';

class PickedLocation {
  final double lat;
  final double lng;
  final String address;
  PickedLocation({required this.lat, required this.lng, required this.address});
}

/// يستبدل _pickPointsDemo القديم بخريطة حقيقية: دبّوس ثابت بالنص +
/// خريطة تتحرك تحته، مع بحث Autocomplete حقيقي عبر الباك إند (بند 14).
class LocationPickerScreen extends StatefulWidget {
  final String title;
  const LocationPickerScreen({super.key, required this.title});

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  final MapsService _mapsService = MapsService();
  final TextEditingController _searchController = TextEditingController();
  GoogleMapController? _mapController;
  LatLng _center = const LatLng(32.8872, 13.1913); // مركز افتراضي، يُستبدل بموقع المستخدم الفعلي فور توفره
  String? _address;
  List<PlacePrediction> _predictions = [];
  bool _isResolvingAddress = false;

  @override
  void initState() {
    super.initState();
    _useCurrentLocation();
  }

  Future<void> _useCurrentLocation() async {
    try {
      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        final requested = await Geolocator.requestPermission();
        if (requested == LocationPermission.denied) return;
      }
      final position = await Geolocator.getCurrentPosition();
      final target = LatLng(position.latitude, position.longitude);
      setState(() => _center = target);
      _mapController?.animateCamera(CameraUpdate.newLatLng(target));
      _resolveAddress(target);
    } catch (_) {
      // الموقع مرفوض أو غير متاح — يبقى المركز الافتراضي، والمستخدم
      // يقدر يحرك الخريطة يدويًا.
    }
  }

  Future<void> _resolveAddress(LatLng point) async {
    setState(() => _isResolvingAddress = true);
    final token = context.read<AuthProvider>().token!;
    final address = await _mapsService.reverseGeocode(token, point.lat, point.lng);
    if (mounted) setState(() { _address = address; _isResolvingAddress = false; });
  }

  Future<void> _search(String query) async {
    final token = context.read<AuthProvider>().token!;
    final results = await _mapsService.autocomplete(token, query);
    if (mounted) setState(() => _predictions = results);
  }

  Future<void> _selectPrediction(PlacePrediction prediction) async {
    final token = context.read<AuthProvider>().token!;
    final location = await _mapsService.placeDetails(token, prediction.placeId);
    if (location == null) return;
    final target = LatLng(location.lat, location.lng);
    setState(() { _center = target; _address = location.address; _predictions = []; _searchController.clear(); });
    _mapController?.animateCamera(CameraUpdate.newLatLng(target));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _center, zoom: 15),
            onMapCreated: (controller) => _mapController = controller,
            onCameraMove: (position) => _center = position.target,
            onCameraIdle: () => _resolveAddress(_center),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
          ),
          const IgnorePointer(
            child: Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 40),
                child: Icon(Icons.location_pin, size: 44, color: AppColors.primaryPurple),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(children: [
                    IconButton(
                      style: IconButton.styleFrom(backgroundColor: AppColors.darkCardBackground),
                      icon: const Icon(Icons.arrow_back_rounded),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GlassContainer(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: TextField(
                          controller: _searchController,
                          onChanged: _search,
                          decoration: InputDecoration(hintText: widget.title, border: InputBorder.none, prefixIcon: const Icon(Icons.search_rounded)),
                        ),
                      ),
                    ),
                  ]),
                  if (_predictions.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: GlassContainer(
                        child: Column(
                          children: _predictions.map((p) => ListTile(
                            leading: const Icon(Icons.location_on_outlined),
                            title: Text(p.description, maxLines: 1, overflow: TextOverflow.ellipsis),
                            onTap: () => _selectPrediction(p),
                          )).toList(),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: GlassContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(_isResolvingAddress ? 'جارِ تحديد العنوان...' : (_address ?? 'حرّك الخريطة لتحديد الموقع'),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    NeonButton(
                      label: 'تأكيد الموقع',
                      onPressed: _address == null ? () {} : () => Navigator.pop(context, PickedLocation(lat: _center.latitude, lng: _center.longitude, address: _address!)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
