import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'rides_controller.dart';

/// تجميع رحلات نشطة متعددة معًا (عائلة/أصدقاء) مع تنبيه لو انحرف أحد
/// السائقين عن باقي القافلة.
class ConvoyScreen extends StatefulWidget {
  const ConvoyScreen({super.key});

  @override
  State<ConvoyScreen> createState() => _ConvoyScreenState();
}

class _ConvoyScreenState extends State<ConvoyScreen> {
  final RidesController _controller = RidesController();
  List<Map<String, dynamic>> _rides = [];
  final Set<String> _selectedIds = {};
  bool _isLoading = true;
  bool _isCreating = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthProvider>().token!;
    final rides = await _controller.fetchMyActiveRides(token);
    if (mounted) setState(() { _rides = rides; _isLoading = false; });
  }

  Future<void> _createConvoy() async {
    if (_selectedIds.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اختر رحلتين على الأقل لتجميعهما')));
      return;
    }
    setState(() => _isCreating = true);
    try {
      final token = context.read<AuthProvider>().token!;
      await _controller.createConvoy(token, _selectedIds.toList());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تجميع الرحلات — سنراقب المسار ونرسل تنبيه عند أي انحراف')));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => _isCreating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('سافروا معًا'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : _rides.length < 2
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('تحتاج رحلتين نشطتين على الأقل عشان تجمعهم — اطلب رحلة أولاً',
                        textAlign: TextAlign.center, style: TextStyle(color: AppColors.darkTextSecondary)),
                  ),
                )
              : Column(
                  children: [
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _rides.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final ride = _rides[index];
                          final isSelected = _selectedIds.contains(ride['id']);
                          return GestureDetector(
                            onTap: () => setState(() => isSelected ? _selectedIds.remove(ride['id']) : _selectedIds.add(ride['id'])),
                            child: GlassContainer(
                              child: Row(children: [
                                Icon(isSelected ? Icons.check_circle_rounded : Icons.circle_outlined, color: AppColors.primaryPurpleLight),
                                const SizedBox(width: 12),
                                Expanded(child: Text('رحلة #${ride['id'].toString().substring(0, 8)} — ${ride['status']}')),
                                Text('${ride['estimated_fare'] ?? ''}'),
                              ]),
                            ),
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: NeonButton(label: 'تجميع الرحلات المختارة', isLoading: _isCreating, onPressed: _createConvoy),
                    ),
                  ],
                ),
    );
  }
}
