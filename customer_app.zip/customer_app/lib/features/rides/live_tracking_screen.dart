import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../shared/services/socket_service.dart';
import 'rides_controller.dart';
import 'package:ode_customer_app/core/config/env.dart';

/// تتبع لحظي حقيقي — الدبّوس يتحرك فعليًا مع حدث `ride:driver_location`
/// اللي يبثّه السائق كل بضع ثوانٍ (بند 5).
class LiveTrackingScreen extends StatefulWidget {
  final String rideId;
  const LiveTrackingScreen({super.key, required this.rideId});

  @override
  State<LiveTrackingScreen> createState() => _LiveTrackingScreenState();
}

class _LiveTrackingScreenState extends State<LiveTrackingScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  final RidesController _controller = RidesController();
  GoogleMapController? _mapController;
  LatLng? _driverPosition;
  String _status = 'requested';
  bool _isLoading = true;

  static const _statusLabels = {
    'requested': 'بانتظار قبول سائق', 'driver_assigned': 'السائق في الطريق إليك',
    'driver_arrived': 'السائق وصل', 'in_progress': 'الرحلة جارية', 'completed': 'اكتملت الرحلة', 'cancelled': 'أُلغيت الرحلة',
  };

  @override
  void initState() {
    super.initState();
    _loadRide();
    _listenForUpdates();
  }

  Future<void> _loadRide() async {
    final token = context.read<AuthProvider>().token!;
    final response = await http.get(Uri.parse('$baseUrl/rides/${widget.rideId}'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode == 200 && mounted) {
      final data = jsonDecode(response.body);
      setState(() {
        _status = data['status'];
        if (data['driver_lat'] != null) _driverPosition = LatLng((data['driver_lat'] as num).toDouble(), (data['driver_lng'] as num).toDouble());
        _isLoading = false;
      });
    } else if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  void _listenForUpdates() {
    final token = context.read<AuthProvider>().token!;
    final socket = SocketService.connect(token);
    socket.on('ride:driver_location', (data) {
      if (!mounted) return;
      final target = LatLng((data['lat'] as num).toDouble(), (data['lng'] as num).toDouble());
      setState(() => _driverPosition = target);
      _mapController?.animateCamera(CameraUpdate.newLatLng(target));
    });
    for (final event in ['ride:driver_assigned', 'ride:driver_arrived', 'ride:started', 'ride:completed', 'ride:cancelled']) {
      socket.on(event, (_) { if (mounted) _loadRide(); });
    }
  }

  @override
  void dispose() {
    SocketService.disconnect();
    super.dispose();
  }

  Future<void> _share() async {
    final token = context.read<AuthProvider>().token!;
    final link = await _controller.generateShareLink(token, widget.rideId);
    Share.share('تابع رحلتي مباشرة: $link');
  }

  Future<void> _cancel() async {
    final token = context.read<AuthProvider>().token!;
    await http.post(Uri.parse('$baseUrl/rides/${widget.rideId}/cancel'), headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'});
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primaryPurple)));

    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _driverPosition ?? const LatLng(32.8872, 13.1913), zoom: 15),
            onMapCreated: (c) => _mapController = c,
            markers: _driverPosition == null ? {} : {
              Marker(markerId: const MarkerId('driver'), position: _driverPosition!, icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueViolet)),
            },
            myLocationEnabled: true,
            zoomControlsEnabled: false,
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                IconButton(style: IconButton.styleFrom(backgroundColor: AppColors.darkCardBackground), icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.pop(context)),
                const Spacer(),
                IconButton(style: IconButton.styleFrom(backgroundColor: AppColors.darkCardBackground), icon: const Icon(Icons.share_rounded), onPressed: _share),
              ]),
            ),
          ),
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: GlassContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(_statusLabels[_status] ?? _status, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    if (!['completed', 'cancelled'].contains(_status))
                      OutlinedButton(onPressed: _cancel, child: const Text('إلغاء الرحلة', style: TextStyle(color: AppColors.error))),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
