import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../core/theme/app_colors.dart';

/// يفتح صفحة الدفع المستضافة عند مزود الدفع (Stripe Checkout أو وضع
/// Dev بدون مفاتيح حقيقية) ويكتشف رابط النجاح `ode://payment-success`
/// اللي يرسله /payments/wallet-topup/initiate كـ success_url.
class PaymentWebviewScreen extends StatefulWidget {
  final String checkoutUrl;
  const PaymentWebviewScreen({super.key, required this.checkoutUrl});

  @override
  State<PaymentWebviewScreen> createState() => _PaymentWebviewScreenState();
}

class _PaymentWebviewScreenState extends State<PaymentWebviewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => setState(() => _isLoading = true),
        onPageFinished: (_) => setState(() => _isLoading = false),
        onNavigationRequest: (request) {
          if (request.url.startsWith('ode://payment-success')) {
            Navigator.pop(context, true);
            return NavigationDecision.prevent;
          }
          if (request.url.startsWith('ode://payment-cancelled')) {
            Navigator.pop(context, false);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(widget.checkoutUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إتمام الدفع'), backgroundColor: Colors.transparent),
      body: Stack(children: [
        WebViewWidget(controller: _controller),
        if (_isLoading) Center(child: CircularProgressIndicator(color: AppColors.primaryPurple)),
      ]),
    );
  }
}
