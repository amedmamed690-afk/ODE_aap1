import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'ode_pay_controller.dart';
import 'payment_webview_screen.dart';

/// بند 9/11: محفظة العميل — رصيد + سجل حركات + شحن بكود (بند 12).
class OdePayScreen extends StatefulWidget {
  const OdePayScreen({super.key});

  @override
  State<OdePayScreen> createState() => _OdePayScreenState();
}

class _OdePayScreenState extends State<OdePayScreen> {
  final OdePayController _controller = OdePayController();
  double _balance = 0;
  List<WalletTxnModel> _transactions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthProvider>().token!;
    try {
      final results = await Future.wait([
        _controller.fetchBalance(token),
        _controller.fetchTransactions(token),
      ]);
      if (mounted) {
        setState(() {
          _balance = results[0] as double;
          _transactions = results[1] as List<WalletTxnModel>;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _showRedeemDialog() async {
    final codeController = TextEditingController();
    String? error;
    bool isSubmitting = false;

    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.darkCardBackground,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 20, right: 20, top: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('شحن الرصيد بكود', style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 16),
              TextField(
                controller: codeController,
                style: const TextStyle(color: AppColors.darkTextPrimary, letterSpacing: 2),
                textAlign: TextAlign.center,
                decoration: const InputDecoration(hintText: 'أدخل الكود', border: OutlineInputBorder()),
              ),
              if (error != null) ...[
                const SizedBox(height: 8),
                Text(error!, style: const TextStyle(color: AppColors.error)),
              ],
              const SizedBox(height: 16),
              NeonButton(
                label: 'شحن',
                isLoading: isSubmitting,
                onPressed: () async {
                  setSheetState(() { isSubmitting = true; error = null; });
                  try {
                    final token = context.read<AuthProvider>().token!;
                    final newBalance = await _controller.redeemCode(token, codeController.text.trim());
                    if (mounted) {
                      Navigator.pop(ctx);
                      setState(() => _balance = newBalance);
                      _load();
                    }
                  } catch (e) {
                    setSheetState(() { error = e.toString().replaceFirst('Exception: ', ''); isSubmitting = false; });
                  }
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _topUpWithCard() async {
    final amountController = TextEditingController();
    final amount = await showModalBottomSheet<double>(
      context: context,
      backgroundColor: AppColors.darkCardBackground,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 20, right: 20, top: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('المبلغ المراد شحنه', style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 16),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: AppColors.darkTextPrimary),
              decoration: const InputDecoration(hintText: 'مثال: 50', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            NeonButton(label: 'متابعة للدفع', onPressed: () {
              final value = double.tryParse(amountController.text.trim());
              if (value != null && value > 0) Navigator.pop(ctx, value);
            }),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
    if (amount == null || !mounted) return;

    try {
      final token = context.read<AuthProvider>().token!;
      // بند 10 (Audit): من AppConfig المركزي بدل رقم عملة ثابت.
      final checkoutUrl = await _controller.initiateCardTopUp(token, amount, context.read<AppConfig>().currencyId);
      if (!mounted) return;
      final success = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => PaymentWebviewScreen(checkoutUrl: checkoutUrl)));
      if (success == true) _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('ODE PAY'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  GlassContainer(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        const Text('رصيدك الحالي', style: TextStyle(color: AppColors.darkTextSecondary)),
                        const SizedBox(height: 8),
                        Text('${_balance.toStringAsFixed(2)}', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: AppColors.primaryPurpleLight)),
                        const SizedBox(height: 16),
                        NeonButton(label: 'شحن الرصيد بكود', onPressed: _showRedeemDialog),
                        const SizedBox(height: 10),
                        OutlinedButton(onPressed: _topUpWithCard, child: const Text('شحن ببطاقة')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('لا يمكن تحويل الرصيد لمستخدم آخر ولا سحبه نقدًا — يُستخدم داخل ODE فقط.',
                        style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                  ),
                  const SizedBox(height: 8),
                  Text('سجل الحركات', style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 8),
                  if (_transactions.isEmpty)
                    const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد حركات بعد', style: TextStyle(color: AppColors.darkTextSecondary)))
                  else
                    ..._transactions.map((txn) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: GlassContainer(
                            child: Row(children: [
                              Icon(txn.amount >= 0 ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded,
                                  color: txn.amount >= 0 ? AppColors.success : AppColors.error),
                              const SizedBox(width: 10),
                              Expanded(child: Text(_typeLabel(txn.type))),
                              Text('${txn.amount >= 0 ? '+' : ''}${txn.amount.toStringAsFixed(2)}',
                                  style: TextStyle(color: txn.amount >= 0 ? AppColors.success : AppColors.error, fontWeight: FontWeight.bold)),
                            ]),
                          ),
                        )),
                ],
              ),
            ),
    );
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'topup_code': return 'شحن بكود';
      case 'order_payment': return 'دفع طلب';
      case 'refund': return 'استرجاع';
      case 'points_redeem': return 'استبدال نقاط';
      default: return type;
    }
  }
}
