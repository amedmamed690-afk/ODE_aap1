import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class WalletTxnModel {
  final String type;
  final double amount;
  final DateTime createdAt;
  WalletTxnModel({required this.type, required this.amount, required this.createdAt});

  factory WalletTxnModel.fromJson(Map<String, dynamic> j) => WalletTxnModel(
        type: j['type'],
        amount: (j['amount'] as num).toDouble(),
        createdAt: DateTime.parse(j['createdAt']),
      );
}

/// بند 9/11/12: محفظة العميل — استخدام داخل ODE فقط، لا تحويل ولا سحب.
class OdePayController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<double> fetchBalance(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/wallet/me'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل الرصيد');
    return (jsonDecode(response.body)['balance'] as num).toDouble();
  }

  Future<List<WalletTxnModel>> fetchTransactions(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/wallet/transactions'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل سجل الحركات');
    return (jsonDecode(response.body) as List).map((e) => WalletTxnModel.fromJson(e)).toList();
  }

  Future<double> redeemCode(String token, String code) async {
    final response = await http.post(
      Uri.parse('$baseUrl/wallet/redeem-code'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode({'code': code}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(_arabicError(data['error']));
    }
    return (data['newBalance'] as num).toDouble();
  }

  /// بند 11/30/35: شحن ببطاقة عبر بوابة دفع خارجية قابلة للاستبدال —
  /// يرجّع رابط صفحة دفع (Stripe Checkout أو ما يعادلها) يُفتح بـWebView.
  Future<String> initiateCardTopUp(String token, double amount, int currencyId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/payments/wallet-topup/initiate'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode({'amount': amount, 'currencyId': currencyId}),
    );
    if (response.statusCode != 200) throw Exception('تعذر بدء عملية الدفع');
    return jsonDecode(response.body)['checkoutUrl'];
  }

  String _arabicError(String? code) {
    switch (code) {
      case 'code_not_found': return 'الكود غير صحيح';
      case 'code_used': return 'هذا الكود مستخدم من قبل';
      case 'code_cancelled': return 'هذا الكود ملغى';
      case 'code_expired': return 'انتهت صلاحية هذا الكود';
      default: return 'تعذر شحن الرصيد';
    }
  }
}
