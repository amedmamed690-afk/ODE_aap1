import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class ActivityCategoryModel {
  final String id;
  final String nameAr;
  ActivityCategoryModel({required this.id, required this.nameAr});
  factory ActivityCategoryModel.fromJson(Map<String, dynamic> j) => ActivityCategoryModel(id: j['id'], nameAr: j['name_ar']);
}

class DigitalPartnerModel {
  final String id;
  final String nameAr;
  final String? logoUrl;
  final double ratingAvg;
  DigitalPartnerModel({required this.id, required this.nameAr, this.logoUrl, required this.ratingAvg});
  factory DigitalPartnerModel.fromJson(Map<String, dynamic> j) => DigitalPartnerModel(
        id: j['id'], nameAr: j['name_ar'], logoUrl: j['logo_url'],
        ratingAvg: double.tryParse(j['rating_avg']?.toString() ?? '0') ?? 0,
      );
}

/// يخدم شاشتي "مطاعم إلكترونية" و"متاجر إلكترونية" معاً — الفرق بينهم
/// فقط businessType (restaurant | store)، والفلترة النهائية دايماً
/// accountType=digital ثابتة، لأن الهدف تحديداً عزل الحسابات الإلكترونية
/// عن أصحاب المحلات الفعلية.
class DigitalPartnersController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<ActivityCategoryModel>> fetchCategories() async {
    final response = await http.get(Uri.parse('$baseUrl/partner-onboarding/options'));
    if (response.statusCode != 200) throw Exception('failed_to_load_categories');
    final data = jsonDecode(response.body);
    return (data['activityCategories'] as List).map((e) => ActivityCategoryModel.fromJson(e)).toList();
  }

  Future<List<DigitalPartnerModel>> fetchPartners({
    required String businessType, String? categoryId, String? search, required int countryId,
  }) async {
    final params = <String, String>{
      'type': businessType, 'accountType': 'digital', 'countryId': '$countryId',
      if (categoryId != null) 'categoryId': categoryId,
      if (search != null && search.isNotEmpty) 'search': search,
    };
    final uri = Uri.parse('$baseUrl/partners').replace(queryParameters: params);
    final response = await http.get(uri);
    if (response.statusCode != 200) throw Exception('failed_to_load_partners');
    return (jsonDecode(response.body) as List).map((e) => DigitalPartnerModel.fromJson(e)).toList();
  }
}
