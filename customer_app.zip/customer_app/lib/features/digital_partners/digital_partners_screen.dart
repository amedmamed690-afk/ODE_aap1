import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/glass_container.dart';
import '../../shared/widgets/search_bar_field.dart';
import '../../shared/widgets/top_ad_banner.dart';
import 'digital_partners_controller.dart';
import '../ode_brand/store_details_screen.dart';

/// تُفتح بنفس الشاشة لكل من "مطاعم إلكترونية" و"متاجر إلكترونية"
/// (بند 7) — الفرق فقط businessType، والفلترة الثابتة accountType=digital
/// موجودة أصلاً داخل DigitalPartnersController.
class DigitalPartnersScreen extends StatefulWidget {
  final String businessType; // 'restaurant' | 'store'
  final String title;
  final String pageKey;
  const DigitalPartnersScreen({super.key, required this.businessType, required this.title, required this.pageKey});

  @override
  State<DigitalPartnersScreen> createState() => _DigitalPartnersScreenState();
}

class _DigitalPartnersScreenState extends State<DigitalPartnersScreen> {
  final DigitalPartnersController _controller = DigitalPartnersController();
  List<ActivityCategoryModel> _categories = [];
  List<DigitalPartnerModel> _partners = [];
  String? _selectedCategoryId;
  String? _searchQuery;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCategories();
    _loadPartners();
  }

  Future<void> _loadCategories() async {
    try {
      final cats = await _controller.fetchCategories();
      if (mounted) setState(() => _categories = cats);
    } catch (_) {}
  }

  Future<void> _loadPartners() async {
    setState(() => _isLoading = true);
    try {
      final partners = await _controller.fetchPartners(
        businessType: widget.businessType, categoryId: _selectedCategoryId, search: _searchQuery,
        countryId: context.read<AppConfig>().countryId, // بند 9 (Audit)
      );
      if (mounted) setState(() { _partners = partners; _isLoading = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: Text(widget.title), backgroundColor: Colors.transparent),
      body: Column(
        children: [
          TopAdBanner(pageKey: widget.pageKey, countryId: context.watch<AppConfig>().countryId), // بند 9
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SearchBarField(
              hintText: 'ابحث...',
              onChanged: (q) { _searchQuery = q.isEmpty ? null : q; _loadPartners(); },
            ),
          ),
          const SizedBox(height: 8),
          if (_categories.isNotEmpty)
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: _categories.map((cat) => Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: ChoiceChip(
                    label: Text(cat.nameAr),
                    selected: _selectedCategoryId == cat.id,
                    onSelected: (_) { setState(() => _selectedCategoryId = _selectedCategoryId == cat.id ? null : cat.id); _loadPartners(); },
                    selectedColor: AppColors.primaryPurple,
                  ),
                )).toList(),
              ),
            ),
          const SizedBox(height: 8),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
                : _partners.isEmpty
                    ? Center(
                        child: GlassContainer(
                          padding: const EdgeInsets.all(24),
                          child: const Text('لا توجد نتائج حالياً'),
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _partners.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final partner = _partners[index];
                          return GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StoreDetailsScreen(partnerId: partner.id, partnerNameAr: partner.nameAr))),
                            child: GlassContainer(
                              child: Row(children: [
                                CircleAvatar(
                                  radius: 26,
                                  backgroundColor: AppColors.darkCardBackground,
                                  backgroundImage: partner.logoUrl != null ? NetworkImage(partner.logoUrl!) : null,
                                  child: partner.logoUrl == null ? Icon(Icons.storefront_rounded, color: AppColors.primaryPurpleLight) : null,
                                ),
                                const SizedBox(width: 12),
                                Expanded(child: Text(partner.nameAr, style: Theme.of(context).textTheme.titleSmall)),
                                Row(children: [
                                  const Icon(Icons.star_rounded, color: Colors.amber, size: 16),
                                  const SizedBox(width: 4),
                                  Text(partner.ratingAvg.toStringAsFixed(1)),
                                ]),
                              ]),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
