import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class ShortsController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<void> registerView(String shortId) async {
    // Fire-and-forget حقيقي — لا نعطّل التمرير بانتظار الرد
    try {
      await http.post(Uri.parse('$baseUrl/marketing/shorts/$shortId/view'));
    } catch (_) {}
  }

  Future<void> toggleLike(String token, String shortId) async {
    await http.post(
      Uri.parse('$baseUrl/marketing/shorts/$shortId/like'),
      headers: {'Authorization': 'Bearer $token'},
    );
  }
}
