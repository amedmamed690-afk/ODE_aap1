import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../home/models/short_model.dart';
import '../ode_brand/store_details_screen.dart';
import '../product_details/product_details_screen.dart';
import '../home/models/product_model.dart';
import 'shorts_controller.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

/// فيد عمودي حقيقي (Swipe Up/Down) بنفس منطق التطبيقات المعروفة —
/// كل فيديو له VideoPlayerController مستقل، ويُشغَّل فقط عندما يكون
/// هو الصفحة الحالية بالـ PageView (auto-play/pause حقيقي، مش وهمي).
class ShortsFeedScreen extends StatefulWidget {
  final List<ShortModel> shorts;
  final int initialIndex;

  const ShortsFeedScreen({super.key, required this.shorts, this.initialIndex = 0});

  @override
  State<ShortsFeedScreen> createState() => _ShortsFeedScreenState();
}

class _ShortsFeedScreenState extends State<ShortsFeedScreen> {
  final ShortsController _controller = ShortsController();
  late final PageController _pageController;
  final Map<int, VideoPlayerController> _videoControllers = {};
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
    _initVideoAt(_currentIndex);
    _controller.registerView(widget.shorts[_currentIndex].id);
  }

  Future<void> _initVideoAt(int index) async {
    if (_videoControllers.containsKey(index)) return;
    final controller = VideoPlayerController.networkUrl(Uri.parse(widget.shorts[index].videoUrl));
    _videoControllers[index] = controller;
    await controller.initialize();
    controller.setLooping(true);
    if (index == _currentIndex && mounted) {
      controller.play();
      setState(() {});
    }
  }

  /// auto-play/pause حقيقي: عند تغيّر الصفحة المرئية، نوقف الفيديو
  /// السابق فوراً ونشغّل الحالي — ونحمّل الفيديو التالي مسبقاً (Prefetch)
  /// عشان ما يكون فيه تأخير عند التمرير.
  void _onPageChanged(int index) {
    _videoControllers[_currentIndex]?.pause();
    setState(() => _currentIndex = index);
    _initVideoAt(index).then((_) => _videoControllers[index]?.play());
    _controller.registerView(widget.shorts[index].id);

    // Prefetch الفيديو التالي مسبقاً
    if (index + 1 < widget.shorts.length) _initVideoAt(index + 1);
  }

  @override
  void dispose() {
    for (final c in _videoControllers.values) {
      c.dispose();
    }
    _pageController.dispose();
    super.dispose();
  }

  void _onLike(int index) {
    final token = context.read<AuthProvider>().token;
    if (token != null) _controller.toggleLike(token, widget.shorts[index].id);
  }

  // بند 13 (Audit): مشاركة حقيقية عبر share_plus — لا يوجد رابط ويب عام
  // لعرض Short معيّن (بخلاف الرحلات اللي عندها public-tracking جاهز)، فمن
  // غير الصحيح اختلاق رابط لصفحة غير موجودة أصلاً. نشارك المحتوى النصي
  // الحقيقي (الكابشن) — وهذا لا يكسر الشاشة حتى لو لم يتوفر أي تطبيق
  // للمشاركة على الجهاز (share_plus نفسه يتعامل مع هذه الحالة داخليًا).
  Future<void> _onShare(ShortModel short) async {
    final text = short.captionAr?.isNotEmpty == true
        ? 'شاهد هذا الفيديو على ODE: ${short.captionAr}'
        : 'شاهد هذا الفيديو على تطبيق ODE!';
    await Share.share(text);
  }

  // بند 14 (Audit): التنقل الفعلي حسب البيانات الحقيقية القادمة من
  // الباك إند (sponsoredProductId/sponsoredPartnerId) — بدون اختلاق أي id.
  // لا يوجد endpoint لجلب منتج واحد بمعرّفه مباشرة لجدول partners products
  // المشترك (بخلاف ode_brand اللي له GET /products/:id منفصل)، فنعيد
  // استخدام GET /partners/:id/products الموجود فعليًا (بدل إنشاء endpoint
  // مكرر) ونفلتر بالمعرّف — الشريك نفسه دائمًا معروف من sponsoredPartnerId.
  Future<void> _onSponsoredTap(ShortModel short) async {
    if (short.sponsoredPartnerId == null) return;
    if (short.sponsoredProductId == null) {
      // إعلان لمتجر/مطعم كامل بدون منتج محدد — نفتح صفحة المتجر مباشرة
      Navigator.push(context, MaterialPageRoute(builder: (_) => StoreDetailsScreen(
        partnerId: short.sponsoredPartnerId!, partnerNameAr: 'المتجر',
      )));
      return;
    }
    showDialog(context: context, barrierDismissible: false, builder: (_) => Center(child: CircularProgressIndicator(color: AppColors.primaryPurple)));
    http.Response? response;
    try {
      response = await http.get(Uri.parse('${Env.apiBaseUrl}/partners/${short.sponsoredPartnerId}/products'));
    } catch (_) {
      // فشل شبكة فقط — نغلق مؤشر التحميل مرة واحدة بالضبط ونتوقف هنا
      if (mounted) Navigator.pop(context);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح المنتج، تحقق من الاتصال')));
      return;
    }
    if (!mounted) return;
    Navigator.pop(context); // إغلاق مؤشر التحميل — مرة واحدة فقط، بعد اكتمال الطلب (نجح أو فشل من طرف السيرفر)
    if (response.statusCode != 200) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح المنتج، حاول مرة أخرى')));
      return;
    }
    try {
      final products = (jsonDecode(response.body) as List);
      final match = products.firstWhere((p) => p['id'] == short.sponsoredProductId, orElse: () => null);
      if (match == null) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هذا المنتج لم يعد متاحًا')));
        return;
      }
      Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailsScreen(
        product: ProductModel.fromJson(match, sourceType: 'partner'),
      )));
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح المنتج، حاول مرة أخرى')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: PageView.builder(
        controller: _pageController,
        scrollDirection: Axis.vertical,
        itemCount: widget.shorts.length,
        onPageChanged: _onPageChanged,
        itemBuilder: (context, index) => _ShortVideoPage(
          short: widget.shorts[index],
          controller: _videoControllers[index],
          onLike: () => _onLike(index),
          onShare: () => _onShare(widget.shorts[index]),
          onSponsoredTap: () => _onSponsoredTap(widget.shorts[index]),
        ),
      ),
    );
  }
}

class _ShortVideoPage extends StatelessWidget {
  final ShortModel short;
  final VideoPlayerController? controller;
  final VoidCallback onLike;
  final VoidCallback onShare;
  final VoidCallback onSponsoredTap;

  const _ShortVideoPage({
    required this.short, required this.controller, required this.onLike,
    required this.onShare, required this.onSponsoredTap,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // الفيديو نفسه — لو لسه بيتحمّل نعرض الصورة المصغّرة بدل شاشة سوداء
        (controller != null && controller!.value.isInitialized)
            ? FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(width: controller!.value.size.width, height: controller!.value.size.height, child: VideoPlayer(controller!)),
              )
            : short.thumbnailUrl != null
                ? Image.network(short.thumbnailUrl!, fit: BoxFit.cover)
                : Container(color: AppColors.darkBackground),

        // تعتيم خفيف أسفل الشاشة لوضوح النصوص فوق الفيديو
        Positioned(
          bottom: 0, left: 0, right: 0,
          child: Container(
            height: 220,
            decoration: const BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87]),
            ),
          ),
        ),

        // أزرار التفاعل (Like/Share) — يمين الشاشة
        Positioned(
          bottom: 140, right: 16,
          child: Column(
            children: [
              _ActionButton(icon: Icons.favorite_rounded, label: '${short.likeCount}', onTap: onLike),
              const SizedBox(height: 20),
              _ActionButton(icon: Icons.share_rounded, label: 'مشاركة', onTap: onShare),
            ],
          ),
        ),

        // الكابشن أسفل يسار الشاشة
        if (short.captionAr != null)
          Positioned(
            bottom: 100, left: 16, right: 80,
            child: Text(short.captionAr!, style: const TextStyle(color: Colors.white, fontSize: 14), maxLines: 2, overflow: TextOverflow.ellipsis),
          ),

        // بطاقة المنتج/الخدمة الممولة — زجاجية شفافة، تنتقل مباشرة للشراء/الحجز
        if (short.isSponsored)
          Positioned(
            bottom: 16, left: 16, right: 16,
            child: GestureDetector(
              onTap: onSponsoredTap,
              child: GlassContainer(
                borderRadius: 14,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(
                  children: [
                    Icon(Icons.shopping_bag_rounded, color: AppColors.primaryPurpleLight, size: 20),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('اطلب المنتج المعروض الآن', style: TextStyle(color: Colors.white, fontSize: 13))),
                    const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white, size: 12),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ActionButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(0.3),
              boxShadow: [BoxShadow(color: AppColors.neonGlow.withOpacity(0.3), blurRadius: 10)],
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 11)),
        ],
      ),
    );
  }
}
