import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/glass_container.dart';
import '../../shared/widgets/search_bar_field.dart';
import '../../shared/widgets/top_ad_banner.dart';
import '../ode_brand/store_details_screen.dart'; // نفس شاشة تفاصيل المتجر تُستخدم لعرض قائمة الطعام
import '../../core/config/remote_settings_provider.dart';
import '../../shared/widgets/service_unavailable_view.dart';
import 'package:ode_customer_app/core/config/env.dart';

class RestaurantModel {
  final String id;
  final String nameAr;
  final String? logoUrl;
  final double ratingAvg;

  RestaurantModel({required this.id, required this.nameAr, this.logoUrl, required this.ratingAvg});

  factory RestaurantModel.fromJson(Map<String, dynamic> json) {
    return RestaurantModel(
      id: json['id'],
      nameAr: json['name_ar'],
      logoUrl: json['logo_url'],
      ratingAvg: double.tryParse(json['rating_avg']?.toString() ?? '0') ?? 0,
    );
  }
}

/// شاشة تصفح المطاعم — تجيب GET /partners?type=restaurant (نفس نقطة
/// الربط الموجودة بالـ Backend من البداية) بدل GET /ode-brand/products.
class RestaurantsScreen extends StatefulWidget {
  const RestaurantsScreen({super.key});

  @override
  State<RestaurantsScreen> createState() => _RestaurantsScreenState();
}

class _RestaurantsScreenState extends State<RestaurantsScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  List<RestaurantModel> _restaurants = [];
  bool _isLoading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      // البحث بيتبعت للسيرفر مباشرة (query param) بدل ما نجيب كل المطاعم
      // ونفلترها محلياً — نفس منطق GET /ode-brand/products?search=
      final uri = Uri.parse('$baseUrl/partners').replace(queryParameters: {
        'type': 'restaurant',
        'countryId': '${context.read<AppConfig>().countryId}', // بند 9 (Audit): من AppConfig
        if (_query.isNotEmpty) 'search': _query,
      });
      final response = await http.get(uri);
      if (response.statusCode == 200) {
        final all = (jsonDecode(response.body) as List).map((e) => RestaurantModel.fromJson(e)).toList();
        setState(() { _restaurants = all; _isLoading = false; });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // طلب صريح (بند 2/10): تفعيل/تعطيل من لوحة الإدارة، بالتحقق الفعلي
    // بالباك إند أيضًا (order-flow.service.ts) — هذا فقط يمنع صدمة واجهة
    // فارغة/معطوبة، لا يحل محل التحقق الحقيقي بالسيرفر.
    final restaurantsEnabled = context.watch<RemoteSettingsProvider>().isEnabled('services.restaurants.enabled');
    return ScreenWithPinnedAd(
      title: 'المطاعم',
      pageKey: 'restaurants',
      countryId: context.watch<AppConfig>().countryId, // بند 9 (Audit): من AppConfig
      searchBar: restaurantsEnabled ? SearchBarField(
        hintText: 'ابحث عن مطعم...',
        onChanged: (q) { _query = q; _load(); },
      ) : null,
      body: !restaurantsEnabled
          ? const ServiceUnavailableView(serviceName: 'المطاعم')
          : _isLoading
          ? Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: AppColors.primaryPurple)))
          : _restaurants.isEmpty
              ? const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('لا توجد مطاعم متاحة حالياً')))
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: _restaurants.map((r) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => StoreDetailsScreen(partnerId: r.id, partnerNameAr: r.nameAr),
                        )),
                        child: GlassContainer(
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 24,
                                backgroundColor: AppColors.darkCardBackground,
                                backgroundImage: r.logoUrl != null ? NetworkImage(r.logoUrl!) : null,
                                child: r.logoUrl == null ? Icon(Icons.restaurant_rounded, color: AppColors.primaryPurpleLight) : null,
                              ),
                              const SizedBox(width: 14),
                              Expanded(child: Text(r.nameAr, style: Theme.of(context).textTheme.titleMedium)),
                              Row(children: [
                                const Icon(Icons.star_rounded, color: Colors.amber, size: 16),
                                Text(r.ratingAvg.toStringAsFixed(1), style: Theme.of(context).textTheme.bodyMedium),
                              ]),
                            ],
                          ),
                        ),
                      ),
                    )).toList(),
                  ),
                ),
    );
  }
}
