import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class SubscriptionPlanModel {
  final String id;
  final String code;
  final String nameAr;
  final double price;
  final String currencyCode;
  final int durationDays;
  final List<dynamic> benefits;
  SubscriptionPlanModel({required this.id, required this.code, required this.nameAr, required this.price, required this.currencyCode, required this.durationDays, required this.benefits});

  factory SubscriptionPlanModel.fromJson(Map<String, dynamic> j) => SubscriptionPlanModel(
        id: j['id'], code: j['code'], nameAr: j['name_ar'], price: (j['price'] as num).toDouble(),
        currencyCode: j['currency_code'], durationDays: j['duration_days'], benefits: j['benefits'] ?? [],
      );
}

/// بند 17: ODE Plus / ODE Pro — كل المزايا تُدار بالكامل من الأدمن
/// (subscription_plans.benefits)، لا شيء مثبت بالكود هنا.
class SubscriptionsController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<SubscriptionPlanModel>> fetchPlans(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/subscriptions/plans'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل الخطط');
    return (jsonDecode(response.body) as List).map((e) => SubscriptionPlanModel.fromJson(e)).toList();
  }

  Future<Map<String, dynamic>?> fetchMySubscription(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/subscriptions/me'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) return null;
    final body = response.body;
    return body == 'null' ? null : jsonDecode(body);
  }

  Future<void> subscribe(String token, String planId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/subscriptions/subscribe'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode({'planId': planId}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode != 201) throw Exception(_arabicError(data['error']));
  }

  String _arabicError(String? code) {
    switch (code) {
      case 'insufficient_wallet_balance': return 'رصيد محفظتك غير كافٍ — اشحن رصيدك أولاً';
      case 'plan_not_found': return 'هذه الخطة غير متاحة حاليًا';
      default: return 'تعذر الاشتراك';
    }
  }
}
