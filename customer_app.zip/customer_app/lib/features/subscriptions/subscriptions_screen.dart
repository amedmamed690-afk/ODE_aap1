import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'subscriptions_controller.dart';
import '../ode_pay/ode_pay_screen.dart';

/// بند 17: ODE Plus / ODE Pro.
class SubscriptionsScreen extends StatefulWidget {
  const SubscriptionsScreen({super.key});

  @override
  State<SubscriptionsScreen> createState() => _SubscriptionsScreenState();
}

class _SubscriptionsScreenState extends State<SubscriptionsScreen> {
  final SubscriptionsController _controller = SubscriptionsController();
  List<SubscriptionPlanModel> _plans = [];
  Map<String, dynamic>? _currentSub;
  bool _isLoading = true;
  String? _subscribingPlanId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthProvider>().token!;
    try {
      final results = await Future.wait([_controller.fetchPlans(token), _controller.fetchMySubscription(token)]);
      if (mounted) {
        setState(() {
          _plans = results[0] as List<SubscriptionPlanModel>;
          _currentSub = results[1] as Map<String, dynamic>?;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _subscribe(SubscriptionPlanModel plan) async {
    setState(() => _subscribingPlanId = plan.id);
    try {
      final token = context.read<AuthProvider>().token!;
      await _controller.subscribe(token, plan.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم الاشتراك بـ${plan.nameAr} 🎉')));
        _load();
      }
    } catch (e) {
      if (mounted) {
        final message = e.toString().replaceFirst('Exception: ', '');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(message),
          action: message.contains('رصيد') ? SnackBarAction(
            label: 'شحن الرصيد',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OdePayScreen())),
          ) : null,
        ));
      }
    } finally {
      if (mounted) setState(() => _subscribingPlanId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('ODE Plus / Pro'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                if (_currentSub != null)
                  GlassContainer(
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      const Icon(Icons.workspace_premium_rounded, color: Colors.amber),
                      const SizedBox(width: 10),
                      Expanded(child: Text('مشترك حاليًا بـ ${_currentSub!['name_ar']}')),
                    ]),
                  ),
                const SizedBox(height: 16),
                ..._plans.map((plan) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: GlassContainer(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Icon(plan.code == 'pro' ? Icons.diamond_rounded : Icons.star_rounded,
                                  color: plan.code == 'pro' ? AppColors.primaryPurpleLight : Colors.amber),
                              const SizedBox(width: 8),
                              Text(plan.nameAr, style: Theme.of(context).textTheme.titleMedium),
                            ]),
                            const SizedBox(height: 6),
                            Text('${plan.price} ${plan.currencyCode} / ${plan.durationDays} يوم', style: const TextStyle(color: AppColors.darkTextSecondary)),
                            const SizedBox(height: 10),
                            ...plan.benefits.map((b) => Padding(
                                  padding: const EdgeInsets.only(bottom: 4),
                                  child: Row(children: [
                                    const Icon(Icons.check_circle_rounded, size: 14, color: AppColors.success),
                                    const SizedBox(width: 6),
                                    Text('$b', style: const TextStyle(fontSize: 12)),
                                  ]),
                                )),
                            const SizedBox(height: 12),
                            NeonButton(
                              label: _currentSub?['code'] == plan.code ? 'مفعّل حاليًا' : 'اشترك الآن',
                              isLoading: _subscribingPlanId == plan.id,
                              disabled: _currentSub?['code'] == plan.code,
                              onPressed: () => _subscribe(plan),
                            ),
                          ],
                        ),
                      ),
                    )),
              ],
            ),
    );
  }
}
