import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'points_controller.dart';

/// بند 18: نظام النقاط.
class PointsScreen extends StatefulWidget {
  const PointsScreen({super.key});

  @override
  State<PointsScreen> createState() => _PointsScreenState();
}

class _PointsScreenState extends State<PointsScreen> {
  final PointsController _controller = PointsController();
  int _balance = 0;
  List<PointRewardModel> _rewards = [];
  bool _isLoading = true;
  String? _redeemingId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthProvider>().token!;
    try {
      final results = await Future.wait([_controller.fetchBalance(token), _controller.fetchRewards(token)]);
      if (mounted) {
        setState(() {
          _balance = results[0] as int;
          _rewards = results[1] as List<PointRewardModel>;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _redeem(PointRewardModel reward) async {
    setState(() => _redeemingId = reward.id);
    try {
      final token = context.read<AuthProvider>().token!;
      final newBalance = await _controller.redeem(token, reward.id);
      if (mounted) {
        setState(() => _balance = newBalance);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم استبدال ${reward.nameAr} 🎉')));
        _load();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => _redeemingId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('نقاطي'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  GlassContainer(
                    padding: const EdgeInsets.all(24),
                    child: Column(children: [
                      const Text('رصيدك من النقاط', style: TextStyle(color: AppColors.darkTextSecondary)),
                      const SizedBox(height: 8),
                      Text('$_balance', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: AppColors.primaryPurpleLight)),
                    ]),
                  ),
                  const SizedBox(height: 20),
                  Text('استبدل نقاطك بجوائز', style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 10),
                  if (_rewards.isEmpty)
                    const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد جوائز متاحة حاليًا', style: TextStyle(color: AppColors.darkTextSecondary)))
                  else
                    ..._rewards.map((reward) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassContainer(
                            child: Row(children: [
                              CircleAvatar(
                                backgroundColor: AppColors.darkCardBackground,
                                backgroundImage: reward.imageUrl != null ? NetworkImage(reward.imageUrl!) : null,
                                child: reward.imageUrl == null ? Icon(Icons.card_giftcard_rounded, color: AppColors.primaryPurpleLight) : null,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(reward.nameAr, style: Theme.of(context).textTheme.titleSmall),
                                    Text('${reward.pointsCost} نقطة', style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                                  ],
                                ),
                              ),
                              ElevatedButton(
                                onPressed: (_balance < reward.pointsCost || _redeemingId == reward.id) ? null : () => _redeem(reward),
                                child: _redeemingId == reward.id
                                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Text('استبدال'),
                              ),
                            ]),
                          ),
                        )),
                ],
              ),
            ),
    );
  }
}
