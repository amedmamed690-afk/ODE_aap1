import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class PointRewardModel {
  final String id;
  final String nameAr;
  final int pointsCost;
  final String? imageUrl;
  PointRewardModel({required this.id, required this.nameAr, required this.pointsCost, this.imageUrl});

  factory PointRewardModel.fromJson(Map<String, dynamic> j) =>
      PointRewardModel(id: j['id'], nameAr: j['name_ar'], pointsCost: j['points_cost'], imageUrl: j['image_url']);
}

class PointTxnModel {
  final String type;
  final int points;
  final DateTime createdAt;
  PointTxnModel({required this.type, required this.points, required this.createdAt});

  factory PointTxnModel.fromJson(Map<String, dynamic> j) =>
      PointTxnModel(type: j['type'], points: j['points'], createdAt: DateTime.parse(j['createdAt']));
}

/// بند 18: النقاط — العميل يكسبها تلقائيًا من كل طلب مكتمل (يديره
/// order-flow.service.ts بالباك إند)، ويستبدلها هنا بجوائز.
class PointsController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<int> fetchBalance(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/points/me'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل رصيد النقاط');
    return jsonDecode(response.body)['balance'];
  }

  Future<List<PointTxnModel>> fetchTransactions(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/points/transactions'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل السجل');
    return (jsonDecode(response.body) as List).map((e) => PointTxnModel.fromJson(e)).toList();
  }

  Future<List<PointRewardModel>> fetchRewards(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/points/rewards'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل الجوائز');
    return (jsonDecode(response.body) as List).map((e) => PointRewardModel.fromJson(e)).toList();
  }

  Future<int> redeem(String token, String rewardId) async {
    final response = await http.post(Uri.parse('$baseUrl/points/redeem/$rewardId'), headers: {'Authorization': 'Bearer $token'});
    final data = jsonDecode(response.body);
    if (response.statusCode != 200) throw Exception(_arabicError(data['error']));
    return data['newBalance'];
  }

  String _arabicError(String? code) {
    switch (code) {
      case 'insufficient_points': return 'نقاطك غير كافية لهذه الجائزة';
      case 'reward_out_of_stock': return 'نفدت الكمية من هذه الجائزة';
      default: return 'تعذر استبدال النقاط';
    }
  }
}
