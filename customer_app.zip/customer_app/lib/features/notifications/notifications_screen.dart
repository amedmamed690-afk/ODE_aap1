import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'package:ode_customer_app/core/config/env.dart';

class NotificationModel {
  final String id;
  final String type;
  final String titleAr;
  final String? bodyAr;
  final bool isRead;
  final DateTime createdAt;
  NotificationModel({required this.id, required this.type, required this.titleAr, this.bodyAr, required this.isRead, required this.createdAt});

  factory NotificationModel.fromJson(Map<String, dynamic> j) => NotificationModel(
        id: j['id'], type: j['type'], titleAr: j['title_ar'], bodyAr: j['body_ar'],
        isRead: j['is_read'], createdAt: DateTime.parse(j['created_at']),
      );
}

const _typeIcons = {
  'order': Icons.receipt_long_rounded, 'driver': Icons.directions_car_rounded,
  'partner': Icons.storefront_rounded, 'payment': Icons.payment_rounded,
  'promotion': Icons.local_offer_rounded, 'system': Icons.info_rounded,
};

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  List<NotificationModel> _notifications = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final token = context.read<AuthProvider>().token!;
    final response = await http.get(Uri.parse('$baseUrl/notifications'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode == 200 && mounted) {
      setState(() {
        _notifications = (jsonDecode(response.body) as List).map((e) => NotificationModel.fromJson(e)).toList();
        _isLoading = false;
      });
    } else if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _markRead(String id) async {
    final token = context.read<AuthProvider>().token!;
    await http.patch(Uri.parse('$baseUrl/notifications/$id/read'), headers: {'Authorization': 'Bearer $token'});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: const Text('الإشعارات'), backgroundColor: Colors.transparent),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : _notifications.isEmpty
              ? const Center(child: Text('لا توجد إشعارات بعد', style: TextStyle(color: AppColors.darkTextSecondary)))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _notifications.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final n = _notifications[index];
                      return GestureDetector(
                        onTap: () { if (!n.isRead) { _markRead(n.id); setState(() {}); } },
                        child: GlassContainer(
                          child: Row(children: [
                            Icon(_typeIcons[n.type] ?? Icons.notifications_rounded, color: n.isRead ? AppColors.darkTextSecondary : AppColors.primaryPurpleLight),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(n.titleAr, style: TextStyle(fontWeight: n.isRead ? FontWeight.normal : FontWeight.bold)),
                                  if (n.bodyAr != null) Text(n.bodyAr!, style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                                ],
                              ),
                            ),
                            if (!n.isRead) Container(width: 8, height: 8, decoration: BoxDecoration(color: AppColors.primaryPurple, shape: BoxShape.circle)),
                          ]),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
