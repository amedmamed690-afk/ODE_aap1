import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_customer_app/core/config/env.dart';

class HomeServiceModel {
  final String id;
  final String nameAr;
  final double basePrice;
  final String currencyCode;
  final String? iconUrl;

  HomeServiceModel({required this.id, required this.nameAr, required this.basePrice, required this.currencyCode, this.iconUrl});

  factory HomeServiceModel.fromJson(Map<String, dynamic> json) {
    return HomeServiceModel(
      id: json['id'],
      nameAr: json['name_ar'],
      basePrice: double.parse(json['base_price'].toString()),
      currencyCode: json['currency_code'] ?? '',
      iconUrl: json['icon_url'],
    );
  }
}

class ServiceProviderModel {
  final String id;
  final String? bio;
  final double ratingAvg;
  final double? customPrice;
  final String startTime;
  final String endTime;

  ServiceProviderModel({required this.id, this.bio, required this.ratingAvg, this.customPrice, required this.startTime, required this.endTime});

  factory ServiceProviderModel.fromJson(Map<String, dynamic> json) {
    return ServiceProviderModel(
      id: json['id'],
      bio: json['bio'],
      ratingAvg: double.tryParse(json['rating_avg']?.toString() ?? '0') ?? 0,
      customPrice: json['custom_price'] != null ? double.parse(json['custom_price'].toString()) : null,
      startTime: json['start_time'] ?? '',
      endTime: json['end_time'] ?? '',
    );
  }
}

class HomeServicesController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<HomeServiceModel>> fetchServices(int countryId) async {
    final response = await http.get(Uri.parse('$baseUrl/home-services?countryId=$countryId'));
    if (response.statusCode != 200) throw Exception('failed_to_load_services');
    return (jsonDecode(response.body) as List).map((e) => HomeServiceModel.fromJson(e)).toList();
  }

  Future<List<ServiceProviderModel>> fetchProviders(String serviceId, DateTime date) async {
    final dateStr = '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
    final response = await http.get(Uri.parse('$baseUrl/home-services/$serviceId/providers?date=$dateStr'));
    if (response.statusCode != 200) throw Exception('failed_to_load_providers');
    return (jsonDecode(response.body) as List).map((e) => ServiceProviderModel.fromJson(e)).toList();
  }

  /// الحجز يفشل بوضوح لو نقص أي حقل إجباري — نفس التحقق الموجود بالسيرفر
  /// (full_name/primary_phone/alt_phone NOT NULL) لكن نكرره بالتطبيق
  /// لإعطاء المستخدم رد فعل فوري بدل انتظار خطأ من الشبكة.
  Future<void> createBooking({
    required String token,
    required String serviceId,
    String? providerId,
    required String fullName,
    required String primaryPhone,
    required String altPhone,
    required String addressId,
    required DateTime scheduledAt,
  }) async {
    if (fullName.trim().isEmpty || primaryPhone.trim().isEmpty || altPhone.trim().isEmpty) {
      throw Exception('full_name_and_both_phone_numbers_are_required');
    }
    final response = await http.post(
      Uri.parse('$baseUrl/home-services/bookings'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({
        'serviceId': serviceId,
        'providerId': providerId,
        'fullName': fullName,
        'primaryPhone': primaryPhone,
        'altPhone': altPhone,
        'addressId': addressId,
        'scheduledAt': scheduledAt.toIso8601String(),
      }),
    );
    if (response.statusCode != 201) {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'booking_failed');
    }
  }
}
