import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/addresses_service.dart';
import '../addresses/addresses_screen.dart';
import 'home_services_controller.dart';

/// شاشة الحجز — الحقول (الاسم، الهاتف الرئيسي، الهاتف البديل) إجبارية
/// وتُتحقق منها قبل تفعيل زر الدفع بالكامل (مش بس رسالة خطأ بعد الضغط).
class BookingFormScreen extends StatefulWidget {
  final HomeServiceModel service;
  const BookingFormScreen({super.key, required this.service});

  @override
  State<BookingFormScreen> createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final HomeServicesController _controller = HomeServicesController();
  final _formKey = GlobalKey<FormState>();

  final _fullNameController = TextEditingController();
  final _primaryPhoneController = TextEditingController();
  final _altPhoneController = TextEditingController();

  DateTime _selectedDate = DateTime.now().add(const Duration(days: 1));
  List<ServiceProviderModel> _providers = [];
  String? _selectedProviderId;
  bool _isLoadingProviders = true;
  bool _isSubmitting = false;
  String? _errorText;
  AddressModel? _selectedAddress;

  @override
  void initState() {
    super.initState();
    _loadProviders();
    _loadDefaultAddress();
  }

  // إصلاح (بند D بالتقرير): نفس مشكلة السلة تمامًا — addressId كان ثابتًا
  // 'PLACEHOLDER_ADDRESS_ID'، والخدمة المنزلية أصلاً تحتاج عنوانًا حقيقيًا
  // ليصل إليه مزود الخدمة.
  Future<void> _loadDefaultAddress() async {
    final token = context.read<AuthProvider>().token;
    if (token == null) return;
    try {
      final addresses = await AddressesService().list(token);
      if (!mounted || addresses.isEmpty) return;
      setState(() {
        _selectedAddress = addresses.firstWhere((a) => a.isDefault, orElse: () => addresses.first);
      });
    } catch (_) {}
  }

  Future<void> _pickAddress() async {
    final picked = await Navigator.push<AddressModel>(
      context, MaterialPageRoute(builder: (_) => const AddressesScreen(selectMode: true)),
    );
    if (picked != null && mounted) setState(() => _selectedAddress = picked);
  }

  Future<void> _loadProviders() async {
    setState(() => _isLoadingProviders = true);
    try {
      final providers = await _controller.fetchProviders(widget.service.id, _selectedDate);
      if (mounted) setState(() { _providers = providers; _isLoadingProviders = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoadingProviders = false);
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
      _loadProviders();
    }
  }

  Future<void> _submit() async {
    // التحقق الصارم: لا انتقال للدفع بدون الاسم + الهاتفين، بالضبط زي ما طلبت
    if (!_formKey.currentState!.validate()) {
      setState(() => _errorText = 'أكمل جميع الحقول الإجبارية (الاسم، رقم الهاتف الأساسي، رقم الهاتف البديل)');
      return;
    }
    if (_selectedAddress == null) {
      setState(() => _errorText = 'اختر عنوان تنفيذ الخدمة أولاً');
      return;
    }
    final token = context.read<AuthProvider>().token;
    if (token == null) {
      setState(() => _errorText = 'انتهت الجلسة، الرجاء تسجيل الدخول من جديد');
      return;
    }
    setState(() { _isSubmitting = true; _errorText = null; });

    try {
      await _controller.createBooking(
        token: token,
        serviceId: widget.service.id,
        providerId: _selectedProviderId,
        fullName: _fullNameController.text.trim(),
        primaryPhone: _primaryPhoneController.text.trim(),
        altPhone: _altPhoneController.text.trim(),
        addressId: _selectedAddress!.id,
        scheduledAt: _selectedDate,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(backgroundColor: AppColors.success, content: Text('تم إرسال طلب الحجز، سيتم تأكيده قريباً')),
      );
      Navigator.pop(context);
    } catch (e) {
      setState(() => _errorText = 'تعذر إتمام الحجز، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _primaryPhoneController.dispose();
    _altPhoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.service.nameAr)),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            GlassContainer(
              child: ListTile(
                leading: Icon(Icons.calendar_today_rounded, color: AppColors.primaryPurpleLight),
                title: Text('${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}'),
                trailing: TextButton(onPressed: _pickDate, child: const Text('تغيير')),
              ),
            ),
            const SizedBox(height: 16),
            Text('العاملات/المزودون المتاحون', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (_isLoadingProviders)
              Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
            else if (_providers.isEmpty)
              const Text('لا يوجد مزودون متاحون بهذا التاريخ — جرّب تاريخاً آخر')
            else
              ..._providers.map((p) => RadioListTile<String>(
                    value: p.id,
                    groupValue: _selectedProviderId,
                    onChanged: (v) => setState(() => _selectedProviderId = v),
                    title: Text('مزود خدمة (${p.ratingAvg.toStringAsFixed(1)} ★)'),
                    subtitle: Text('متاح ${p.startTime} - ${p.endTime}'),
                    activeColor: AppColors.primaryPurple,
                  )),
            const SizedBox(height: 16),
            GlassContainer(
              child: ListTile(
                leading: Icon(Icons.location_on_rounded, color: AppColors.primaryPurpleLight),
                title: Text(_selectedAddress != null
                    ? (_selectedAddress!.label?.isNotEmpty == true ? _selectedAddress!.label! : _selectedAddress!.line1)
                    : 'اختر عنوان تنفيذ الخدمة'),
                subtitle: _selectedAddress != null ? Text(_selectedAddress!.line1) : null,
                trailing: TextButton(onPressed: _pickAddress, child: const Text('تغيير')),
                onTap: _pickAddress,
              ),
            ),
            const SizedBox(height: 20),
            Text('بيانات الطلب (إجبارية)', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            _buildTextField(_fullNameController, 'الاسم الكامل', Icons.person_rounded),
            const SizedBox(height: 12),
            _buildTextField(_primaryPhoneController, 'رقم الهاتف الرئيسي', Icons.phone_rounded, keyboardType: TextInputType.phone),
            const SizedBox(height: 12),
            _buildTextField(_altPhoneController, 'رقم هاتف بديل', Icons.phone_android_rounded, keyboardType: TextInputType.phone),
            if (_errorText != null) ...[
              const SizedBox(height: 12),
              Text(_errorText!, style: const TextStyle(color: AppColors.error)),
            ],
            const SizedBox(height: 24),
            NeonButton(label: 'متابعة إلى الدفع', isLoading: _isSubmitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {TextInputType? keyboardType}) {
    return GlassContainer(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(color: AppColors.darkTextPrimary),
        validator: (value) => (value == null || value.trim().isEmpty) ? 'هذا الحقل إجباري' : null,
        decoration: InputDecoration(
          hintText: label,
          hintStyle: const TextStyle(color: AppColors.darkTextSecondary),
          prefixIcon: Icon(icon, color: AppColors.primaryPurpleLight),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
