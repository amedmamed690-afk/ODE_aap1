import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/glass_container.dart';
import 'home_services_controller.dart';
import 'booking_form_screen.dart';
import '../../core/config/remote_settings_provider.dart';
import '../../shared/widgets/service_unavailable_view.dart';

class HomeServicesScreen extends StatefulWidget {
  const HomeServicesScreen({super.key});

  @override
  State<HomeServicesScreen> createState() => _HomeServicesScreenState();
}

class _HomeServicesScreenState extends State<HomeServicesScreen> {
  final HomeServicesController _controller = HomeServicesController();
  late Future<List<HomeServiceModel>> _servicesFuture;

  @override
  void initState() {
    super.initState();
    // بند 9 (Audit): من AppConfig المركزي بدل رقم ثابت.
    _servicesFuture = _controller.fetchServices(context.read<AppConfig>().countryId);
  }

  @override
  Widget build(BuildContext context) {
    // طلب صريح (بند 2/10): نفس مبدأ المطاعم/المتاجر بالضبط.
    final servicesEnabled = context.watch<RemoteSettingsProvider>().isEnabled('services.home_services.enabled');
    return Scaffold(
      appBar: AppBar(title: const Text('الخدمات المنزلية')),
      body: !servicesEnabled
          ? const ServiceUnavailableView(serviceName: 'الخدمات المنزلية')
          : FutureBuilder<List<HomeServiceModel>>(
        future: _servicesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: AppColors.primaryPurple));
          }
          if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('لا توجد خدمات متاحة حالياً'));
          }
          final services = snapshot.data!;
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: services.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, i) {
              final service = services[i];
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingFormScreen(service: service))),
                child: GlassContainer(
                  child: Row(
                    children: [
                      Icon(Icons.cleaning_services_rounded, color: AppColors.primaryPurpleLight, size: 30),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(service.nameAr, style: Theme.of(context).textTheme.titleMedium),
                            Text('يبدأ من ${service.basePrice.toStringAsFixed(0)} ${service.currencyCode}', style: Theme.of(context).textTheme.bodyMedium),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.darkTextSecondary),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
