import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models/ad_banner_model.dart';
import 'models/product_model.dart';
import 'models/short_model.dart';
import 'package:ode_customer_app/core/config/env.dart';

class HomeController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<HomeData> loadHomeData({required String token, required int countryId}) async {
    final headers = {'Authorization': 'Bearer $token'};

    final results = await Future.wait([
      http.get(Uri.parse('$baseUrl/marketing/ads?pageKey=home&countryId=$countryId')),
      http.get(Uri.parse('$baseUrl/ode-brand/products?limit=10'), headers: headers),
      http.get(Uri.parse('$baseUrl/marketing/shorts')),
      http.get(Uri.parse('$baseUrl/wallet/me'), headers: headers),
    ]);

    final ads = (jsonDecode(results[0].body) as List).map((e) => AdBannerModel.fromJson(e)).toList();
    final products = (jsonDecode(results[1].body) as List).map((e) => ProductModel.fromJson(e, sourceType: 'ode_brand')).toList();
    final shorts = (jsonDecode(results[2].body) as List).map((e) => ShortModel.fromJson(e)).toList();

    double walletBalance = 0;
    if (results[3].statusCode == 200) {
      final walletJson = jsonDecode(results[3].body);
      walletBalance = double.tryParse(walletJson['balance'].toString()) ?? 0;
    }

    return HomeData(ads: ads, products: products, shorts: shorts, walletBalance: walletBalance);
  }
}

class HomeData {
  final List<AdBannerModel> ads;
  final List<ProductModel> products;
  final List<ShortModel> shorts;
  final double walletBalance;

  HomeData({required this.ads, required this.products, required this.shorts, required this.walletBalance});
}
