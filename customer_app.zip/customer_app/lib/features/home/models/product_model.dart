class ProductModel {
  final String id;
  final String nameAr;
  final double price;
  final String currencyCode;
  final int? currencyId;
  final String? imageUrl;
  final String? storeName;
  final String sourceType;
  final String? partnerId;
  final String? branchId;

  ProductModel({
    required this.id,
    required this.nameAr,
    required this.price,
    required this.currencyCode,
    this.currencyId,
    this.imageUrl,
    this.storeName,
    required this.sourceType,
    this.partnerId,
    this.branchId,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json, {required String sourceType}) {
    return ProductModel(
      id: json['id'],
      nameAr: json['name_ar'],
      price: double.parse(json['price'].toString()),
      currencyCode: json['currency_code'] ?? '',
      currencyId: json['currency_id'] is int ? json['currency_id'] : int.tryParse(json['currency_id']?.toString() ?? ''),
      imageUrl: json['image_url'],
      storeName: json['store_name'],
      sourceType: sourceType,
      // إصلاح (بند حرج بالجولة الثالثة): كان partnerId يُشتق خطأً بمكان
      // آخر (product_details_screen.dart) من معرّف المنتج نفسه بدل معرّف
      // الشريك الفعلي — الآن يُقرأ من json['partner_id'] الحقيقي القادم
      // من الـBackend (عمود موجود بجدول products من البداية).
      partnerId: json['partner_id'],
      branchId: json['branch_id'],
    );
  }
}
