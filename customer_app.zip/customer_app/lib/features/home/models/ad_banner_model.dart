class AdBannerModel {
  final String id;
  final String? titleAr;
  final String imageUrl;
  final String linkType;
  final String linkValue;

  AdBannerModel({
    required this.id,
    this.titleAr,
    required this.imageUrl,
    required this.linkType,
    required this.linkValue,
  });

  factory AdBannerModel.fromJson(Map<String, dynamic> json) {
    return AdBannerModel(
      id: json['id'],
      titleAr: json['title_ar'],
      imageUrl: json['image_url'],
      linkType: json['link_type'],
      linkValue: json['link_value'],
    );
  }
}
