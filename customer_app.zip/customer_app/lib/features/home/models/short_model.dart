class ShortModel {
  final String id;
  final String videoUrl;
  final String? thumbnailUrl;
  final String? captionAr;
  final int viewCount;
  final int likeCount;
  final bool isSponsored;
  final String? sponsoredProductId;
  final String? sponsoredPartnerId;

  ShortModel({
    required this.id,
    required this.videoUrl,
    this.thumbnailUrl,
    this.captionAr,
    required this.viewCount,
    required this.likeCount,
    required this.isSponsored,
    this.sponsoredProductId,
    this.sponsoredPartnerId,
  });

  factory ShortModel.fromJson(Map<String, dynamic> json) {
    return ShortModel(
      id: json['id'],
      videoUrl: json['video_url'],
      thumbnailUrl: json['thumbnail_url'],
      captionAr: json['caption_ar'],
      viewCount: json['view_count'] ?? 0,
      likeCount: json['like_count'] ?? 0,
      isSponsored: json['sponsorship_id'] != null,
      sponsoredProductId: json['sponsored_product_id'],
      sponsoredPartnerId: json['sponsored_partner_id'],
    );
  }
}
