import 'dart:async';
import 'package:flutter/material.dart';
import '../models/ad_banner_model.dart';
import '../../../core/theme/app_colors.dart';

class AdCarousel extends StatefulWidget {
  final List<AdBannerModel> ads;
  final void Function(AdBannerModel) onTapAd;

  const AdCarousel({super.key, required this.ads, required this.onTapAd});

  @override
  State<AdCarousel> createState() => _AdCarouselState();
}

class _AdCarouselState extends State<AdCarousel> {
  final PageController _pageController = PageController(viewportFraction: 0.92);
  Timer? _autoScrollTimer;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    if (widget.ads.length > 1) {
      _autoScrollTimer = Timer.periodic(const Duration(seconds: 4), (_) {
        if (!_pageController.hasClients) return;
        final nextPage = (_currentPage + 1) % widget.ads.length;
        _pageController.animateToPage(nextPage, duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
      });
    }
  }

  @override
  void dispose() {
    _autoScrollTimer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.ads.isEmpty) return const SizedBox.shrink();

    return SizedBox(
      height: 160,
      child: PageView.builder(
        controller: _pageController,
        itemCount: widget.ads.length,
        onPageChanged: (i) => setState(() => _currentPage = i),
        itemBuilder: (context, index) {
          final ad = widget.ads[index];
          return GestureDetector(
            onTap: () => widget.onTapAd(ad),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: AppColors.neonGlow.withOpacity(0.2), blurRadius: 16, offset: const Offset(0, 6))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(
                  ad.imageUrl,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  loadingBuilder: (context, child, progress) {
                    if (progress == null) return child;
                    return Container(
                      color: AppColors.darkCardBackground,
                      child: Center(child: CircularProgressIndicator(color: AppColors.primaryPurple)),
                    );
                  },
                  errorBuilder: (context, error, stack) => Container(
                    color: AppColors.darkCardBackground,
                    child: const Icon(Icons.image_not_supported, color: AppColors.darkTextSecondary),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
