import 'package:flutter/material.dart';
import '../../../core/theme/glass_container.dart';
import '../../../core/theme/app_colors.dart';

class ServiceItem {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final String? badgeText;

  ServiceItem({required this.label, required this.icon, required this.onTap, this.badgeText});
}

class ServicesGrid extends StatelessWidget {
  final List<ServiceItem> items;

  const ServicesGrid({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 4),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.8,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return GestureDetector(
          onTap: item.onTap,
          child: Column(
            children: [
              Hero(
                tag: 'service_${item.label}',
                child: GlassContainer(
                  borderRadius: 18,
                  padding: const EdgeInsets.all(14),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Icon(item.icon, color: AppColors.primaryPurpleLight, size: 26),
                      if (item.badgeText != null)
                        Positioned(
                          top: -6, right: -10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.primaryPurple,
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: [BoxShadow(color: AppColors.neonGlow.withOpacity(0.6), blurRadius: 8)],
                            ),
                            child: Text(item.badgeText!, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(item.label, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ),
        );
      },
    );
  }
}
