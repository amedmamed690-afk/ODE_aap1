import 'package:flutter/material.dart';
import '../models/short_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../shorts/shorts_feed_screen.dart';

class ShortsStrip extends StatelessWidget {
  final List<ShortModel> shorts;

  const ShortsStrip({super.key, required this.shorts});

  @override
  Widget build(BuildContext context) {
    if (shorts.isEmpty) return const SizedBox.shrink();

    return SizedBox(
      height: 180,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: shorts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final short = shorts[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => ShortsFeedScreen(shorts: shorts, initialIndex: index)));
            },
            child: Container(
              width: 110,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: AppColors.neonGlow.withOpacity(0.15), blurRadius: 12)],
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: short.thumbnailUrl != null ? Image.network(short.thumbnailUrl!, fit: BoxFit.cover) : Container(color: AppColors.darkCardBackground),
                  ),
                  if (short.isSponsored)
                    Positioned(
                      top: 8, right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: AppColors.primaryPurple, borderRadius: BorderRadius.circular(6)),
                        child: const Text('مُمول', style: TextStyle(color: Colors.white, fontSize: 9)),
                      ),
                    ),
                  Positioned(
                    bottom: 8, right: 8, left: 8,
                    child: Row(
                      children: [
                        const Icon(Icons.play_circle_fill, color: Colors.white, size: 16),
                        const SizedBox(width: 4),
                        Text('${short.viewCount}', style: const TextStyle(color: Colors.white, fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
