import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../../../core/theme/glass_container.dart';
import '../../product_details/product_details_screen.dart';

class ProductCard extends StatelessWidget {
  final ProductModel product;

  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 400),
            pageBuilder: (_, animation, __) => FadeTransition(opacity: animation, child: ProductDetailsScreen(product: product)),
          ),
        );
      },
      child: SizedBox(
        width: 140,
        child: GlassContainer(
          borderRadius: 16,
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Hero(
                tag: 'product_image_${product.id}',
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: product.imageUrl != null
                      ? Image.network(product.imageUrl!, height: 90, width: double.infinity, fit: BoxFit.cover)
                      : Container(height: 90, color: Colors.grey.withOpacity(0.2)),
                ),
              ),
              const SizedBox(height: 6),
              Text(product.nameAr, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontSize: 13)),
              if (product.storeName != null)
                Text(product.storeName!, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 10)),
              const SizedBox(height: 4),
              Text('${product.price.toStringAsFixed(2)} ${product.currencyCode}', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}
