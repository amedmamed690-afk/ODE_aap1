import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/providers/theme_provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'home_controller.dart';
import 'widgets/ad_carousel.dart';
import 'widgets/services_grid.dart';
import 'widgets/product_card.dart';
import 'widgets/shorts_strip.dart';
import '../ode_brand/ode_brand_screen.dart';
import '../ode_brand/store_details_screen.dart';
import '../ode_pay/ode_pay_screen.dart';
import '../home_services/home_services_screen.dart';
import '../rides/rides_screen.dart';
import '../restaurants/restaurants_screen.dart';
import '../digital_partners/digital_partners_screen.dart';
import '../profile/profile_screen.dart';
import '../cart/cart_screen.dart';
import '../cart/cart_provider.dart';
import '../notifications/notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController _controller = HomeController();
  late Future<HomeData> _homeDataFuture;

  @override
  void initState() {
    super.initState();
    _homeDataFuture = _loadData();
  }

  Future<HomeData> _loadData() {
    // Fix: كان يستخدم توكن وهمي ثابت — يعني الشاشة الرئيسية كانت ترسل
    // طلبات غير مُصادَق عليها فعليًا لأي backend حقيقي (401 دائمًا).
    // الآن يُقرأ التوكن الحقيقي من AuthProvider بعد تسجيل الدخول.
    // بند 9 (Audit): countryId الآن من AppConfig المركزي بدل تكرار الرقم.
    final token = context.read<AuthProvider>().token;
    return _controller.loadHomeData(token: token ?? '', countryId: context.read<AppConfig>().countryId);
  }

  Future<void> _onRefresh() async {
    setState(() => _homeDataFuture = _loadData());
    await _homeDataFuture;
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final cart = context.watch<CartProvider>();

    return Scaffold(
      appBar: _buildAppBar(context, themeProvider, cart),
      body: FutureBuilder<HomeData>(
        future: _homeDataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: AppColors.primaryPurple));
          }
          if (snapshot.hasError) return _buildErrorState();

          final data = snapshot.data!;
          return RefreshIndicator(
            color: AppColors.primaryPurple,
            onRefresh: _onRefresh,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                AdCarousel(
                  ads: data.ads,
                  onTapAd: (ad) async {
                    switch (ad.linkType) {
                      case 'partner':
                        // بند 12 (Audit): التنقل الفعلي لصفحة الشريك — نفس
                        // الشاشة المستخدمة بكل مكان آخر بالتطبيق. لا يوجد
                        // اسم شريك منفصل بموديل الإعلان، فنستخدم عنوان
                        // الإعلان نفسه (titleAr) كعنوان مؤقت للشاشة — بيانات
                        // حقيقية موجودة فعلًا، وليست مُختلَقة.
                        Navigator.push(context, MaterialPageRoute(builder: (_) => StoreDetailsScreen(
                          partnerId: ad.linkValue, partnerNameAr: ad.titleAr ?? 'المتجر',
                        )));
                        break;
                      case 'category':
                        Navigator.push(context, MaterialPageRoute(builder: (_) => OdeBrandScreen(initialCategoryId: ad.linkValue)));
                        break;
                      case 'external_url':
                        // بند 12 (Audit): فتح فعلي عبر url_launcher بدل TODO فارغ.
                        final uri = Uri.tryParse(ad.linkValue);
                        if (uri != null && await canLaunchUrl(uri)) {
                          await launchUrl(uri, mode: LaunchMode.externalApplication);
                        } else if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط')));
                        }
                        break;
                    }
                  },
                ),
                const SizedBox(height: 20),
                ServicesGrid(items: [
                  ServiceItem(label: 'المطاعم', icon: Icons.restaurant_rounded,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RestaurantsScreen()))),
                  ServiceItem(label: 'مطاعم إلكترونية', icon: Icons.soup_kitchen_rounded,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DigitalPartnersScreen(
                          businessType: 'restaurant', title: 'مطاعم إلكترونية', pageKey: 'digital_restaurants')))),
                  ServiceItem(label: 'متاجر إلكترونية', icon: Icons.shopping_bag_rounded,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DigitalPartnersScreen(
                          businessType: 'store', title: 'متاجر إلكترونية', pageKey: 'digital_stores')))),
                  ServiceItem(label: 'ODE براند', icon: Icons.storefront_rounded,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OdeBrandScreen()))),
                  ServiceItem(label: 'ODE PAY', icon: Icons.account_balance_wallet_rounded,
                      badgeText: data.walletBalance.toStringAsFixed(0),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OdePayScreen()))),
                  ServiceItem(label: 'الخدمات المنزلية', icon: Icons.cleaning_services_rounded,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeServicesScreen()))),
                  ServiceItem(label: 'التوصيل والركاب', icon: Icons.delivery_dining_rounded,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RidesScreen()))),
                ]),
                const SizedBox(height: 24),
                Text('منتجات ODE والشركاء', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 12),
                SizedBox(
                  height: 200,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: data.products.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (context, i) => ProductCard(product: data.products[i]),
                  ),
                ),
                const SizedBox(height: 24),
                Text('فيديوهات مختارة', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 12),
                ShortsStrip(shorts: data.shorts),
                const SizedBox(height: 40),
              ],
            ),
          );
        },
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeProvider themeProvider, CartProvider cart) {
    return AppBar(
      title: Image.asset('assets/images/ode_logo.png', height: 32),
      actions: [
        IconButton(
          icon: Icon(themeProvider.isDarkMode ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
          onPressed: () => themeProvider.toggleTheme(),
          tooltip: 'تبديل الوضع الداكن/الفاتح',
        ),
        IconButton(
          icon: const Icon(Icons.notifications_none_rounded),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            IconButton(
              icon: const Icon(Icons.shopping_cart_rounded),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
            ),
            if (cart.itemCount > 0)
              Positioned(
                top: 6, right: 6,
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: const BoxDecoration(color: AppColors.error, shape: BoxShape.circle),
                  child: Text('${cart.itemCount}', style: const TextStyle(color: Colors.white, fontSize: 9)),
                ),
              ),
          ],
        ),
        IconButton(
          icon: const Icon(Icons.person_rounded),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())),
        ),
      ],
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: GlassContainer(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, color: AppColors.error, size: 40),
            const SizedBox(height: 12),
            const Text('تعذر تحميل البيانات، تحقق من الاتصال'),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: _onRefresh, child: const Text('إعادة المحاولة')),
          ],
        ),
      ),
    );
  }
}
