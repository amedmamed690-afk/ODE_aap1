import 'package:flutter/material.dart';
import 'models/cart_item_model.dart';

/// State Management الحقيقي للسلة — كل شاشة بالتطبيق تقرأ/تعدّل نفس
/// النسخة الوحيدة من السلة. نفرض أيضاً: لا يمكن خلط منتجات من أكثر
/// من شريك واحد بنفس السلة (نفس منطق تطبيقات التوصيل المعروفة).
class CartProvider extends ChangeNotifier {
  final List<CartItemModel> _items = [];

  List<CartItemModel> get items => List.unmodifiable(_items);
  int get itemCount => _items.fold(0, (sum, i) => sum + i.quantity);
  double get subtotal => _items.fold(0, (sum, i) => sum + i.totalPrice);
  bool get isEmpty => _items.isEmpty;
  String? get currentPartnerId => _items.isEmpty ? null : _items.first.partnerId;
  // إضافة (بند D — اختيار الفرع): السلة الآن تتتبع الفرع فعليًا، مو بس
  // الشريك — كل منتج بالسلة يحمل branchId حقيقي من الـBackend الآن.
  String? get currentBranchId => _items.isEmpty ? null : _items.first.branchId;
  int? get currentCurrencyId => _items.isEmpty ? null : _items.first.currencyId;
  String get currentCurrencyCode => _items.isEmpty ? '' : _items.first.currencyCode;

  String? addItem(CartItemModel item) {
    // إصلاح: كان يمنع الخلط بين شريكين فقط — الآن يمنع أيضًا خلط منتجات
    // من فرعين مختلفين لنفس الشريك بنفس الطلب (فرع واحد = عنوان مصدر
    // واحد لحساب رسوم التوصيل وتعيين السائق، ومخزون منفصل لكل فرع).
    if (_items.isNotEmpty && (item.partnerId != currentPartnerId || item.branchId != currentBranchId)) {
      return 'cart_different_store';
    }
    final existingIndex = _items.indexWhere((i) => i.productId == item.productId);
    if (existingIndex >= 0) {
      _items[existingIndex].quantity += item.quantity;
    } else {
      _items.add(item);
    }
    notifyListeners();
    return null;
  }

  void updateQuantity(String productId, int newQuantity) {
    if (newQuantity <= 0) {
      removeItem(productId);
      return;
    }
    final index = _items.indexWhere((i) => i.productId == productId);
    if (index >= 0) {
      _items[index].quantity = newQuantity;
      notifyListeners();
    }
  }

  void removeItem(String productId) {
    _items.removeWhere((i) => i.productId == productId);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
