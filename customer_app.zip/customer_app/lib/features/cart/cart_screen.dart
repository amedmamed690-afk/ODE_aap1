import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/providers/auth_provider.dart';
import '../../core/config/remote_settings_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/addresses_service.dart';
import '../addresses/addresses_screen.dart';
import '../ode_pay/ode_pay_controller.dart';
import '../ode_pay/payment_webview_screen.dart';
import 'cart_provider.dart';
import 'package:ode_customer_app/core/config/env.dart';

/// شاشة السلة والدفع عبر ODE PAY — تحقق حقيقي من الرصيد قبل تأكيد الطلب،
/// وليس مجرد افتراض إن الدفع سينجح. الخصم الفعلي يحدث بالسيرفر عبر
/// POST /orders الذي يستدعي WalletService.debit() داخلياً (بنيناه بالـ Backend).
class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  final OdePayController _payController = OdePayController();

  double? _walletBalance;
  bool _isCheckingOut = false;
  String? _errorText;
  AddressModel? _selectedAddress;
  // طلب صريح (بند 1 — نظام الدفع Cash + Payment Gateway): اختيار حقيقي
  // بدل 'wallet' ثابتة — يُقرأ توفّر كل وسيلة من إعدادات لوحة الإدارة
  // فعليًا (RemoteSettingsProvider)، ويُرسل الاختيار الحقيقي للباك إند.
  String _paymentMethod = 'wallet';
  bool _didInitPaymentMethod = false;

  @override
  void initState() {
    super.initState();
    _loadBalance();
    _loadDefaultAddress();
  }

  /// يختار أول وسيلة دفع متاحة فعليًا كافتراضي — مرة واحدة بعد أول تحميل
  /// للإعدادات، حتى لا نفترض أن "wallet" متاحة دائمًا.
  void _initPaymentMethodIfNeeded(RemoteSettingsProvider settings) {
    if (_didInitPaymentMethod) return;
    _didInitPaymentMethod = true;
    if (settings.isEnabled('services.wallet.enabled')) {
      _paymentMethod = 'wallet';
    } else if (settings.isEnabled('payment.cash.enabled')) {
      _paymentMethod = 'cash';
    } else if (settings.isEnabled('payment.gateway.enabled', defaultValue: false)) {
      _paymentMethod = 'card';
    }
  }

  // إصلاح (بند D بالتقرير): كان addressId يُرسل كنص ثابت 'PLACEHOLDER_ADDRESS_ID'
  // بغض النظر عن أي شيء — أي طلب حقيقي كان سيُرفض من الـBackend (بند 15:
  // "address must belong to the customer"). الآن نجيب عناوين المستخدم
  // الحقيقية ونختار الافتراضي تلقائيًا، مع إمكانية تغييره يدويًا.
  Future<void> _loadDefaultAddress() async {
    final token = context.read<AuthProvider>().token;
    if (token == null) return;
    try {
      final addresses = await AddressesService().list(token);
      if (!mounted || addresses.isEmpty) return;
      setState(() {
        _selectedAddress = addresses.firstWhere((a) => a.isDefault, orElse: () => addresses.first);
      });
    } catch (_) {
      // لو فشل التحميل، تبقى null وزر الدفع يمنع المتابعة (انظر _checkout)
    }
  }

  Future<void> _pickAddress() async {
    final picked = await Navigator.push<AddressModel>(
      context, MaterialPageRoute(builder: (_) => const AddressesScreen(selectMode: true)),
    );
    if (picked != null && mounted) setState(() => _selectedAddress = picked);
  }

  Future<void> _loadBalance() async {
    final token = context.read<AuthProvider>().token;
    if (token == null) return; // بند 11 (Audit): بدون توكن حقيقي، لا نحاول الطلب أصلاً
    try {
      final balance = await _payController.fetchBalance(token);
      if (mounted) setState(() => _walletBalance = balance);
    } catch (_) {}
  }

  Future<void> _checkout(CartProvider cart) async {
    if (_selectedAddress == null) {
      setState(() => _errorText = 'اختر عنوان التوصيل أولاً');
      return;
    }
    final token = context.read<AuthProvider>().token;
    if (token == null) {
      setState(() => _errorText = 'انتهت الجلسة، الرجاء تسجيل الدخول من جديد');
      return;
    }
    // إصلاح (بند حرج بالجولة الثالثة): branchId كان ثابتًا وهميًا، ولم يكن
    // يُرسل currencyId إطلاقًا رغم أن الـBackend يرفضه كحقل إجباري
    // (zod schema بـorders.routes.ts) — أي طلب حقيقي سابق كان يفشل 400
    // قبل حتى الوصول لمنطق الطلب نفسه.
    if (cart.currentBranchId == null || cart.currentCurrencyId == null) {
      setState(() => _errorText = 'تعذر تحديد فرع المتجر أو العملة — أعد فتح المتجر واختر فرعًا أولاً');
      return;
    }
    setState(() { _isCheckingOut = true; _errorText = null; });

    // تحقق الرصيد محليًا مفيد فقط لوسيلة المحفظة تحديدًا — لا معنى له
    // إطلاقًا لو اختار العميل كاش أو بطاقة.
    if (_paymentMethod == 'wallet' && _walletBalance != null && _walletBalance! < cart.subtotal) {
      setState(() {
        _isCheckingOut = false;
        _errorText = 'رصيدك غير كافٍ لإتمام هذا الطلب. رصيدك ${_walletBalance!.toStringAsFixed(2)}، والمطلوب ${cart.subtotal.toStringAsFixed(2)}';
      });
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/orders'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({
          'orderType': cart.items.first.sourceType == 'ode_brand' ? 'store' : 'food',
          'partnerId': cart.currentPartnerId,
          // branchId/currencyId: كانا مفقودين تمامًا قبل هذه الجولة —
          // الآن يُقرآن من عناصر السلة الحقيقية (كل عنصر يحمل branch_id
          // وcurrency_id القادمين فعليًا من الـBackend).
          'branchId': cart.currentBranchId,
          'currencyId': cart.currentCurrencyId,
          'addressId': _selectedAddress!.id,
          // طلب صريح: وسيلة الدفع الحقيقية المختارة، مو 'wallet' ثابتة.
          'paymentMethod': _paymentMethod,
          'items': cart.items.map((i) => {'productId': i.productId, 'qty': i.quantity}).toList(),
        }),
      );

      if (response.statusCode != 201) {
        final err = jsonDecode(response.body);
        // رسائل واضحة حسب السبب الفعلي القادم من الباك إند — بدل رسالة
        // عامة واحدة لكل شيء (طلب صريح: "لا يستطيع العميل إنشاء طلب من
        // خدمة معطّلة"، ولازم يفهم لماذا بالضبط).
        setState(() => _errorText = switch (err['error']) {
          'insufficient_balance' => 'رصيدك غير كافٍ — تم رفض العملية من السيرفر',
          'service_unavailable' => 'هذه الخدمة غير متوفرة حاليًا',
          'wallet_payment_disabled' => 'الدفع عبر المحفظة غير متاح حاليًا — اختر وسيلة أخرى',
          'cash_payment_disabled' => 'الدفع النقدي غير متاح حاليًا — اختر وسيلة أخرى',
          'payment_gateway_not_configured' => 'الدفع بالبطاقة غير مفعّل بعد — اختر وسيلة أخرى',
          _ => 'تعذر إتمام الطلب، حاول مرة أخرى',
        });
        setState(() => _isCheckingOut = false);
        return;
      }

      final order = jsonDecode(response.body);

      // طلب صريح (بوابة الدفع): الطلب أُنشئ لكنه لسا "unpaid" — نفتح صفحة
      // الدفع الحقيقية (نفس WebView المستخدم أصلاً لشحن المحفظة، بدون أي
      // تكرار) وننتظر تأكيد المستخدم إتمام الدفع فعليًا هناك.
      if (_paymentMethod == 'card' && order['checkout_url'] != null) {
        if (!mounted) return;
        final paid = await Navigator.push<bool>(
          context, MaterialPageRoute(builder: (_) => PaymentWebviewScreen(checkoutUrl: order['checkout_url'])),
        );
        if (!mounted) return;
        setState(() => _isCheckingOut = false);
        if (paid == true) {
          cart.clear();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(backgroundColor: AppColors.success, content: Text('تم تأكيد الطلب والدفع بنجاح')),
          );
          Navigator.pop(context);
        } else {
          // الطلب موجود فعليًا بحالة unpaid — لا نحذف السلة حتى يقدر
          // يحاول الدفع مرة ثانية بنفس المنتجات لو رجع.
          setState(() => _errorText = 'لم يكتمل الدفع — طلبك محفوظ ويمكنك إعادة المحاولة');
        }
        return;
      }

      final successMessage = _paymentMethod == 'cash'
          ? 'تم تأكيد طلبك — ادفع نقدًا عند الاستلام'
          : 'تم تأكيد الطلب وخصم المبلغ من محفظتك بنجاح';

      cart.clear();
      if (mounted) {
        setState(() => _isCheckingOut = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(backgroundColor: AppColors.success, content: Text(successMessage)),
        );
        Navigator.pop(context);
      }
    } catch (_) {
      setState(() { _isCheckingOut = false; _errorText = 'تعذر الاتصال بالسيرفر'; });
    }
  }

  Widget _paymentChip(String value, String label, IconData icon) {
    final selected = _paymentMethod == value;
    return ChoiceChip(
      label: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 15, color: selected ? Colors.white : AppColors.darkTextSecondary),
        const SizedBox(width: 4),
        Text(label),
      ]),
      selected: selected,
      onSelected: (_) => setState(() => _paymentMethod = value),
      selectedColor: AppColors.primaryPurple,
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final settings = context.watch<RemoteSettingsProvider>();
    _initPaymentMethodIfNeeded(settings);

    return Scaffold(
      appBar: AppBar(title: const Text('السلة')),
      body: cart.isEmpty
          ? const Center(child: Text('السلة فارغة'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: cart.items.length,
                    itemBuilder: (context, index) {
                      final item = cart.items[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: GlassContainer(
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: item.imageUrl != null
                                    ? Image.network(item.imageUrl!, width: 60, height: 60, fit: BoxFit.cover)
                                    : Container(width: 60, height: 60, color: AppColors.darkSurface),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item.nameAr, style: Theme.of(context).textTheme.bodyLarge),
                                    Text('${item.price.toStringAsFixed(2)} ${item.currencyCode}', style: Theme.of(context).textTheme.bodyMedium),
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.remove_circle_outline, color: AppColors.primaryPurpleLight, size: 20),
                                onPressed: () => cart.updateQuantity(item.productId, item.quantity - 1),
                              ),
                              Text('${item.quantity}'),
                              IconButton(
                                icon: Icon(Icons.add_circle_outline, color: AppColors.primaryPurpleLight, size: 20),
                                onPressed: () => cart.updateQuantity(item.productId, item.quantity + 1),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GlassContainer(
                    child: ListTile(
                      leading: Icon(Icons.location_on_rounded, color: AppColors.primaryPurpleLight),
                      title: Text(_selectedAddress != null
                          ? (_selectedAddress!.label?.isNotEmpty == true ? _selectedAddress!.label! : _selectedAddress!.line1)
                          : 'اختر عنوان التوصيل'),
                      subtitle: _selectedAddress != null ? Text(_selectedAddress!.line1) : null,
                      trailing: TextButton(onPressed: _pickAddress, child: const Text('تغيير')),
                      onTap: _pickAddress,
                    ),
                  ),
                ),
                // طلب صريح (بند 1): اختيار وسيلة دفع حقيقي — تُعرض فقط
                // الوسائل المفعّلة فعليًا من لوحة الإدارة (لا تُخفى بالكود،
                // تُقرأ ديناميكيًا من الإعدادات).
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GlassContainer(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('وسيلة الدفع', style: TextStyle(fontSize: 12, color: AppColors.darkTextSecondary)),
                        const SizedBox(height: 8),
                        Wrap(spacing: 8, runSpacing: 8, children: [
                          if (settings.isEnabled('services.wallet.enabled'))
                            _paymentChip('wallet', 'المحفظة', Icons.account_balance_wallet_rounded),
                          if (settings.isEnabled('payment.cash.enabled'))
                            _paymentChip('cash', 'نقدًا عند الاستلام', Icons.payments_rounded),
                          if (settings.isEnabled('payment.gateway.enabled', defaultValue: false))
                            _paymentChip('card', 'بطاقة', Icons.credit_card_rounded),
                        ]),
                        if (!settings.isEnabled('services.wallet.enabled') &&
                            !settings.isEnabled('payment.cash.enabled') &&
                            !settings.isEnabled('payment.gateway.enabled', defaultValue: false))
                          const Padding(
                            padding: EdgeInsets.only(top: 4),
                            child: Text('لا توجد وسيلة دفع متاحة حاليًا', style: TextStyle(color: AppColors.error, fontSize: 12)),
                          ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: GlassContainer(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          const Text('الإجمالي'),
                          Text('${cart.subtotal.toStringAsFixed(2)} ${cart.currentCurrencyCode}', style: Theme.of(context).textTheme.titleMedium),
                        ]),
                        if (_paymentMethod == 'wallet' && _walletBalance != null) ...[
                          const SizedBox(height: 4),
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                            const Text('رصيد محفظتك', style: TextStyle(fontSize: 12, color: AppColors.darkTextSecondary)),
                            Text(_walletBalance!.toStringAsFixed(2), style: const TextStyle(fontSize: 12, color: AppColors.darkTextSecondary)),
                          ]),
                        ],
                        if (_errorText != null) ...[
                          const SizedBox(height: 8),
                          Text(_errorText!, style: const TextStyle(color: AppColors.error, fontSize: 12)),
                        ],
                        const SizedBox(height: 16),
                        NeonButton(
                          label: _paymentMethod == 'cash' ? 'تأكيد الطلب (الدفع عند الاستلام)' : 'الدفع الآن',
                          icon: Icons.shopping_bag_rounded,
                          isLoading: _isCheckingOut,
                          onPressed: () => _checkout(cart),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
