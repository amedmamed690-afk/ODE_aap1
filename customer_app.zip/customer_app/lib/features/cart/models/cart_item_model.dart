class CartItemModel {
  final String productId;
  final String nameAr;
  final double price;
  final String currencyCode;
  final int? currencyId;
  final String? imageUrl;
  final String sourceType;
  final String? partnerId;
  final String? branchId;
  int quantity;

  CartItemModel({
    required this.productId,
    required this.nameAr,
    required this.price,
    required this.currencyCode,
    this.currencyId,
    this.imageUrl,
    required this.sourceType,
    this.partnerId,
    this.branchId,
    this.quantity = 1,
  });

  double get totalPrice => price * quantity;
}
