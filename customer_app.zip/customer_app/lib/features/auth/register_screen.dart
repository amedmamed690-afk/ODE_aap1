import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/neon_effects.dart';
import '../../core/theme/glass_container.dart';
import '../home/home_screen.dart';

class RegisterScreen extends StatefulWidget {
  final String phone;
  const RegisterScreen({super.key, required this.phone});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameController = TextEditingController();
  String? _errorText;

  Future<void> _submit() async {
    if (_nameController.text.trim().length < 3) {
      setState(() => _errorText = 'أدخل الاسم الكامل');
      return;
    }
    setState(() => _errorText = null);
    final auth = context.read<AuthProvider>();
    try {
      // بند 9 (Audit): من AppConfig المركزي بدل رقم ثابت.
      await auth.completeRegistration(widget.phone, _nameController.text.trim(), context.read<AppConfig>().countryId);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (_) {
      setState(() => _errorText = 'تعذر إكمال التسجيل، حاول مرة أخرى');
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('أكمل بياناتك', style: Theme.of(context).textTheme.headlineLarge),
            const SizedBox(height: 20),
            GlassContainer(
              child: TextField(
                controller: _nameController,
                style: const TextStyle(color: AppColors.darkTextPrimary),
                decoration: const InputDecoration(
                  hintText: 'الاسم الكامل',
                  hintStyle: TextStyle(color: AppColors.darkTextSecondary),
                  prefixIcon: Icon(Icons.person_rounded, color: AppColors.primaryPurpleLight),
                  border: InputBorder.none,
                ),
              ),
            ),
            if (_errorText != null) ...[
              const SizedBox(height: 12),
              Text(_errorText!, style: const TextStyle(color: AppColors.error)),
            ],
            const SizedBox(height: 24),
            NeonButton(label: 'إنشاء الحساب', isLoading: auth.isLoading, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
