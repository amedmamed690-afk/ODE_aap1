import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/neon_effects.dart';
import '../../core/theme/glass_container.dart';
import '../home/home_screen.dart';
import 'register_screen.dart';

/// شاشة الدخول — خطوتين: رقم الهاتف ثم رمز التحقق (بند 13: OTP لكل
/// التطبيقات). نفس منطق DriverAuthProvider/PartnerAuthProvider لكن
/// بدون مرحلة "بانتظار الموافقة" لأن العميل يصير نشطًا فورًا.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  bool _codeSent = false;
  String? _errorText;

  Future<void> _sendCode() async {
    final phone = _phoneController.text.trim();
    if (phone.length < 8) {
      setState(() => _errorText = 'أدخل رقم هاتف صحيح');
      return;
    }
    setState(() => _errorText = null);
    final auth = context.read<AuthProvider>();
    final sent = await auth.requestOtp(phone);
    if (!mounted) return;
    if (sent) {
      setState(() => _codeSent = true);
    } else {
      setState(() => _errorText = 'تعذر إرسال رمز التحقق، حاول مرة أخرى');
    }
  }

  Future<void> _verifyCode() async {
    final phone = _phoneController.text.trim();
    final code = _codeController.text.trim();
    if (code.length != 6) {
      setState(() => _errorText = 'أدخل رمز التحقق المكوّن من 6 أرقام');
      return;
    }
    setState(() => _errorText = null);
    final auth = context.read<AuthProvider>();
    final outcome = await auth.verifyOtp(phone, code);
    if (!mounted) return;

    switch (outcome) {
      case LoginOutcome.existingUser:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
        break;
      case LoginOutcome.newUser:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => RegisterScreen(phone: phone)));
        break;
      case LoginOutcome.error:
        setState(() => _errorText = 'رمز التحقق غير صحيح أو منتهي الصلاحية');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _codeSent ? 'أدخل رمز التحقق' : 'مرحبًا بك في ODE',
                style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: AppColors.darkTextPrimary),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                _codeSent ? 'أرسلنا رمزًا إلى ${_phoneController.text}' : 'سجّل دخولك برقم هاتفك',
                style: const TextStyle(color: AppColors.darkTextSecondary),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              if (!_codeSent)
                GlassContainer(
                  child: TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(color: AppColors.darkTextPrimary),
                    decoration: const InputDecoration(
                      hintText: 'رقم الهاتف',
                      hintStyle: TextStyle(color: AppColors.darkTextSecondary),
                      prefixIcon: Icon(Icons.phone_rounded, color: AppColors.primaryPurpleLight),
                      border: InputBorder.none,
                    ),
                  ),
                )
              else
                GlassContainer(
                  child: TextField(
                    controller: _codeController,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    style: const TextStyle(color: AppColors.darkTextPrimary, letterSpacing: 8, fontSize: 20),
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      counterText: '',
                      hintText: '------',
                      hintStyle: TextStyle(color: AppColors.darkTextSecondary),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              if (_errorText != null) ...[
                const SizedBox(height: 12),
                Text(_errorText!, style: const TextStyle(color: AppColors.error), textAlign: TextAlign.center),
              ],
              const SizedBox(height: 24),
              NeonButton(
                label: _codeSent ? 'تأكيد' : 'إرسال رمز التحقق',
                isLoading: auth.isLoading,
                onPressed: _codeSent ? _verifyCode : _sendCode,
              ),
              if (_codeSent) ...[
                const SizedBox(height: 12),
                TextButton(
                  onPressed: auth.isLoading ? null : () => setState(() => _codeSent = false),
                  child: const Text('تغيير رقم الهاتف', style: TextStyle(color: AppColors.darkTextSecondary)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
