import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/neon_effects.dart';
import '../cart/cart_provider.dart';
import '../cart/models/cart_item_model.dart';
import '../home/models/product_model.dart';

class ProductDetailsScreen extends StatefulWidget {
  final ProductModel product;
  const ProductDetailsScreen({super.key, required this.product});

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> with SingleTickerProviderStateMixin {
  int _quantity = 1;
  late final AnimationController _bounceController;

  @override
  void initState() {
    super.initState();
    _bounceController = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
  }

  @override
  void dispose() {
    _bounceController.dispose();
    super.dispose();
  }

  void _addToCart() {
    final cart = context.read<CartProvider>();
    final error = cart.addItem(CartItemModel(
      productId: widget.product.id,
      nameAr: widget.product.nameAr,
      price: widget.product.price,
      currencyCode: widget.product.currencyCode,
      currencyId: widget.product.currencyId,
      imageUrl: widget.product.imageUrl,
      sourceType: widget.product.sourceType,
      // إصلاح (بند حرج): كان `widget.product.id` — أي معرّف المنتج نفسه —
      // يُرسل باعتباره partnerId! كل طلب حقيقي كان سيفشل حتمًا بالـBackend
      // (partnerId غير موجود أصلاً كشريك، أو يشير خطأً لشريك آخر بالصدفة).
      partnerId: widget.product.sourceType == 'partner' ? widget.product.partnerId : null,
      branchId: widget.product.sourceType == 'partner' ? widget.product.branchId : null,
      quantity: _quantity,
    ));

    if (error == 'cart_different_store') {
      _showDifferentStoreDialog();
      return;
    }

    _bounceController.forward(from: 0);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.primaryPurple,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        content: Text('تمت إضافة "${widget.product.nameAr}" للسلة ($_quantity)'),
      ),
    );
  }

  void _showDifferentStoreDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.darkCardBackground,
        title: const Text('سلة من متجر مختلف'),
        content: const Text('سلتك تحتوي منتجات من متجر آخر. هل تريد إفراغ السلة والبدء من هذا المتجر؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          TextButton(
            onPressed: () {
              context.read<CartProvider>().clear();
              Navigator.pop(context);
              _addToCart();
            },
            child: const Text('إفراغ والمتابعة', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Hero(
                tag: 'product_image_${widget.product.id}',
                child: widget.product.imageUrl != null
                    ? Image.network(widget.product.imageUrl!, fit: BoxFit.cover)
                    : Container(color: AppColors.darkCardBackground),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.product.nameAr, style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Text('${widget.product.price.toStringAsFixed(2)} ${widget.product.currencyCode}',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(color: AppColors.primaryPurpleLight, fontSize: 20)),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      const Text('الكمية:'),
                      const Spacer(),
                      IconButton(onPressed: () => setState(() => _quantity = (_quantity - 1).clamp(1, 99)), icon: Icon(Icons.remove_circle_outline, color: AppColors.primaryPurpleLight)),
                      Text('$_quantity', style: const TextStyle(fontSize: 16)),
                      IconButton(onPressed: () => setState(() => _quantity = (_quantity + 1).clamp(1, 99)), icon: Icon(Icons.add_circle_outline, color: AppColors.primaryPurpleLight)),
                    ],
                  ),
                  const SizedBox(height: 24),
                  ScaleTransition(
                    scale: Tween(begin: 1.0, end: 1.08).animate(CurvedAnimation(parent: _bounceController, curve: Curves.elasticOut)),
                    child: NeonButton(label: 'إضافة إلى السلة', icon: Icons.add_shopping_cart_rounded, onPressed: _addToCart),
                  ),
                  if (cart.itemCount > 0) ...[
                    const SizedBox(height: 12),
                    Text('${cart.itemCount} عنصر بالسلة — ${cart.subtotal.toStringAsFixed(2)} ${widget.product.currencyCode}', style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
