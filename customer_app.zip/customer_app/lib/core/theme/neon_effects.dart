import 'package:flutter/material.dart';
import 'app_colors.dart';

class NeonButton extends StatefulWidget {
  final String label;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool isLoading;
  final bool disabled;

  const NeonButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.isLoading = false,
    this.disabled = false,
  });

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> with SingleTickerProviderStateMixin {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: (widget.isLoading || widget.disabled) ? null : widget.onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOut,
        transform: Matrix4.identity()..scale(_isPressed ? 0.97 : 1.0),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppColors.buttonRadius),
          gradient: LinearGradient(
            colors: widget.disabled
                ? [AppColors.darkTextSecondary, AppColors.darkTextSecondary]
                : [AppColors.primaryPurple, AppColors.primaryPurpleLight],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: widget.disabled ? [] : [
            BoxShadow(
              color: AppColors.neonGlow.withOpacity(_isPressed ? 0.3 : 0.55),
              blurRadius: _isPressed ? 12 : 22,
              spreadRadius: _isPressed ? 0 : 2,
            ),
            BoxShadow(
              color: AppColors.neonGlow.withOpacity(0.25),
              blurRadius: 40,
              spreadRadius: 4,
            ),
          ],
        ),
        child: widget.isLoading
            ? const SizedBox(
                width: 20, height: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            : Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon, color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    widget.label,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ],
              ),
      ),
    );
  }
}
