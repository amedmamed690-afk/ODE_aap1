import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/appearance_provider.dart';
import 'app_colors.dart';

/// شعار افتراضي جاهز (ODE + أيقونة برق داخل دائرة متدرجة) — طلب صريح:
/// "حط شعار مناسب من عندك وخليه قابل للتعديل من لوحة الإدارة". هذا الشعار
/// Vector بالكامل (Icon + Text)، مو صورة، فيظهر حادًا بأي حجم بدون أي ملف
/// أصول (asset) مطلوب. بمجرد ما الأدمن يحط رابط شعار حقيقي بلوحة التحكم
/// (Appearance → الشعار)، تظهر الصورة الحقيقية تلقائيًا بدل هذا الافتراضي
/// — بدون أي تعديل كود أو نشر نسخة جديدة.
class AppLogo extends StatelessWidget {
  final double size;
  const AppLogo({super.key, this.size = 96});

  @override
  Widget build(BuildContext context) {
    final logoUrl = context.watch<AppearanceProvider>().logoUrl;

    if (logoUrl != null && logoUrl.isNotEmpty) {
      return Image.network(
        logoUrl,
        height: size,
        errorBuilder: (_, __, ___) => _defaultLogo(),
      );
    }
    return _defaultLogo();
  }

  Widget _defaultLogo() {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primaryPurple, AppColors.primaryPurpleLight],
        ),
        boxShadow: [BoxShadow(color: AppColors.primaryPurple.withOpacity(0.5), blurRadius: size * 0.25, spreadRadius: 1)],
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.bolt_rounded, color: Colors.white, size: size * 0.42),
            Text('ODE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: size * 0.16, letterSpacing: 1.5)),
          ],
        ),
      ),
    );
  }
}
