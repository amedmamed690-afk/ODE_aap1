import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../shared/services/fcm_service.dart';
import 'package:ode_customer_app/core/config/env.dart';

/// نتيجة verifyOtp — يحدد شاشة login_screen.dart وين ينتقل بعدها:
/// existingUser -> الرئيسية مباشرة، newUser -> شاشة إكمال البيانات
/// (register_screen.dart)، error -> يبقى بشاشة الدخول برسالة خطأ.
enum LoginOutcome { existingUser, newUser, error }

/// نفس فلسفة DriverAuthProvider/PartnerAuthProvider: /auth/otp/verify
/// يرجّع توكن فعلي قابل للاستخدام فورًا (مو توكن مؤقت)، حتى لو كان
/// المستخدم جديد — الفرق الوحيد إن `fullName` بيكون فاضي لحد ما يكمّل
/// بياناته بشاشة التسجيل.
class AuthProvider extends ChangeNotifier {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  String? _token;
  String? _userId;
  String? _role;
  String? _fullName;
  bool _isLoading = false;

  String? get token => _token;
  String? get userId => _userId;
  String? get role => _role;
  bool get isAuthenticated => _token != null;
  bool get isLoading => _isLoading;

  Future<void> loadFromStorage() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
    _userId = prefs.getString('user_id');
    _role = prefs.getString('user_role');
    notifyListeners();
  }

  Future<bool> requestOtp(String phone) async {
    _isLoading = true;
    notifyListeners();
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/otp/request'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'phone': phone}),
      );
      return response.statusCode == 200;
    } catch (_) {
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<LoginOutcome> verifyOtp(String phone, String code) async {
    _isLoading = true;
    notifyListeners();
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/otp/verify'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'phone': phone, 'code': code}),
      );
      if (response.statusCode != 200) return LoginOutcome.error;

      final data = jsonDecode(response.body);
      await _persistSession(
        token: data['token'],
        userId: data['user']['id'],
        role: data['user']['role'],
      );
      _fullName = data['user']['fullName'];

      return data['isNewUser'] == true ? LoginOutcome.newUser : LoginOutcome.existingUser;
    } catch (_) {
      return LoginOutcome.error;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// تُستدعى من register_screen.dart بعد verifyOtp لو كانت النتيجة newUser.
  /// التوكن أصلاً صالح من verifyOtp — هذا فقط يكمّل الاسم/الدولة عليه.
  /// countryId يُمرر من الشاشة، وهي تقرأه من AppConfig المركزي (بند 9 —
  /// Audit) بدل رقم ثابت مكرر بكل مكان.
  Future<void> completeRegistration(String phone, String fullName, int countryId) async {
    if (_token == null) throw Exception('not_authenticated');
    _isLoading = true;
    notifyListeners();
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/auth/complete-profile'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $_token'},
        body: jsonEncode({'fullName': fullName, 'countryId': countryId}),
      );
      if (response.statusCode != 200) throw Exception('registration_failed');
      _fullName = fullName;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _persistSession({required String token, required String userId, required String role}) async {
    _token = token;
    _userId = userId;
    _role = role;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    await prefs.setString('user_id', userId);
    await prefs.setString('user_role', role);
    notifyListeners();
    FcmService.registerToken(token); // بند 15
  }

  Future<void> logout() async {
    _token = null;
    _userId = null;
    _role = null;
    _fullName = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('user_id');
    await prefs.remove('user_role');
    notifyListeners();
  }
}
