import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// طلب صريح: لازم يكون فيه وضع فاتح وداكن بالتطبيق مع إمكانية اختيار
/// المستخدم بنفسه. يدعم 3 خيارات: فاتح / داكن / حسب الجهاز — ويحترم أول
/// اختيار المستخدم دائمًا فوق أي إعداد افتراضي يجيء من الأدمن.
class ThemeProvider extends ChangeNotifier {
  static const _prefKey = 'theme_mode_v2';
  ThemeMode _mode = ThemeMode.dark;
  bool _hasUserPreference = false;

  ThemeMode get themeMode => _mode;
  bool get isDarkMode => _mode == ThemeMode.dark;

  Future<void> loadSavedTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_prefKey);
    if (saved != null) {
      _mode = _fromString(saved);
      _hasUserPreference = true;
      notifyListeners();
    }
  }

  /// طلب صريح (طلب الأدمن): الوضع الافتراضي عند أول تشغيل يأتي من لوحة
  /// الإدارة (/app-appearance → default_theme_mode) — لكن فقط لو المستخدم
  /// لسا ما اختار شيء بنفسه من قبل؛ اختياره الشخصي دائمًا له الأولوية.
  void applyRemoteDefault(String serverDefault) {
    if (_hasUserPreference) return;
    _mode = _fromString(serverDefault);
    notifyListeners();
  }

  Future<void> setMode(ThemeMode mode) async {
    _mode = mode;
    _hasUserPreference = true;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, _toString(mode));
  }

  Future<void> toggleTheme() async {
    await setMode(_mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark);
  }

  ThemeMode _fromString(String s) {
    switch (s) {
      case 'light': return ThemeMode.light;
      case 'system': return ThemeMode.system;
      default: return ThemeMode.dark;
    }
  }

  String _toString(ThemeMode m) {
    switch (m) {
      case ThemeMode.light: return 'light';
      case ThemeMode.system: return 'system';
      default: return 'dark';
    }
  }
}
