import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// إعداد مركزي للدولة/العملة الحالية — بند 9/10 بالمراجعة.
///
/// كان `countryId = 1` مكررًا حرفيًا بأكثر من 8 ملفات مختلفة (splash،
/// register، restaurants، digital_partners، ode_brand، home_services،
/// home_screen...). المشروع فعليًا يخدم دولة واحدة حاليًا (لا يوجد أي شاشة
/// لاختيار الدولة، ولا عمود country_id بجدول users يُقرأ منه بأي مكان)،
/// فالإبقاء على القيمة 1 مؤقتًا مقبول تمامًا حسب توجيهك — لكن بمكان واحد
/// فقط، وليس مكررًا. أي منطق مستقبلي لاكتشاف الدولة الفعلية (GPS، اختيار
/// يدوي، ملف تعريف المستخدم) يُبنى هنا فقط، ويظهر تلقائيًا بكل الشاشات
/// دون تعديلها من جديد.
class AppConfig extends ChangeNotifier {
  static const int _defaultCountryId = 1;
  static const int _defaultCurrencyId = 1;

  int _countryId = _defaultCountryId;
  int _currencyId = _defaultCurrencyId;

  int get countryId => _countryId;
  int get currencyId => _currencyId;

  /// تُستدعى مرة عند إقلاع التطبيق (main.dart). تقرأ آخر قيمة محفوظة محليًا
  /// إن وُجدت (مثلاً لو أُضيف مستقبلاً اختيار دولة يدوي)، وإلا تبقى على
  /// القيمة الافتراضية الموثّقة أعلاه.
  Future<void> loadFromStorage() async {
    final prefs = await SharedPreferences.getInstance();
    _countryId = prefs.getInt('app_country_id') ?? _defaultCountryId;
    _currencyId = prefs.getInt('app_currency_id') ?? _defaultCurrencyId;
    notifyListeners();
  }

  /// نقطة التوسّع الوحيدة لدعم أكثر من دولة مستقبلاً — بمجرد وجود شاشة
  /// اختيار دولة حقيقية أو منطق GPS، تستدعي هذه الدالة فقط، ولا حاجة
  /// لتعديل أي شاشة أخرى بالتطبيق.
  Future<void> setCountry(int countryId, int currencyId) async {
    _countryId = countryId;
    _currencyId = currencyId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('app_country_id', countryId);
    await prefs.setInt('app_currency_id', currencyId);
    notifyListeners();
  }
}
