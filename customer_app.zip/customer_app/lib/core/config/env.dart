/// إعداد بيئة مركزي — بند 16 بالمراجعة.
///
/// كان `'https://api.ode-app.com'` مكررًا حرفيًا بـ25 ملفًا مختلفًا. الآن
/// قيمة واحدة فقط هنا، وكل الملفات تشير إليها. يمكن تغييرها وقت البناء
/// بدون تعديل أي كود عبر:
///
///   flutter build apk --dart-define=API_BASE_URL=https://staging-api.ode-app.com
///   flutter run --dart-define=API_BASE_URL=http://localhost:3000
///
/// بدون تمرير `--dart-define`، القيمة الافتراضية تبقى نطاق الإنتاج الحالي
/// كما هو — لم يتغيّر شيء بالسلوك الفعلي، فقط أصبح قابلاً للتهيئة.
class Env {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.ode-app.com',
  );
}
