import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_colors.dart';
import 'env.dart';

/// طلب صريح: تحكّم الأدمن الكامل بمظهر التطبيق (شعار، ألوان، حجم خط،
/// استدارة الأزرار، الوضع الافتراضي، رابط خدمة العملاء) بدون أي تعديل
/// كود أو نشر نسخة جديدة — يُجلب مرة عند إقلاع التطبيق من endpoint عام
/// (GET /app-appearance، بدون توكن لأنه يُستدعى حتى قبل تسجيل الدخول).
///
/// تصميم Offline-first: تُحفظ آخر نسخة محليًا (SharedPreferences)، فلو
/// فشل الجلب (بدون إنترنت مثلاً) يستخدم آخر قيم معروفة، وإلا القيم
/// الافتراضية المدمجة بالتطبيق أصلاً — التطبيق لا يعلّق أبدًا بانتظار
/// هذا الطلب ولا ينهار لو فشل.
class AppearanceProvider extends ChangeNotifier {
  static const _cacheKey = 'app_appearance_cache_v1';

  double fontScale = 1.0;
  String? logoUrl;
  String? customerSupportUrl;
  String defaultThemeMode = 'dark';
  bool _isLoaded = false;
  bool get isLoaded => _isLoaded;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(_cacheKey);
    if (cached != null) {
      try {
        _applyJson(jsonDecode(cached));
      } catch (_) {}
    }

    try {
      final response = await http
          .get(Uri.parse('${Env.apiBaseUrl}/app-appearance'))
          .timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        _applyJson(json);
        await prefs.setString(_cacheKey, response.body);
      }
    } catch (_) {
      // لا إنترنت أو الباك إند غير متاح — نكمل بآخر قيمة محفوظة/الافتراضية
    }
    _isLoaded = true;
    notifyListeners();
  }

  void _applyJson(Map<String, dynamic> json) {
    Color? _hex(String? hex) {
      if (hex == null) return null;
      final clean = hex.replaceFirst('#', '');
      return Color(int.parse('FF$clean', radix: 16));
    }

    final primary = _hex(json['primary_color'] as String?);
    final secondary = _hex(json['secondary_color'] as String?);
    if (primary != null) AppColors.primaryPurple = primary;
    if (secondary != null) AppColors.primaryPurpleLight = secondary;
    if (json['button_radius'] != null) {
      AppColors.buttonRadius = (json['button_radius'] as num).toDouble();
    }
    fontScale = json['font_scale'] != null ? (json['font_scale'] as num).toDouble() : fontScale;
    logoUrl = json['logo_url'] as String?;
    customerSupportUrl = json['customer_support_url'] as String?;
    defaultThemeMode = json['default_theme_mode'] as String? ?? defaultThemeMode;
  }
}
