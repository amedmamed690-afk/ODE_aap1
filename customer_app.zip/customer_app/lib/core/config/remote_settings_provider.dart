import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'env.dart';

/// طلب صريح (نظام إعدادات مركزي — بند 2/3/4): "لا تستخدم Boolean محلي
/// داخل Flutter فقط". هذا الـProvider لا يخترع أي منطق — فقط يستهلك
/// endpoint كان موجودًا بالفعل بالباك إند (GET /config/bootstrap) ولم يكن
/// أي تطبيق يستدعيه إطلاقًا. مصدر الحقيقة الوحيد يبقى قاعدة البيانات؛
/// هذا مجرد Cache محلي قصير العمر بنفس مبدأ AppearanceProvider
/// (Offline-first: لا يعلّق التطبيق ولا ينهار لو تعذّر الجلب).
class RemoteSettingsProvider extends ChangeNotifier {
  static const _cacheKey = 'remote_settings_cache_v1';
  Map<String, dynamic> _settings = {};
  bool _isLoaded = false;
  bool get isLoaded => _isLoaded;

  /// افتراضي "متاح" لو الإعداد غير موجود بعد بالاستجابة — يطابق نفس
  /// الافتراضي المحافظ المستخدم بجانب الباك إند (getAppSettingBool)، حتى
  /// لا يُخفي أي خدمة عن طريق الخطأ بسبب مشكلة شبكة عابرة.
  bool isEnabled(String key, {bool defaultValue = true}) {
    final value = _settings[key];
    if (value == null) return defaultValue;
    return value == true;
  }

  Future<void> load({int? countryId}) async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(_cacheKey);
    if (cached != null) {
      try {
        _settings = jsonDecode(cached) as Map<String, dynamic>;
      } catch (_) {}
    }

    try {
      final uri = Uri.parse('${Env.apiBaseUrl}/config/bootstrap').replace(
        queryParameters: countryId != null ? {'countryId': '$countryId'} : null,
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        _settings = Map<String, dynamic>.from(json['settings'] ?? {});
        await prefs.setString(_cacheKey, jsonEncode(_settings));
      }
    } catch (_) {
      // لا إنترنت — نكمل بآخر نسخة محفوظة أو الافتراضي المحافظ (متاح)
    }
    _isLoaded = true;
    notifyListeners();
  }
}
