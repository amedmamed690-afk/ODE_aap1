#!/usr/bin/env bash
# سكربت نشر بسيط لصفحة تتبع الرحلة العامة (public-tracking).
#
# لماذا موجود: track.html ملف ثابت (static) بدون أي محرّك عرض بالسيرفر،
# ومفتاح Google Maps JavaScript API *يجب* أن يكون client-side بطبيعته
# (هذه توصية Google نفسها لهذا النوع من المفاتيح تحديدًا — الحماية تكون
# بتقييد HTTP referrer من Google Cloud Console، مش بإخفاء المفتاح). لذلك
# لا يوضع مفتاح حقيقي أبدًا داخل track.html بالمستودع — هذا السكربت يستبدل
# الـplaceholder بالقيمة الفعلية وقت النشر فقط، من متغيرات بيئة الخادم.
#
# الاستخدام:
#   GOOGLE_MAPS_API_KEY="AIza..." API_BASE_URL="https://api.ode-app.com" ./build.sh
#
# الناتج: يكتب نسخة جاهزة للنشر إلى dist/track.html (لا يُعدّل المصدر نفسه).

set -euo pipefail

: "${GOOGLE_MAPS_API_KEY:?يجب ضبط GOOGLE_MAPS_API_KEY قبل تشغيل هذا السكربت}"
API_BASE_URL="${API_BASE_URL:-https://api.ode-app.com}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$SCRIPT_DIR/dist"

sed \
  -e "s|GOOGLE_MAPS_API_KEY_PLACEHOLDER|${GOOGLE_MAPS_API_KEY}|g" \
  -e "s|const API_BASE = 'https://api.ode-app.com';|const API_BASE = '${API_BASE_URL}';|" \
  "$SCRIPT_DIR/track.html" > "$SCRIPT_DIR/dist/track.html"

echo "✅ تم إنشاء $SCRIPT_DIR/dist/track.html — انشر هذا الملف فقط، وليس المصدر الأصلي."
echo "⚠️  تذكير: قيّد مفتاح GOOGLE_MAPS_API_KEY هذا بـHTTP referrer لنطاق النشر فقط من Google Cloud Console."
