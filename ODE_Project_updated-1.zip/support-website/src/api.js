const baseUrl = 'https://api.ode-app.com'; // PLACEHOLDER

function getToken() {
  return localStorage.getItem('ode_support_token');
}

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
      ...options.headers,
    },
  });
  if (response.status === 401) {
    localStorage.removeItem('ode_support_token');
    window.location.href = '/login';
    throw new Error('unauthorized');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'request_failed');
  return data;
}

export const api = {
  // نفس /admin/auth/login بالضبط — الفرق إن حساب موظف الدعم ما يحمل
  // صلاحيات لوحة التحكم الرئيسية أصلاً (بند 2)، فمعظم /admin/* يرفضه.
  login: (body) => request('/admin/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  lookupCustomer: (phone) => request(`/support/customers?phone=${encodeURIComponent(phone)}`),
  getOrder: (id) => request(`/support/orders/${id}`),
  addOrderNote: (id, note) => request(`/support/orders/${id}/note`, { method: 'POST', body: JSON.stringify({ note }) }),
};
