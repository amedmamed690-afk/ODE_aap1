import React, { useState } from 'react';
import { Search, LogOut } from 'lucide-react';
import { Card, Button, Input, Toast, Badge, EmptyState } from '../components/ui.jsx';
import { api } from '../api.js';

export default function Lookup() {
  const [phone, setPhone] = useState('');
  const [result, setResult] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [note, setNote] = useState('');
  const [toast, setToast] = useState(null);

  const search = async (e) => {
    e.preventDefault();
    try {
      const data = await api.lookupCustomer(phone);
      setResult(data);
      setSelectedOrder(null);
    } catch {
      setToast({ message: 'لا يوجد عميل بهذا الرقم', tone: 'error' });
      setResult(null);
    }
  };

  const openOrder = async (id) => {
    const data = await api.getOrder(id).catch(() => null);
    setSelectedOrder(data);
  };

  const addNote = async () => {
    if (!note.trim() || !selectedOrder) return;
    try {
      await api.addOrderNote(selectedOrder.order.id, note);
      setToast({ message: 'تمت إضافة الملاحظة', tone: 'success' });
      setNote('');
      openOrder(selectedOrder.order.id);
    } catch {
      setToast({ message: 'تعذرت الإضافة', tone: 'error' });
    }
  };

  const logout = () => { localStorage.removeItem('ode_support_token'); window.location.href = '/login'; };

  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-primary-light font-bold text-lg">ODE — خدمة العملاء</h1>
        <button onClick={logout} className="text-red-400 flex items-center gap-1.5 text-sm"><LogOut size={16} /> خروج</button>
      </div>

      <Card className="mb-4">
        <form onSubmit={search} className="flex gap-2">
          <Input placeholder="رقم هاتف العميل" value={phone} onChange={(e) => setPhone(e.target.value)} className="flex-1" />
          <Button type="submit"><Search size={16} /></Button>
        </form>
      </Card>

      {result && (
        <Card className="mb-4">
          <h3 className="font-bold text-sm mb-1">{result.customer.full_name || 'بدون اسم'}</h3>
          <p className="text-white/50 text-xs mb-4">{result.customer.phone} {result.customer.is_blocked && <Badge tone="danger">محظور</Badge>}</p>

          <p className="text-xs text-white/40 mb-2">آخر الطلبات</p>
          {result.recentOrders.length === 0 ? <EmptyState text="لا توجد طلبات" /> : (
            <div className="space-y-1.5 mb-4">
              {result.recentOrders.map((o) => (
                <button key={o.id} onClick={() => openOrder(o.id)} className="w-full text-right bg-dark-surface rounded-lg px-3 py-2 text-xs flex justify-between hover:bg-white/5">
                  <span>#{o.order_number} — {o.status}</span><span>{o.total}</span>
                </button>
              ))}
            </div>
          )}
        </Card>
      )}

      {selectedOrder && (
        <Card>
          <h3 className="font-bold text-sm mb-3">تفاصيل الطلب #{selectedOrder.order.order_number}</h3>
          <div className="space-y-1.5 mb-4">
            {selectedOrder.history.map((h, i) => (
              <div key={i} className="text-xs bg-dark-surface rounded-lg px-3 py-2">
                <span className="text-primary-light">{h.status}</span>
                {h.note && <span className="text-white/50"> — {h.note}</span>}
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Input placeholder="أضف ملاحظة داخلية..." value={note} onChange={(e) => setNote(e.target.value)} className="flex-1" />
            <Button onClick={addNote}>إضافة</Button>
          </div>
        </Card>
      )}

      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
