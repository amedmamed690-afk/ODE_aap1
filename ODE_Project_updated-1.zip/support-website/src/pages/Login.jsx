import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Card, Button, Input, Toast } from '../components/ui.jsx';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [totpCode, setTotpCode] = useState('');
  const [needsTotp, setNeedsTotp] = useState(false);
  const [toast, setToast] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const result = await api.login({ email, password, ...(needsTotp ? { totpCode } : {}) });
      localStorage.setItem('ode_support_token', result.token);
      navigate('/');
    } catch (err) {
      if (err.message === 'totp_required') setNeedsTotp(true);
      else setToast({ message: 'بيانات الدخول غير صحيحة', tone: 'error' });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <h1 className="text-xl font-bold text-primary-light mb-1">ODE — خدمة العملاء</h1>
        <p className="text-white/40 text-xs mb-6">حساب موظف دعم فقط — بدون صلاحيات لوحة التحكم الرئيسية</p>
        <form onSubmit={submit} className="space-y-3">
          <Input label="البريد الإلكتروني" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <Input label="كلمة المرور" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          {needsTotp && <Input label="رمز التحقق بخطوتين" value={totpCode} onChange={(e) => setTotpCode(e.target.value)} maxLength={6} required />}
          <Button type="submit" className="w-full">دخول</Button>
        </form>
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
