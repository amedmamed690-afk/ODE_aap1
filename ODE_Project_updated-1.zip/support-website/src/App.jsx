import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Lookup from './pages/Lookup.jsx';

function ProtectedRoute({ children }) {
  return localStorage.getItem('ode_support_token') ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<ProtectedRoute><Lookup /></ProtectedRoute>} />
    </Routes>
  );
}
