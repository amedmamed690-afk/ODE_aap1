/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT: '#6A0DAD', light: '#9B4DE0' },
        dark: { bg: '#120026', surface: '#1E0838', card: '#2A0F4A' },
      },
    },
  },
  plugins: [],
};
