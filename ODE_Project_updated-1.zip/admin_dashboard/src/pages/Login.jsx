import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Card, Button, Input, Toast } from '../components/ui.jsx';
import SetupWizard from './SetupWizard.jsx';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [totpCode, setTotpCode] = useState('');
  const [needsTotp, setNeedsTotp] = useState(false);
  const [toast, setToast] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  // طلب صريح (بند 5): "فتح لوحة الإدارة لأول مرة... إذا كانت غير مهيأة:
  // إجبار المستخدم على الدخول لشاشة الإعداد الأمني" — قبل عرض شاشة
  // الدخول العادية إطلاقًا، مو خيارًا يظهر بجانبها.
  const [needsSetup, setNeedsSetup] = useState(null); // null = جارِ الفحص
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoverForm, setRecoverForm] = useState({ email: '', keyPassword: '', referencePassword: '', newPassword: '' });

  useEffect(() => {
    api.getSetupStatus().then((r) => setNeedsSetup(r.needsSetup)).catch(() => setNeedsSetup(false));
  }, []);

  const submitRecovery = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await api.recoverAccount(recoverForm);
      setToast({ message: 'تم إعادة تعيين كلمة المرور — سجّل دخولك الآن', tone: 'success' });
      setShowRecovery(false);
    } catch (_) {
      setToast({ message: 'تعذر الاسترجاع — تحقق من البريد وكلمتي المرور المفتاحية والمرجعية', tone: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const result = await api.login({ email, password, ...(needsTotp ? { totpCode } : {}) });
      localStorage.setItem('ode_admin_token', result.token);
      localStorage.setItem('ode_admin_permissions', JSON.stringify(result.permissions || []));
      localStorage.setItem('ode_admin_is_super', String(result.isSuperAdmin));
      navigate(result.mustChangePassword ? '/change-password' : '/');
    } catch (err) {
      if (err.message === 'totp_required') {
        setNeedsTotp(true);
      } else {
        setToast({ message: 'بيانات الدخول غير صحيحة', tone: 'error' });
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (needsSetup === null) return null; // لحظة فحص قصيرة — لا نومض شاشة الدخول ثم نستبدلها فورًا
  if (needsSetup) return <SetupWizard />;

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <h1 className="text-xl font-bold text-primary-light mb-1">ODE — لوحة التحكم</h1>
        <p className="text-white/40 text-xs mb-6">حساب الإدارة فقط — مو نفس تسجيل دخول التطبيقات</p>

        {!showRecovery ? (
          <>
            <form onSubmit={submit} className="space-y-3">
              <Input label="البريد الإلكتروني" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              <Input label="كلمة المرور" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              {needsTotp && (
                <Input label="رمز التحقق بخطوتين" value={totpCode} onChange={(e) => setTotpCode(e.target.value)} maxLength={6} required />
              )}
              <Button type="submit" className="w-full" disabled={isLoading}>{isLoading ? 'جارِ الدخول...' : 'دخول'}</Button>
            </form>
            <button onClick={() => setShowRecovery(true)} className="text-xs text-white/40 hover:text-white/70 mt-4 block mx-auto">
              نسيت كلمة المرور؟
            </button>
          </>
        ) : (
          <form onSubmit={submitRecovery} className="space-y-3">
            <p className="text-xs text-white/50 mb-1">استرجاع باستخدام كلمتي المرور المفتاحية والمرجعية اللي حفظتهما وقت التهيئة</p>
            <Input label="البريد الإلكتروني" type="email" value={recoverForm.email} onChange={(e) => setRecoverForm({ ...recoverForm, email: e.target.value })} required />
            <Input label="كلمة المرور المفتاحية" type="password" value={recoverForm.keyPassword} onChange={(e) => setRecoverForm({ ...recoverForm, keyPassword: e.target.value })} required />
            <Input label="كلمة المرور المرجعية" type="password" value={recoverForm.referencePassword} onChange={(e) => setRecoverForm({ ...recoverForm, referencePassword: e.target.value })} required />
            <Input label="كلمة المرور الجديدة" type="password" value={recoverForm.newPassword} onChange={(e) => setRecoverForm({ ...recoverForm, newPassword: e.target.value })} required />
            <Button type="submit" className="w-full" disabled={isLoading}>{isLoading ? '...' : 'إعادة تعيين كلمة المرور'}</Button>
            <button type="button" onClick={() => setShowRecovery(false)} className="text-xs text-white/40 hover:text-white/70 block mx-auto">رجوع لتسجيل الدخول</button>
          </form>
        )}
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
