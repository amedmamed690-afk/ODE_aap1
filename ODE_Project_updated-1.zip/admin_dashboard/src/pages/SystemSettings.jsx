import React, { useState, useEffect } from 'react';
import { Settings, Store, UtensilsCrossed, Wrench, Car, Package, Wallet, Banknote, CreditCard } from 'lucide-react';
import { Card, Toast } from '../components/ui.jsx';
import { api } from '../api.js';

/**
 * طلب صريح (بند 2/3/4/9): "قسم واضح في لوحة الإدارة باسم System Settings"
 * يتحكم بتوفر كل خدمة ووسيلة دفع — القيم محفوظة بقاعدة البيانات فعليًا
 * (app_settings، نفس الجدول الذي GET /config/bootstrap يقدّمه لكل تطبيق)
 * والباك إند يتحقق منها مستقلًا بكل نقطة حرجة (order-flow.service.ts) —
 * تعطيل خيار هنا يمنع استخدامه فعليًا حتى لو نودي الـAPI مباشرة.
 */
const SERVICE_ITEMS = [
  { key: 'services.restaurants.enabled', label: 'المطاعم', icon: UtensilsCrossed },
  { key: 'services.stores.enabled', label: 'المتاجر', icon: Store },
  { key: 'services.home_services.enabled', label: 'الخدمات المنزلية', icon: Wrench },
  { key: 'services.rides.enabled', label: 'الرحلات (نقل الركاب)', icon: Car },
  { key: 'services.parcel.enabled', label: 'التوصيل السريع (طرود)', icon: Package },
];

const PAYMENT_ITEMS = [
  { key: 'services.wallet.enabled', label: 'المحفظة (ODE Pay)', icon: Wallet },
  { key: 'payment.cash.enabled', label: 'الدفع النقدي (Cash)', icon: Banknote },
  { key: 'payment.gateway.enabled', label: 'بوابة الدفع الإلكتروني (بطاقات)', icon: CreditCard, note: 'لن تعمل فعليًا حتى تُضبط بيانات المزود الحقيقية بالبيئة (STRIPE_SECRET_KEY) — تفعيلها هنا بدون ذلك يجعل العميل يختارها ويفشل الطلب برسالة واضحة، لا يكسر التطبيق.' },
];

export default function SystemSettings() {
  const [values, setValues] = useState(null);
  const [savingKey, setSavingKey] = useState(null);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    api.getSystemSettings().then(setValues).catch(() => setToast({ message: 'تعذر تحميل الإعدادات', tone: 'error' }));
  }, []);

  const toggle = async (key, current) => {
    const next = !current;
    setSavingKey(key);
    // تحديث متفائل (Optimistic) — يرجع للقيمة القديمة تلقائيًا لو فشل الحفظ
    setValues((v) => ({ ...v, [key]: next }));
    try {
      await api.updateSystemSetting(key, next);
      setToast({ message: `${next ? 'تم التفعيل' : 'تم التعطيل'} — ينعكس فورًا على التطبيقات`, tone: 'success' });
    } catch (err) {
      setValues((v) => ({ ...v, [key]: current })); // تراجع عن التحديث المتفائل
      setToast({ message: 'تعذر الحفظ — لم تتغيّر الحالة الفعلية', tone: 'error' });
    } finally {
      setSavingKey(null);
    }
  };

  if (!values) return <div className="text-white/40 text-sm">جاري التحميل...</div>;

  const renderGroup = (title, items) => (
    <Card className="mb-4">
      <h4 className="font-bold text-xs text-white/60 mb-3">{title}</h4>
      <div className="space-y-1">
        {items.map(({ key, label, icon: Icon, note }) => {
          const enabled = values[key] === true;
          return (
            <div key={key} className="py-3 border-b border-white/5 last:border-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Icon size={16} className="text-white/40" />
                  <span className="text-sm">{label}</span>
                </div>
                <button
                  onClick={() => toggle(key, enabled)}
                  disabled={savingKey === key}
                  style={{ direction: 'ltr' }}
                  className={`relative w-11 h-6 rounded-full transition-colors ${enabled ? 'bg-primary' : 'bg-white/10'} ${savingKey === key ? 'opacity-50' : ''}`}
                >
                  <span
                    className="absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform"
                    style={{ transform: enabled ? 'translateX(22px)' : 'translateX(2px)' }}
                  />
                </button>
              </div>
              {note && <p className="text-[10px] text-white/30 mt-1.5">{note}</p>}
            </div>
          );
        })}
      </div>
    </Card>
  );

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Settings size={16} className="text-primary-light" />
        <h3 className="font-bold text-sm">إعدادات النظام — الخدمات والدفع</h3>
      </div>
      {renderGroup('الخدمات', SERVICE_ITEMS)}
      {renderGroup('الدفع', PAYMENT_ITEMS)}
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
