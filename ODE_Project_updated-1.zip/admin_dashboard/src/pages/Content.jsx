import React, { useState, useEffect } from 'react';
import { Card, Button, Input, Toast, EmptyState } from '../components/ui.jsx';
import { api } from '../api.js';

export default function Content() {
  const [banners, setBanners] = useState([]);
  const [rewards, setRewards] = useState([]);
  const [plans, setPlans] = useState([]);
  const [inviteSettings, setInviteSettings] = useState(null);
  const [toast, setToast] = useState(null);

  const [bannerForm, setBannerForm] = useState({ titleAr: '', imageUrl: '' });
  const [rewardForm, setRewardForm] = useState({ nameAr: '', pointsCost: '', stockQty: '' });
  const [planForm, setPlanForm] = useState({ code: 'plus', nameAr: '', price: '', currencyId: 1, durationDays: 30 });
  const [broadcastForm, setBroadcastForm] = useState({ audience: 'all_customers', titleAr: '', bodyAr: '' });

  const load = () => {
    api.getBanners().then(setBanners).catch(() => {});
    api.getPointRewards().then(setRewards).catch(() => {});
    api.getSubscriptionPlans().then(setPlans).catch(() => {});
    api.getInviteSettings().then(setInviteSettings).catch(() => {});
  };
  useEffect(load, []);

  const notify = (message, tone = 'success') => setToast({ message, tone });

  const addBanner = async () => {
    try { await api.createBanner(bannerForm); setBannerForm({ titleAr: '', imageUrl: '' }); load(); notify('تمت الإضافة'); }
    catch { notify('تعذرت الإضافة', 'error'); }
  };
  const removeBanner = async (id) => { await api.deleteBanner(id); load(); };

  const addReward = async () => {
    try {
      await api.createPointReward({ ...rewardForm, pointsCost: Number(rewardForm.pointsCost), stockQty: Number(rewardForm.stockQty) });
      setRewardForm({ nameAr: '', pointsCost: '', stockQty: '' }); load(); notify('تمت الإضافة');
    } catch { notify('تعذرت الإضافة', 'error'); }
  };

  const addPlan = async () => {
    try {
      await api.createSubscriptionPlan({ ...planForm, price: Number(planForm.price), currencyId: Number(planForm.currencyId), durationDays: Number(planForm.durationDays), benefits: [] });
      setPlanForm({ code: 'plus', nameAr: '', price: '', currencyId: 1, durationDays: 30 }); load(); notify('تمت الإضافة');
    } catch { notify('تعذرت الإضافة', 'error'); }
  };

  const saveInviteSettings = async () => {
    try { await api.updateInviteSettings(inviteSettings); notify('تم الحفظ'); }
    catch { notify('تعذر الحفظ', 'error'); }
  };

  const sendBroadcast = async () => {
    try {
      const result = await api.sendBroadcast(broadcastForm);
      notify(result.message);
      setBroadcastForm({ audience: 'all_customers', titleAr: '', bodyAr: '' });
    } catch { notify('تعذر الإرسال', 'error'); }
  };

  return (
    <div>
      <Card className="mb-4">
        <h3 className="font-bold text-sm mb-3">البانرات الإعلانية (بند 16/26)</h3>
        <div className="flex gap-2 mb-3">
          <Input placeholder="العنوان" value={bannerForm.titleAr} onChange={(e) => setBannerForm((s) => ({ ...s, titleAr: e.target.value }))} />
          <Input placeholder="رابط الصورة" value={bannerForm.imageUrl} onChange={(e) => setBannerForm((s) => ({ ...s, imageUrl: e.target.value }))} />
          <Button onClick={addBanner}>إضافة</Button>
        </div>
        {banners.length === 0 ? <EmptyState text="لا توجد بانرات" /> : (
          <div className="space-y-1.5">
            {banners.map((b) => (
              <div key={b.id} className="flex justify-between bg-dark-surface rounded-lg px-3 py-2 text-xs">
                <span>{b.title_ar}</span>
                <button onClick={() => removeBanner(b.id)} className="text-red-400">حذف</button>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="mb-4">
        <h3 className="font-bold text-sm mb-3">جوائز النقاط (بند 18)</h3>
        <div className="flex gap-2 mb-3">
          <Input placeholder="اسم الجائزة" value={rewardForm.nameAr} onChange={(e) => setRewardForm((s) => ({ ...s, nameAr: e.target.value }))} />
          <Input placeholder="تكلفة بالنقاط" type="number" value={rewardForm.pointsCost} onChange={(e) => setRewardForm((s) => ({ ...s, pointsCost: e.target.value }))} />
          <Input placeholder="الكمية" type="number" value={rewardForm.stockQty} onChange={(e) => setRewardForm((s) => ({ ...s, stockQty: e.target.value }))} />
          <Button onClick={addReward}>إضافة</Button>
        </div>
        {rewards.length === 0 ? <EmptyState text="لا توجد جوائز" /> : (
          <div className="space-y-1.5">{rewards.map((r) => <div key={r.id} className="bg-dark-surface rounded-lg px-3 py-2 text-xs">{r.name_ar} — {r.points_cost} نقطة — متبقي {r.stock_qty}</div>)}</div>
        )}
      </Card>

      <Card className="mb-4">
        <h3 className="font-bold text-sm mb-3">خطط الاشتراك — ODE Plus/Pro (بند 17)</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-3">
          <select value={planForm.code} onChange={(e) => setPlanForm((s) => ({ ...s, code: e.target.value }))} className="bg-dark-surface border border-white/10 rounded-xl px-3 text-sm">
            <option value="plus">ODE Plus</option><option value="pro">ODE Pro</option>
          </select>
          <Input placeholder="الاسم" value={planForm.nameAr} onChange={(e) => setPlanForm((s) => ({ ...s, nameAr: e.target.value }))} />
          <Input placeholder="السعر" type="number" value={planForm.price} onChange={(e) => setPlanForm((s) => ({ ...s, price: e.target.value }))} />
          <Input placeholder="عدد الأيام" type="number" value={planForm.durationDays} onChange={(e) => setPlanForm((s) => ({ ...s, durationDays: e.target.value }))} />
          <Button onClick={addPlan}>إضافة</Button>
        </div>
        {plans.length === 0 ? <EmptyState text="لا توجد خطط بعد" /> : (
          <div className="space-y-1.5">{plans.map((p) => <div key={p.id} className="bg-dark-surface rounded-lg px-3 py-2 text-xs">{p.name_ar} ({p.code}) — {p.price} / {p.duration_days} يوم</div>)}</div>
        )}
      </Card>

      {inviteSettings && (
        <Card className="mb-4">
          <h3 className="font-bold text-sm mb-3">إعدادات نظام الدعوات (بند 19)</h3>
          <div className="grid grid-cols-3 gap-2 mb-3">
            <Input label="مدة الإكمال (يوم)" type="number" value={inviteSettings.completion_window_days}
              onChange={(e) => setInviteSettings((s) => ({ ...s, completionWindowDays: Number(e.target.value) }))} />
            <Input label="مكافأة الداعي (نقطة)" type="number" value={inviteSettings.inviter_reward_points}
              onChange={(e) => setInviteSettings((s) => ({ ...s, inviterRewardPoints: Number(e.target.value) }))} />
            <Input label="مكافأة المدعو (نقطة)" type="number" value={inviteSettings.invitee_reward_points}
              onChange={(e) => setInviteSettings((s) => ({ ...s, inviteeRewardPoints: Number(e.target.value) }))} />
          </div>
          <Button onClick={saveInviteSettings}>حفظ</Button>
        </Card>
      )}

      <Card>
        <h3 className="font-bold text-sm mb-3">إشعار جماعي (بند 15)</h3>
        <div className="grid grid-cols-3 gap-2 mb-3">
          <select value={broadcastForm.audience} onChange={(e) => setBroadcastForm((s) => ({ ...s, audience: e.target.value }))} className="bg-dark-surface border border-white/10 rounded-xl px-3 text-sm">
            <option value="all_customers">كل العملاء</option><option value="all_drivers">كل السائقين</option><option value="all_partners">كل الشركاء</option>
          </select>
          <Input placeholder="العنوان" value={broadcastForm.titleAr} onChange={(e) => setBroadcastForm((s) => ({ ...s, titleAr: e.target.value }))} />
          <Input placeholder="النص" value={broadcastForm.bodyAr} onChange={(e) => setBroadcastForm((s) => ({ ...s, bodyAr: e.target.value }))} />
        </div>
        <Button onClick={sendBroadcast}>إرسال</Button>
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
