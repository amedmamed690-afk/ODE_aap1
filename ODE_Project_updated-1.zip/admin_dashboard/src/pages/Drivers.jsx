import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Pause, RotateCcw } from 'lucide-react';
import { Card, Button, Table, Badge, Toast, Modal, Input } from '../components/ui.jsx';
import { api } from '../api.js';

const STATUS_TABS = [
  { key: 'pending', label: 'قيد المراجعة' },
  { key: 'active', label: 'مفعّل' },
  { key: 'rejected', label: 'مرفوض' },
  { key: 'suspended', label: 'موقوف' },
];

export default function Drivers() {
  const [status, setStatus] = useState('pending');
  const [drivers, setDrivers] = useState([]);
  const [toast, setToast] = useState(null);
  const [reasonModal, setReasonModal] = useState(null); // { driverId, action }
  const [reason, setReason] = useState('');

  const load = () => api.getDrivers(status).then(setDrivers).catch(() => setDrivers([]));
  useEffect(load, [status]);

  const approve = async (id) => {
    try {
      await api.approveDriver(id);
      setToast({ message: 'تم قبول السائق', tone: 'success' });
      load();
    } catch {
      setToast({ message: 'تعذر القبول', tone: 'error' });
    }
  };

  const submitReason = async () => {
    if (!reason.trim()) return;
    try {
      if (reasonModal.action === 'reject') await api.rejectDriver(reasonModal.driverId, reason);
      if (reasonModal.action === 'suspend') await api.suspendDriver(reasonModal.driverId, reason);
      setToast({ message: 'تم', tone: 'success' });
      setReasonModal(null); setReason('');
      load();
    } catch {
      setToast({ message: 'تعذر الإجراء', tone: 'error' });
    }
  };

  const reinstate = async (id) => {
    try {
      await api.reinstateDriver(id);
      setToast({ message: 'تم رفع الإيقاف', tone: 'success' });
      load();
    } catch {
      setToast({ message: 'تعذر الإجراء', tone: 'error' });
    }
  };

  // مستندات الهوية بـbucket منفصل غير عام (بند 8) — الرابط المخزّن هو
  // مجرد مفتاح تخزين، لازم نولّد رابط مؤقت الصلاحية قبل الفتح مباشرة.
  const viewDocument = async (key) => {
    try {
      const { url } = await api.getDocumentViewUrl(key);
      window.open(url, '_blank');
    } catch {
      setToast({ message: 'تعذر فتح المستند', tone: 'error' });
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {STATUS_TABS.map((t) => (
          <button key={t.key} onClick={() => setStatus(t.key)}
            className={`px-3 py-1.5 rounded-lg text-xs ${status === t.key ? 'bg-primary text-white' : 'bg-white/5 text-white/50'}`}>
            {t.label}
          </button>
        ))}
      </div>
      <Card>
        <Table
          columns={['السائق', 'الهاتف', 'المركبة', 'اللوحة', 'المستندات', 'إجراءات']}
          rows={drivers}
          renderRow={(d) => (
            <tr key={d.id}>
              <td className="py-3 px-2">{d.full_name || '—'}</td>
              <td className="py-3 px-2 text-white/60">{d.phone}</td>
              <td className="py-3 px-2 text-white/60">{d.vehicle_type}</td>
              <td className="py-3 px-2 text-white/60">{d.plate_number}</td>
              <td className="py-3 px-2">
                {d.license_doc_url ? <button onClick={() => viewDocument(d.license_doc_url)} className="text-primary-light underline text-xs bg-transparent border-none cursor-pointer">عرض الرخصة</button> : '—'}
              </td>
              <td className="py-3 px-2">
                <div className="flex gap-2">
                  {status === 'pending' && (
                    <>
                      <button onClick={() => approve(d.id)} className="text-emerald-400" title="قبول"><CheckCircle size={18} /></button>
                      <button onClick={() => setReasonModal({ driverId: d.id, action: 'reject' })} className="text-red-400" title="رفض"><XCircle size={18} /></button>
                    </>
                  )}
                  {status === 'active' && (
                    <button onClick={() => setReasonModal({ driverId: d.id, action: 'suspend' })} className="text-amber-400" title="إيقاف"><Pause size={18} /></button>
                  )}
                  {status === 'suspended' && (
                    <button onClick={() => reinstate(d.id)} className="text-emerald-400" title="رفع الإيقاف"><RotateCcw size={18} /></button>
                  )}
                  {d.rejected_reason && <Badge tone="danger">{d.rejected_reason}</Badge>}
                </div>
              </td>
            </tr>
          )}
        />
      </Card>

      <Modal open={!!reasonModal} onClose={() => setReasonModal(null)} title={reasonModal?.action === 'reject' ? 'سبب الرفض' : 'سبب الإيقاف'}>
        <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="اكتب السبب هنا..." />
        <Button className="w-full mt-4" onClick={submitReason}>تأكيد</Button>
      </Modal>

      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
