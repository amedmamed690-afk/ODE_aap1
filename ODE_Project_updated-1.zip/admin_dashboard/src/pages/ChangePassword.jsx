import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Card, Button, Input, Toast } from '../components/ui.jsx';

export default function ChangePassword() {
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [toast, setToast] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.changePassword({ currentPassword, newPassword });
      navigate('/');
    } catch {
      setToast({ message: 'تعذر تحديث كلمة المرور', tone: 'error' });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <h1 className="text-lg font-bold mb-1">غيّر كلمة المرور المؤقتة</h1>
        <p className="text-white/40 text-xs mb-6">إجباري قبل أول استخدام لأي حساب أدمن جديد</p>
        <form onSubmit={submit} className="space-y-3">
          <Input label="كلمة المرور المؤقتة" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
          <Input label="كلمة المرور الجديدة" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} minLength={8} required />
          <Button type="submit" className="w-full">حفظ</Button>
        </form>
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
