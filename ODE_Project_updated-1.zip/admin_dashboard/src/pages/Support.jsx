import React, { useState } from 'react';
import { Headphones, Search, X } from 'lucide-react';
import { Card, Table, Badge, Button, Input, Modal, Toast, EmptyState } from '../components/ui.jsx';
import { api } from '../api.js';

/**
 * صفحة الدعم — كانت فجوة D حقيقية (تقرير الجولة الثانية): موديول
 * support.routes.ts موجود بالـBackend بالكامل (بحث عميل، تفاصيل طلب،
 * إضافة ملاحظة) لكن بدون أي واجهة إطلاقًا. تتطلب صلاحية 'support.access'
 * بحساب الأدمن نفسه — لو الحساب الحالي لا يملكها، الـBackend يرفض
 * بـ403 وتظهر رسالة خطأ واضحة بدل صفحة فارغة صامتة.
 */

const ORDER_STATUS_LABELS = {
  // إصلاح: نفس الخلل (الأسماء ما كانت تطابق حالات الباك إند الحقيقية) —
  // موجود بهذا الملف نفسه من يوم بنيته، صححته الآن.
  placed: 'قيد الانتظار', accepted_by_partner: 'مقبول', preparing: 'قيد التجهيز',
  ready_for_pickup: 'بانتظار سائق', driver_assigned: 'السائق بالطريق', picked_up: 'تم الاستلام',
  on_the_way: 'في الطريق', delivered: 'تم التوصيل', cancelled: 'ملغي', rejected: 'مرفوض',
};

const RIDE_STATUS_LABELS = {
  requested: 'بانتظار سائق', driver_assigned: 'السائق بالطريق', driver_arrived: 'السائق وصل',
  in_progress: 'الرحلة جارية', completed: 'اكتملت', cancelled: 'أُلغيت',
};

export default function Support() {
  const [phone, setPhone] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [result, setResult] = useState(null); // { customer, recentOrders, recentRides }
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [orderDetail, setOrderDetail] = useState(null);
  const [noteText, setNoteText] = useState('');
  const [isSavingNote, setIsSavingNote] = useState(false);
  const [toast, setToast] = useState(null);

  const search = async (e) => {
    e.preventDefault();
    if (!phone.trim()) return;
    setIsSearching(true);
    setNotFound(false);
    setResult(null);
    try {
      const data = await api.searchSupportCustomer(phone.trim());
      setResult(data);
    } catch (err) {
      if (err.message === 'customer_not_found') setNotFound(true);
      else setToast({ message: 'تعذر البحث — تحقق من صلاحية الوصول لموديول الدعم بحسابك', tone: 'error' });
    } finally {
      setIsSearching(false);
    }
  };

  const openOrder = async (orderId) => {
    setSelectedOrderId(orderId);
    setOrderDetail(null);
    setNoteText('');
    try {
      const data = await api.getSupportOrder(orderId);
      setOrderDetail(data);
    } catch {
      setToast({ message: 'تعذر تحميل تفاصيل الطلب', tone: 'error' });
    }
  };

  const saveNote = async () => {
    if (!noteText.trim()) return;
    setIsSavingNote(true);
    try {
      await api.addSupportNote(selectedOrderId, noteText.trim());
      setToast({ message: 'تمت إضافة الملاحظة', tone: 'success' });
      setNoteText('');
      const data = await api.getSupportOrder(selectedOrderId); // تحديث الـTimeline فورًا بالملاحظة الجديدة
      setOrderDetail(data);
    } catch {
      setToast({ message: 'تعذر حفظ الملاحظة', tone: 'error' });
    } finally {
      setIsSavingNote(false);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Headphones size={16} className="text-primary-light" />
        <h3 className="font-bold text-sm">دعم العملاء — بحث بسرعة عن عميل وطلباته</h3>
      </div>

      <Card className="mb-4">
        <form onSubmit={search} className="flex items-end gap-3">
          <Input label="رقم هاتف العميل" placeholder="مثال: 966501234567" value={phone}
            onChange={(e) => setPhone(e.target.value)} className="flex-1" />
          <Button type="submit" disabled={isSearching}>
            <span className="flex items-center gap-1.5"><Search size={14} /> بحث</span>
          </Button>
        </form>
      </Card>

      {notFound && <EmptyState text="لا يوجد عميل بهذا الرقم" />}

      {result && (
        <>
          <Card className="mb-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-sm">{result.customer.full_name || 'بدون اسم'}</div>
                <div className="text-white/50 text-xs mt-1">{result.customer.phone} {result.customer.email ? `— ${result.customer.email}` : ''}</div>
                <div className="text-white/30 text-xs mt-1">عضو منذ {new Date(result.customer.created_at).toLocaleDateString('ar')}</div>
              </div>
              <Badge tone={result.customer.is_blocked ? 'danger' : 'success'}>
                {result.customer.is_blocked ? 'محظور' : 'فعّال'}
              </Badge>
            </div>
          </Card>

          <Card className="mb-4">
            <h4 className="font-bold text-xs text-white/60 mb-3">آخر الطلبات</h4>
            <Table
              columns={['رقم الطلب', 'الحالة', 'الإجمالي', 'التاريخ', '']}
              rows={result.recentOrders}
              renderRow={(o) => (
                <tr key={o.id}>
                  <td className="py-3 px-2">#{o.order_number}</td>
                  <td className="py-3 px-2"><Badge tone={o.status === 'delivered' ? 'success' : o.status === 'cancelled' ? 'danger' : 'default'}>{ORDER_STATUS_LABELS[o.status] || o.status}</Badge></td>
                  <td className="py-3 px-2">{o.total}</td>
                  <td className="py-3 px-2 text-white/40">{new Date(o.created_at).toLocaleDateString('ar')}</td>
                  <td className="py-3 px-2"><Button variant="ghost" onClick={() => openOrder(o.id)}>عرض التفاصيل</Button></td>
                </tr>
              )}
            />
          </Card>

          <Card>
            <h4 className="font-bold text-xs text-white/60 mb-3">آخر الرحلات</h4>
            <Table
              columns={['الحالة', 'السعر المقدّر', 'التاريخ']}
              rows={result.recentRides}
              renderRow={(r) => (
                <tr key={r.id}>
                  <td className="py-3 px-2"><Badge tone={r.status === 'completed' ? 'success' : r.status === 'cancelled' ? 'danger' : 'default'}>{RIDE_STATUS_LABELS[r.status] || r.status}</Badge></td>
                  <td className="py-3 px-2">{r.estimated_fare}</td>
                  <td className="py-3 px-2 text-white/40">{new Date(r.requested_at).toLocaleDateString('ar')}</td>
                </tr>
              )}
            />
          </Card>
        </>
      )}

      <Modal open={!!selectedOrderId} onClose={() => setSelectedOrderId(null)} title="تفاصيل الطلب">
        {!orderDetail ? (
          <div className="text-white/40 text-xs">جاري التحميل...</div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-bold">#{orderDetail.order.order_number}</div>
              <button onClick={() => setSelectedOrderId(null)} className="text-white/40 hover:text-white"><X size={16} /></button>
            </div>
            <div className="text-xs text-white/60">
              {orderDetail.order.customer_name} — {orderDetail.order.customer_phone}
            </div>
            <div className="text-xs">
              الحالة الحالية: <Badge tone={orderDetail.order.status === 'delivered' ? 'success' : orderDetail.order.status === 'cancelled' ? 'danger' : 'default'}>{ORDER_STATUS_LABELS[orderDetail.order.status] || orderDetail.order.status}</Badge>
            </div>

            <div>
              <h5 className="text-xs font-bold text-white/50 mb-2">سجل الحالة</h5>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {orderDetail.history.map((h, i) => (
                  <div key={i} className="text-xs bg-dark-surface rounded-lg px-3 py-2">
                    <div className="flex justify-between">
                      <span className="text-white/70">{ORDER_STATUS_LABELS[h.status] || h.status}</span>
                      <span className="text-white/30">{new Date(h.created_at).toLocaleString('ar')}</span>
                    </div>
                    {h.note && <div className="text-white/40 mt-1">{h.note}</div>}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h5 className="text-xs font-bold text-white/50 mb-2">إضافة ملاحظة دعم (توثيق داخلي فقط — لا تغيّر حالة الطلب)</h5>
              <textarea value={noteText} onChange={(e) => setNoteText(e.target.value)} rows={3}
                className="w-full bg-dark-surface border border-white/10 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary-light"
                placeholder="مثال: تواصل العميل عبر الهاتف بخصوص تأخر التوصيل..." />
              <div className="mt-2 flex justify-end">
                <Button onClick={saveNote} disabled={isSavingNote || !noteText.trim()}>حفظ الملاحظة</Button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
