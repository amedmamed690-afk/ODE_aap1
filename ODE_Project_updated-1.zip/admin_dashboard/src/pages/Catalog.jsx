import React, { useState, useEffect } from 'react';
import { Card, Button, Input, Toast, EmptyState } from '../components/ui.jsx';
import { api } from '../api.js';

function Section({ title, items, renderItem, form, onCreated, api: apiKey, extraArgs = {} }) {
  const [fields, setFields] = useState({});
  const [toast, setToast] = useState(null);

  const submit = async () => {
    try {
      await api[apiKey]({ ...fields, ...extraArgs });
      setFields({});
      onCreated();
      setToast({ message: 'تمت الإضافة', tone: 'success' });
    } catch {
      setToast({ message: 'تعذرت الإضافة', tone: 'error' });
    }
  };

  return (
    <Card className="mb-4">
      <h3 className="font-bold text-sm mb-3">{title}</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
        {form.map((f) => (
          <Input key={f.key} placeholder={f.label} value={fields[f.key] || ''}
            onChange={(e) => setFields((s) => ({ ...s, [f.key]: f.number ? Number(e.target.value) : e.target.value }))} />
        ))}
        <Button onClick={submit}>إضافة</Button>
      </div>
      {items.length === 0 ? <EmptyState text="لا توجد عناصر بعد" /> : (
        <div className="space-y-1.5">{items.map(renderItem)}</div>
      )}
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </Card>
  );
}

export default function Catalog() {
  const [countries, setCountries] = useState([]);
  const [currencies, setCurrencies] = useState([]);
  const [rideCategories, setRideCategories] = useState([]);
  const [activityCategories, setActivityCategories] = useState([]);
  const [digitalSubtypes, setDigitalSubtypes] = useState([]);
  const [homeServices, setHomeServices] = useState([]);

  const loadAll = () => {
    api.getCountries().then(setCountries).catch(() => {});
    api.getCurrencies().then(setCurrencies).catch(() => {});
    api.getRideCategories().then(setRideCategories).catch(() => {});
    api.getPartnerActivityCategories().then(setActivityCategories).catch(() => {});
    api.getPartnerDigitalSubtypes().then(setDigitalSubtypes).catch(() => {});
    api.getHomeServices().then(setHomeServices).catch(() => {});
  };
  useEffect(loadAll, []);

  const row = (text, key) => <div key={key} className="bg-dark-surface rounded-lg px-3 py-2 text-xs">{text}</div>;

  return (
    <div>
      <Section title="الدول (بند 24)" items={countries} onCreated={loadAll} apiKey="createCountry"
        form={[{ key: 'isoCode', label: 'رمز ISO مثل SA' }, { key: 'nameAr', label: 'الاسم بالعربي' }, { key: 'nameEn', label: 'Name in English' }]}
        renderItem={(c) => row(`${c.name_ar} (${c.iso_code})`, c.id)} />

      <Section title="العملات (بند 25)" items={currencies} onCreated={loadAll} apiKey="createCurrency"
        form={[{ key: 'code', label: 'الرمز مثل SAR' }, { key: 'symbol', label: 'رمز العرض ر.س' }, { key: 'nameAr', label: 'الاسم بالعربي' }, { key: 'nameEn', label: 'Name in English' }]}
        renderItem={(c) => row(`${c.name_ar} (${c.symbol})`, c.id)} />

      <Section title="فئات الرحلات/التوصيل (بند 5/6)" items={rideCategories} onCreated={loadAll} apiKey="createRideCategory"
        form={[
          { key: 'domain', label: "delivery أو ride" }, { key: 'groupType', label: 'passenger أو heavy_transport' },
          { key: 'nameAr', label: 'الاسم بالعربي' }, { key: 'nameEn', label: 'Name in English' },
          { key: 'baseFare', label: 'السعر الأساسي', number: true }, { key: 'ratePerKm', label: 'السعر لكل كم', number: true },
        ]}
        renderItem={(c) => row(`${c.name_ar} — ${c.domain} — أساس ${c.base_fare} + ${c.rate_per_km}/كم`, c.id)} />

      <Section title="فئات نشاط الشريك (بند 7)" items={activityCategories} onCreated={loadAll} apiKey="createPartnerActivityCategory"
        form={[{ key: 'nameAr', label: 'الاسم بالعربي' }, { key: 'nameEn', label: 'Name in English' }]}
        renderItem={(c) => row(c.name_ar, c.id)} />

      <Section title="أنواع المتاجر الرقمية (بند 7)" items={digitalSubtypes} onCreated={loadAll} apiKey="createPartnerDigitalSubtype"
        form={[{ key: 'nameAr', label: 'الاسم بالعربي' }, { key: 'nameEn', label: 'Name in English' }]}
        renderItem={(c) => row(c.name_ar, c.id)} />

      <Section title="الخدمات المنزلية (بند 4)" items={homeServices} onCreated={loadAll} apiKey="createHomeService"
        form={[
          { key: 'countryId', label: 'رقم الدولة', number: true }, { key: 'nameAr', label: 'الاسم بالعربي' },
          { key: 'nameEn', label: 'Name in English' }, { key: 'basePrice', label: 'السعر الأساسي', number: true },
          { key: 'currencyId', label: 'رقم العملة', number: true },
        ]}
        renderItem={(c) => row(`${c.name_ar} — ${c.base_price}`, c.id)} />
    </div>
  );
}
