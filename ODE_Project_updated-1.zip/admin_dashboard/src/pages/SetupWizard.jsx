import React, { useState } from 'react';
import { Card, Button, Input, Toast } from '../components/ui.jsx';
import { api } from '../api.js';

/**
 * طلب صريح (بند 5) — معالج تهيئة أمان إجباري لأول فتح للوحة الإدارة.
 * التدفق بالضبط كما طُلب: بريد → هاتف أول + OTP → هاتف ثانٍ + OTP →
 * كلمة مرور + كلمة مرور مفتاحية + كلمة مرور مرجعية + اسم مستخدم → تأكيد.
 * "جميع هذه البيانات مطلوبة ولا يمكن تخطي أي خطوة منها" — كل خطوة هنا
 * تتطلب نجاح الخطوة السابقة فعليًا بالسيرفر قبل الانتقال للتالية.
 */
const STEPS = ['bootstrap', 'phone1', 'otp1', 'phone2', 'otp2', 'secrets', 'confirm', 'done'];

export default function SetupWizard() {
  const [step, setStep] = useState('bootstrap');
  const [toast, setToast] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const [setupSessionId, setSetupSessionId] = useState(null);
  const [email, setEmail] = useState('');
  const [bootstrapSecret, setBootstrapSecret] = useState('');
  const [phone1, setPhone1] = useState('');
  const [otp1, setOtp1] = useState('');
  const [phone2, setPhone2] = useState('');
  const [otp2, setOtp2] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [keyPassword, setKeyPassword] = useState('');
  const [referencePassword, setReferencePassword] = useState('');

  const fail = (msg) => setToast({ message: msg, tone: 'error' });

  const startSetup = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const { setupSessionId: id } = await api.setupStart({ email, bootstrapSecret });
      setSetupSessionId(id);
      setStep('phone1');
    } catch (err) {
      fail(err.message === 'invalid_bootstrap_secret' ? 'سر التهيئة غير صحيح' : 'تعذر بدء التهيئة');
    } finally {
      setIsLoading(false);
    }
  };

  const requestOtp = async (which, phone) => {
    setIsLoading(true);
    try {
      await api.setupRequestPhoneOtp({ setupSessionId, which, phone });
      setStep(which === 1 ? 'otp1' : 'otp2');
    } catch (err) {
      fail(err.message === 'second_phone_must_differ' ? 'الهاتف الثاني يجب أن يختلف عن الأول' : 'تعذر إرسال رمز التحقق');
    } finally {
      setIsLoading(false);
    }
  };

  const verifyOtp = async (which, code) => {
    setIsLoading(true);
    try {
      await api.setupVerifyPhoneOtp({ setupSessionId, which, code });
      setStep(which === 1 ? 'phone2' : 'secrets');
    } catch (err) {
      fail('رمز التحقق غير صحيح أو منتهي الصلاحية');
    } finally {
      setIsLoading(false);
    }
  };

  const submitAll = async () => {
    if (password === keyPassword || password === referencePassword || keyPassword === referencePassword) {
      return fail('لا يمكن أن تتكرر أي من كلمات المرور الثلاث — يجب أن تكون مختلفة جميعًا');
    }
    setIsLoading(true);
    try {
      await api.setupComplete({ setupSessionId, username, password, keyPassword, referencePassword });
      setStep('done');
    } catch (err) {
      fail(err.message === 'username_taken' ? 'اسم المستخدم مستخدم بالفعل' : 'تعذر إكمال التهيئة');
    } finally {
      setIsLoading(false);
    }
  };

  const stepIndex = STEPS.indexOf(step);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <h1 className="text-xl font-bold text-primary-light mb-1">تهيئة أمان لوحة الإدارة</h1>
        <p className="text-white/40 text-xs mb-4">أول استخدام للوحة — إعداد إجباري لمرة واحدة فقط</p>
        <div className="flex gap-1 mb-6">
          {STEPS.slice(0, 7).map((s, i) => (
            <div key={s} className={`h-1 flex-1 rounded-full ${i <= stepIndex ? 'bg-primary' : 'bg-white/10'}`} />
          ))}
        </div>

        {step === 'bootstrap' && (
          <form onSubmit={startSetup} className="space-y-3">
            <Input label="البريد الإلكتروني" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <Input label="سر التهيئة (ADMIN_BOOTSTRAP_SECRET)" type="password" value={bootstrapSecret} onChange={(e) => setBootstrapSecret(e.target.value)} required />
            <Button type="submit" className="w-full" disabled={isLoading}>{isLoading ? '...' : 'التالي'}</Button>
          </form>
        )}

        {step === 'phone1' && (
          <div className="space-y-3">
            <p className="text-xs text-white/50">أدخل رقم الهاتف الأول — سنرسل رمز تحقق إليه</p>
            <Input label="رقم الهاتف الأول" value={phone1} onChange={(e) => setPhone1(e.target.value)} placeholder="+9665xxxxxxxx" />
            <Button className="w-full" disabled={isLoading || !phone1} onClick={() => requestOtp(1, phone1)}>{isLoading ? '...' : 'إرسال رمز التحقق'}</Button>
          </div>
        )}
        {step === 'otp1' && (
          <div className="space-y-3">
            <p className="text-xs text-white/50">أدخل الرمز المُرسَل إلى {phone1}</p>
            <Input label="رمز التحقق" value={otp1} onChange={(e) => setOtp1(e.target.value)} maxLength={6} />
            <Button className="w-full" disabled={isLoading || otp1.length !== 6} onClick={() => verifyOtp(1, otp1)}>{isLoading ? '...' : 'تأكيد'}</Button>
          </div>
        )}

        {step === 'phone2' && (
          <div className="space-y-3">
            <p className="text-xs text-white/50">أدخل رقم هاتف ثانٍ مختلف — للتحقق الإضافي</p>
            <Input label="رقم الهاتف الثاني" value={phone2} onChange={(e) => setPhone2(e.target.value)} placeholder="+9665xxxxxxxx" />
            <Button className="w-full" disabled={isLoading || !phone2} onClick={() => requestOtp(2, phone2)}>{isLoading ? '...' : 'إرسال رمز التحقق'}</Button>
          </div>
        )}
        {step === 'otp2' && (
          <div className="space-y-3">
            <p className="text-xs text-white/50">أدخل الرمز المُرسَل إلى {phone2}</p>
            <Input label="رمز التحقق" value={otp2} onChange={(e) => setOtp2(e.target.value)} maxLength={6} />
            <Button className="w-full" disabled={isLoading || otp2.length !== 6} onClick={() => verifyOtp(2, otp2)}>{isLoading ? '...' : 'تأكيد'}</Button>
          </div>
        )}

        {step === 'secrets' && (
          <div className="space-y-3">
            <Input label="اسم مستخدم لوحة الإدارة" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="أحرف/أرقام إنجليزية فقط" />
            <Input label="كلمة المرور" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <Input label="كلمة المرور المفتاحية" type="password" value={keyPassword} onChange={(e) => setKeyPassword(e.target.value)} />
            <Input label="كلمة المرور المرجعية" type="password" value={referencePassword} onChange={(e) => setReferencePassword(e.target.value)} />
            <p className="text-[10px] text-white/30">الكلمتان المفتاحية والمرجعية تُستخدمان لاحقًا لاسترجاع الوصول لو نسيت كلمة المرور أو فقدت هاتفك — احفظهما بمكان آمن منفصل، لن تُعرضا لك مرة أخرى.</p>
            <Button className="w-full" disabled={isLoading || !username || !password || !keyPassword || !referencePassword} onClick={() => setStep('confirm')}>التالي</Button>
          </div>
        )}

        {step === 'confirm' && (
          <div className="space-y-3">
            <p className="text-xs text-white/60">راجع بياناتك قبل التأكيد النهائي:</p>
            <div className="bg-dark-surface rounded-xl p-3 text-xs space-y-1 text-white/50">
              <p>البريد: {email}</p>
              <p>الهاتف الأول: {phone1}</p>
              <p>الهاتف الثاني: {phone2}</p>
              <p>اسم المستخدم: {username}</p>
            </div>
            <Button className="w-full" disabled={isLoading} onClick={submitAll}>{isLoading ? 'جارِ الحفظ...' : 'تأكيد وإكمال التهيئة'}</Button>
          </div>
        )}

        {step === 'done' && (
          <div className="space-y-3 text-center">
            <p className="text-sm text-green-400">تم إعداد حسابك بنجاح 🎉</p>
            <p className="text-xs text-white/50">سجّل دخولك الآن بالبريد وكلمة المرور</p>
            <Button className="w-full" onClick={() => window.location.href = '/login'}>الذهاب لتسجيل الدخول</Button>
          </div>
        )}
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
