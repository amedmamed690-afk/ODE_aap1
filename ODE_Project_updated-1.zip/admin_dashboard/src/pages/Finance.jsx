import React, { useState, useEffect } from 'react';
import { Card, Button, Input, Toast, EmptyState, Table } from '../components/ui.jsx';
import { api } from '../api.js';

const SETTING_LABELS = {
  commission_restaurants: 'عمولة المطاعم %', commission_stores: 'عمولة المتاجر %',
  commission_delivery: 'عمولة التوصيل %', commission_passenger: 'عمولة نقل الركاب %',
  fee_driver_registration: 'رسوم تسجيل سائق', fee_store_registration: 'رسوم تسجيل متجر',
  fee_page_creation: 'رسوم إنشاء صفحة', fee_delivery_base: 'رسوم التوصيل الأساسية',
  driver_timeout_minutes: 'مهلة تنبيه السائق (دقيقة) — بند 21', order_cancellation_grace_minutes: 'مهلة إلغاء الطلب (دقيقة) — بند 20',
};

export default function Finance() {
  const [settings, setSettings] = useState({});
  const [codes, setCodes] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [settlements, setSettlements] = useState([]);
  const [batchCount, setBatchCount] = useState(10);
  const [batchValue, setBatchValue] = useState(50);
  const [generatedCodes, setGeneratedCodes] = useState(null);
  const [toast, setToast] = useState(null);

  const load = () => {
    api.getFinanceSettings().then(setSettings).catch(() => {});
    api.getTopupCodes().then(setCodes).catch(() => {});
    api.getWithdrawals().then(setWithdrawals).catch(() => {});
    api.getSettlements().then(setSettlements).catch(() => {});
  };
  useEffect(load, []);

  const saveSetting = async (key, value) => {
    try {
      await api.updateFinanceSetting(key, Number(value));
      setToast({ message: 'تم الحفظ', tone: 'success' });
    } catch {
      setToast({ message: 'تعذر الحفظ', tone: 'error' });
    }
  };

  const generateCodes = async () => {
    try {
      const result = await api.generateTopupCodes({ count: Number(batchCount), value: Number(batchValue) });
      setGeneratedCodes(result.codes);
      load();
    } catch {
      setToast({ message: 'تعذر التوليد', tone: 'error' });
    }
  };

  const markWithdrawalPaid = async (id) => {
    try {
      await api.markWithdrawalPaid(id);
      setToast({ message: 'تم', tone: 'success' });
      load();
    } catch {
      setToast({ message: 'تعذر — تأكد من الدفع الفعلي أولاً', tone: 'error' });
    }
  };

  const markSettlementPaid = async (id) => {
    try {
      await api.markSettlementPaid(id);
      setToast({ message: 'تم', tone: 'success' });
      load();
    } catch {
      setToast({ message: 'تعذر', tone: 'error' });
    }
  };

  return (
    <div>
      <Card className="mb-4">
        <h3 className="font-bold text-sm mb-3">العمولات والرسوم (بند 9/10) — لا شيء منها مثبّت بالكود</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {Object.entries(SETTING_LABELS).map(([key, label]) => (
            <div key={key} className="flex items-end gap-2">
              <Input label={label} type="number" defaultValue={settings[key] ?? ''} id={`s_${key}`} />
              <Button onClick={() => saveSetting(key, document.getElementById(`s_${key}`).value)}>حفظ</Button>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-4">
        <h3 className="font-bold text-sm mb-3">توليد أكواد شحن (بند 12)</h3>
        <div className="flex gap-2 mb-3">
          <Input label="العدد" type="number" value={batchCount} onChange={(e) => setBatchCount(e.target.value)} />
          <Input label="القيمة" type="number" value={batchValue} onChange={(e) => setBatchValue(e.target.value)} />
          <Button onClick={generateCodes} className="self-end">توليد</Button>
        </div>
        {generatedCodes && (
          <div className="bg-dark-surface rounded-xl p-3 text-xs mb-3">
            <p className="text-white/50 mb-2">انسخها الآن — تظهر مرة واحدة فقط هنا:</p>
            <div className="grid grid-cols-4 gap-1 font-mono">{generatedCodes.map((c) => <span key={c}>{c}</span>)}</div>
          </div>
        )}
        <Table columns={['الكود', 'القيمة', 'الحالة']} rows={codes.slice(0, 20)}
          renderRow={(c) => <tr key={c.id}><td className="py-2 px-2 font-mono">{c.code}</td><td className="py-2 px-2">{c.value}</td><td className="py-2 px-2">{c.status}</td></tr>} />
      </Card>

      <Card className="mb-4">
        <h3 className="font-bold text-sm mb-3">طلبات سحب السائقين (بند 11/12)</h3>
        {withdrawals.length === 0 ? <EmptyState text="لا توجد طلبات معلّقة" /> : (
          <div className="space-y-2">
            {withdrawals.map((w) => (
              <div key={w.id} className="flex justify-between items-center bg-dark-surface rounded-xl px-4 py-3 text-xs">
                <span>{w.full_name} — {w.phone} — {w.amount}</span>
                <Button onClick={() => markWithdrawalPaid(w.id)}>تعليم كمدفوع</Button>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card>
        <h3 className="font-bold text-sm mb-3">تسويات الشركاء (بند 9)</h3>
        {settlements.length === 0 ? <EmptyState text="لا توجد تسويات معلّقة" /> : (
          <div className="space-y-2">
            {settlements.map((s) => (
              <div key={s.id} className="flex justify-between items-center bg-dark-surface rounded-xl px-4 py-3 text-xs">
                <span>{s.owner_full_name} — صافي {s.net_payable}</span>
                <Button onClick={() => markSettlementPaid(s.id)}>تعليم كمدفوع</Button>
              </div>
            ))}
          </div>
        )}
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
