import React, { useState, useEffect } from 'react';
import { History } from 'lucide-react';
import { Card, EmptyState } from '../components/ui.jsx';
import { api } from '../api.js';

const ACTION_LABELS = {
  approve_partner: 'موافقة على شريك', update_theme: 'تعديل المظهر', block_partner_product: 'حظر منتج شريك',
  create_admin_user: 'إنشاء حساب أدمن', suspend_user_via_anomaly: 'تعليق حساب (نشاط غير طبيعي)',
  clear_anomaly_flag: 'إعفاء بلاغ نشاط غير طبيعي', send_broadcast_notification: 'إرسال إشعار جماعي',
  update_service_availability: 'تعديل توفر خدمة', mark_withdrawal_paid: 'تعليم سحب كمدفوع',
};

/** عارض سجل التدقيق — Append-only، Super Admin فقط، يوثّق كل إجراء إداري حساس */
export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api.getAuditLog().then(setLogs).catch(() => setLogs([])).finally(() => setIsLoading(false));
  }, []);

  if (isLoading) return <div className="text-white/40 text-sm">جاري التحميل...</div>;
  if (logs.length === 0) return <EmptyState text="لا توجد إجراءات مسجّلة بعد" />;

  return (
    <Card>
      <div className="flex items-center gap-2 mb-4"><History size={16} className="text-primary-light" /><h3 className="font-bold text-sm">سجل التدقيق (غير قابل للتعديل أو الحذف)</h3></div>
      <div className="space-y-2">
        {logs.map((l) => (
          <div key={l.id} className="flex items-center justify-between bg-dark-surface rounded-xl px-4 py-3 text-xs">
            <div>
              <span className="text-white font-medium">{ACTION_LABELS[l.action] || l.action}</span>
              <span className="text-white/40"> — بواسطة {l.email || 'غير معروف'}</span>
            </div>
            <span className="text-white/30">{new Date(l.created_at).toLocaleString('ar')}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}
