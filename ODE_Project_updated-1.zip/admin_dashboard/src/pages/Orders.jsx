import React, { useState, useEffect } from 'react';
import { Card, Table, Badge, Button, Toast } from '../components/ui.jsx';
import { api } from '../api.js';

const ORDER_STATUS_LABELS = {
  // إصلاح: كانت القيم هنا (pending/accepted) لا تطابق حالات الباك إند
  // الحقيقية (placed/accepted_by_partner) — نفس الخلل اللي كان بتطبيق
  // الشريك، لكن هنا كان تجميليًا بس (الجدول يعرض النص الخام لو ما لقى
  // ترجمة، فما كان يكسر شي، بس يطلع "placed" بدل "قيد الانتظار").
  placed: 'قيد الانتظار', accepted_by_partner: 'مقبول', preparing: 'قيد التجهيز',
  ready_for_pickup: 'بانتظار سائق', driver_assigned: 'السائق بالطريق', picked_up: 'تم الاستلام',
  on_the_way: 'في الطريق', delivered: 'تم التوصيل', cancelled: 'ملغي', rejected: 'مرفوض',
};

export default function Orders() {
  const [tab, setTab] = useState('orders');
  const [orders, setOrders] = useState([]);
  const [rides, setRides] = useState([]);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (tab === 'orders') api.getOrders().then(setOrders).catch(() => setOrders([]));
    else api.getRides().then(setRides).catch(() => setRides([]));
  }, [tab]);

  const forceCancel = async (id) => {
    const reason = prompt('سبب الإلغاء الإداري؟');
    if (!reason) return;
    try {
      await api.forceCancelOrder(id, reason);
      setToast({ message: 'تم الإلغاء', tone: 'success' });
      api.getOrders().then(setOrders);
    } catch {
      setToast({ message: 'تعذر الإلغاء', tone: 'error' });
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setTab('orders')} className={`px-3 py-1.5 rounded-lg text-xs ${tab === 'orders' ? 'bg-primary text-white' : 'bg-white/5 text-white/50'}`}>الطلبات</button>
        <button onClick={() => setTab('rides')} className={`px-3 py-1.5 rounded-lg text-xs ${tab === 'rides' ? 'bg-primary text-white' : 'bg-white/5 text-white/50'}`}>الرحلات</button>
      </div>

      {tab === 'orders' ? (
        <Card>
          <Table
            columns={['رقم الطلب', 'العميل', 'الشريك', 'الحالة', 'الإجمالي', 'إجراء']}
            rows={orders}
            renderRow={(o) => (
              <tr key={o.id}>
                <td className="py-3 px-2">#{o.order_number}</td>
                <td className="py-3 px-2 text-white/60">{o.customer_name}</td>
                <td className="py-3 px-2 text-white/60">{o.partner_name || '—'}</td>
                <td className="py-3 px-2"><Badge tone={o.status === 'delivered' ? 'success' : o.status === 'cancelled' ? 'danger' : 'default'}>{ORDER_STATUS_LABELS[o.status] || o.status}</Badge></td>
                <td className="py-3 px-2">{o.total}</td>
                <td className="py-3 px-2">
                  {!['delivered', 'cancelled'].includes(o.status) && (
                    <Button variant="danger" onClick={() => forceCancel(o.id)}>إلغاء إداري</Button>
                  )}
                </td>
              </tr>
            )}
          />
        </Card>
      ) : (
        <Card>
          <Table
            columns={['العميل', 'السائق', 'الحالة', 'السعر المقدّر', 'السعر النهائي']}
            rows={rides}
            renderRow={(r) => (
              <tr key={r.id}>
                <td className="py-3 px-2">{r.customer_name}</td>
                <td className="py-3 px-2 text-white/60">{r.driver_name || '—'}</td>
                <td className="py-3 px-2"><Badge tone={r.status === 'completed' ? 'success' : r.status === 'cancelled' ? 'danger' : 'default'}>{r.status}</Badge></td>
                <td className="py-3 px-2">{r.estimated_fare}</td>
                <td className="py-3 px-2">{r.final_fare || '—'}</td>
              </tr>
            )}
          />
        </Card>
      )}
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
