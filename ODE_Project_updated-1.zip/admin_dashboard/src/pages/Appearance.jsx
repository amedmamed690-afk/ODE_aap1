import React, { useState, useEffect } from 'react';
import { Palette } from 'lucide-react';
import { Card, Button, Input, Toast } from '../components/ui.jsx';
import { api } from '../api.js';

/**
 * تحكّم كامل بمظهر التطبيقات الثلاثة (طلب صريح) — كل تعديل هنا ينعكس على
 * customer_app/driver_app/partner_app تلقائيًا بمجرد فتحهم من جديد،
 * بدون أي تعديل كود أو نشر نسخة جديدة (الشعار، الألوان، حجم الخط،
 * استدارة الأزرار، الوضع الافتراضي، ورابط خدمة العملاء).
 */
export default function Appearance() {
  const [form, setForm] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    api.getAppAppearance().then((data) => setForm({
      logoUrl: data.logo_url || '',
      primaryColor: data.primary_color,
      secondaryColor: data.secondary_color,
      fontScale: Number(data.font_scale),
      buttonRadius: data.button_radius,
      defaultThemeMode: data.default_theme_mode,
      customerSupportUrl: data.customer_support_url || '',
    })).catch(() => setToast({ message: 'تعذر تحميل إعدادات المظهر', tone: 'error' }));
  }, []);

  const set = (key, value) => setForm((s) => ({ ...s, [key]: value }));

  const save = async () => {
    setIsSaving(true);
    try {
      await api.updateAppAppearance({
        logoUrl: form.logoUrl.trim() === '' ? null : form.logoUrl.trim(),
        primaryColor: form.primaryColor,
        secondaryColor: form.secondaryColor,
        fontScale: Number(form.fontScale),
        buttonRadius: Number(form.buttonRadius),
        defaultThemeMode: form.defaultThemeMode,
        customerSupportUrl: form.customerSupportUrl.trim(), // '' مقبولة صراحة = تفريغ الرابط
      });
      setToast({ message: 'تم الحفظ — التغييرات تظهر بالتطبيقات فور فتحها من جديد', tone: 'success' });
    } catch (err) {
      setToast({ message: err.message === 'missing_permission' ? 'ما تملك صلاحية appearance.write' : 'تعذر الحفظ', tone: 'error' });
    } finally {
      setIsSaving(false);
    }
  };

  if (!form) return <div className="text-white/40 text-sm">جاري التحميل...</div>;

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Palette size={16} className="text-primary-light" />
        <h3 className="font-bold text-sm">مظهر التطبيقات الثلاثة — عميل / سائق / شريك</h3>
      </div>

      <Card className="mb-4">
        <h4 className="font-bold text-xs text-white/60 mb-3">الشعار</h4>
        <Input
          label="رابط صورة الشعار (يظهر بشاشة البداية بالتطبيقات الثلاثة)"
          value={form.logoUrl}
          onChange={(e) => set('logoUrl', e.target.value)}
          placeholder="https://... — اتركه فارغًا لاستخدام الشعار الافتراضي المدمج"
        />
        {form.logoUrl && (
          <div className="mt-3 bg-dark-surface rounded-xl p-4 flex justify-center">
            <img src={form.logoUrl} alt="معاينة الشعار" className="h-16 object-contain"
              onError={(e) => { e.target.style.display = 'none'; }} />
          </div>
        )}
      </Card>

      <Card className="mb-4">
        <h4 className="font-bold text-xs text-white/60 mb-3">الألوان</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-white/50 block mb-1.5">اللون الأساسي</label>
            <div className="flex items-center gap-2">
              <input type="color" value={form.primaryColor} onChange={(e) => set('primaryColor', e.target.value)}
                className="w-10 h-10 rounded-lg border border-white/10 bg-transparent cursor-pointer" />
              <span className="text-xs font-mono text-white/60">{form.primaryColor}</span>
            </div>
          </div>
          <div>
            <label className="text-xs text-white/50 block mb-1.5">اللون الثانوي (تدرّج/تمييز)</label>
            <div className="flex items-center gap-2">
              <input type="color" value={form.secondaryColor} onChange={(e) => set('secondaryColor', e.target.value)}
                className="w-10 h-10 rounded-lg border border-white/10 bg-transparent cursor-pointer" />
              <span className="text-xs font-mono text-white/60">{form.secondaryColor}</span>
            </div>
          </div>
        </div>
      </Card>

      <Card className="mb-4">
        <h4 className="font-bold text-xs text-white/60 mb-3">حجم الخط واستدارة الأزرار</h4>
        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="text-xs text-white/50 block mb-2">حجم الخط بكل التطبيقات — {form.fontScale.toFixed(2)}×</label>
            <input type="range" min="0.8" max="1.4" step="0.05" value={form.fontScale}
              onChange={(e) => set('fontScale', e.target.value)} className="w-full accent-primary" />
            <div className="flex justify-between text-[10px] text-white/30 mt-1"><span>أصغر</span><span>عادي</span><span>أكبر</span></div>
          </div>
          <div>
            <label className="text-xs text-white/50 block mb-2">استدارة زوايا الأزرار — {form.buttonRadius}px</label>
            <input type="range" min="0" max="32" step="2" value={form.buttonRadius}
              onChange={(e) => set('buttonRadius', e.target.value)} className="w-full accent-primary" />
            <div className="flex justify-between text-[10px] text-white/30 mt-1"><span>حاد</span><span>متوسط</span><span>دائري بالكامل</span></div>
          </div>
        </div>
      </Card>

      <Card className="mb-4">
        <h4 className="font-bold text-xs text-white/60 mb-3">الوضع الافتراضي عند أول تشغيل</h4>
        <div className="flex gap-2">
          {[{ v: 'dark', l: 'داكن' }, { v: 'light', l: 'فاتح' }, { v: 'system', l: 'حسب الجهاز' }].map((opt) => (
            <button key={opt.v} onClick={() => set('defaultThemeMode', opt.v)}
              className={`px-4 py-2 rounded-lg text-xs ${form.defaultThemeMode === opt.v ? 'bg-primary text-white' : 'bg-white/5 text-white/50'}`}>
              {opt.l}
            </button>
          ))}
        </div>
        <p className="text-[10px] text-white/30 mt-2">المستخدم يقدر يغيّره بنفسه لاحقًا من داخل التطبيق — هذا فقط ما يُفتح عليه أول مرة.</p>
      </Card>

      <Card className="mb-4">
        <h4 className="font-bold text-xs text-white/60 mb-3">خدمة العملاء</h4>
        <Input
          label="رابط خدمة العملاء (يظهر بالملف الشخصي بالتطبيقات الثلاثة)"
          value={form.customerSupportUrl}
          onChange={(e) => set('customerSupportUrl', e.target.value)}
          placeholder="اتركه فارغًا حتى تجهّز الرابط المناسب — الزر يظهر بالتطبيق لكن يبقى معطّلاً بدونه"
        />
      </Card>

      <Button onClick={save} disabled={isSaving} className="w-full">{isSaving ? 'جارِ الحفظ...' : 'حفظ كل التعديلات'}</Button>

      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
