import React, { useState, useEffect } from 'react';
import { UserPlus, ShieldCheck, Ban } from 'lucide-react';
import { Card, Button, Input, Toast, EmptyState, Badge } from '../components/ui.jsx';
import { api } from '../api.js';

const AVAILABLE_PERMISSIONS = [
  'appearance.write', 'catalog.write', 'broadcast.write', 'availability.write',
  'partners.review', 'drivers.review', 'security.review', 'marketing.write', 'finance.review',
];

/**
 * إدارة حسابات الأدمن — Super Admin بس يقدر يوصلها (requireSuperAdmin
 * بالباك إند). كانت فجوة أمنية حقيقية: ما فيش طريقة تضيف أدمن جديد
 * غير مباشرة بقاعدة البيانات.
 */
export default function AdminUsers() {
  const [admins, setAdmins] = useState([]);
  const [email, setEmail] = useState('');
  const [selectedPerms, setSelectedPerms] = useState([]);
  const [newAdminCreds, setNewAdminCreds] = useState(null);
  const [toast, setToast] = useState(null);

  const load = () => api.getAdmins().then(setAdmins).catch(() => setAdmins([]));
  useEffect(load, []);

  const togglePerm = (perm) => {
    setSelectedPerms((prev) => prev.includes(perm) ? prev.filter((p) => p !== perm) : [...prev, perm]);
  };

  const create = async () => {
    if (!email) return setToast({ message: 'الإيميل إجباري', tone: 'error' });
    try {
      const result = await api.createAdmin({ email, permissions: selectedPerms });
      setNewAdminCreds(result);
      setEmail(''); setSelectedPerms([]);
      load();
    } catch {
      setToast({ message: 'تعذر الإنشاء', tone: 'error' });
    }
  };

  const deactivate = async (id) => {
    if (!confirm('تعطيل هذا الحساب فوراً؟')) return;
    await api.deactivateAdmin(id);
    setToast({ message: 'تم التعطيل', tone: 'success' });
    load();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="space-y-3 h-fit">
        <div className="flex items-center gap-2"><UserPlus size={16} className="text-primary-light" /><h3 className="font-bold text-sm">أدمن جديد</h3></div>
        <Input label="البريد الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@ode-app.com" />
        <div>
          <span className="text-xs text-white/60 mb-2 block">الصلاحيات</span>
          <div className="flex flex-wrap gap-2">
            {AVAILABLE_PERMISSIONS.map((p) => (
              <button key={p} onClick={() => togglePerm(p)}
                className={`text-[10px] px-2.5 py-1.5 rounded-lg border ${selectedPerms.includes(p) ? 'border-primary-light bg-white/10' : 'border-white/10 text-white/50'}`}>
                {p}
              </button>
            ))}
          </div>
        </div>
        <Button onClick={create} className="w-full">إنشاء الحساب</Button>

        {newAdminCreds && (
          <div className="bg-dark-surface rounded-xl p-3 text-xs">
            <p className="text-white/50 mb-1">كلمة مرور مؤقتة (أرسلها للأدمن بأمان، لن تظهر مجدداً):</p>
            <code className="text-primary-light break-all">{newAdminCreds.tempPassword}</code>
          </div>
        )}
      </Card>

      <Card className="lg:col-span-2">
        <h3 className="font-bold text-sm mb-4">كل الأدمنز</h3>
        {admins.length === 0 ? <EmptyState text="لا يوجد أدمن آخر بعد" /> : (
          <div className="space-y-2">
            {admins.map((a) => (
              <div key={a.id} className="flex items-center justify-between bg-dark-surface rounded-xl px-4 py-3">
                <div>
                  <div className="text-sm font-medium flex items-center gap-2">
                    {a.email}
                    {a.is_super_admin && <Badge tone="warning">Super Admin</Badge>}
                    {!a.is_active && <Badge tone="danger">معطّل</Badge>}
                    {!a.totp_enabled && <Badge>2FA غير مفعّل</Badge>}
                  </div>
                  <div className="text-[10px] text-white/40 mt-1">{(a.permissions || []).join(', ') || 'بدون صلاحيات محددة'}</div>
                </div>
                {!a.is_super_admin && a.is_active && (
                  <button onClick={() => deactivate(a.id)} className="text-red-400"><Ban size={16} /></button>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
