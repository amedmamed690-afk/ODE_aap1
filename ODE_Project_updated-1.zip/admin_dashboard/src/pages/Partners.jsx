import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Pause, FileText } from 'lucide-react';
import { Card, Button, Table, Badge, Toast, Modal, Input } from '../components/ui.jsx';
import { api } from '../api.js';

const STATUS_TABS = [
  { key: 'pending', label: 'قيد المراجعة' },
  { key: 'active', label: 'مفعّل' },
  { key: 'rejected', label: 'مرفوض' },
  { key: 'suspended', label: 'موقوف' },
];

export default function Partners() {
  const [status, setStatus] = useState('pending');
  const [partners, setPartners] = useState([]);
  const [toast, setToast] = useState(null);
  const [reasonModal, setReasonModal] = useState(null);
  const [reason, setReason] = useState('');
  const [docsModal, setDocsModal] = useState(null);
  const [docs, setDocs] = useState([]);

  const load = () => api.getPartners(status).then(setPartners).catch(() => setPartners([]));
  useEffect(load, [status]);

  const approve = async (id) => {
    try {
      await api.approvePartner(id);
      setToast({ message: 'تم قبول الشريك', tone: 'success' });
      load();
    } catch {
      setToast({ message: 'تعذر القبول', tone: 'error' });
    }
  };

  const submitReason = async () => {
    if (!reason.trim()) return;
    try {
      if (reasonModal.action === 'reject') await api.rejectPartner(reasonModal.partnerId, reason);
      if (reasonModal.action === 'suspend') await api.suspendPartner(reasonModal.partnerId, reason);
      setToast({ message: 'تم', tone: 'success' });
      setReasonModal(null); setReason('');
      load();
    } catch {
      setToast({ message: 'تعذر الإجراء', tone: 'error' });
    }
  };

  const viewDocs = async (id) => {
    const result = await api.getPartnerDocuments(id).catch(() => []);
    setDocs(result);
    setDocsModal(id);
  };

  // مستندات الهوية بـbucket منفصل غير عام (بند 8) — الرابط المخزّن هو
  // مجرد مفتاح تخزين، لازم نولّد رابط مؤقت الصلاحية قبل الفتح مباشرة.
  const viewDocument = async (key) => {
    try {
      const { url } = await api.getDocumentViewUrl(key);
      window.open(url, '_blank');
    } catch {
      setToast({ message: 'تعذر فتح المستند', tone: 'error' });
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {STATUS_TABS.map((t) => (
          <button key={t.key} onClick={() => setStatus(t.key)}
            className={`px-3 py-1.5 rounded-lg text-xs ${status === t.key ? 'bg-primary text-white' : 'bg-white/5 text-white/50'}`}>
            {t.label}
          </button>
        ))}
      </div>
      <Card>
        <Table
          columns={['الاسم', 'الهاتف', 'النوع', 'المستندات', 'إجراءات']}
          rows={partners}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="py-3 px-2">{p.owner_full_name || '—'}</td>
              <td className="py-3 px-2 text-white/60">{p.primary_phone}</td>
              <td className="py-3 px-2 text-white/60">{p.account_type === 'digital' ? 'رقمي' : 'فعلي'}</td>
              <td className="py-3 px-2">
                <button onClick={() => viewDocs(p.id)} className="text-primary-light flex items-center gap-1 text-xs"><FileText size={14} /> عرض</button>
              </td>
              <td className="py-3 px-2">
                <div className="flex gap-2">
                  {status === 'pending' && (
                    <>
                      <button onClick={() => approve(p.id)} className="text-emerald-400" title="قبول"><CheckCircle size={18} /></button>
                      <button onClick={() => setReasonModal({ partnerId: p.id, action: 'reject' })} className="text-red-400" title="رفض"><XCircle size={18} /></button>
                    </>
                  )}
                  {status === 'active' && (
                    <button onClick={() => setReasonModal({ partnerId: p.id, action: 'suspend' })} className="text-amber-400" title="إيقاف"><Pause size={18} /></button>
                  )}
                  {p.rejected_reason && <Badge tone="danger">{p.rejected_reason}</Badge>}
                </div>
              </td>
            </tr>
          )}
        />
      </Card>

      <Modal open={!!reasonModal} onClose={() => setReasonModal(null)} title={reasonModal?.action === 'reject' ? 'سبب الرفض' : 'سبب الإيقاف'}>
        <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="اكتب السبب هنا..." />
        <Button className="w-full mt-4" onClick={submitReason}>تأكيد</Button>
      </Modal>

      <Modal open={!!docsModal} onClose={() => setDocsModal(null)} title="مستندات الشريك">
        {docs.length === 0 ? <p className="text-white/40 text-sm">لا توجد مستندات مرفوعة</p> : (
          <div className="space-y-2">
            {docs.map((d, i) => (
              <button key={i} onClick={() => viewDocument(d.file_url)} className="block text-primary-light underline text-sm bg-transparent border-none cursor-pointer text-right w-full mb-1">{d.doc_type}</button>
            ))}
          </div>
        )}
      </Modal>

      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
