import React, { useState, useEffect } from 'react';
import { ShieldCheck, Monitor, X } from 'lucide-react';
import { Card, Button, Input, Toast } from '../components/ui.jsx';
import { api } from '../api.js';

/**
 * طلب صريح (بند 6): "دعم تسجيل الدخول من أجهزة مختلفة، Sessions آمنة،
 * إبطال الجلسات عند الحاجة" — صفحة دائمة (بخلاف ChangePassword.jsx التي
 * تظهر مرة واحدة إجباريًا فقط) لإدارة كلمة المرور والجلسات النشطة بأي وقت.
 */
export default function Security() {
  const [sessions, setSessions] = useState(null);
  const [toast, setToast] = useState(null);
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '' });

  const loadSessions = () => api.getSessions().then(setSessions).catch(() => setToast({ message: 'تعذر تحميل الجلسات', tone: 'error' }));
  useEffect(() => { loadSessions(); }, []);

  const revoke = async (id) => {
    try {
      await api.revokeSession(id);
      setToast({ message: 'تم إبطال الجلسة', tone: 'success' });
      loadSessions();
    } catch (_) {
      setToast({ message: 'تعذر إبطال الجلسة', tone: 'error' });
    }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    try {
      await api.changePassword(pwForm);
      setToast({ message: 'تم تحديث كلمة المرور', tone: 'success' });
      setPwForm({ currentPassword: '', newPassword: '' });
    } catch (_) {
      setToast({ message: 'كلمة المرور الحالية غير صحيحة', tone: 'error' });
    }
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <ShieldCheck size={16} className="text-primary-light" />
        <h3 className="font-bold text-sm">الأمان — كلمة المرور والجلسات النشطة</h3>
      </div>

      <Card className="mb-4">
        <h4 className="font-bold text-xs text-white/60 mb-3">تغيير كلمة المرور</h4>
        <form onSubmit={changePassword} className="space-y-3">
          <Input label="كلمة المرور الحالية" type="password" value={pwForm.currentPassword}
            onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })} required />
          <Input label="كلمة المرور الجديدة" type="password" value={pwForm.newPassword} minLength={8}
            onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })} required />
          <Button type="submit">تحديث</Button>
        </form>
      </Card>

      <Card>
        <h4 className="font-bold text-xs text-white/60 mb-3">الجلسات النشطة</h4>
        {!sessions ? (
          <p className="text-white/40 text-xs">جاري التحميل...</p>
        ) : sessions.length === 0 ? (
          <p className="text-white/40 text-xs">لا توجد جلسات نشطة</p>
        ) : (
          <div className="space-y-2">
            {sessions.map((s) => (
              <div key={s.id} className="flex items-center justify-between bg-dark-surface rounded-xl px-3 py-2.5">
                <div className="flex items-center gap-2.5">
                  <Monitor size={16} className="text-white/40" />
                  <div>
                    <p className="text-xs">{s.device_label || 'جهاز غير معروف'} {s.is_current && <span className="text-primary-light">(هذا الجهاز)</span>}</p>
                    <p className="text-[10px] text-white/30">{s.ip_address} — آخر ظهور {new Date(s.last_seen_at).toLocaleString('ar')}</p>
                  </div>
                </div>
                {!s.is_current && (
                  <button onClick={() => revoke(s.id)} className="text-red-400 hover:text-red-300">
                    <X size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>

      <Toast message={toast?.message} tone={toast?.tone} onClose={() => setToast(null)} />
    </div>
  );
}
