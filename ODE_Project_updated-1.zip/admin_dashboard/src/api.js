// بند أمني (اكتشاف أثناء جولة المراجعة): كان ثابتًا هنا فقط بلوحة الإدارة
// (الثلاث تطبيقات مركزية عبر Env.apiBaseUrl من قبل، لوحة الإدارة كانت
// الوحيدة المتبقية). Vite يقرأ متغيرات البيئة فقط بادئة VITE_ وقت البناء.
const baseUrl = import.meta.env.VITE_API_BASE_URL || 'https://api.ode-app.com';

function getToken() {
  return localStorage.getItem('ode_admin_token');
}

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
      ...options.headers,
    },
  });
  if (response.status === 401) {
    localStorage.removeItem('ode_admin_token');
    window.location.href = '/login';
    throw new Error('unauthorized');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'request_failed');
  return data;
}

const get = (path) => request(path);
const post = (path, body) => request(path, { method: 'POST', body: JSON.stringify(body) });
const patch = (path, body) => request(path, { method: 'PATCH', body: JSON.stringify(body ?? {}) });
const put = (path, body) => request(path, { method: 'PUT', body: JSON.stringify(body) });
const del = (path) => request(path, { method: 'DELETE' });

export const api = {
  // ---- Auth ----
  login: (body) => post('/admin/auth/login', body),
  logout: () => post('/admin/auth/logout'),
  getSessions: () => get('/admin/auth/sessions'),
  revokeSession: (id) => post(`/admin/auth/sessions/${id}/revoke`),

  // ---- طلب صريح (بند 5): معالج التهيئة الأمنية الإجباري لأول استخدام ----
  getSetupStatus: () => get('/admin/auth/setup-status'),
  setupStart: (body) => post('/admin/auth/setup/start', body),
  setupRequestPhoneOtp: (body) => post('/admin/auth/setup/phone/request-otp', body),
  setupVerifyPhoneOtp: (body) => post('/admin/auth/setup/phone/verify-otp', body),
  setupComplete: (body) => post('/admin/auth/setup/complete', body),
  recoverAccount: (body) => post('/admin/auth/recover', body),
  changePassword: (body) => post('/admin/auth/change-password', body),
  setupTotp: () => post('/admin/auth/totp/setup', {}),
  confirmTotp: (code) => post('/admin/auth/totp/confirm', { code }),

  // ---- Admin accounts ----
  getAdmins: () => get('/admin/admins'),
  createAdmin: (body) => post('/admin/admins', body),
  deactivateAdmin: (id) => patch(`/admin/admins/${id}/deactivate`),

  // ---- Audit log ----
  getAuditLog: () => get('/admin/audit-log'),

  // ---- Drivers ----
  getDrivers: (status = 'pending') => get(`/admin/drivers?status=${status}`),
  approveDriver: (id) => patch(`/admin/drivers/${id}/approve`),
  rejectDriver: (id, reason) => patch(`/admin/drivers/${id}/reject`, { reason }),
  suspendDriver: (id, reason) => patch(`/admin/drivers/${id}/suspend`, { reason }),
  reinstateDriver: (id) => patch(`/admin/drivers/${id}/reinstate`),

  // ---- Partners ----
  getPartners: (status = 'pending') => get(`/admin/partners?status=${status}`),
  getPartnerDocuments: (id) => get(`/admin/partners/${id}/documents`),
  getDocumentViewUrl: (key) => get(`/upload/document-view-url?key=${encodeURIComponent(key)}`),
  approvePartner: (id) => patch(`/admin/partners/${id}/approve`),
  rejectPartner: (id, reason) => patch(`/admin/partners/${id}/reject`, { reason }),
  suspendPartner: (id, reason) => patch(`/admin/partners/${id}/suspend`, { reason }),
  blockPartnerProduct: (partnerId, productId) => patch(`/admin/partners/${partnerId}/products/${productId}/block`),

  // ---- Orders / rides oversight ----
  getOrders: (status) => get(`/admin/orders${status ? `?status=${status}` : ''}`),
  forceCancelOrder: (id, reason) => patch(`/admin/orders/${id}/force-cancel`, { reason }),
  getRides: (status) => get(`/admin/rides${status ? `?status=${status}` : ''}`),

  // ---- Catalog ----
  getCountries: () => get('/admin/catalog/countries'),
  createCountry: (body) => post('/admin/catalog/countries', body),
  getCities: (countryId) => get(`/admin/catalog/cities${countryId ? `?countryId=${countryId}` : ''}`),
  createCity: (body) => post('/admin/catalog/cities', body),
  getCurrencies: () => get('/admin/catalog/currencies'),
  createCurrency: (body) => post('/admin/catalog/currencies', body),
  getRideCategories: () => get('/admin/catalog/ride-categories'),
  createRideCategory: (body) => post('/admin/catalog/ride-categories', body),
  updateRideCategory: (id, body) => patch(`/admin/catalog/ride-categories/${id}`, body),
  getPartnerActivityCategories: () => get('/admin/catalog/partner-activity-categories'),
  createPartnerActivityCategory: (body) => post('/admin/catalog/partner-activity-categories', body),
  getPartnerDigitalSubtypes: () => get('/admin/catalog/partner-digital-subtypes'),
  createPartnerDigitalSubtype: (body) => post('/admin/catalog/partner-digital-subtypes', body),
  getOdeBrandCategories: () => get('/admin/catalog/ode-brand/categories'),
  createOdeBrandCategory: (body) => post('/admin/catalog/ode-brand/categories', body),
  createOdeBrandProduct: (body) => post('/admin/catalog/ode-brand/products', body),
  updateOdeBrandProduct: (id, body) => patch(`/admin/catalog/ode-brand/products/${id}`, body),
  getHomeServices: () => get('/admin/catalog/home-services'),
  createHomeService: (body) => post('/admin/catalog/home-services', body),

  // ---- Finance ----
  getFinanceSettings: () => get('/admin/finance/settings'),
  updateFinanceSetting: (key, value, countryId) => put('/admin/finance/settings', { key, value, countryId }),
  getTopupCodes: () => get('/admin/finance/topup-codes'),
  generateTopupCodes: (body) => post('/admin/finance/topup-codes/batch', body),
  cancelTopupCode: (id) => patch(`/admin/finance/topup-codes/${id}/cancel`),
  getWithdrawals: (status = 'pending') => get(`/admin/finance/withdrawals?status=${status}`),
  markWithdrawalPaid: (id) => patch(`/admin/finance/withdrawals/${id}/mark-paid`),
  getSettlements: (status = 'pending') => get(`/admin/finance/settlements?status=${status}`),
  markSettlementPaid: (id) => patch(`/admin/finance/settlements/${id}/mark-paid`),

  // ---- Content ----
  getBanners: () => get('/admin/content/banners'),
  createBanner: (body) => post('/admin/content/banners', body),
  deleteBanner: (id) => del(`/admin/content/banners/${id}`),
  getPromotions: () => get('/admin/content/promotions'),
  createPromotion: (body) => post('/admin/content/promotions', body),
  getPointRewards: () => get('/admin/content/point-rewards'),
  createPointReward: (body) => post('/admin/content/point-rewards', body),
  updatePointRules: (pointsPerCurrency) => put('/admin/content/point-rules', { pointsPerCurrency }),
  getInviteSettings: () => get('/admin/content/invite-settings'),
  updateInviteSettings: (body) => put('/admin/content/invite-settings', body),
  getSubscriptionPlans: () => get('/admin/content/subscription-plans'),
  createSubscriptionPlan: (body) => post('/admin/content/subscription-plans', body),
  updateSubscriptionPlan: (id, body) => patch(`/admin/content/subscription-plans/${id}`, body),
  sendBroadcast: (body) => post('/admin/content/broadcast', body),

  // ---- Support (موديول جديد — Backend كان جاهزًا بدون أي واجهة) ----
  searchSupportCustomer: (phone) => get(`/support/customers?phone=${encodeURIComponent(phone)}`),
  getSupportOrder: (id) => get(`/support/orders/${id}`),
  addSupportNote: (id, note) => post(`/support/orders/${id}/note`, { note }),

  // ---- Appearance (طلب صريح: تحكّم كامل بمظهر التطبيقات الثلاثة) ----
  getAppAppearance: () => get('/app-appearance'),
  updateAppAppearance: (body) => patch('/app-appearance', body),

  // ---- System Settings (طلب صريح: تفعيل/تعطيل الخدمات ووسائل الدفع) ----
  getSystemSettings: () => get('/admin/finance/system-settings'),
  // نفس PUT العام الموجود أصلاً لإعدادات المالية — بدون أي تكرار.
  updateSystemSetting: (key, value) => put('/admin/finance/settings', { key, value }),
};
