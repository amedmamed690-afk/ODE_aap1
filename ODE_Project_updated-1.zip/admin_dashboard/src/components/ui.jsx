import React, { useEffect } from 'react';

export function Card({ children, className = '' }) {
  return <div className={`bg-dark-card rounded-2xl p-5 ${className}`}>{children}</div>;
}

export function Button({ children, onClick, variant = 'primary', className = '', disabled = false, type = 'button' }) {
  const styles = {
    primary: 'bg-primary hover:bg-primary-light text-white',
    danger: 'bg-red-600/80 hover:bg-red-600 text-white',
    ghost: 'bg-white/5 hover:bg-white/10 text-white',
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      className={`px-4 py-2.5 rounded-xl text-sm font-medium transition disabled:opacity-50 ${styles[variant]} ${className}`}>
      {children}
    </button>
  );
}

export function Input({ label, className = '', ...props }) {
  return (
    <label className={`block ${className}`}>
      {label && <span className="text-xs text-white/60 mb-1 block">{label}</span>}
      <input {...props}
        className="w-full bg-dark-surface border border-white/10 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-primary-light" />
    </label>
  );
}

export function Badge({ children, tone = 'default' }) {
  const tones = {
    default: 'bg-white/10 text-white/70',
    warning: 'bg-amber-500/20 text-amber-300',
    danger: 'bg-red-500/20 text-red-300',
    success: 'bg-emerald-500/20 text-emerald-300',
  };
  return <span className={`text-[10px] px-2 py-0.5 rounded-full ${tones[tone]}`}>{children}</span>;
}

export function EmptyState({ text }) {
  return <div className="text-center py-10 text-white/30 text-sm">{text}</div>;
}

export function Toast({ message, tone = 'success', onClose }) {
  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [message, onClose]);

  if (!message) return null;
  const toneClass = tone === 'error' ? 'bg-red-600' : 'bg-emerald-600';
  return (
    <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 ${toneClass} text-white text-sm px-4 py-2.5 rounded-xl shadow-lg z-50`}>
      {message}
    </div>
  );
}

export function Table({ columns, rows, renderRow }) {
  if (rows.length === 0) return <EmptyState text="لا توجد بيانات" />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-right">
        <thead>
          <tr className="text-white/40 text-xs border-b border-white/10">
            {columns.map((c) => <th key={c} className="pb-3 font-medium px-2">{c}</th>)}
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {rows.map((row, i) => renderRow(row, i))}
        </tbody>
      </table>
    </div>
  );
}

export function Modal({ open, onClose, title, children }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-dark-card rounded-2xl p-6 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <h3 className="font-bold text-sm mb-4">{title}</h3>
        {children}
      </div>
    </div>
  );
}
