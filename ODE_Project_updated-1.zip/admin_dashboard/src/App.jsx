import React from 'react';
import { Routes, Route, Navigate, NavLink } from 'react-router-dom';
import { api } from './api.js';
import { Users, Car, Store, Receipt, LayoutGrid, Wallet, Megaphone, History, ShieldCheck, LogOut, Headphones, Palette, Settings, Lock } from 'lucide-react';
import Login from './pages/Login.jsx';
import ChangePassword from './pages/ChangePassword.jsx';
import Drivers from './pages/Drivers.jsx';
import Partners from './pages/Partners.jsx';
import Orders from './pages/Orders.jsx';
import Catalog from './pages/Catalog.jsx';
import Finance from './pages/Finance.jsx';
import Content from './pages/Content.jsx';
import AdminUsers from './pages/AdminUsers.jsx';
import AuditLog from './pages/AuditLog.jsx';
import Support from './pages/Support.jsx';
import Appearance from './pages/Appearance.jsx';
import SystemSettings from './pages/SystemSettings.jsx';
import Security from './pages/Security.jsx';

function isAuthenticated() {
  return !!localStorage.getItem('ode_admin_token');
}

function ProtectedRoute({ children }) {
  return isAuthenticated() ? children : <Navigate to="/login" replace />;
}

const NAV_ITEMS = [
  { to: '/', icon: Car, label: 'السائقون' },
  { to: '/partners', icon: Store, label: 'الشركاء' },
  { to: '/orders', icon: Receipt, label: 'الطلبات والرحلات' },
  { to: '/support', icon: Headphones, label: 'الدعم' },
  { to: '/appearance', icon: Palette, label: 'المظهر' },
  { to: '/system-settings', icon: Settings, label: 'إعدادات النظام' },
  { to: '/security', icon: Lock, label: 'الأمان' },
  { to: '/catalog', icon: LayoutGrid, label: 'الفئات والدول' },
  { to: '/finance', icon: Wallet, label: 'المالية' },
  { to: '/content', icon: Megaphone, label: 'المحتوى والتسويق' },
  { to: '/admins', icon: ShieldCheck, label: 'حسابات الأدمن' },
  { to: '/audit-log', icon: History, label: 'سجل التدقيق' },
];

function Layout({ children }) {
  // إصلاح (بند 6 — طلب صريح): كان تسجيل الخروج يمسح التوكن من المتصفح
  // فقط — الجلسة تبقى فعّالة بالسيرفر لحد انتهاء صلاحيتها الطبيعية (12
  // ساعة) حتى لو "سُجِّل خروج". الآن يُبطل الجلسة فعليًا بالسيرفر أولاً.
  const logout = async () => {
    try { await api.logout(); } catch (_) { /* حتى لو فشل الطلب، امسح المحلي وأخرج */ }
    localStorage.removeItem('ode_admin_token');
    window.location.href = '/login';
  };

  return (
    <div className="min-h-screen flex">
      <aside className="w-56 bg-dark-surface p-4 flex flex-col shrink-0">
        <h1 className="text-primary-light font-bold text-lg mb-8 px-2">ODE — الإدارة</h1>
        <nav className="flex-1 space-y-1">
          {NAV_ITEMS.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} end={to === '/'}
              className={({ isActive }) => `flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm transition ${isActive ? 'bg-primary text-white' : 'text-white/60 hover:bg-white/5'}`}>
              <Icon size={16} /> {label}
            </NavLink>
          ))}
        </nav>
        <button onClick={logout} className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-red-400 hover:bg-white/5">
          <LogOut size={16} /> تسجيل الخروج
        </button>
      </aside>
      <main className="flex-1 p-8 overflow-y-auto">{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/change-password" element={<ChangePassword />} />
      <Route path="/" element={<ProtectedRoute><Layout><Drivers /></Layout></ProtectedRoute>} />
      <Route path="/partners" element={<ProtectedRoute><Layout><Partners /></Layout></ProtectedRoute>} />
      <Route path="/orders" element={<ProtectedRoute><Layout><Orders /></Layout></ProtectedRoute>} />
      <Route path="/support" element={<ProtectedRoute><Layout><Support /></Layout></ProtectedRoute>} />
      <Route path="/appearance" element={<ProtectedRoute><Layout><Appearance /></Layout></ProtectedRoute>} />
      <Route path="/system-settings" element={<ProtectedRoute><Layout><SystemSettings /></Layout></ProtectedRoute>} />
      <Route path="/security" element={<ProtectedRoute><Layout><Security /></Layout></ProtectedRoute>} />
      <Route path="/catalog" element={<ProtectedRoute><Layout><Catalog /></Layout></ProtectedRoute>} />
      <Route path="/finance" element={<ProtectedRoute><Layout><Finance /></Layout></ProtectedRoute>} />
      <Route path="/content" element={<ProtectedRoute><Layout><Content /></Layout></ProtectedRoute>} />
      <Route path="/admins" element={<ProtectedRoute><Layout><AdminUsers /></Layout></ProtectedRoute>} />
      <Route path="/audit-log" element={<ProtectedRoute><Layout><AuditLog /></Layout></ProtectedRoute>} />
    </Routes>
  );
}
