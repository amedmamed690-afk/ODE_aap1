import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../shared/services/fcm_service.dart';
import 'package:ode_driver_app/core/config/env.dart';

enum DriverLoginOutcome { newRegistration, pendingApproval, rejected, suspended, active, error }

/// نفس تدفق PartnerAuthProvider بالظبط — نفس فلسفة OTP + اكتشاف تلقائي
/// لحالة الحساب (جديد/بانتظار/مرفوض/موقوف/مفعّل).
class DriverAuthProvider extends ChangeNotifier {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  String? _token;
  String? _pendingToken;
  String? _driverId;
  bool _isLoading = false;

  String? get token => _token;
  String? get pendingToken => _pendingToken;
  String? get driverId => _driverId;
  bool get isAuthenticated => _token != null && _driverId != null;
  bool get isLoading => _isLoading;

  Future<void> loadFromStorage() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('driver_auth_token');
    _driverId = prefs.getString('driver_id');
    notifyListeners();
  }

  Future<void> requestOtp(String phone) async {
    _isLoading = true; notifyListeners();
    try {
      await http.post(Uri.parse('$baseUrl/auth/otp/request'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'phone': phone}));
    } finally {
      _isLoading = false; notifyListeners();
    }
  }

  Future<DriverLoginOutcome> verifyOtp(String phone, String code) async {
    _isLoading = true; notifyListeners();
    try {
      final response = await http.post(Uri.parse('$baseUrl/auth/otp/verify'),
          headers: {'Content-Type': 'application/json'}, body: jsonEncode({'phone': phone, 'code': code}));
      if (response.statusCode != 200) return DriverLoginOutcome.error;

      final data = jsonDecode(response.body);
      _pendingToken = data['token'];

      final statusResponse = await http.get(Uri.parse('$baseUrl/driver-onboarding/my-status'), headers: {'Authorization': 'Bearer $_pendingToken'});
      if (statusResponse.statusCode == 404) {
        notifyListeners();
        return DriverLoginOutcome.newRegistration;
      }
      if (statusResponse.statusCode != 200) return DriverLoginOutcome.error;

      final status = jsonDecode(statusResponse.body);
      switch (status['approval_status']) {
        case 'rejected': return DriverLoginOutcome.rejected;
        case 'suspended': return DriverLoginOutcome.suspended;
        case 'pending': return DriverLoginOutcome.pendingApproval;
      }

      final driverResponse = await http.get(Uri.parse('$baseUrl/driver-app/me'), headers: {'Authorization': 'Bearer $_pendingToken'});
      final driver = jsonDecode(driverResponse.body);

      _token = _pendingToken;
      _driverId = driver['id'];

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('driver_auth_token', _token!);
      await prefs.setString('driver_id', _driverId!);

      notifyListeners();
      FcmService.registerToken(_token!); // بند 15
      return DriverLoginOutcome.active;
    } finally {
      _isLoading = false; notifyListeners();
    }
  }

  /// بند 28 (مراجعة أمنية): بعد أي ترقية دور (customer -> driver) لازم
  /// نستبدل التوكن القديم فورًا — endpoints دور السائق ترفض التوكن
  /// القديم مباشرة (requireRole('driver')) حتى لو الحساب فعليًا صار
  /// سائقًا بقاعدة البيانات.
  Future<void> updateTokenAfterUpgrade(String newToken) async {
    _token = newToken;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('driver_auth_token', newToken);
    notifyListeners();
  }

  Future<void> logout() async {
    _token = null; _pendingToken = null; _driverId = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('driver_auth_token');
    await prefs.remove('driver_id');
    notifyListeners();
  }
}
