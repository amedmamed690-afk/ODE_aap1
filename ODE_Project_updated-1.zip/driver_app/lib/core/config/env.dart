/// إعداد بيئة مركزي — بند 16 بالمراجعة (نفس الحل المطبّق بتطبيق العميل).
/// يمكن تغيير الرابط وقت البناء بدون تعديل أي كود عبر:
///   flutter build apk --dart-define=API_BASE_URL=https://staging-api.ode-app.com
/// بدون تمرير --dart-define، القيمة الافتراضية تبقى نطاق الإنتاج الحالي كما هو.
class Env {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.ode-app.com',
  );
}
