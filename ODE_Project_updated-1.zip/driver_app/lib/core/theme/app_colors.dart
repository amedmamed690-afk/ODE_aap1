import 'package:flutter/material.dart';

/// كل ألوان التطبيق معرّفة هنا فقط — أي تعديل على البنفسجي (مثلاً بعد رفع
/// الشعار الحقيقي) يتم من هذا الملف فقط وينعكس على كل الشاشات تلقائياً.
class AppColors {
  AppColors._();

  // ---- البنفسجي الأساسي (مستوحى من شعار ODE) ----
  static Color primaryPurple = const Color(0xFF6A0DAD);
  static Color primaryPurpleLight = const Color(0xFF9B4DE0);
  static const Color primaryPurpleDark = Color(0xFF3D0768);

  // استدارة الأزرار — تتحكم فيها لوحة الإدارة (button_radius)
  static double buttonRadius = 16;

  // ---- الوضع الداكن ----
  static const Color darkBackground = Color(0xFF120026);
  static const Color darkSurface = Color(0xFF1E0838);
  static const Color darkCardBackground = Color(0xFF2A0F4A);
  static const Color darkTextPrimary = Color(0xFFF5F0FF);
  static const Color darkTextSecondary = Color(0xFFB8A6D9);

  // ---- الوضع الفاتح ----
  static const Color lightBackground = Color(0xFFFFFFFF);
  static const Color lightSurface = Color(0xFFF7F3FC);
  static const Color lightCardBackground = Color(0xFFFFFFFF);
  static const Color lightTextPrimary = Color(0xFF1A0433);
  static const Color lightTextSecondary = Color(0xFF6B5B85);

  // ---- تأثير النيون ----
  static const Color neonGlow = Color(0xFFB537F2);

  // ---- ألوان دلالية ----
  static const Color success = Color(0xFF2ECC71);
  static const Color error = Color(0xFFE74C3C);
  static const Color warning = Color(0xFFF39C12);
}
