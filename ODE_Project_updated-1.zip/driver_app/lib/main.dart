import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/providers/theme_provider.dart';
import 'core/providers/driver_auth_provider.dart';
import 'core/config/appearance_provider.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/driver_login_screen.dart';
import 'features/home/driver_home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  final themeProvider = ThemeProvider();
  await themeProvider.loadSavedTheme();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider(create: (_) => DriverAuthProvider()..loadFromStorage()),
        // طلب صريح: تحكّم الأدمن الكامل بالشعار/الألوان/حجم الخط/الوضع
        // الافتراضي بدون كود — نفس نظام تطبيق العميل بالضبط.
        ChangeNotifierProvider(create: (_) => AppearanceProvider()..load()),
      ],
      child: const OdeDriverApp(),
    ),
  );
}

class OdeDriverApp extends StatelessWidget {
  const OdeDriverApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final driverAuth = context.watch<DriverAuthProvider>();
    final appearance = context.watch<AppearanceProvider>();

    if (appearance.isLoaded) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        themeProvider.applyRemoteDefault(appearance.defaultThemeMode);
      });
    }

    return MaterialApp(
      title: 'ODE للسائقين',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeProvider.themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(appearance.fontScale)),
        child: child!,
      ),
      home: driverAuth.isAuthenticated ? const DriverHomeScreen() : const DriverLoginScreen(),
    );
  }
}
