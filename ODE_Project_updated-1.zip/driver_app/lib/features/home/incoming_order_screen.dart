import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/providers/driver_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'active_delivery_screen.dart';
import 'package:ode_driver_app/core/config/env.dart';

/// بند 6: "قبول/رفض الطلب" — تظهر فور وصول order:assigned عبر Socket.
class IncomingOrderScreen extends StatefulWidget {
  final String orderId;
  const IncomingOrderScreen({super.key, required this.orderId});

  @override
  State<IncomingOrderScreen> createState() => _IncomingOrderScreenState();
}

class _IncomingOrderScreenState extends State<IncomingOrderScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  Map<String, dynamic>? _order;
  bool _isResponding = false;

  @override
  void initState() {
    super.initState();
    _loadOrder();
  }

  Future<void> _loadOrder() async {
    final token = context.read<DriverAuthProvider>().token!;
    final response = await http.get(Uri.parse('$baseUrl/orders/${widget.orderId}'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode == 200 && mounted) setState(() => _order = jsonDecode(response.body));
  }

  Future<void> _decline() async {
    setState(() => _isResponding = true);
    final token = context.read<DriverAuthProvider>().token!;
    await http.patch(Uri.parse('$baseUrl/orders/${widget.orderId}/decline'), headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'});
    if (mounted) Navigator.pop(context);
  }

  void _accept() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ActiveDeliveryScreen(orderId: widget.orderId)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: _order == null
                ? CircularProgressIndicator(color: AppColors.primaryPurple)
                : GlassContainer(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.delivery_dining_rounded, size: 48, color: AppColors.primaryPurpleLight),
                        const SizedBox(height: 12),
                        Text('طلب جديد #${_order!['order_number']}', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 8),
                        Text(_order!['pickup_address'] ?? 'عنوان الاستلام غير محدد', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.darkTextSecondary)),
                        const SizedBox(height: 4),
                        Text('${_order!['total']}', style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 24),
                        Row(children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: _isResponding ? null : _decline,
                              child: const Text('رفض', style: TextStyle(color: AppColors.error)),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: NeonButton(label: 'قبول', onPressed: _accept)),
                        ]),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
