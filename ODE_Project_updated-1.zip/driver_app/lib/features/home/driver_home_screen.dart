import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import '../../core/providers/driver_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/socket_service.dart';
import '../earnings/earnings_screen.dart';
import 'incoming_order_screen.dart';
import '../settings/driver_settings_screen.dart';
import 'package:ode_driver_app/core/config/env.dart';

/// الرئيسية بعد التفعيل (بند 6): تشغيل/إيقاف الحالة + بث الموقع اللحظي
/// طالما السائق متصل (هذا بالضبط ما يحرّك الدبّوس بشاشة العميل).
/// استقبال الطلبات الحيّة نفسها (قبول/رفض) لسه الخطوة التالية.
class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  bool _isAvailable = false;
  bool _isUpdating = false;
  StreamSubscription<Position>? _positionStream;

  @override
  void dispose() {
    _positionStream?.cancel();
    SocketService.disconnect();
    super.dispose();
  }

  Future<void> _startBroadcastingLocation() async {
    final permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      final requested = await Geolocator.requestPermission();
      if (requested == LocationPermission.denied) return;
    }

    final token = context.read<DriverAuthProvider>().token!;
    final socket = SocketService.connect(token);

    _positionStream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 20),
    ).listen((position) {
      socket.emit('driver:location', {'lat': position.latitude, 'lng': position.longitude});
    });

    // بند 6: إشعار طلب جديد يوصل فورًا عبر نفس اتصال Socket المستخدم للموقع.
    socket.on('order:assigned', (data) {
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => IncomingOrderScreen(orderId: data['orderId'])));
    });
  }

  void _stopBroadcastingLocation() {
    _positionStream?.cancel();
    _positionStream = null;
    SocketService.disconnect();
  }

  Future<void> _toggleAvailability() async {
    final auth = context.read<DriverAuthProvider>();
    final newStatus = _isAvailable ? 'offline' : 'available';
    setState(() => _isUpdating = true);
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/driver-app/status'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ${auth.token}'},
        body: jsonEncode({'status': newStatus}),
      );
      if (response.statusCode == 200) {
        setState(() => _isAvailable = newStatus == 'available');
        if (_isAvailable) {
          await _startBroadcastingLocation();
        } else {
          _stopBroadcastingLocation();
        }
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر تحديث الحالة')));
      }
    } finally {
      if (mounted) setState(() => _isUpdating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<DriverAuthProvider>();
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(
        title: const Text('ODE للسائقين'),
        backgroundColor: Colors.transparent,
        actions: [
          // إضافة (طلب صريح): شاشة إعدادات كانت مفقودة بالكامل بتطبيق السائق.
          IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () =>
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverSettingsScreen()))),
          IconButton(icon: const Icon(Icons.logout_rounded), onPressed: () {
            _stopBroadcastingLocation();
            auth.logout();
          }),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GlassContainer(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Icon(
                    _isAvailable ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                    color: _isAvailable ? AppColors.success : AppColors.darkTextSecondary,
                    size: 40,
                  ),
                  const SizedBox(height: 12),
                  Text(_isAvailable ? 'متصل — بانتظار الطلبات' : 'غير متصل',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 20),
                  NeonButton(
                    label: _isAvailable ? 'إيقاف الاستقبال' : 'بدء استقبال الطلبات',
                    isLoading: _isUpdating,
                    onPressed: _toggleAvailability,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EarningsScreen())),
              child: GlassContainer(
                child: Row(children: [
                  Icon(Icons.account_balance_wallet_rounded, color: AppColors.primaryPurpleLight),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('أرباحي')),
                  const Icon(Icons.arrow_back_ios_rounded, size: 14, color: AppColors.darkTextSecondary),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
