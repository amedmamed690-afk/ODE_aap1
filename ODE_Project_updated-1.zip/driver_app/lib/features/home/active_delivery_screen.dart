import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/providers/driver_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'package:ode_driver_app/core/config/env.dart';

/// بند 6: "تحديث حالة الطلب" — يمشي بالترتيب: تم الاستلام -> في الطريق
/// -> تم التوصيل. كل زر يستدعي order-flow.service.ts نفسه اللي يتحقق
/// من صحة الانتقال (transition من status لازم يطابق الترتيب الفعلي).
class ActiveDeliveryScreen extends StatefulWidget {
  final String orderId;
  const ActiveDeliveryScreen({super.key, required this.orderId});

  @override
  State<ActiveDeliveryScreen> createState() => _ActiveDeliveryScreenState();
}

class _ActiveDeliveryScreenState extends State<ActiveDeliveryScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  Map<String, dynamic>? _order;
  bool _isUpdating = false;

  static const _nextStatus = {
    'driver_assigned': 'picked_up',
    'picked_up': 'on_the_way',
    'on_the_way': 'delivered',
  };
  static const _actionLabels = {
    'driver_assigned': 'تأكيد استلام الطلب', 'picked_up': 'بدء التوصيل', 'on_the_way': 'تأكيد التوصيل',
  };

  @override
  void initState() {
    super.initState();
    _loadOrder();
  }

  Future<void> _loadOrder() async {
    final token = context.read<DriverAuthProvider>().token!;
    final response = await http.get(Uri.parse('$baseUrl/orders/${widget.orderId}'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode == 200 && mounted) setState(() => _order = jsonDecode(response.body));
  }

  Future<void> _advanceStatus() async {
    final next = _nextStatus[_order?['status']];
    if (next == null) return;
    setState(() => _isUpdating = true);
    try {
      final token = context.read<DriverAuthProvider>().token!;
      final response = await http.patch(
        Uri.parse('$baseUrl/orders/${widget.orderId}/status'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
        body: jsonEncode({'status': next}),
      );
      if (response.statusCode == 200) {
        if (next == 'delivered' && mounted) {
          Navigator.pop(context);
          return;
        }
        await _loadOrder();
      }
    } finally {
      if (mounted) setState(() => _isUpdating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = _order?['status'];
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: Text('طلب #${_order?['order_number'] ?? ''}'), backgroundColor: Colors.transparent),
      body: _order == null
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  GlassContainer(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('نقطة الاستلام', style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                        Text(_order!['pickup_address'] ?? '—', style: Theme.of(context).textTheme.titleSmall),
                        const SizedBox(height: 16),
                        Text('الإجمالي', style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                        Text('${_order!['total']}', style: Theme.of(context).textTheme.titleMedium),
                      ],
                    ),
                  ),
                  const Spacer(),
                  if (_actionLabels.containsKey(status))
                    NeonButton(label: _actionLabels[status]!, isLoading: _isUpdating, onPressed: _advanceStatus),
                ],
              ),
            ),
    );
  }
}
