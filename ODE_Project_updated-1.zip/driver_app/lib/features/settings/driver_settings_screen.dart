import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/providers/theme_provider.dart';
import '../../core/providers/driver_auth_provider.dart';
import '../../core/config/appearance_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';

/// شاشة الإعدادات — كانت مفقودة تمامًا بتطبيق السائق (لا يوجد أي مكان
/// لتغيير المظهر أو الوصول لخدمة العملاء). طلب صريح: "خدمة العملاء" لازم
/// تكون بالملف الشخصي بتطبيق السائق أيضًا، ونفس مطلب الوضع الفاتح/الداكن.
class DriverSettingsScreen extends StatelessWidget {
  const DriverSettingsScreen({super.key});

  Future<void> _openCustomerSupport(BuildContext context) async {
    final url = context.read<AppearanceProvider>().customerSupportUrl;
    if (url == null || url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خدمة العملاء غير مفعّلة حاليًا')));
      return;
    }
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح رابط خدمة العملاء')));
    }
  }

  void _openThemePicker(BuildContext context) {
    final themeProvider = context.read<ThemeProvider>();
    showModalBottomSheet(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('المظهر')),
          ListTile(leading: const Icon(Icons.dark_mode_rounded), title: const Text('داكن'),
            onTap: () { themeProvider.setMode(ThemeMode.dark); Navigator.pop(sheetContext); }),
          ListTile(leading: const Icon(Icons.light_mode_rounded), title: const Text('فاتح'),
            onTap: () { themeProvider.setMode(ThemeMode.light); Navigator.pop(sheetContext); }),
          ListTile(leading: const Icon(Icons.brightness_auto_rounded), title: const Text('حسب إعدادات الجهاز'),
            onTap: () { themeProvider.setMode(ThemeMode.system); Navigator.pop(sheetContext); }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _tile(context, Icons.support_agent_rounded, 'خدمة العملاء', () => _openCustomerSupport(context)),
          _tile(context, Icons.palette_outlined, 'المظهر', () => _openThemePicker(context)),
          _tile(context, Icons.logout_rounded, 'تسجيل الخروج', () => context.read<DriverAuthProvider>().logout(), isDestructive: true),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String label, VoidCallback onTap, {bool isDestructive = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: GlassContainer(
          child: Row(children: [
            Icon(icon, color: isDestructive ? AppColors.error : AppColors.primaryPurpleLight),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: TextStyle(color: isDestructive ? AppColors.error : AppColors.darkTextPrimary))),
          ]),
        ),
      ),
    );
  }
}
