import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/driver_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'earnings_controller.dart';

/// شاشة "أرباحي" — كانت مفقودة تماماً قبل كذا لأن نظام أرباح السائق
/// نفسه ما كانش موجود بقاعدة البيانات. تعرض الرصيد المستحق، ملخص
/// الفترة، سجل الحركات، وطلب السحب.
class EarningsScreen extends StatefulWidget {
  const EarningsScreen({super.key});

  @override
  State<EarningsScreen> createState() => _EarningsScreenState();
}

class _EarningsScreenState extends State<EarningsScreen> {
  final EarningsController _controller = EarningsController();
  DriverWalletModel? _wallet;
  Map<String, dynamic>? _summary;
  List<DriverTxnModel> _transactions = [];
  String _period = 'today';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      final token = context.read<DriverAuthProvider>().token!;
      final results = await Future.wait([
        _controller.fetchWallet(token),
        _controller.fetchSummary(token, _period),
        _controller.fetchTransactions(token),
      ]);
      if (mounted) {
        setState(() {
          _wallet = results[0] as DriverWalletModel;
          _summary = results[1] as Map<String, dynamic>;
          _transactions = results[2] as List<DriverTxnModel>;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _showWithdrawSheet() async {
    final amountController = TextEditingController();
    final accountController = TextEditingController();
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.darkCardBackground,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom, left: 20, right: 20, top: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('طلب سحب أرباح', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.darkTextPrimary)),
            const SizedBox(height: 16),
            TextField(controller: amountController, keyboardType: TextInputType.number,
                style: const TextStyle(color: AppColors.darkTextPrimary),
                decoration: const InputDecoration(hintText: 'المبلغ', hintStyle: TextStyle(color: AppColors.darkTextSecondary))),
            const SizedBox(height: 10),
            TextField(controller: accountController,
                style: const TextStyle(color: AppColors.darkTextPrimary),
                decoration: const InputDecoration(hintText: 'رقم الحساب / المحفظة المالية', hintStyle: TextStyle(color: AppColors.darkTextSecondary))),
            const SizedBox(height: 16),
            NeonButton(
              label: 'إرسال الطلب',
              onPressed: () async {
                final amount = double.tryParse(amountController.text);
                if (amount == null || amount <= 0 || accountController.text.trim().isEmpty) return;
                Navigator.pop(sheetContext);
                try {
                  final token = context.read<DriverAuthProvider>().token!;
                  await _controller.requestWithdrawal(token, amount, {'account': accountController.text.trim()});
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال طلب السحب، بانتظار مراجعة الإدارة')));
                    _load();
                  }
                } catch (e) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر الإرسال: $e')));
                }
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'order_earning': return 'أرباح توصيل';
      case 'ride_earning': return 'أرباح رحلة';
      case 'tip': return 'إكرامية';
      case 'withdrawal': return 'طلب سحب';
      default: return type;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أرباحي')),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                GlassContainer(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      const Text('الرصيد المستحق', style: TextStyle(color: AppColors.darkTextSecondary)),
                      const SizedBox(height: 8),
                      Text(_wallet?.balance.toStringAsFixed(2) ?? '0.00', style: Theme.of(context).textTheme.headlineLarge?.copyWith(fontSize: 34)),
                      const SizedBox(height: 4),
                      Text('إجمالي تاريخي: ${_wallet?.totalEarned.toStringAsFixed(2) ?? '0.00'}', style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 11)),
                      const SizedBox(height: 20),
                      NeonButton(label: 'طلب سحب', icon: Icons.account_balance_rounded, onPressed: _showWithdrawSheet),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: ['today', 'week', 'month'].map((p) => Expanded(
                    child: GestureDetector(
                      onTap: () { setState(() => _period = p); _load(); },
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: _period == p ? AppColors.primaryPurple : AppColors.darkCardBackground,
                        ),
                        child: Text(p == 'today' ? 'اليوم' : p == 'week' ? 'الأسبوع' : 'الشهر',
                            textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ),
                  )).toList(),
                ),
                if (_summary != null) ...[
                  const SizedBox(height: 12),
                  GlassContainer(
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Column(children: [
                        Text('${_summary!['total_earnings']}', style: Theme.of(context).textTheme.titleMedium),
                        const Text('الأرباح', style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 11)),
                      ]),
                      Column(children: [
                        Text('${_summary!['completed_trips']}', style: Theme.of(context).textTheme.titleMedium),
                        const Text('رحلات مكتملة', style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 11)),
                      ]),
                    ]),
                  ),
                ],
                const SizedBox(height: 24),
                Text('سجل الحركات', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 12),
                if (_transactions.isEmpty)
                  const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد حركات بعد')))
                else
                  ..._transactions.map((t) => Card(
                        color: AppColors.darkCardBackground,
                        child: ListTile(
                          leading: Icon(t.amount >= 0 ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded,
                              color: t.amount >= 0 ? AppColors.success : AppColors.error),
                          title: Text(_typeLabel(t.type)),
                          subtitle: Text('${t.createdAt.day}/${t.createdAt.month}/${t.createdAt.year}'),
                          trailing: Text(t.amount.toStringAsFixed(2),
                              style: TextStyle(color: t.amount >= 0 ? AppColors.success : AppColors.error, fontWeight: FontWeight.bold)),
                        ),
                      )),
              ],
            ),
    );
  }
}
