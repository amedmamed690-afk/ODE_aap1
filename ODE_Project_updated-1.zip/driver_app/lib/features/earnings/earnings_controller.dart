import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_driver_app/core/config/env.dart';

class DriverWalletModel {
  final double balance;
  final double totalEarned;
  DriverWalletModel({required this.balance, required this.totalEarned});

  factory DriverWalletModel.fromJson(Map<String, dynamic> j) =>
      DriverWalletModel(balance: (j['balance'] as num).toDouble(), totalEarned: (j['totalEarned'] as num).toDouble());
}

class DriverTxnModel {
  final String type;
  final double amount;
  final DateTime createdAt;
  DriverTxnModel({required this.type, required this.amount, required this.createdAt});

  factory DriverTxnModel.fromJson(Map<String, dynamic> j) => DriverTxnModel(
        type: j['type'],
        amount: (j['amount'] as num).toDouble(),
        createdAt: DateTime.parse(j['createdAt']),
      );
}

class EarningsController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<DriverWalletModel> fetchWallet(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/driver-earnings/wallet'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل الرصيد');
    return DriverWalletModel.fromJson(jsonDecode(response.body));
  }

  Future<Map<String, dynamic>> fetchSummary(String token, String period) async {
    final response = await http.get(Uri.parse('$baseUrl/driver-earnings/summary?period=$period'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل الملخص');
    return jsonDecode(response.body);
  }

  Future<List<DriverTxnModel>> fetchTransactions(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/driver-earnings/transactions'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('تعذر تحميل سجل الحركات');
    final list = jsonDecode(response.body) as List;
    return list.map((e) => DriverTxnModel.fromJson(e)).toList();
  }

  Future<void> requestWithdrawal(String token, double amount, Map<String, dynamic> payoutDetails) async {
    final response = await http.post(
      Uri.parse('$baseUrl/driver-earnings/withdraw'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode({'amount': amount, 'payoutDetails': payoutDetails}),
    );
    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['error'] ?? 'تعذر إرسال الطلب');
    }
  }
}
