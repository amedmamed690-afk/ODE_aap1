import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_driver_app/core/config/env.dart';

class DriverCategoryModel {
  final String id;
  final String nameAr;
  DriverCategoryModel({required this.id, required this.nameAr});

  factory DriverCategoryModel.fromJson(Map<String, dynamic> json) =>
      DriverCategoryModel(id: json['id'], nameAr: json['nameAr']);
}

/// نفس شكل OnboardingController الخاص بالشريك بالضبط، لكن لمسارات
/// /driver-onboarding بدل /partner-onboarding (بند 6).
class DriverOnboardingController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<DriverCategoryModel>> fetchCategories(String domain) async {
    final response = await http.get(Uri.parse('$baseUrl/driver-onboarding/options?domain=$domain'));
    if (response.statusCode != 200) throw Exception('تعذر تحميل الفئات');
    final list = jsonDecode(response.body) as List;
    return list.map((e) => DriverCategoryModel.fromJson(e)).toList();
  }

  Future<String> submitApplication(String token, Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse('$baseUrl/driver-onboarding/submit'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      body: jsonEncode(data),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 201) {
      throw Exception(body['error'] ?? 'تعذر إرسال الطلب');
    }
    // بند 28: توكن جديد يعكس ترقية الحساب لـdriver — القديم بيصير غير
    // صالح لأي endpoint يتطلب دور السائق فور هذا الاستدعاء.
    return body['token'];
  }
}
