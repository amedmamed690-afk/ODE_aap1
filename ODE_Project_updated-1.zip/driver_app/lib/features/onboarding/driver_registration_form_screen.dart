import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/providers/driver_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/upload_service.dart';
import '../../core/config/app_config.dart';
import 'driver_onboarding_controller.dart';
import 'pending_approval_screen.dart';

/// الخطوة الأخيرة بتسجيل السائق (بند 6): بيانات المركبة + رخصة القيادة.
/// نفس فلسفة RegistrationFormScreen الخاصة بالشريك (زر الإرسال معطّل
/// لحد ما كل شيء إجباري يكتمل) لكن بحقول مختلفة تمامًا.
class DriverRegistrationFormScreen extends StatefulWidget {
  final DriverCategoryModel category;
  const DriverRegistrationFormScreen({super.key, required this.category});

  @override
  State<DriverRegistrationFormScreen> createState() => _DriverRegistrationFormScreenState();
}

class _DriverRegistrationFormScreenState extends State<DriverRegistrationFormScreen> {
  final DriverOnboardingController _controller = DriverOnboardingController();
  final UploadService _uploadService = UploadService();

  final _plateController = TextEditingController();
  String? _vehicleType;
  String? _licenseUrl;
  bool _isUploadingLicense = false;
  bool _isSubmitting = false;
  String? _error;

  static const _vehicleTypes = {
    'motorbike': 'دراجة نارية',
    'car': 'سيارة',
    'van': 'فان',
    'tow_truck': 'ساحبة/نش',
    'moving_truck': 'شاحنة نقل أثاث',
  };

  // إصلاح (بند C بالتقرير): كان يرسل اسم ملف وهمي ثابت 'driving_license.jpg'
  // غير موجود فعليًا على الجهاز أصلاً — أي محاولة رفع حقيقية كانت ستفشل
  // فورًا (الملف غير موجود بالمسار). الآن يفتح الكاميرا/المعرض فعليًا
  // عبر image_picker ويرفع الصورة الحقيقية المُلتقطة.
  Future<void> _uploadLicense() async {
    final picked = await showModalBottomSheet<XFile?>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_rounded),
            title: const Text('التقاط صورة بالكاميرا'),
            onTap: () async => Navigator.pop(sheetContext, await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85)),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_rounded),
            title: const Text('اختيار من المعرض'),
            onTap: () async => Navigator.pop(sheetContext, await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85)),
          ),
        ]),
      ),
    );
    if (picked == null) return;

    setState(() => _isUploadingLicense = true);
    try {
      final token = context.read<DriverAuthProvider>().pendingToken;
      final ext = picked.path.split('.').last.toLowerCase();
      final url = await _uploadService.uploadFile(
        token: token!,
        filePath: picked.path,
        purpose: 'driver_document',
        mimeType: ext == 'png' ? 'image/png' : 'image/jpeg',
      );
      if (mounted) setState(() { _licenseUrl = url; _isUploadingLicense = false; });
    } catch (_) {
      if (mounted) {
        setState(() => _isUploadingLicense = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(backgroundColor: AppColors.error, content: Text('تعذر رفع صورة الرخصة، حاول مرة أخرى')),
        );
      }
    }
  }

  bool get _isFormComplete =>
      _vehicleType != null && _plateController.text.trim().isNotEmpty && _licenseUrl != null;

  Future<void> _submit() async {
    if (!_isFormComplete) {
      setState(() => _error = 'أكمل كل الحقول والمستندات الإجبارية قبل الإرسال');
      return;
    }
    setState(() { _isSubmitting = true; _error = null; });
    try {
      final token = context.read<DriverAuthProvider>().pendingToken;
      final newToken = await _controller.submitApplication(token!, {
        'categoryId': widget.category.id,
        'vehicleType': _vehicleType,
        'plateNumber': _plateController.text.trim(),
        'countryId': AppConfig.defaultCountryId, // بند 9 (Audit): من config مركزي بدل رقم ثابت مكرر
        'licenseDocUrl': _licenseUrl,
      });
      if (!mounted) return;
      // بند 28: نستبدل التوكن القديم فورًا بالتوكن الجديد اللي يعكس دور
      // السائق — قبل ما ننتقل لأي شاشة تحتاج مصادقة سائق.
      await context.read<DriverAuthProvider>().updateTokenAfterUpgrade(newToken);
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const PendingApprovalScreen()), (route) => false);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(title: Text('تسجيل مركبتك — ${widget.category.nameAr}'), backgroundColor: Colors.transparent),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('نوع المركبة', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: _vehicleTypes.entries.map((e) => ChoiceChip(
              label: Text(e.value),
              selected: _vehicleType == e.key,
              onSelected: (_) => setState(() => _vehicleType = e.key),
              selectedColor: AppColors.primaryPurple,
            )).toList(),
          ),
          const SizedBox(height: 16),
          GlassContainer(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: TextField(
              controller: _plateController,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(color: AppColors.darkTextPrimary),
              decoration: const InputDecoration(
                hintText: 'رقم اللوحة',
                hintStyle: TextStyle(color: AppColors.darkTextSecondary),
                prefixIcon: Icon(Icons.pin_rounded, color: AppColors.primaryPurpleLight),
                border: InputBorder.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: _isUploadingLicense ? null : _uploadLicense,
            child: GlassContainer(
              child: Row(children: [
                Icon(Icons.badge_outlined, color: AppColors.primaryPurpleLight),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(_isUploadingLicense ? 'جاري الرفع...' : (_licenseUrl == null ? 'رفع رخصة القيادة (إجباري)' : 'تم رفع الرخصة ✓')),
                ),
              ]),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 16),
            Text(_error!, style: const TextStyle(color: AppColors.error), textAlign: TextAlign.center),
          ],
          const SizedBox(height: 24),
          NeonButton(label: 'إرسال الطلب', isLoading: _isSubmitting, disabled: !_isFormComplete, onPressed: _submit),
        ],
      ),
    );
  }
}
