import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';

/// شاشة "بانتظار موافقة الإدارة" — بند 4، ما فيها أي إجراء غير الخروج،
/// لأن لوحة الشريك تفضل مقفولة (dashboard_unlocked = false) لحد الموافقة.
class PendingApprovalScreen extends StatelessWidget {
  const PendingApprovalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: GlassContainer(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.hourglass_top_rounded, color: AppColors.primaryPurpleLight, size: 48),
                const SizedBox(height: 16),
                Text('تم تقديم طلبك بنجاح', style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
                const SizedBox(height: 8),
                const Text(
                  'طلبك الآن في انتظار موافقة الإدارة. سيصلك إشعار فور المراجعة، وبعدها تُفتح لوحة تحكمك لإدخال أوقات العمل والمنتجات والترخيص.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12, height: 1.6),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
