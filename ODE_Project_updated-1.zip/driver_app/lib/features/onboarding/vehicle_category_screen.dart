import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'category_picker_screen.dart';

/// الخطوة 1 (بند 1): اختيار القسم الرئيسي (توصيل طلبات / نقل ركاب
/// ولوجستيات)، ثم الفئة الفرعية جوّه القسم المختار.
class VehicleCategoryScreen extends StatefulWidget {
  const VehicleCategoryScreen({super.key});

  @override
  State<VehicleCategoryScreen> createState() => _VehicleCategoryScreenState();
}

class _VehicleCategoryScreenState extends State<VehicleCategoryScreen> {
  String? _domain; // 'delivery' | 'ride'

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل سائق جديد')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('اختر قسم عملك', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 20),
            _SectionCard(
              icon: Icons.two_wheeler_rounded,
              title: 'توصيل الطلبات',
              subtitle: 'موتور، سيارة عادية، أو بورتر/تركتور للبضائع الكبيرة',
              onTap: () => setState(() => _domain = 'delivery'),
              selected: _domain == 'delivery',
            ),
            const SizedBox(height: 14),
            _SectionCard(
              icon: Icons.local_taxi_rounded,
              title: 'نقل الركاب والخدمات اللوجستية',
              subtitle: 'تاكسي عادي، VIP، ساحبة/نش، أو شاحنة نقل أثاث',
              onTap: () => setState(() => _domain = 'ride'),
              selected: _domain == 'ride',
            ),
            const Spacer(),
            if (_domain != null)
              ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryPickerScreen(domain: _domain!))),
                child: const Text('متابعة'),
              ),
          ],
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool selected;
  final VoidCallback onTap;

  const _SectionCard({required this.icon, required this.title, required this.subtitle, required this.onTap, required this.selected});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: selected ? Border.all(color: AppColors.primaryPurpleLight, width: 2) : null,
        ),
        child: GlassContainer(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Icon(icon, color: AppColors.primaryPurpleLight, size: 32),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium),
                    Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
