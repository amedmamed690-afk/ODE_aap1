import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';

/// شاشة مشتركة لحالتي "مرفوض" و"موقوف" (بند 6: السائق الموقوف يُمنع من
/// استقبال الطلبات) — isSuspended تغيّر العنوان والأيقونة فقط.
class RejectedScreen extends StatelessWidget {
  final String? reason;
  final bool isSuspended;
  const RejectedScreen({super.key, this.reason, this.isSuspended = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: GlassContainer(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(isSuspended ? Icons.pause_circle_filled_rounded : Icons.cancel_rounded,
                    color: AppColors.error, size: 48),
                const SizedBox(height: 16),
                Text(
                  isSuspended ? 'تم إيقاف حسابك مؤقتًا' : 'لم تتم الموافقة على طلبك',
                  style: Theme.of(context).textTheme.titleMedium,
                  textAlign: TextAlign.center,
                ),
                if (reason != null) ...[
                  const SizedBox(height: 8),
                  Text(reason!, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
