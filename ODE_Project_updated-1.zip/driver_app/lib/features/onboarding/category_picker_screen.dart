import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'driver_onboarding_controller.dart';
import 'driver_registration_form_screen.dart';

class CategoryPickerScreen extends StatefulWidget {
  final String domain; // 'delivery' | 'ride'
  const CategoryPickerScreen({super.key, required this.domain});

  @override
  State<CategoryPickerScreen> createState() => _CategoryPickerScreenState();
}

class _CategoryPickerScreenState extends State<CategoryPickerScreen> {
  final DriverOnboardingController _controller = DriverOnboardingController();
  List<DriverCategoryModel> _categories = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final cats = await _controller.fetchCategories(widget.domain);
      if (mounted) setState(() { _categories = cats; _isLoading = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اختر فئتك')),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final cat = _categories[i];
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DriverRegistrationFormScreen(category: cat))),
                  child: GlassContainer(
                    child: Row(children: [
                      Icon(Icons.directions_car_filled_rounded, color: AppColors.primaryPurpleLight),
                      const SizedBox(width: 14),
                      Expanded(child: Text(cat.nameAr, style: Theme.of(context).textTheme.titleMedium)),
                      const Icon(Icons.arrow_back_ios_rounded, size: 14, color: AppColors.darkTextSecondary),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}
