import 'package:socket_io_client/socket_io_client.dart' as socket_io;
import 'package:ode_driver_app/core/config/env.dart';

/// اتصال Socket.io واحد لكل جلسة تطبيق — نفس الأحداث اللي يبثّها
/// server.ts فعليًا: ride:driver_location, ride:driver_assigned,
/// ride:driver_arrived, ride:started, ride:completed, ride:cancelled.
class SocketService {
  static socket_io.Socket? _socket;

  static socket_io.Socket connect(String token) {
    _socket?.dispose();
    _socket = socket_io.io(
      Env.apiBaseUrl, // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
      socket_io.OptionBuilder()
          .setTransports(['websocket'])
          .setAuth({'token': token})
          .disableAutoConnect()
          .build(),
    );
    _socket!.connect();
    return _socket!;
  }

  static void disconnect() {
    _socket?.dispose();
    _socket = null;
  }
}
