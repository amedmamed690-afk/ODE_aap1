import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_driver_app/core/config/env.dart';

/// خدمة رفع ملفات حقيقية مشتركة — تستبدل كل دوال uploadDocument()
/// الوهمية اللي كانت موجودة بالتسجيل (شريك/سائق) وترجع رابط وهمي.
/// نفس الخدمة تصلح لأي تطبيق (عميل/شريك/سائق) بمجرد نسخ الملف —
/// فقط الـ token يختلف حسب نوع الحساب المسجّل دخوله.
class UploadService {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  /// purpose: 'product_image' | 'partner_document' | 'driver_document' | 'short_video'
  /// المستندات الحساسة (جواز، رخصة) لازم تحتوي كلمة "document" بالـ
  /// purpose عشان تتخزن بصلاحية خاصة بالسيرفر (مش عامة للجميع).
  Future<String> uploadFile({
    required String token,
    required String filePath,
    required String purpose,
    required String mimeType, // 'image/jpeg' | 'image/png' | 'application/pdf'
  }) async {
    final request = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload'))
      ..headers['Authorization'] = 'Bearer $token'
      ..fields['purpose'] = purpose
      ..files.add(await http.MultipartFile.fromPath('file', filePath));

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode != 201) {
      final err = jsonDecode(response.body);
      throw UploadException(err['error'] ?? 'upload_failed');
    }
    final data = jsonDecode(response.body);
    // مستندات الهوية الحساسة (driver_document/partner_document) ترجع
    // 'key' بس (بند 8 بمراجعة الأمان: bucket منفصل غير عام) — كل شيء
    // ثاني (صور منتجات، فيديو Shorts) يرجع 'url' عام مباشر.
    return data['url'] ?? data['key'];
  }
}

class UploadException implements Exception {
  final String code;
  UploadException(this.code);

  String get userMessage {
    switch (code) {
      case 'file_too_large_max_8mb': return 'حجم الملف أكبر من المسموح (8 ميجا)';
      case 'video_too_large_max_80mb': return 'حجم الفيديو أكبر من المسموح (80 ميجا)';
      case 'video_not_allowed_for_this_purpose': return 'الفيديو غير مسموح لهذا النوع من الرفع';
      case 'unsupported_file_type': return 'نوع الملف غير مدعوم';
      default: return 'تعذر رفع الملف، حاول مرة أخرى';
    }
  }
}
