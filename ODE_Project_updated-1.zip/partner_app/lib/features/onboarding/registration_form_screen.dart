import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../core/providers/partner_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import 'onboarding_controller.dart';
import 'pending_approval_screen.dart';
import 'pick_location_screen.dart';
import '../../core/config/app_config.dart';

/// الخطوة 3: كل البيانات والمستندات الإجبارية دفعة واحدة (بند 3) —
/// زر الإرسال معطّل تماماً لحد ما كل حقل إجباري يتعبى + المستندات تترفع،
/// بدل ما نسمح بإرسال ناقص ونرفضه من السيرفر بعدين.
class RegistrationFormScreen extends StatefulWidget {
  final String businessType;
  final String accountType;
  final String? digitalSubtypeId;

  const RegistrationFormScreen({super.key, required this.businessType, required this.accountType, this.digitalSubtypeId});

  @override
  State<RegistrationFormScreen> createState() => _RegistrationFormScreenState();
}

class _RegistrationFormScreenState extends State<RegistrationFormScreen> {
  final OnboardingController _controller = OnboardingController();
  final _formKey = GlobalKey<FormState>();

  final _ownerNameController = TextEditingController();
  final _nationalIdController = TextEditingController();
  final _primaryPhoneController = TextEditingController();
  final _secondaryPhoneController = TextEditingController();
  final _storeNameController = TextEditingController();

  List<ActivityCategory> _categories = [];
  String? _selectedCategoryId;
  String? _passportUrl;
  String? _licenseUrl;
  bool _isUploadingLicense = false;
  double? _gpsLat, _gpsLng;
  bool _isUploadingPassport = false;
  bool _isSubmitting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    try {
      final options = await _controller.fetchOptions();
      if (mounted) setState(() => _categories = options['activityCategories']!);
    } catch (_) {}
  }

  // إصلاح (بند G — مشكلة Build حقيقية): الاستدعاء القديم
  // `_controller.uploadDocument('passport_photo.jpg')` كان بمعامل واحد
  // فقط، بينما التوقيع الفعلي `uploadDocument(token, filePath, mimeType)`
  // يطلب 3 معاملات إجبارية — هذا لا يُبنى (compile error) أصلاً، بصرف
  // النظر عن مشكلة عدم ربط image_picker. تم إصلاح الاثنين معًا.
  Future<XFile?> _pickImage() {
    return showModalBottomSheet<XFile?>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_rounded),
            title: const Text('التقاط صورة بالكاميرا'),
            onTap: () async => Navigator.pop(sheetContext, await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85)),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_rounded),
            title: const Text('اختيار من المعرض'),
            onTap: () async => Navigator.pop(sheetContext, await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85)),
          ),
        ]),
      ),
    );
  }

  String _mimeTypeOf(String path) => path.split('.').last.toLowerCase() == 'png' ? 'image/png' : 'image/jpeg';

  Future<void> _uploadPassport() async {
    final picked = await _pickImage();
    if (picked == null) return;
    setState(() => _isUploadingPassport = true);
    try {
      final token = context.read<PartnerAuthProvider>().pendingToken!;
      final url = await _controller.uploadDocument(token, picked.path, _mimeTypeOf(picked.path));
      if (mounted) setState(() { _passportUrl = url; _isUploadingPassport = false; });
    } catch (e) {
      if (mounted) {
        setState(() { _isUploadingPassport = false; _error = e.toString().replaceFirst('Exception: ', ''); });
      }
    }
  }

  Future<void> _uploadLicense() async {
    final picked = await _pickImage();
    if (picked == null) return;
    setState(() => _isUploadingLicense = true);
    try {
      final token = context.read<PartnerAuthProvider>().pendingToken!;
      final url = await _controller.uploadDocument(token, picked.path, _mimeTypeOf(picked.path));
      if (mounted) setState(() { _licenseUrl = url; _isUploadingLicense = false; });
    } catch (e) {
      if (mounted) {
        setState(() { _isUploadingLicense = false; _error = e.toString().replaceFirst('Exception: ', ''); });
      }
    }
  }

  bool get _isPhysical => widget.accountType == 'physical';

  Future<void> _pickLocation() async {
    // إصلاح (بند C بالتقرير): كانت الإحداثيات ثابتة (32.8872, 13.1913)
    // لكل الشركاء بغض النظر عن موقعهم الحقيقي.
    final picked = await Navigator.push<LatLng>(context, MaterialPageRoute(builder: (_) => const PickLocationScreen()));
    if (picked != null) setState(() { _gpsLat = picked.latitude; _gpsLng = picked.longitude; });
  }

  bool get _isFormComplete =>
      _ownerNameController.text.trim().length >= 6 &&
      _nationalIdController.text.trim().isNotEmpty &&
      _primaryPhoneController.text.trim().isNotEmpty &&
      _secondaryPhoneController.text.trim().isNotEmpty &&
      _storeNameController.text.trim().isNotEmpty &&
      _selectedCategoryId != null &&
      _passportUrl != null &&
      // الترخيص إجباري فقط لحساب "أرض الواقع" — الحساب الإلكتروني معفى منه
      (!_isPhysical || _licenseUrl != null) &&
      _gpsLat != null && _gpsLng != null;

  Future<void> _submit() async {
    if (!_isFormComplete) {
      setState(() => _error = 'أكمل جميع الحقول والمستندات الإجبارية قبل الإرسال');
      return;
    }
    setState(() { _isSubmitting = true; _error = null; });

    try {
      final token = context.read<PartnerAuthProvider>().pendingToken; // توكن مؤقت من OTP قبل ما يصير شريك فعلي
      final newToken = await _controller.submitApplication(token!, {
        'businessType': widget.businessType,
        'accountType': widget.accountType,
        if (widget.digitalSubtypeId != null) 'digitalSubtypeId': widget.digitalSubtypeId,
        'ownerFullName': _ownerNameController.text.trim(),
        'nationalIdNumber': _nationalIdController.text.trim(),
        'primaryPhone': _primaryPhoneController.text.trim(),
        'secondaryPhone': _secondaryPhoneController.text.trim(),
        'storeName': _storeNameController.text.trim(),
        'gpsLat': _gpsLat,
        'gpsLng': _gpsLng,
        'activityCategoryId': _selectedCategoryId,
        'countryId': AppConfig.defaultCountryId, // بند 9 (Audit): من config مركزي بدل رقم ثابت مكرر
        'passportImageUrl': _passportUrl,
        if (_licenseUrl != null) 'businessLicenseUrl': _licenseUrl,
      });
      if (!mounted) return;
      // بند 28: نستبدل التوكن القديم فورًا بالتوكن الجديد اللي يعكس دور
      // partner_owner — قبل الانتقال لأي شاشة تحتاج مصادقة شريك.
      await context.read<PartnerAuthProvider>().updateTokenAfterUpgrade(newToken);
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const PendingApprovalScreen()), (route) => false);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بيانات التسجيل')),
      body: Form(
        key: _formKey,
        onChanged: () => setState(() {}),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _field(_ownerNameController, 'الاسم الثلاثي لصاحب النشاط', Icons.badge_rounded),
            const SizedBox(height: 12),
            _field(_nationalIdController, 'الرقم الوطني', Icons.credit_card_rounded, keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            _field(_primaryPhoneController, 'رقم الهاتف الأساسي (مربوط بالرقم الوطني)', Icons.phone_rounded, keyboardType: TextInputType.phone),
            const SizedBox(height: 12),
            _field(_secondaryPhoneController, 'رقم هاتف إضافي', Icons.phone_android_rounded, keyboardType: TextInputType.phone),
            const SizedBox(height: 12),
            _field(_storeNameController, widget.businessType == 'restaurant' ? 'اسم المطعم' : 'اسم المتجر', Icons.store_rounded),
            const SizedBox(height: 16),

            Text('تصنيف النشاط', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 8),
            _categories.isEmpty
                ? CircularProgressIndicator(color: AppColors.primaryPurple)
                : Wrap(
                    spacing: 8, runSpacing: 8,
                    children: _categories.map((c) => ChoiceChip(
                      label: Text(c.nameAr),
                      selected: _selectedCategoryId == c.id,
                      onSelected: (_) => setState(() => _selectedCategoryId = c.id),
                      selectedColor: AppColors.primaryPurple,
                    )).toList(),
                  ),
            const SizedBox(height: 20),

            GestureDetector(
              onTap: _pickLocation,
              child: GlassContainer(
                child: Row(children: [
                  Icon(Icons.location_on_rounded, color: AppColors.primaryPurpleLight),
                  const SizedBox(width: 10),
                  Expanded(child: Text(_gpsLat == null ? 'حدد موقع المتجر/المطعم على الخريطة' : 'تم تحديد الموقع ✓')),
                ]),
              ),
            ),
            const SizedBox(height: 12),

            GestureDetector(
              onTap: _isUploadingPassport ? null : _uploadPassport,
              child: GlassContainer(
                child: Row(children: [
                  Icon(Icons.badge_outlined, color: AppColors.primaryPurpleLight),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_isUploadingPassport ? 'جاري الرفع...' : (_passportUrl == null ? 'رفع صورة جواز السفر (إجباري)' : 'تم رفع الجواز ✓')),
                  ),
                ]),
              ),
            ),

            // الترخيص التجاري يظهر ويكون إجبارياً فقط لحساب "أرض الواقع"
            if (_isPhysical) ...[
              const SizedBox(height: 12),
              GestureDetector(
                onTap: _isUploadingLicense ? null : _uploadLicense,
                child: GlassContainer(
                  child: Row(children: [
                    Icon(Icons.description_outlined, color: AppColors.primaryPurpleLight),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(_isUploadingLicense ? 'جاري الرفع...' : (_licenseUrl == null ? 'رفع الترخيص التجاري (إجباري)' : 'تم رفع الترخيص ✓')),
                    ),
                  ]),
                ),
              ),
            ],

            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: const TextStyle(color: AppColors.error), textAlign: TextAlign.center),
            ],
            const SizedBox(height: 24),
            NeonButton(label: 'إرسال الطلب', isLoading: _isSubmitting, disabled: !_isFormComplete, onPressed: _submit),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, IconData icon, {TextInputType? keyboardType}) {
    return GlassContainer(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(color: AppColors.darkTextPrimary),
        decoration: InputDecoration(hintText: label, hintStyle: TextStyle(color: AppColors.darkTextSecondary), prefixIcon: Icon(icon, color: AppColors.primaryPurpleLight), border: InputBorder.none),
      ),
    );
  }
}
