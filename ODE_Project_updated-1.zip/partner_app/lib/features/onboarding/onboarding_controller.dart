import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../shared/services/upload_service.dart';
import 'package:ode_partner_app/core/config/env.dart';

class ActivityCategory {
  final String id;
  final String nameAr;
  ActivityCategory({required this.id, required this.nameAr});
  factory ActivityCategory.fromJson(Map<String, dynamic> j) => ActivityCategory(id: j['id'], nameAr: j['name_ar']);
}

class OnboardingController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  final UploadService _uploadService = UploadService();

  Future<Map<String, List<ActivityCategory>>> fetchOptions() async {
    final response = await http.get(Uri.parse('$baseUrl/partner-onboarding/options'));
    if (response.statusCode != 200) throw Exception('failed_to_load_options');
    final data = jsonDecode(response.body);
    return {
      'activityCategories': (data['activityCategories'] as List).map((e) => ActivityCategory.fromJson(e)).toList(),
      'digitalSubtypes': (data['digitalSubtypes'] as List).map((e) => ActivityCategory.fromJson(e)).toList(),
    };
  }

  /// رفع حقيقي عبر POST /upload — يرجع رابط دائم فعلي، مش وهمي.
  /// purpose='partner_document' يخلي السيرفر يخزّنه بصلاحية خاصة (مش عامة).
  Future<String> uploadDocument(String token, String filePath, String mimeType) async {
    try {
      return await _uploadService.uploadFile(token: token, filePath: filePath, purpose: 'partner_document', mimeType: mimeType);
    } on UploadException catch (e) {
      throw Exception(e.userMessage);
    }
  }

  Future<String> submitApplication(String token, Map<String, dynamic> payload) async {
    final response = await http.post(
      Uri.parse('$baseUrl/partner-onboarding/submit'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode(payload),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 201) {
      throw Exception(body['error']?.toString() ?? 'submission_failed');
    }
    // بند 28: توكن جديد يعكس ترقية الحساب لـpartner_owner.
    return body['token'];
  }

  Future<Map<String, dynamic>> fetchMyStatus(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/partner-onboarding/my-status'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('no_application_found');
    return jsonDecode(response.body);
  }
}
