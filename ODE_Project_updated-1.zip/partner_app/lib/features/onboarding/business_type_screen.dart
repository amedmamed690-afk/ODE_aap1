import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'account_type_screen.dart';

/// الخطوة 1: اختيار النشاط الرئيسي (متجر أو مطعم) — بند 1
class BusinessTypeScreen extends StatelessWidget {
  const BusinessTypeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل شريك جديد')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('ما هو نوع نشاطك؟', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 20),
            _OptionCard(
              icon: Icons.storefront_rounded,
              title: 'متجر',
              subtitle: 'بقالة، تجميل، إلكترونيات، وغيرها',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountTypeScreen(businessType: 'store'))),
            ),
            const SizedBox(height: 14),
            _OptionCard(
              icon: Icons.restaurant_rounded,
              title: 'مطعم',
              subtitle: 'مطعم، مطبخ منزلي، أو مطبخ افتراضي',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountTypeScreen(businessType: 'restaurant'))),
            ),
          ],
        ),
      ),
    );
  }
}

class _OptionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _OptionCard({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GlassContainer(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primaryPurpleLight, size: 32),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            const Icon(Icons.arrow_back_ios_rounded, size: 14, color: AppColors.darkTextSecondary),
          ],
        ),
      ),
    );
  }
}
