import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'onboarding_controller.dart';
import 'registration_form_screen.dart';

/// الخطوة 2: حساب على أرض الواقع vs حساب إلكتروني — بند 2
/// عند اختيار "إلكتروني" تظهر قائمة فرعية يحددها الأدمن بالكامل.
class AccountTypeScreen extends StatefulWidget {
  final String businessType; // 'store' | 'restaurant'
  const AccountTypeScreen({super.key, required this.businessType});

  @override
  State<AccountTypeScreen> createState() => _AccountTypeScreenState();
}

class _AccountTypeScreenState extends State<AccountTypeScreen> {
  final OnboardingController _controller = OnboardingController();
  String? _selectedAccountType;
  List<ActivityCategory> _digitalSubtypes = [];
  String? _selectedDigitalSubtypeId;
  bool _isLoadingSubtypes = false;

  Future<void> _selectDigital() async {
    setState(() { _selectedAccountType = 'digital'; _isLoadingSubtypes = true; });
    try {
      final options = await _controller.fetchOptions();
      if (mounted) setState(() { _digitalSubtypes = options['digitalSubtypes']!; _isLoadingSubtypes = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoadingSubtypes = false);
    }
  }

  void _continue() {
    if (_selectedAccountType == null) return;
    if (_selectedAccountType == 'digital' && _selectedDigitalSubtypeId == null) return;

    Navigator.push(context, MaterialPageRoute(
      builder: (_) => RegistrationFormScreen(
        businessType: widget.businessType,
        accountType: _selectedAccountType!,
        digitalSubtypeId: _selectedDigitalSubtypeId,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('نوع الحساب')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GestureDetector(
              onTap: () => setState(() { _selectedAccountType = 'physical'; _digitalSubtypes = []; _selectedDigitalSubtypeId = null; }),
              child: GlassContainer(
                padding: const EdgeInsets.all(18),
                style: _selectedAccountType == 'physical' ? {} : null,
                child: Row(children: [
                  Radio<String>(value: 'physical', groupValue: _selectedAccountType, onChanged: (_) => setState(() { _selectedAccountType = 'physical'; _digitalSubtypes = []; }), activeColor: AppColors.primaryPurple),
                  const Expanded(child: Text('حساب على أرض الواقع — لدي محل/مطعم فعلي مرخّص')),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: _selectDigital,
              child: GlassContainer(
                padding: const EdgeInsets.all(18),
                child: Row(children: [
                  Radio<String>(value: 'digital', groupValue: _selectedAccountType, onChanged: (_) => _selectDigital(), activeColor: AppColors.primaryPurple),
                  const Expanded(child: Text('حساب إلكتروني — نشاط رقمي / أسرة منتجة بدون محل واقعي')),
                ]),
              ),
            ),
            if (_selectedAccountType == 'digital') ...[
              const SizedBox(height: 16),
              if (_isLoadingSubtypes)
                Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
              else if (_digitalSubtypes.isEmpty)
                const Text('لا توجد أنواع فرعية متاحة حالياً', style: TextStyle(color: AppColors.darkTextSecondary))
              else
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: _digitalSubtypes.map((s) => ChoiceChip(
                    label: Text(s.nameAr),
                    selected: _selectedDigitalSubtypeId == s.id,
                    onSelected: (_) => setState(() => _selectedDigitalSubtypeId = s.id),
                    selectedColor: AppColors.primaryPurple,
                  )).toList(),
                ),
            ],
            const Spacer(),
            ElevatedButton(onPressed: _continue, child: const Text('متابعة')),
          ],
        ),
      ),
    );
  }
}
