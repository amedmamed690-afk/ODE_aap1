import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/neon_effects.dart';

/// إصلاح (بند C بالتقرير): كان تحديد موقع المتجر/المطعم مثبّتًا على
/// إحداثيات ثابتة (طرابلس، 32.8872/13.1913) بغض النظر عن الموقع الفعلي —
/// كل الشركاء بأي مدينة كانوا سيُسجَّلون بنفس النقطة تمامًا. هذه شاشة
/// خريطة حقيقية تُرجع الإحداثيات التي يحددها المستخدم فعليًا.
class PickLocationScreen extends StatefulWidget {
  const PickLocationScreen({super.key});

  @override
  State<PickLocationScreen> createState() => _PickLocationScreenState();
}

class _PickLocationScreenState extends State<PickLocationScreen> {
  GoogleMapController? _mapController;
  LatLng _selected = const LatLng(24.7136, 46.6753);
  bool _isLocating = true;

  @override
  void initState() {
    super.initState();
    _useCurrentLocation();
  }

  Future<void> _useCurrentLocation() async {
    setState(() => _isLocating = true);
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        setState(() => _isLocating = false);
        return;
      }
      final position = await Geolocator.getCurrentPosition();
      final target = LatLng(position.latitude, position.longitude);
      setState(() => _selected = target);
      _mapController?.animateCamera(CameraUpdate.newLatLng(target));
    } catch (_) {
      // يبقى بإمكان المستخدم تحديد الموقع يدويًا بتحريك الخريطة
    } finally {
      if (mounted) setState(() => _isLocating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حدد موقع المتجر/المطعم')),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _selected, zoom: 15),
            onMapCreated: (c) => _mapController = c,
            onCameraMove: (position) => _selected = position.target,
          ),
          Center(child: Icon(Icons.location_on, color: AppColors.primaryPurple, size: 40)),
          if (_isLocating)
            Positioned(top: 16, right: 16, child: CircularProgressIndicator(color: AppColors.primaryPurple)),
          Positioned(
            bottom: 16, right: 16,
            child: FloatingActionButton.small(
              heroTag: 'partner_current_location',
              backgroundColor: AppColors.primaryPurple,
              onPressed: _useCurrentLocation,
              child: const Icon(Icons.my_location_rounded, color: Colors.white),
            ),
          ),
          Positioned(
            bottom: 16, left: 16, right: 80,
            child: NeonButton(
              label: 'تأكيد هذا الموقع',
              onPressed: () => Navigator.pop(context, _selected),
            ),
          ),
        ],
      ),
    );
  }
}
