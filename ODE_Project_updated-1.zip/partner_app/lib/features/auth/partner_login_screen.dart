import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/partner_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/neon_effects.dart';
import '../../core/theme/glass_container.dart';
import '../dashboard/partner_dashboard_screen.dart';
import '../onboarding/business_type_screen.dart';
import '../onboarding/pending_approval_screen.dart';
import '../onboarding/rejected_screen.dart';

class PartnerLoginScreen extends StatefulWidget {
  const PartnerLoginScreen({super.key});

  @override
  State<PartnerLoginScreen> createState() => _PartnerLoginScreenState();
}

class _PartnerLoginScreenState extends State<PartnerLoginScreen> {
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  bool _otpSent = false;
  String? _errorText;

  Future<void> _sendOtp() async {
    final auth = context.read<PartnerAuthProvider>();
    await auth.requestOtp(_phoneController.text.trim());
    setState(() => _otpSent = true);
  }

  Future<void> _verifyOtp() async {
    final auth = context.read<PartnerAuthProvider>();
    final outcome = await auth.verifyOtp(_phoneController.text.trim(), _otpController.text.trim());
    if (!mounted) return;

    switch (outcome) {
      case PartnerLoginOutcome.newRegistration:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const BusinessTypeScreen()));
        break;
      case PartnerLoginOutcome.pendingApproval:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const PendingApprovalScreen()));
        break;
      case PartnerLoginOutcome.rejected:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const RejectedScreen()));
        break;
      case PartnerLoginOutcome.active:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const PartnerDashboardScreen()));
        break;
      case PartnerLoginOutcome.error:
        setState(() => _errorText = 'رمز التحقق غير صحيح، حاول مرة أخرى');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<PartnerAuthProvider>();
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 60),
              Text('ODE للشركاء', textAlign: TextAlign.center, style: TextStyle(color: AppColors.primaryPurpleLight, fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(_otpSent ? 'أدخل رمز التحقق' : 'دخول أو تسجيل كشريك جديد (متجر / مطعم)',
                  textAlign: TextAlign.center, style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
              const SizedBox(height: 40),
              GlassContainer(
                child: _otpSent
                    ? TextField(controller: _otpController, keyboardType: TextInputType.number, textAlign: TextAlign.center,
                        style: const TextStyle(color: AppColors.darkTextPrimary, fontSize: 22, letterSpacing: 8),
                        decoration: const InputDecoration(hintText: '••••', border: InputBorder.none))
                    : TextField(controller: _phoneController, keyboardType: TextInputType.phone,
                        style: const TextStyle(color: AppColors.darkTextPrimary),
                        decoration: const InputDecoration(hintText: '05xxxxxxxx', hintStyle: TextStyle(color: AppColors.darkTextSecondary),
                            prefixIcon: Icon(Icons.phone_rounded, color: AppColors.primaryPurpleLight), border: InputBorder.none)),
              ),
              if (_errorText != null) ...[
                const SizedBox(height: 12),
                Text(_errorText!, style: const TextStyle(color: AppColors.error), textAlign: TextAlign.center),
              ],
              const SizedBox(height: 24),
              NeonButton(label: _otpSent ? 'دخول' : 'إرسال رمز التحقق', isLoading: auth.isLoading, onPressed: _otpSent ? _verifyOtp : _sendOtp),
            ],
          ),
        ),
      ),
    );
  }
}
