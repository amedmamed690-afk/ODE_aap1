import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../../core/providers/partner_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/upload_service.dart';
import 'package:ode_partner_app/core/config/env.dart';

/// رفع Short من تطبيق الشريك — نفس المبدأ يُستخدم لاحقاً بتطبيق السائق
/// (partner_id أو driver_id، وليس الاثنين معاً، كما بقاعدة البيانات).
///
/// إصلاح (بند C بالتقرير — الأخطر بهذه القائمة): الميزة كانت شكلية بالكامل.
/// اختيار الفيديو كان يضع اسم ملف وهمي 'demo_video.mp4' غير موجود على
/// الجهاز، والنشر كان يرسل 'PLACEHOLDER_UPLOADED_VIDEO_URL' كنص ثابت
/// للـBackend مباشرة بدون رفع أي فيديو حقيقي إطلاقًا — أي فيديو "منشور"
/// كان سيكون رابطًا ميتًا للجميع. الآن: اختيار فيديو حقيقي عبر image_picker
/// (يدعم فيديو مباشرة، بدون حاجة لـfile_picker إضافية)، ثم رفعه فعليًا عبر
/// UploadService (نفس آلية المستندات) قبل إرسال الرابط الحقيقي الناتج.
class PartnerUploadShortScreen extends StatefulWidget {
  const PartnerUploadShortScreen({super.key});

  @override
  State<PartnerUploadShortScreen> createState() => _PartnerUploadShortScreenState();
}

class _PartnerUploadShortScreenState extends State<PartnerUploadShortScreen> {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط
  final _captionController = TextEditingController();
  final _uploadService = UploadService();
  bool _isUploading = false;
  XFile? _pickedVideo;

  Future<void> _pickVideo() async {
    final picked = await ImagePicker().pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 2));
    if (picked != null) setState(() => _pickedVideo = picked);
  }

  String _videoMimeType(String path) {
    final ext = path.split('.').last.toLowerCase();
    if (ext == 'mov') return 'video/quicktime';
    if (ext == 'webm') return 'video/webm';
    return 'video/mp4';
  }

  Future<void> _upload() async {
    if (_pickedVideo == null) return;
    setState(() => _isUploading = true);
    try {
      final token = context.read<PartnerAuthProvider>().token!;
      // رفع حقيقي لملف الفيديو أولاً (multipart، بحد أقصى 80 ميجا حسب
      // الـBackend)، ثم نرسل الرابط الناتج فقط — لا نرسل الملف الخام بالـJSON.
      final videoUrl = await _uploadService.uploadFile(
        token: token,
        filePath: _pickedVideo!.path,
        purpose: 'short_video',
        mimeType: _videoMimeType(_pickedVideo!.path),
      );
      await http.post(
        Uri.parse('$baseUrl/marketing/shorts'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'videoUrl': videoUrl, 'captionAr': _captionController.text.trim()}),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.success, content: Text('تم رفع الفيديو بنجاح')));
        Navigator.pop(context);
      }
    } on UploadException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.userMessage)));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر رفع الفيديو')));
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رفع فيديو Short')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GestureDetector(
              onTap: _pickVideo,
              child: GlassContainer(
                padding: const EdgeInsets.all(30),
                child: Column(children: [
                  Icon(_pickedVideo == null ? Icons.video_call_rounded : Icons.check_circle_rounded,
                      color: AppColors.primaryPurpleLight, size: 36),
                  const SizedBox(height: 8),
                  Text(_pickedVideo == null ? 'اضغط لاختيار فيديو' : 'تم اختيار الفيديو ✓', style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                ]),
              ),
            ),
            const SizedBox(height: 16),
            GlassContainer(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextField(
                controller: _captionController,
                maxLines: 2,
                style: const TextStyle(color: AppColors.darkTextPrimary),
                decoration: const InputDecoration(hintText: 'وصف الفيديو...', hintStyle: TextStyle(color: AppColors.darkTextSecondary), border: InputBorder.none),
              ),
            ),
            const SizedBox(height: 20),
            NeonButton(label: 'نشر الفيديو', icon: Icons.upload_rounded, isLoading: _isUploading, disabled: _pickedVideo == null, onPressed: _upload),
          ],
        ),
      ),
    );
  }
}
