import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/partner_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import 'partner_orders_controller.dart';
import 'print_receipt_screen.dart';
import '../shorts/partner_upload_short_screen.dart';
import '../settings/partner_settings_screen.dart';

/// الرئيسية بعد التفعيل (بند 7): قائمة الطلبات + قبول/رفض + تحديث الحالة.
class PartnerDashboardScreen extends StatefulWidget {
  const PartnerDashboardScreen({super.key});

  @override
  State<PartnerDashboardScreen> createState() => _PartnerDashboardScreenState();
}

class _PartnerDashboardScreenState extends State<PartnerDashboardScreen> {
  final PartnerOrdersController _controller = PartnerOrdersController();
  List<PartnerOrderModel> _orders = [];
  bool _isLoading = true;

  // إصلاح (اكتشاف أثناء توثيق تدفق معالجة الطلب): القيم هنا كانت لا تطابق
  // القيم الحقيقية اللي يستخدمها order-flow.service.ts بالباك إند إطلاقًا
  // (`pending`/`accepted` غير موجودتين أصلاً بالـVALID_TRANSITIONS — الحقيقي
  // `placed`/`accepted_by_partner`) — يعني كل زر بهذي الشاشة كان يفشل أو
  // ما يظهر أصلاً. والأخطر: ما كان فيه زر لتحويل preparing → ready_for_pickup
  // إطلاقًا، وهذي بالضبط اللحظة اللي يبحث فيها الباك إند عن سائق تلقائيًا
  // (assignNearestDriver) — يعني كل طلب كان بيعلق عند preparing للأبد.
  static const _statusLabels = {
    'placed': 'قيد الانتظار', 'accepted_by_partner': 'تم القبول', 'preparing': 'قيد التجهيز',
    'ready_for_pickup': 'بانتظار سائق', 'driver_assigned': 'السائق بالطريق لاستلامه', 'picked_up': 'تم الاستلام',
    'on_the_way': 'في الطريق للعميل', 'delivered': 'تم التوصيل', 'cancelled': 'ملغي', 'rejected': 'مرفوض',
  };

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    setState(() => _isLoading = true);
    try {
      final token = context.read<PartnerAuthProvider>().token!;
      final orders = await _controller.fetchOrders(token);
      if (mounted) setState(() { _orders = orders; _isLoading = false; });
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _updateStatus(PartnerOrderModel order, String newStatus) async {
    try {
      final token = context.read<PartnerAuthProvider>().token!;
      await _controller.updateStatus(token, order.id, newStatus);
      _loadOrders();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<PartnerAuthProvider>();
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(
        title: const Text('لوحة الشريك'),
        backgroundColor: Colors.transparent,
        actions: [
          IconButton(icon: const Icon(Icons.video_call_outlined), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PartnerUploadShortScreen()))),
          IconButton(icon: const Icon(Icons.logout_rounded), onPressed: () => auth.logout()),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadOrders,
        child: _isLoading
            ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
            : _orders.isEmpty
                ? ListView(children: const [
                    Padding(padding: EdgeInsets.all(40), child: Center(child: Text('لا توجد طلبات حالياً', style: TextStyle(color: AppColors.darkTextSecondary)))),
                  ])
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _orders.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final order = _orders[index];
                      return GlassContainer(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                              Text('#${order.orderNumber}', style: Theme.of(context).textTheme.titleSmall),
                              Text('${order.total} ${order.currencyCode}'),
                            ]),
                            const SizedBox(height: 6),
                            Text(_statusLabels[order.status] ?? order.status, style: TextStyle(color: AppColors.primaryPurpleLight)),
                            const SizedBox(height: 10),
                            Wrap(spacing: 8, children: [
                              if (order.status == 'placed')
                                ElevatedButton(onPressed: () => _updateStatus(order, 'accepted_by_partner'), child: const Text('قبول')),
                              if (order.status == 'accepted_by_partner')
                                ElevatedButton(onPressed: () => _updateStatus(order, 'preparing'), child: const Text('بدء التجهيز')),
                              if (order.status == 'preparing') ...[
                                ElevatedButton(onPressed: () => _updateStatus(order, 'ready_for_pickup'), child: const Text('جاهز — ابحث عن سائق')),
                                OutlinedButton(
                                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PrintReceiptScreen(order: order))),
                                  child: const Text('طباعة وصل الاستلام'),
                                ),
                              ],
                              if (order.status == 'placed')
                                TextButton(onPressed: () => _updateStatus(order, 'rejected'), child: const Text('رفض', style: TextStyle(color: AppColors.error))),
                            ]),
                          ],
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
