import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import '../../core/providers/partner_auth_provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/glass_container.dart';
import '../../core/theme/neon_effects.dart';
import '../../shared/services/bluetooth_printer_service.dart';
import 'partner_orders_controller.dart';

/// شاشة "طباعة الوصل" — بتضغط عليها تجيب رمز QR الحقيقي من السيرفر
/// (مش مولّد محلياً بالتطبيق، عشان الرمز السري ما يتولّدش إلا بالباك إند)
/// وتعرضه جاهز للطباعة. بمجرد ما سائق التوصيل الصحيح يمسحه، الطلب
/// يتحول لحالة "picked_up" فوراً ويُحسب على حساب الشركة والسائق.
class PrintReceiptScreen extends StatefulWidget {
  final PartnerOrderModel order;
  const PrintReceiptScreen({super.key, required this.order});

  @override
  State<PrintReceiptScreen> createState() => _PrintReceiptScreenState();
}

class _PrintReceiptScreenState extends State<PrintReceiptScreen> {
  final PartnerOrdersController _controller = PartnerOrdersController();
  final BluetoothPrinterService _printerService = BluetoothPrinterService();
  String? _qrPayload;
  String? _error;
  bool _isLoading = true;
  bool _isPrinting = false;

  @override
  void initState() {
    super.initState();
    _loadQr();
  }

  // بند 15 (Audit): يحاول الاتصال التلقائي بآخر طابعة نجح الاتصال بها من
  // قبل؛ لو فشل أو ما فيه طابعة محفوظة، يعرض قائمة اختيار حقيقية بدل
  // محاولة الطباعة على طابعة غير معروفة.
  Future<String?> _ensureConnectedPrinter() async {
    final lastMac = await _printerService.getLastConnectedMac();
    if (lastMac != null) {
      final reconnected = await _printerService.connect(lastMac);
      if (reconnected) return lastMac;
    }
    if (!mounted) return null;
    return _pickPrinter();
  }

  Future<String?> _pickPrinter() async {
    if (!await _printerService.isBluetoothEnabled) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فعّل البلوتوث بالجهاز أولاً')));
      }
      return null;
    }
    final devices = await _printerService.listPairedDevices();
    if (devices.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('لا توجد طابعة مقترنة — اقرن الطابعة من إعدادات البلوتوث بالجهاز أولاً'),
        ));
      }
      return null;
    }
    if (!mounted) return null;
    final selected = await showModalBottomSheet<BluetoothInfo>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('اختر الطابعة')),
          ...devices.map((d) => ListTile(
                leading: const Icon(Icons.print_rounded),
                title: Text(d.name),
                subtitle: Text(d.macAdress),
                onTap: () => Navigator.pop(sheetContext, d),
              )),
        ]),
      ),
    );
    if (selected == null) return null;
    final connected = await _printerService.connect(selected.macAdress);
    return connected ? selected.macAdress : null;
  }

  Future<void> _print() async {
    if (_qrPayload == null) return;
    setState(() => _isPrinting = true);
    try {
      final mac = await _ensureConnectedPrinter();
      if (mac == null) return; // المستخدم ألغى الاختيار أو لا توجد طابعة — رسالة الخطأ ظهرت فعلاً بالدوال أعلاه
      final success = await _printerService.printReceipt(
        orderNumber: widget.order.orderNumber,
        total: widget.order.total.toStringAsFixed(2),
        currencyCode: widget.order.currencyCode,
        qrPayload: _qrPayload!,
      );
      if (mounted && !success) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذرت الطباعة — تحقق من اتصال الطابعة والورق')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذرت الطباعة — تحقق من اتصال الطابعة')));
    } finally {
      if (mounted) setState(() => _isPrinting = false);
    }
  }

  Future<void> _loadQr() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final token = context.read<PartnerAuthProvider>().token!;
      final payload = await _controller.fetchQrPayload(token, widget.order.id);
      if (mounted) setState(() { _qrPayload = payload; _isLoading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = e.toString().replaceFirst('Exception: ', ''); _isLoading = false; });
    }
  }

  String _errorLabel(String code) {
    switch (code) {
      case 'no_driver_assigned_yet': return 'لسه ما تعيّن سائق على هذا الطلب — انتظر التعيين ثم أعد المحاولة';
      default: return 'تعذر توليد رمز الاستلام';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('طباعة الوصل')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _isLoading
            ? Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
            : _error != null
                ? Center(
                    child: GlassContainer(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.error_outline_rounded, color: AppColors.error, size: 36),
                        const SizedBox(height: 12),
                        Text(_errorLabel(_error!), textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        NeonButton(label: 'إعادة المحاولة', onPressed: _loadQr),
                      ]),
                    ),
                  )
                : Column(
                    children: [
                      // شكل "الوصل" — عنوان الطلب، ثم QR أسفله، جاهز للطباعة
                      GlassContainer(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          children: [
                            Text('وصل الطلب', style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 4),
                            Text('#${widget.order.orderNumber}', style: Theme.of(context).textTheme.bodyMedium),
                            const SizedBox(height: 4),
                            Text('${widget.order.total.toStringAsFixed(2)} ${widget.order.currencyCode}', style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 20),
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                              child: QrImageView(
                                data: _qrPayload!,
                                version: QrVersions.auto,
                                size: 180,
                                backgroundColor: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'يمسحه سائق التوصيل عند الاستلام فقط — لا تشاركه مع أي طرف آخر',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      NeonButton(
                        label: 'طباعة',
                        icon: Icons.print_rounded,
                        isLoading: _isPrinting,
                        onPressed: _print,
                      ),
                    ],
                  ),
      ),
    );
  }
}
