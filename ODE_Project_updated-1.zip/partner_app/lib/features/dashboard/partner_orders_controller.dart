import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ode_partner_app/core/config/env.dart';

class PartnerOrderModel {
  final String id;
  final String orderNumber;
  final String status;
  final double total;
  final String currencyCode;
  final String? driverId;

  PartnerOrderModel({required this.id, required this.orderNumber, required this.status, required this.total, required this.currencyCode, this.driverId});

  factory PartnerOrderModel.fromJson(Map<String, dynamic> json) {
    return PartnerOrderModel(
      id: json['id'],
      orderNumber: json['order_number'],
      status: json['status'],
      total: double.parse(json['total'].toString()),
      currencyCode: json['currency_code'] ?? '',
      driverId: json['driver_id'],
    );
  }
}

class PartnerOrdersController {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  Future<List<PartnerOrderModel>> fetchOrders(String token) async {
    final response = await http.get(Uri.parse('$baseUrl/orders/partner'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) throw Exception('failed_to_load_orders');
    return (jsonDecode(response.body) as List).map((e) => PartnerOrderModel.fromJson(e)).toList();
  }

  Future<void> updateStatus(String token, String orderId, String status) async {
    final response = await http.patch(
      Uri.parse('$baseUrl/orders/$orderId/status'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode({'status': status}),
    );
    if (response.statusCode != 200) {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'update_failed');
    }
  }

  /// يجيب بيانات QR الحقيقية من السيرفر — الرمز السري لا يوصل التطبيق
  /// أبداً كنص خام، فقط كـ payload جاهز لتوليد صورة QR منه.
  Future<String> fetchQrPayload(String token, String orderId) async {
    final response = await http.get(Uri.parse('$baseUrl/pickup/orders/$orderId/qr'), headers: {'Authorization': 'Bearer $token'});
    if (response.statusCode != 200) {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'qr_generation_failed');
    }
    final data = jsonDecode(response.body);
    return data['qrPayload'];
  }
}
