import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// خدمة الطباعة الحرارية عبر Bluetooth — بند 15 بالمراجعة.
///
/// طابعات الإيصالات الشائعة عند المطاعم/المتاجر الصغيرة (58مم/80مم) لا
/// تدعم عادة بروتوكولات الطباعة القياسية (AirPrint/Android Print
/// Framework) — تحتاج أوامر ESC/POS خام عبر Bluetooth SPP، وهذا بالضبط ما
/// تقدمه `print_bluetooth_thermal` (اتصال) مع `esc_pos_utils_plus` (توليد
/// الأوامر: نص، QR، قص الورق). كل هذا لا يمكن اختباره فعليًا بهذه البيئة
/// (لا يوجد جهاز Bluetooth حقيقي) — الكود جاهز بالكامل، والإعداد الخارجي
/// المطلوب موثّق بالتقرير النهائي (صلاحيات Bluetooth بمانيفست
/// Android/iOS، واقتران الطابعة الفعلي من إعدادات الجهاز أولاً).
class BluetoothPrinterService {
  static const _prefsKeyMac = 'last_printer_mac';

  Future<bool> get isBluetoothEnabled => PrintBluetoothThermal.bluetoothEnabled;

  /// الأجهزة المقترنة مسبقًا من إعدادات نظام الهاتف — المستخدم يجب أن
  /// يقرن الطابعة من إعدادات البلوتوث بالجهاز أولًا (خطوة نظام تشغيل، لا
  /// يمكن لأي تطبيق تجاوزها)، ثم تظهر هنا للاختيار.
  Future<List<BluetoothInfo>> listPairedDevices() {
    return PrintBluetoothThermal.pairedBluetooths;
  }

  Future<bool> connect(String macAddress) async {
    final connected = await PrintBluetoothThermal.connect(macPrinterAddress: macAddress);
    if (connected) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKeyMac, macAddress);
    }
    return connected;
  }

  Future<void> disconnect() => PrintBluetoothThermal.disconnect;

  /// آخر طابعة متصلة بنجاح — لإعادة الاتصال التلقائي بالمرة القادمة
  /// بدل إجبار المستخدم يختار من القائمة كل مرة.
  Future<String?> getLastConnectedMac() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefsKeyMac);
  }

  /// يبني ويرسل وصل الطلب فعليًا — نص + QR حقيقي بأوامر ESC/POS مباشرة
  /// (أدق وأسرع بكثير من تحويل QR لصورة ثم طباعتها كصورة).
  Future<bool> printReceipt({
    required String orderNumber,
    required String total,
    required String currencyCode,
    required String qrPayload,
  }) async {
    final profile = await CapabilityProfile.load();
    final generator = Generator(PaperSize.mm58, profile);
    List<int> bytes = [];

    bytes += generator.text('ODE', styles: const PosStyles(align: PosAlign.center, bold: true, height: PosTextSize.size2, width: PosTextSize.size2));
    bytes += generator.text('وصل الطلب', styles: const PosStyles(align: PosAlign.center));
    bytes += generator.hr();
    bytes += generator.text('رقم الطلب: #$orderNumber', styles: const PosStyles(align: PosAlign.center));
    bytes += generator.text('$total $currencyCode', styles: const PosStyles(align: PosAlign.center, bold: true, height: PosTextSize.size2));
    bytes += generator.hr();
    bytes += generator.qrcode(qrPayload, size: QRSize.size6);
    bytes += generator.text('يمسحه سائق التوصيل عند الاستلام فقط', styles: const PosStyles(align: PosAlign.center));
    bytes += generator.feed(2);
    bytes += generator.cut();

    return PrintBluetoothThermal.writeBytes(bytes);
  }
}
