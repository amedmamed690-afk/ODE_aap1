import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../shared/services/fcm_service.dart';
import 'package:ode_partner_app/core/config/env.dart';

enum PartnerLoginOutcome { newRegistration, pendingApproval, rejected, active, error }

class PartnerAuthProvider extends ChangeNotifier {
  static const String baseUrl = Env.apiBaseUrl; // بند 16 (Audit): إعداد مركزي بدل تكرار الرابط

  String? _token;       // توكن نهائي، فقط بعد ما الشريك يصير active
  String? _pendingToken; // توكن مؤقت بين نجاح OTP وانتهاء التسجيل/الموافقة
  String? _partnerId;
  String? _partnerNameAr;
  bool _isLoading = false;

  String? get token => _token;
  String? get pendingToken => _pendingToken;
  String? get partnerId => _partnerId;
  String? get partnerNameAr => _partnerNameAr;
  bool get isAuthenticated => _token != null && _partnerId != null;
  bool get isLoading => _isLoading;

  Future<void> loadFromStorage() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('partner_auth_token');
    _partnerId = prefs.getString('partner_id');
    _partnerNameAr = prefs.getString('partner_name_ar');
    notifyListeners();
  }

  Future<void> requestOtp(String phone) async {
    _isLoading = true; notifyListeners();
    try {
      await http.post(Uri.parse('$baseUrl/auth/otp/request'),
          headers: {'Content-Type': 'application/json'}, body: jsonEncode({'phone': phone}));
    } finally {
      _isLoading = false; notifyListeners();
    }
  }

  /// بعد نجاح الـ OTP، نحدد وين نوجّه المستخدم:
  /// - لسه ما قدّم طلب شراكة أبداً → newRegistration (يبدأ خطوات التسجيل)
  /// - قدّم طلب وبانتظار الأدمن → pendingApproval
  /// - الأدمن رفضه → rejected
  /// - مقبول وفعّال → active (يدخل اللوحة مباشرة)
  Future<PartnerLoginOutcome> verifyOtp(String phone, String code) async {
    _isLoading = true; notifyListeners();
    try {
      final response = await http.post(Uri.parse('$baseUrl/auth/otp/verify'),
          headers: {'Content-Type': 'application/json'}, body: jsonEncode({'phone': phone, 'code': code}));
      if (response.statusCode != 200) return PartnerLoginOutcome.error;

      final data = jsonDecode(response.body);
      _pendingToken = data['token'];

      // نتحقق هل عنده طلب شراكة أصلاً وشو حالته
      final statusResponse = await http.get(Uri.parse('$baseUrl/partner-onboarding/my-status'),
          headers: {'Authorization': 'Bearer $_pendingToken'});

      if (statusResponse.statusCode == 404) {
        notifyListeners();
        return PartnerLoginOutcome.newRegistration;
      }
      if (statusResponse.statusCode != 200) return PartnerLoginOutcome.error;

      final status = jsonDecode(statusResponse.body);
      if (status['status'] == 'rejected') return PartnerLoginOutcome.rejected;
      if (status['status'] == 'pending') return PartnerLoginOutcome.pendingApproval;

      // active → نجيب بيانات الشريك الكاملة ونثبّت الجلسة نهائياً
      final partnerResponse = await http.get(Uri.parse('$baseUrl/partners/me'), headers: {'Authorization': 'Bearer $_pendingToken'});
      final partner = jsonDecode(partnerResponse.body);

      _token = _pendingToken;
      _partnerId = partner['id'];
      _partnerNameAr = partner['name_ar'];

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('partner_auth_token', _token!);
      await prefs.setString('partner_id', _partnerId!);
      await prefs.setString('partner_name_ar', _partnerNameAr!);

      notifyListeners();
      FcmService.registerToken(_token!); // بند 15
      return PartnerLoginOutcome.active;
    } finally {
      _isLoading = false; notifyListeners();
    }
  }

  /// بند 28 (مراجعة أمنية): نفس فكرة DriverAuthProvider — بعد ترقية
  /// الدور لـpartner_owner لازم نستبدل التوكن القديم فورًا.
  Future<void> updateTokenAfterUpgrade(String newToken) async {
    _token = newToken;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('partner_auth_token', newToken);
    notifyListeners();
  }

  Future<void> logout() async {
    _token = null; _pendingToken = null; _partnerId = null; _partnerNameAr = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('partner_auth_token');
    await prefs.remove('partner_id');
    await prefs.remove('partner_name_ar');
    notifyListeners();
  }
}
