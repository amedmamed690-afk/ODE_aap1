package com.odeapp.partner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
