import React, { useState, useEffect, useRef } from 'react';
import { Moon, Sun, User, ShoppingCart, Store, Wallet, Sparkles, Bike, Play, Heart } from 'lucide-react';

// ألوان مطابقة تماماً لـ core/theme/app_colors.dart بالكود الحقيقي
const COLORS = {
  primaryPurple: '#6A0DAD',
  primaryPurpleLight: '#9B4DE0',
  neonGlow: '#B537F2',
  darkBg: '#120026',
  darkSurface: '#1E0838',
  darkCard: '#2A0F4A',
  darkTextPrimary: '#F5F0FF',
  darkTextSecondary: '#B8A6D9',
  lightBg: '#FFFFFF',
  lightSurface: '#F7F3FC',
  lightTextPrimary: '#1A0433',
  lightTextSecondary: '#6B5B85',
};

const ADS = [
  { id: 1, title: 'خصم 20% على أول طلب', color: 'from-[#6A0DAD] to-[#B537F2]' },
  { id: 2, title: 'ODE PAY — اشحن واربح كاش باك', color: 'from-[#3D0768] to-[#9B4DE0]' },
];

const SERVICES = [
  { label: 'ODE براند', icon: Store },
  { label: 'ODE PAY', icon: Wallet, badge: '350' },
  { label: 'الخدمات المنزلية', icon: Sparkles },
  { label: 'التوصيل والركاب', icon: Bike },
];

const PRODUCTS = [
  { id: 1, name: 'عطر ODE الرجالي', price: '85.00', store: 'ODE براند' },
  { id: 2, name: 'سماعة لاسلكية', price: '120.00', store: 'متجر التقنية' },
  { id: 3, name: 'طقم عناية بالبشرة', price: '65.00', store: 'ODE براند' },
];

const SHORTS = [
  { id: 1, sponsored: true, views: '2.3k' },
  { id: 2, sponsored: false, views: '890' },
  { id: 3, sponsored: true, views: '5.1k' },
];

function GlassCard({ children, className = '', dark, style = {} }) {
  return (
    <div
      className={`backdrop-blur-md rounded-2xl border ${className}`}
      style={{
        backgroundColor: dark ? 'rgba(255,255,255,0.06)' : 'rgba(106,13,173,0.04)',
        borderColor: dark ? 'rgba(255,255,255,0.12)' : 'rgba(106,13,173,0.15)',
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function NeonButton({ children, small }) {
  return (
    <button
      className={`rounded-2xl font-bold text-white transition-transform active:scale-95 ${small ? 'px-4 py-2 text-xs' : 'px-6 py-3 text-sm'}`}
      style={{
        background: `linear-gradient(90deg, ${COLORS.primaryPurple}, ${COLORS.primaryPurpleLight})`,
        boxShadow: `0 0 22px 2px ${COLORS.neonGlow}88, 0 0 40px 4px ${COLORS.neonGlow}40`,
      }}
    >
      {children}
    </button>
  );
}

export default function OdeAppPreview() {
  const [isDark, setIsDark] = useState(true);
  const [adIndex, setAdIndex] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => {
    timerRef.current = setInterval(() => setAdIndex((i) => (i + 1) % ADS.length), 3000);
    return () => clearInterval(timerRef.current);
  }, []);

  const bg = isDark ? COLORS.darkBg : COLORS.lightBg;
  const textPrimary = isDark ? COLORS.darkTextPrimary : COLORS.lightTextPrimary;
  const textSecondary = isDark ? COLORS.darkTextSecondary : COLORS.lightTextSecondary;
  const cardBg = isDark ? COLORS.darkCard : '#FFFFFF';

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#0a0014', fontFamily: 'system-ui, sans-serif' }} dir="rtl">
      {/* إطار الجوال */}
      <div
        className="relative w-[375px] h-[780px] rounded-[2.5rem] overflow-hidden border-4 shadow-2xl flex flex-col"
        style={{ backgroundColor: bg, borderColor: '#000', boxShadow: `0 0 60px ${COLORS.neonGlow}30` }}
      >
        {/* شريط الحالة */}
        <div className="h-9 flex items-center justify-between px-6 text-[11px] shrink-0" style={{ color: textSecondary }}>
          <span>9:41</span>
          <span>ODE</span>
        </div>

        {/* AppBar */}
        <div className="flex items-center justify-between px-4 py-2 shrink-0">
          <span className="font-extrabold text-lg tracking-wide" style={{ color: COLORS.primaryPurpleLight }}>ODE</span>
          <div className="flex items-center gap-3">
            <button onClick={() => setIsDark(!isDark)} style={{ color: textPrimary }}>
              {isDark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <div className="relative">
              <ShoppingCart size={18} style={{ color: textPrimary }} />
              <span className="absolute -top-1.5 -left-1.5 text-[8px] rounded-full w-3.5 h-3.5 flex items-center justify-center text-white" style={{ backgroundColor: '#E74C3C' }}>2</span>
            </div>
            <User size={18} style={{ color: textPrimary }} />
          </div>
        </div>

        {/* المحتوى */}
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ scrollbarWidth: 'none' }}>
          {/* بانر الإعلانات */}
          <div className="mt-2 rounded-2xl overflow-hidden h-28 relative" style={{ boxShadow: `0 6px 16px ${COLORS.neonGlow}30` }}>
            {ADS.map((ad, i) => (
              <div
                key={ad.id}
                className={`absolute inset-0 bg-gradient-to-l ${ad.color} flex items-center justify-center text-white font-bold text-sm text-center px-6 transition-opacity duration-500`}
                style={{ opacity: i === adIndex ? 1 : 0 }}
              >
                {ad.title}
              </div>
            ))}
            <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1">
              {ADS.map((_, i) => (
                <span key={i} className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: i === adIndex ? '#fff' : 'rgba(255,255,255,0.4)' }} />
              ))}
            </div>
          </div>

          {/* شبكة الخدمات */}
          <div className="grid grid-cols-4 gap-2 mt-5">
            {SERVICES.map((s) => (
              <div key={s.label} className="flex flex-col items-center gap-1.5">
                <GlassCard dark={isDark} className="w-full aspect-square flex items-center justify-center relative p-3">
                  <s.icon size={20} color={COLORS.primaryPurpleLight} />
                  {s.badge && (
                    <span
                      className="absolute -top-1.5 -left-2 text-[8px] font-bold text-white px-1.5 py-0.5 rounded-md"
                      style={{ backgroundColor: COLORS.primaryPurple, boxShadow: `0 0 8px ${COLORS.neonGlow}` }}
                    >
                      {s.badge}
                    </span>
                  )}
                </GlassCard>
                <span className="text-[9px] text-center leading-tight" style={{ color: textSecondary }}>{s.label}</span>
              </div>
            ))}
          </div>

          {/* منتجات ODE والشركاء */}
          <div className="mt-6">
            <h3 className="font-bold text-sm mb-2" style={{ color: textPrimary }}>منتجات ODE والشركاء</h3>
            <div className="flex gap-3 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
              {PRODUCTS.map((p) => (
                <GlassCard key={p.id} dark={isDark} className="w-28 shrink-0 p-2">
                  <div className="h-16 rounded-xl mb-1.5" style={{ background: `linear-gradient(135deg, ${COLORS.primaryPurple}55, ${COLORS.neonGlow}33)` }} />
                  <p className="text-[10px] font-medium truncate" style={{ color: textPrimary }}>{p.name}</p>
                  <p className="text-[8px] truncate" style={{ color: textSecondary }}>{p.store}</p>
                  <p className="text-[10px] font-bold mt-1" style={{ color: COLORS.primaryPurpleLight }}>{p.price} د.ل</p>
                </GlassCard>
              ))}
            </div>
          </div>

          {/* Shorts */}
          <div className="mt-6">
            <h3 className="font-bold text-sm mb-2" style={{ color: textPrimary }}>فيديوهات مختارة</h3>
            <div className="flex gap-2.5 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
              {SHORTS.map((s) => (
                <div key={s.id} className="w-20 h-32 rounded-2xl relative shrink-0 overflow-hidden flex items-end p-1.5"
                  style={{ background: `linear-gradient(160deg, ${COLORS.darkCard}, ${COLORS.primaryPurple}66)`, boxShadow: `0 0 10px ${COLORS.neonGlow}25` }}>
                  {s.sponsored && (
                    <span className="absolute top-1.5 left-1.5 text-[7px] text-white px-1.5 py-0.5 rounded" style={{ backgroundColor: COLORS.primaryPurple }}>مُمول</span>
                  )}
                  <Play size={16} color="#fff" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" fill="#fff" opacity={0.85} />
                  <div className="flex items-center gap-1 text-white text-[8px]">
                    <Heart size={9} fill="#fff" /> {s.views}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* عينة زر نيون */}
          <div className="mt-6 flex justify-center">
            <NeonButton>إضافة إلى السلة</NeonButton>
          </div>
        </div>

        {/* مؤشر الوضع الحالي */}
        <div className="text-center text-[9px] py-2 shrink-0" style={{ color: textSecondary }}>
          {isDark ? 'الوضع الداكن' : 'الوضع الفاتح'} — اضغط أيقونة الشمس/القمر للتبديل
        </div>
      </div>
    </div>
  );
}
