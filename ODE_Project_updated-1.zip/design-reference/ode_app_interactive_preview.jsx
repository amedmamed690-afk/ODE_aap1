import React, { useState, useEffect, useRef } from 'react';
import {
  Moon, Sun, User, ShoppingCart, Store, Wallet, Sparkles, Bike, Play, Heart, Share2,
  ArrowRight, Plus, Minus, ChevronLeft, MapPin, Phone, MessageCircle, LogOut, Receipt, Globe, Check
} from 'lucide-react';

const C = {
  primary: '#6A0DAD',
  primaryLight: '#9B4DE0',
  neon: '#B537F2',
  darkBg: '#120026',
  darkCard: '#2A0F4A',
  darkTextP: '#F5F0FF',
  darkTextS: '#B8A6D9',
  lightBg: '#FFFFFF',
  lightTextP: '#1A0433',
  lightTextS: '#6B5B85',
  success: '#2ECC71',
  error: '#E74C3C',
};

const CATEGORIES = ['الكل', 'غذائية', 'مكياج', 'رجالي', 'إلكترونيات', 'تنظيف'];
const PRODUCTS = [
  { id: 1, name: 'عطر ODE الرجالي', price: 85, store: 'ODE براند', cat: 'رجالي' },
  { id: 2, name: 'سماعة لاسلكية', price: 120, store: 'متجر التقنية', cat: 'إلكترونيات' },
  { id: 3, name: 'طقم عناية بالبشرة', price: 65, store: 'ODE براند', cat: 'مكياج' },
  { id: 4, name: 'منظف أرضيات', price: 18, store: 'ODE براند', cat: 'تنظيف' },
  { id: 5, name: 'تمر ليبي فاخر', price: 30, store: 'ODE براند', cat: 'غذائية' },
];
const SHORTS = [
  { id: 1, sponsored: true, views: '2.3k', likes: 210, caption: 'عطر الموسم الجديد من ODE براند' },
  { id: 2, sponsored: false, views: '890', likes: 54, caption: 'جولة سريعة في متجر التقنية' },
  { id: 3, sponsored: true, views: '5.1k', likes: 480, caption: 'عرض خاص على خدمات التنظيف' },
];
const SERVICES = [
  { id: 1, name: 'تنظيف منزلي عام', price: 40 },
  { id: 2, name: 'تنظيف سجاد وستائر', price: 55 },
  { id: 3, name: 'تنظيف صالونات', price: 70 },
];

function Glass({ children, dark, className = '', style = {}, onClick }) {
  return (
    <div
      onClick={onClick}
      className={`backdrop-blur-md rounded-2xl border ${className} ${onClick ? 'cursor-pointer active:scale-[0.98] transition-transform' : ''}`}
      style={{
        backgroundColor: dark ? 'rgba(255,255,255,0.06)' : 'rgba(106,13,173,0.04)',
        borderColor: dark ? 'rgba(255,255,255,0.12)' : 'rgba(106,13,173,0.15)',
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function NeonButton({ children, onClick, disabled, small }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`rounded-2xl font-bold text-white transition-transform active:scale-95 w-full flex items-center justify-center gap-2 ${small ? 'px-4 py-2 text-xs' : 'px-6 py-3.5 text-sm'} ${disabled ? 'opacity-50' : ''}`}
      style={{
        background: `linear-gradient(90deg, ${C.primary}, ${C.primaryLight})`,
        boxShadow: disabled ? 'none' : `0 0 22px 2px ${C.neon}88, 0 0 40px 4px ${C.neon}40`,
      }}
    >
      {children}
    </button>
  );
}

function TopBar({ title, onBack, dark, textP }) {
  return (
    <div className="flex items-center gap-2 px-4 py-3 shrink-0">
      {onBack && (
        <button onClick={onBack} style={{ color: textP }}>
          <ArrowRight size={18} />
        </button>
      )}
      <span className="font-bold text-sm" style={{ color: textP }}>{title}</span>
    </div>
  );
}

export default function OdeAppPreview() {
  const [isDark, setIsDark] = useState(true);
  const [screen, setScreen] = useState({ name: 'home' });
  const [stack, setStack] = useState([]);
  const [cart, setCart] = useState([]);
  const [adIndex, setAdIndex] = useState(0);
  const [category, setCategory] = useState('الكل');
  const [toast, setToast] = useState(null);
  const [shortIndex, setShortIndex] = useState(0);
  const [likedShorts, setLikedShorts] = useState({});
  const [rideStep, setRideStep] = useState(0);
  const [bookingForm, setBookingForm] = useState({ name: '', phone: '', altPhone: '' });
  const [bookingError, setBookingError] = useState('');

  useEffect(() => {
    const t = setInterval(() => setAdIndex((i) => (i + 1) % 2), 3000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(null), 1800);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const nav = (s) => { setStack((st) => [...st, screen]); setScreen(s); };
  const back = () => {
    setStack((st) => {
      const copy = [...st];
      const prev = copy.pop() || { name: 'home' };
      setScreen(prev);
      return copy;
    });
  };

  const bg = isDark ? C.darkBg : C.lightBg;
  const textP = isDark ? C.darkTextP : C.lightTextP;
  const textS = isDark ? C.darkTextS : C.lightTextS;

  const addToCart = (product) => {
    setCart((c) => {
      const existing = c.find((i) => i.id === product.id);
      if (existing) return c.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      return [...c, { ...product, qty: 1 }];
    });
    setToast(`تمت إضافة "${product.name}" للسلة`);
  };
  const updateQty = (id, delta) => {
    setCart((c) => c.map((i) => (i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i)).filter((i) => i.qty > 0));
  };
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => s + i.qty * i.price, 0);

  const filteredProducts = category === 'الكل' ? PRODUCTS : PRODUCTS.filter((p) => p.cat === category);

  // ---------- الشاشات ----------
  function HomeScreen() {
    return (
      <>
        <div className="flex items-center justify-between px-4 py-2 shrink-0">
          <span className="font-extrabold text-lg tracking-wide" style={{ color: C.primaryLight }}>ODE</span>
          <div className="flex items-center gap-3">
            <button onClick={() => setIsDark(!isDark)} style={{ color: textP }}>{isDark ? <Sun size={18} /> : <Moon size={18} />}</button>
            <button onClick={() => nav({ name: 'cart' })} className="relative" style={{ color: textP }}>
              <ShoppingCart size={18} />
              {cartCount > 0 && <span className="absolute -top-1.5 -left-1.5 text-[8px] rounded-full w-3.5 h-3.5 flex items-center justify-center text-white" style={{ backgroundColor: C.error }}>{cartCount}</span>}
            </button>
            <button onClick={() => nav({ name: 'profile' })} style={{ color: textP }}><User size={18} /></button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ scrollbarWidth: 'none' }}>
          <div className="mt-2 rounded-2xl overflow-hidden h-28 relative" style={{ boxShadow: `0 6px 16px ${C.neon}30` }}>
            {['خصم 20% على أول طلب', 'ODE PAY — اشحن واربح كاش باك'].map((t, i) => (
              <div key={i} className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm text-center px-6 transition-opacity duration-500"
                style={{ background: `linear-gradient(120deg, ${C.primary}, ${C.neon})`, opacity: i === adIndex ? 1 : 0 }}>{t}</div>
            ))}
          </div>

          <div className="grid grid-cols-4 gap-2 mt-5">
            {[
              { label: 'ODE براند', icon: Store, go: 'brand' },
              { label: 'ODE PAY', icon: Wallet, go: 'pay', badge: '350' },
              { label: 'الخدمات المنزلية', icon: Sparkles, go: 'services' },
              { label: 'التوصيل والركاب', icon: Bike, go: 'rides' },
            ].map((s) => (
              <div key={s.label} className="flex flex-col items-center gap-1.5" onClick={() => nav({ name: s.go })}>
                <Glass dark={isDark} onClick={() => {}} className="w-full aspect-square flex items-center justify-center relative p-3">
                  <s.icon size={20} color={C.primaryLight} />
                  {s.badge && <span className="absolute -top-1.5 -left-2 text-[8px] font-bold text-white px-1.5 py-0.5 rounded-md" style={{ backgroundColor: C.primary, boxShadow: `0 0 8px ${C.neon}` }}>{s.badge}</span>}
                </Glass>
                <span className="text-[9px] text-center leading-tight" style={{ color: textS }}>{s.label}</span>
              </div>
            ))}
          </div>

          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-sm" style={{ color: textP }}>منتجات ODE والشركاء</h3>
              <button className="text-[10px]" style={{ color: C.primaryLight }} onClick={() => nav({ name: 'brand' })}>عرض الكل</button>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
              {PRODUCTS.map((p) => (
                <Glass key={p.id} dark={isDark} className="w-28 shrink-0 p-2" onClick={() => nav({ name: 'product', product: p })}>
                  <div className="h-16 rounded-xl mb-1.5" style={{ background: `linear-gradient(135deg, ${C.primary}55, ${C.neon}33)` }} />
                  <p className="text-[10px] font-medium truncate" style={{ color: textP }}>{p.name}</p>
                  <p className="text-[8px] truncate" style={{ color: textS }}>{p.store}</p>
                  <p className="text-[10px] font-bold mt-1" style={{ color: C.primaryLight }}>{p.price.toFixed(2)} د.ل</p>
                </Glass>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-bold text-sm mb-2" style={{ color: textP }}>فيديوهات مختارة</h3>
            <div className="flex gap-2.5 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
              {SHORTS.map((s, i) => (
                <div key={s.id} onClick={() => { setShortIndex(i); nav({ name: 'shorts' }); }}
                  className="w-20 h-32 rounded-2xl relative shrink-0 overflow-hidden flex items-end p-1.5 cursor-pointer"
                  style={{ background: `linear-gradient(160deg, ${C.darkCard}, ${C.primary}66)`, boxShadow: `0 0 10px ${C.neon}25` }}>
                  {s.sponsored && <span className="absolute top-1.5 left-1.5 text-[7px] text-white px-1.5 py-0.5 rounded" style={{ backgroundColor: C.primary }}>مُمول</span>}
                  <Play size={16} color="#fff" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" fill="#fff" opacity={0.85} />
                  <div className="flex items-center gap-1 text-white text-[8px]"><Heart size={9} fill="#fff" /> {s.views}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </>
    );
  }

  function BrandScreen() {
    return (
      <>
        <TopBar title="ODE براند" onBack={back} dark={isDark} textP={textP} />
        <div className="flex gap-2 px-4 overflow-x-auto pb-2 shrink-0" style={{ scrollbarWidth: 'none' }}>
          {CATEGORIES.map((c) => (
            <button key={c} onClick={() => setCategory(c)}
              className="px-3.5 py-2 rounded-xl text-[11px] font-medium shrink-0"
              style={category === c
                ? { background: `linear-gradient(90deg, ${C.primary}, ${C.primaryLight})`, color: '#fff', boxShadow: `0 0 10px ${C.neon}70` }
                : { backgroundColor: isDark ? C.darkCard : '#eee', color: textS }}>
              {c}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto px-4 pt-2 pb-4 grid grid-cols-2 gap-3 content-start" style={{ scrollbarWidth: 'none' }}>
          {filteredProducts.length === 0 ? (
            <p className="col-span-2 text-center text-xs mt-10" style={{ color: textS }}>لا توجد منتجات بهذا التصنيف</p>
          ) : filteredProducts.map((p) => (
            <Glass key={p.id} dark={isDark} className="p-2" onClick={() => nav({ name: 'product', product: p })}>
              <div className="h-20 rounded-xl mb-1.5" style={{ background: `linear-gradient(135deg, ${C.primary}55, ${C.neon}33)` }} />
              <p className="text-[11px] font-medium truncate" style={{ color: textP }}>{p.name}</p>
              <p className="text-[9px] truncate" style={{ color: textS }}>{p.store}</p>
              <p className="text-[11px] font-bold mt-1" style={{ color: C.primaryLight }}>{p.price.toFixed(2)} د.ل</p>
            </Glass>
          ))}
        </div>
      </>
    );
  }

  function ProductScreen({ product }) {
    const [qty, setQty] = useState(1);
    return (
      <>
        <TopBar title="تفاصيل المنتج" onBack={back} dark={isDark} textP={textP} />
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ scrollbarWidth: 'none' }}>
          <div className="h-44 rounded-2xl mb-4" style={{ background: `linear-gradient(135deg, ${C.primary}77, ${C.neon}44)` }} />
          <h2 className="font-bold text-lg" style={{ color: textP }}>{product.name}</h2>
          <p className="text-sm mt-1" style={{ color: C.primaryLight }}>{product.price.toFixed(2)} د.ل</p>
          <div className="flex items-center justify-between mt-5">
            <span className="text-xs" style={{ color: textS }}>الكمية</span>
            <div className="flex items-center gap-3">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} style={{ color: C.primaryLight }}><Minus size={18} /></button>
              <span style={{ color: textP }}>{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} style={{ color: C.primaryLight }}><Plus size={18} /></button>
            </div>
          </div>
          <div className="mt-6">
            <NeonButton onClick={() => { addToCart({ ...product, qty }); }}>
              <ShoppingCart size={16} /> إضافة إلى السلة
            </NeonButton>
          </div>
        </div>
      </>
    );
  }

  function CartScreen() {
    return (
      <>
        <TopBar title="السلة" onBack={back} dark={isDark} textP={textP} />
        {cart.length === 0 ? (
          <div className="flex-1 flex items-center justify-center"><p style={{ color: textS }} className="text-xs">السلة فارغة</p></div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-2.5" style={{ scrollbarWidth: 'none' }}>
              {cart.map((item) => (
                <Glass key={item.id} dark={isDark} className="p-2.5 flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl shrink-0" style={{ background: `linear-gradient(135deg, ${C.primary}55, ${C.neon}33)` }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-medium truncate" style={{ color: textP }}>{item.name}</p>
                    <p className="text-[10px]" style={{ color: textS }}>{item.price.toFixed(2)} د.ل</p>
                  </div>
                  <button onClick={() => updateQty(item.id, -1)} style={{ color: C.primaryLight }}><Minus size={14} /></button>
                  <span className="text-xs" style={{ color: textP }}>{item.qty}</span>
                  <button onClick={() => updateQty(item.id, 1)} style={{ color: C.primaryLight }}><Plus size={14} /></button>
                </Glass>
              ))}
            </div>
            <div className="px-4 pb-4 shrink-0">
              <Glass dark={isDark} className="p-4">
                <div className="flex justify-between text-xs mb-3" style={{ color: textP }}>
                  <span>الإجمالي</span><span className="font-bold">{cartTotal.toFixed(2)} د.ل</span>
                </div>
                <NeonButton onClick={() => { setCart([]); setToast('تم تأكيد الطلب والدفع عبر ODE PAY بنجاح'); back(); }}>
                  <Wallet size={16} /> الدفع عبر ODE PAY
                </NeonButton>
              </Glass>
            </div>
          </>
        )}
      </>
    );
  }

  function PayScreen() {
    const txns = [
      { label: 'شحن رصيد', amount: 200, positive: true },
      { label: 'طلب #ODE-2026-004521', amount: -85, positive: false },
      { label: 'استرجاع', amount: 15, positive: true },
    ];
    return (
      <>
        <TopBar title="ODE PAY" onBack={back} dark={isDark} textP={textP} />
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ scrollbarWidth: 'none' }}>
          <Glass dark={isDark} className="p-6 text-center">
            <p className="text-xs" style={{ color: textS }}>رصيدك الحالي</p>
            <p className="text-3xl font-extrabold mt-1" style={{ color: textP }}>350.00</p>
            <div className="mt-4"><NeonButton small onClick={() => setToast('تم شحن 100.00 د.ل بنجاح')}>+ شحن المحفظة</NeonButton></div>
          </Glass>
          <h3 className="font-bold text-sm mt-6 mb-2" style={{ color: textP }}>سجل المعاملات</h3>
          <div className="space-y-2">
            {txns.map((t, i) => (
              <div key={i} className="flex items-center justify-between px-3 py-2.5 rounded-xl" style={{ backgroundColor: isDark ? C.darkCard : '#f5f5f5' }}>
                <span className="text-[11px]" style={{ color: textP }}>{t.label}</span>
                <span className="text-[11px] font-bold" style={{ color: t.positive ? C.success : C.error }}>{t.positive ? '+' : ''}{t.amount.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>
      </>
    );
  }

  function ServicesScreen() {
    return (
      <>
        <TopBar title="الخدمات المنزلية" onBack={back} dark={isDark} textP={textP} />
        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2.5" style={{ scrollbarWidth: 'none' }}>
          {SERVICES.map((s) => (
            <Glass key={s.id} dark={isDark} className="p-3 flex items-center gap-3" onClick={() => nav({ name: 'booking', service: s })}>
              <Sparkles size={22} color={C.primaryLight} />
              <div className="flex-1">
                <p className="text-[12px] font-medium" style={{ color: textP }}>{s.name}</p>
                <p className="text-[10px]" style={{ color: textS }}>يبدأ من {s.price.toFixed(0)} د.ل</p>
              </div>
              <ChevronLeft size={14} color={textS} />
            </Glass>
          ))}
        </div>
      </>
    );
  }

  function BookingScreen({ service }) {
    const submit = () => {
      if (!bookingForm.name.trim() || !bookingForm.phone.trim() || !bookingForm.altPhone.trim()) {
        setBookingError('أكمل جميع الحقول الإجبارية (الاسم، الهاتف الأساسي، الهاتف البديل)');
        return;
      }
      setBookingError('');
      setToast('تم إرسال طلب الحجز، سيتم تأكيده قريباً');
      setBookingForm({ name: '', phone: '', altPhone: '' });
      back();
    };
    return (
      <>
        <TopBar title={service.name} onBack={back} dark={isDark} textP={textP} />
        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-3" style={{ scrollbarWidth: 'none' }}>
          <p className="text-[11px] font-bold" style={{ color: textP }}>بيانات الطلب (إجبارية)</p>
          {[
            { key: 'name', ph: 'الاسم الكامل' },
            { key: 'phone', ph: 'رقم الهاتف الرئيسي' },
            { key: 'altPhone', ph: 'رقم هاتف بديل' },
          ].map((f) => (
            <Glass key={f.key} dark={isDark} className="px-3 py-1">
              <input
                value={bookingForm[f.key]}
                onChange={(e) => setBookingForm((b) => ({ ...b, [f.key]: e.target.value }))}
                placeholder={f.ph}
                className="w-full bg-transparent outline-none text-[12px] py-2.5"
                style={{ color: textP }}
              />
            </Glass>
          ))}
          {bookingError && <p className="text-[10px]" style={{ color: C.error }}>{bookingError}</p>}
          <NeonButton onClick={submit}>متابعة إلى الدفع</NeonButton>
        </div>
      </>
    );
  }

  function RidesScreen() {
    const steps = ['حدد نقطة الانطلاق والوجهة', 'جاري البحث عن سائق...', 'تم العثور على سائق، جاري التوجه إليك', 'الرحلة جارية الآن'];
    return (
      <>
        <TopBar title="التوصيل والركاب" onBack={back} dark={isDark} textP={textP} />
        <div className="flex-1 relative">
          <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: isDark ? '#1E0838' : '#F7F3FC' }}>
            <div className="text-center">
              <MapPin size={40} color={textS} className="mx-auto mb-2" />
              <p className="text-[11px]" style={{ color: textS }}>خريطة تفاعلية (تُعرض هنا فعلياً بالتطبيق الحقيقي)</p>
            </div>
          </div>
          <div className="absolute bottom-4 left-4 right-4">
            <Glass dark={isDark} className="p-4">
              <p className="text-[11px] mb-3" style={{ color: textP }}>{steps[rideStep]}</p>
              {rideStep === 0 && <NeonButton onClick={() => setRideStep(1)}>اطلب رحلة الآن</NeonButton>}
              {rideStep > 0 && rideStep < 3 && (
                <button onClick={() => setRideStep((s) => s + 1)} className="text-[10px] w-full text-center" style={{ color: C.primaryLight }}>محاكاة الخطوة التالية ▸</button>
              )}
              {rideStep === 3 && (
                <div className="flex gap-2">
                  <button className="flex-1 flex items-center justify-center gap-1 py-2 rounded-xl text-[10px] text-white" style={{ backgroundColor: C.success }}><Phone size={12} /> اتصال</button>
                  <button className="flex-1 flex items-center justify-center gap-1 py-2 rounded-xl text-[10px] text-white" style={{ backgroundColor: C.primary }}><MessageCircle size={12} /> مراسلة</button>
                </div>
              )}
            </Glass>
          </div>
        </div>
      </>
    );
  }

  function ShortsScreen() {
    const s = SHORTS[shortIndex];
    return (
      <div className="relative w-full h-full bg-black flex flex-col">
        <div className="absolute inset-0" style={{ background: `linear-gradient(160deg, ${C.darkCard}, ${C.primary}55)` }} />
        <button onClick={back} className="absolute top-4 right-4 z-10 text-white"><ArrowRight size={20} /></button>
        <div className="absolute inset-0 flex items-center justify-center">
          <Play size={50} color="#fff" fill="#fff" opacity={0.8} />
        </div>
        <div className="absolute bottom-24 left-4 right-20 text-white text-[12px]">{s.caption}</div>
        <div className="absolute bottom-36 right-4 flex flex-col items-center gap-5">
          <button onClick={() => setLikedShorts((l) => ({ ...l, [s.id]: !l[s.id] }))} className="flex flex-col items-center gap-1">
            <div className="p-2.5 rounded-full" style={{ backgroundColor: 'rgba(0,0,0,0.35)', boxShadow: `0 0 10px ${C.neon}50` }}>
              <Heart size={20} color={likedShorts[s.id] ? C.error : '#fff'} fill={likedShorts[s.id] ? C.error : 'none'} />
            </div>
            <span className="text-white text-[9px]">{s.likes + (likedShorts[s.id] ? 1 : 0)}</span>
          </button>
          <button className="flex flex-col items-center gap-1">
            <div className="p-2.5 rounded-full" style={{ backgroundColor: 'rgba(0,0,0,0.35)' }}><Share2 size={20} color="#fff" /></div>
            <span className="text-white text-[9px]">مشاركة</span>
          </button>
        </div>
        {s.sponsored && (
          <div className="absolute bottom-6 left-4 right-4">
            <Glass dark className="p-3 flex items-center gap-2" onClick={() => setToast('الانتقال لصفحة شراء المنتج المعروض')}>
              <Store size={16} color={C.primaryLight} />
              <span className="text-white text-[11px] flex-1">اطلب المنتج المعروض الآن</span>
              <ChevronLeft size={12} color="#fff" />
            </Glass>
          </div>
        )}
        <div className="absolute top-1/2 left-2 -translate-y-1/2 flex flex-col gap-2">
          <button onClick={() => setShortIndex((i) => Math.max(0, i - 1))} className="text-white/60 text-[9px]">▲</button>
          <button onClick={() => setShortIndex((i) => Math.min(SHORTS.length - 1, i + 1))} className="text-white/60 text-[9px]">▼</button>
        </div>
      </div>
    );
  }

  function ProfileScreen() {
    return (
      <>
        <TopBar title="الملف الشخصي" onBack={back} dark={isDark} textP={textP} />
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ scrollbarWidth: 'none' }}>
          <Glass dark={isDark} className="p-4 flex items-center gap-3">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: C.primary }}>
              <User size={22} color="#fff" />
            </div>
            <div>
              <p className="text-[12px] font-medium" style={{ color: textP }}>عمر</p>
              <p className="text-[10px]" style={{ color: textS }}>0912xxxxxx</p>
            </div>
          </Glass>
          <div className="mt-4 space-y-1">
            {[
              { icon: MapPin, label: 'عناويني' },
              { icon: Receipt, label: 'طلباتي' },
              { icon: Globe, label: 'اللغة' },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-3 px-2 py-3 rounded-xl" style={{ color: textP }}>
                <item.icon size={17} color={C.primaryLight} /><span className="text-[12px]">{item.label}</span>
              </div>
            ))}
            <div className="flex items-center gap-3 px-2 py-3 rounded-xl" style={{ color: C.error }}>
              <LogOut size={17} /><span className="text-[12px]">تسجيل الخروج</span>
            </div>
          </div>
        </div>
      </>
    );
  }

  const screens = {
    home: <HomeScreen />,
    brand: <BrandScreen />,
    product: <ProductScreen product={screen.product} />,
    cart: <CartScreen />,
    pay: <PayScreen />,
    services: <ServicesScreen />,
    booking: <BookingScreen service={screen.service} />,
    rides: <RidesScreen />,
    shorts: <ShortsScreen />,
    profile: <ProfileScreen />,
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#0a0014', fontFamily: 'system-ui, sans-serif' }} dir="rtl">
      <div className="relative w-[375px] h-[780px] rounded-[2.5rem] overflow-hidden border-4 shadow-2xl flex flex-col"
        style={{ backgroundColor: bg, borderColor: '#000', boxShadow: `0 0 60px ${C.neon}30` }}>
        <div className="h-9 flex items-center justify-between px-6 text-[11px] shrink-0" style={{ color: textS }}>
          <span>9:41</span><span>ODE — معاينة تفاعلية</span>
        </div>
        <div className="flex-1 flex flex-col overflow-hidden">{screens[screen.name]}</div>

        {toast && (
          <div className="absolute bottom-6 left-4 right-4 flex items-center gap-2 px-4 py-3 rounded-xl text-white text-[11px] z-20"
            style={{ backgroundColor: C.primary, boxShadow: `0 0 16px ${C.neon}70` }}>
            <Check size={14} /> {toast}
          </div>
        )}
      </div>
    </div>
  );
}
