import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole } from '../../common/auth.middleware';
import { RideSharingService } from './ride-sharing.service';

export function rideSharingRouter(db: Pool) {
  const router = Router();
  const service = new RideSharingService(db);

  // ---- عام تماماً، بدون أي توكن مصادقة — هذا هو المقصود بالرابط المُشارك ----
  router.get('/public/:token', async (req, res) => {
    try {
      const data = await service.getPublicTrackingData(req.params.token);
      res.json(data);
    } catch (e: any) {
      res.status(404).json({ error: e.message });
    }
  });

  router.use(authenticate(db));

  router.post('/:rideId/share-link', requireRole('customer'), async (req, res) => {
    // item 41 (audit): previously any authenticated customer could
    // generate a tracking link for ANY ride by guessing/knowing its
    // UUID — classic Broken Object Level Authorization. The ride must
    // actually belong to the caller.
    try {
      const link = await service.generateShareLink(req.params.rideId, req.auth!.userId);
      res.json({ token: link.public_token, expiresAt: link.expires_at });
    } catch (e: any) {
      res.status(403).json({ error: e.message });
    }
  });

  router.get('/emergency-contacts', requireRole('customer'), async (req, res) => {
    res.json(await service.listEmergencyContacts(req.auth!.userId));
  });

  router.post('/emergency-contacts', requireRole('customer'), async (req, res) => {
    const { name, phone } = req.body;
    res.status(201).json(await service.addEmergencyContact(req.auth!.userId, name, phone));
  });

  return router;
}
