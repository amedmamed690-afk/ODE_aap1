import { Pool } from 'pg';
import { randomBytes } from 'crypto';
import { getOtpProvider } from '../auth/otp.provider';

/**
 * روابط المشاركة اللحظية (بند 4) — رابط عام بدون تسجيل دخول، يفتح صفحة
 * ويب خفيفة (خارج الـ API، Frontend منفصل بسيط) تعرض موقع السائق لحظياً.
 *
 * أمان مهم: الرابط لا يكشف أي بيانات حساسة غير ضرورية (لا رقم هاتف
 * الراكب، لا سجل رحلاته) — فقط: موقع السائق الحالي، اسمه وتقييمه ونوع
 * سيارته، والوقت المتوقع للوصول. والتوكن عشوائي طويل (32 بايت) وله
 * صلاحية محدودة تنتهي بعد الرحلة بهامش ساعة، مش رابط دائم.
 */
export class RideSharingService {
  constructor(private db: Pool) {}

  async generateShareLink(rideId: string, ownerCustomerId: string) {
    // item 41: verify the ride actually belongs to the caller before
    // creating (or rotating) its tracking link.
    const { rows: [ride] } = await this.db.query(
      `SELECT id FROM rides WHERE id = $1 AND customer_id = $2`,
      [rideId, ownerCustomerId]
    );
    if (!ride) throw new Error('ride_not_found_or_not_yours');

    const publicToken = randomBytes(24).toString('hex');
    const { rows: [link] } = await this.db.query(
      `INSERT INTO ride_share_links (ride_id, public_token, expires_at)
       VALUES ($1, $2, now() + interval '6 hours')
       ON CONFLICT (ride_id) DO UPDATE SET public_token = $2, expires_at = now() + interval '6 hours'
       RETURNING *`,
      [rideId, publicToken]
    );
    return link;
  }

  /** بيانات محدودة ومقصودة فقط — لا نُرجع أي شيء عن حساب الراكب نفسه */
  async getPublicTrackingData(publicToken: string) {
    const { rows: [link] } = await this.db.query(`SELECT * FROM ride_share_links WHERE public_token = $1`, [publicToken]);
    if (!link) throw new Error('invalid_or_expired_link');
    if (new Date(link.expires_at) < new Date()) throw new Error('invalid_or_expired_link');

    const { rows: [data] } = await this.db.query(
      `SELECT r.status, r.pickup_lat, r.pickup_lng, r.dropoff_lat, r.dropoff_lng,
              d.current_lat AS driver_lat, d.current_lng AS driver_lng, d.rating_avg, d.vehicle_type, d.plate_number,
              u.full_name AS driver_name
       FROM rides r
       LEFT JOIN drivers d ON d.id = r.driver_id
       LEFT JOIN users u ON u.id = d.user_id
       WHERE r.id = $1`,
      [link.ride_id]
    );
    if (!data) throw new Error('ride_not_found');
    return data;
  }

  /** جهات اتصال الطوارئ — تُدار من إعدادات المستخدم، تُستخدم بكل رحلة ليلية تلقائياً */
  async listEmergencyContacts(userId: string) {
    const { rows } = await this.db.query(`SELECT * FROM user_emergency_contacts WHERE user_id = $1`, [userId]);
    return rows;
  }

  async addEmergencyContact(userId: string, name: string, phone: string) {
    const { rows: [contact] } = await this.db.query(
      `INSERT INTO user_emergency_contacts (user_id, name, phone) VALUES ($1,$2,$3) RETURNING *`,
      [userId, name, phone]
    );
    return contact;
  }

  /**
   * يُستدعى تلقائياً لحظة إنشاء رحلة ليلية (RidesService.requestRide يتحقق
   * من is_night_ride) — يبعث رابط التتبع لكل جهة طوارئ مفعّلة، ويسجّل الإرسال.
   *
   * إصلاح (Audit — بند 3): كان التسجيل بقاعدة البيانات فقط بدون أي إرسال
   * فعلي (TODO صريح). الآن يُستخدم نفس OtpProvider abstraction الموجود
   * أصلاً (`getOtpProvider().sendText`) بدل نظام رسائل منفصل — يتغيّر
   * المزود تلقائيًا حسب OTP_PROVIDER بالبيئة (whatsapp/sms/console-dev)
   * بدون أي كود إضافي هنا. فشل إرسال جهة اتصال واحدة لا يمنع باقي جهات
   * الاتصال ولا يفشل طلب الرحلة نفسه — الرحلة أهم من إشعار الطوارئ
   * الإضافي، لكن كل محاولة (نجحت أو فشلت) تُسجَّل بوضوح بعمودي
   * delivery_status/error_message الجديدين لسهولة التتبع لاحقًا.
   */
  async notifyEmergencyContactsForRide(rideId: string, customerId: string) {
    const contacts = await this.listEmergencyContacts(customerId);
    const activeContacts = contacts.filter((c: any) => c.notify_on_night_rides);
    if (activeContacts.length === 0) return { notified: 0 };

    const link = await this.generateShareLink(rideId, customerId);
    const trackingUrl = `${process.env.PUBLIC_TRACKING_BASE_URL || 'https://track.ode-app.com'}/${link.public_token}`;
    const message = `ODE: أحد أفراد عائلتك بدأ رحلة ليلية. تابع موقعه لحظيًا: ${trackingUrl}`;
    const provider = getOtpProvider();

    let sentCount = 0;
    for (const contact of activeContacts) {
      let status: 'sent' | 'failed' = 'sent';
      let errorMessage: string | null = null;
      try {
        await provider.sendText(contact.phone, message);
        sentCount++;
      } catch (e: any) {
        status = 'failed';
        errorMessage = e?.message ?? 'unknown_error';
        console.error(`emergency notification failed for contact ${contact.id} on ride ${rideId}:`, errorMessage);
      }
      await this.db.query(
        `INSERT INTO ride_emergency_notifications (ride_id, contact_id, delivery_status, error_message) VALUES ($1,$2,$3,$4)`,
        [rideId, contact.id, status, errorMessage]
      );
    }
    return { notified: sentCount, attempted: activeContacts.length, publicToken: link.public_token };
  }
}
