/**
 * OTP delivery is intentionally pluggable (spec item 13): "WhatsApp OTP،
 * SMS fallback، لا تضع بيانات مزود الخدمة داخل الكود، استخدم Environment
 * Variables." Nothing above this interface knows or cares which vendor is
 * behind it — swapping providers later never touches otp.service.ts.
 *
 * تعميم (Audit — بند 3): أُضيفت `sendText()` لإعادة استخدام نفس الـabstraction
 * (نفس بيانات الاعتماد، نفس اختيار WhatsApp/SMS عبر OTP_PROVIDER) لرسائل
 * حرة النص — تحديدًا رابط تتبع الطوارئ بـride-sharing.service.ts — بدل بناء
 * نظام رسائل منفصل ومكرر. `send()` الأصلية بقيت كما هي لرمز التحقق فقط.
 *
 * ملاحظة تقنية مهمة لواتساب تحديدًا: رسائل الأعمال المُبادَرة من الطرف
 * التجاري (business-initiated) خارج نافذة محادثة العميل النشطة (24 ساعة)
 * تتطلب Template معتمد مسبقًا من WhatsApp، مش نص حر فعلي — فـ`sendText`
 * بمزود WhatsApp يستخدم template ثانٍ منفصل (`WHATSAPP_EMERGENCY_TEMPLATE`)
 * بمتغير نصي واحد، بدل افتراض إمكانية إرسال أي نص كيفما كان.
 *
 * To go live: pick one HTTP-based vendor (WhatsApp Cloud API, Twilio,
 * Unifonic, etc.), fill in the two fetch calls below with that vendor's
 * documented request shape, and set the matching env vars. Everything else
 * (code generation, hashing, expiry, rate limiting) already works without
 * any external service.
 */
export interface OtpProvider {
  send(phone: string, code: string): Promise<void>;
  sendText(phone: string, message: string): Promise<void>;
}

/** Logs the code instead of sending it — used automatically when no real
 *  provider credentials are configured, so local/dev work never blocks on
 *  a missing API key. */
class ConsoleDevOtpProvider implements OtpProvider {
  async send(phone: string, code: string): Promise<void> {
    console.log(`[DEV OTP] ${phone} -> ${code} (no OTP_PROVIDER configured; not actually sent)`);
  }
  async sendText(phone: string, message: string): Promise<void> {
    console.log(`[DEV TEXT] ${phone} -> ${message} (no OTP_PROVIDER configured; not actually sent)`);
  }
}

/** WhatsApp Cloud API — first channel per spec ("WhatsApp OTP" listed before
 *  SMS). Requires WHATSAPP_TOKEN + WHATSAPP_PHONE_NUMBER_ID. */
class WhatsAppOtpProvider implements OtpProvider {
  async send(phone: string, code: string): Promise<void> {
    const token = process.env.WHATSAPP_TOKEN;
    const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
    const res = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: phone,
        type: 'template',
        // "otp_login" must exist as an approved WhatsApp message template
        // with one body variable ({{1}}) for the code.
        template: { name: 'otp_login', language: { code: 'ar' }, components: [
          { type: 'body', parameters: [{ type: 'text', text: code }] },
        ] },
      }),
    });
    if (!res.ok) throw new Error(`whatsapp_send_failed_${res.status}`);
  }

  async sendText(phone: string, message: string): Promise<void> {
    const token = process.env.WHATSAPP_TOKEN;
    const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
    // Template منفصل عن otp_login — WhatsApp لا يسمح بنص حر لرسالة يبدأها
    // الطرف التجاري خارج نافذة محادثة نشطة. اسم القالب قابل للتهيئة لأن
    // اعتماد القالب فعليًا يتم من WhatsApp Business Manager، مش من الكود.
    const templateName = process.env.WHATSAPP_EMERGENCY_TEMPLATE || 'emergency_alert';
    const res = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: phone,
        type: 'template',
        template: { name: templateName, language: { code: 'ar' }, components: [
          { type: 'body', parameters: [{ type: 'text', text: message }] },
        ] },
      }),
    });
    if (!res.ok) throw new Error(`whatsapp_send_failed_${res.status}`);
  }
}

/** Generic SMS fallback — works with any provider that exposes a simple
 *  POST-with-bearer-token API (Twilio/Unifonic/etc. all fit this shape with
 *  small adjustments). Requires SMS_API_URL + SMS_API_KEY + SMS_SENDER_ID. */
class SmsOtpProvider implements OtpProvider {
  async send(phone: string, code: string): Promise<void> {
    await this._post(phone, `ODE: رمز التحقق الخاص بك هو ${code}`);
  }

  async sendText(phone: string, message: string): Promise<void> {
    // SMS لا يفرض قوالب معتمدة مسبقًا مثل WhatsApp — نص حر مباشر.
    await this._post(phone, message);
  }

  private async _post(phone: string, message: string): Promise<void> {
    const url = process.env.SMS_API_URL!;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.SMS_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ sender: process.env.SMS_SENDER_ID || 'ODE', to: phone, message }),
    });
    if (!res.ok) throw new Error(`sms_send_failed_${res.status}`);
  }
}

export function getOtpProvider(): OtpProvider {
  switch (process.env.OTP_PROVIDER) {
    case 'whatsapp':
      return new WhatsAppOtpProvider();
    case 'sms':
      return new SmsOtpProvider();
    default:
      return new ConsoleDevOtpProvider();
  }
}
