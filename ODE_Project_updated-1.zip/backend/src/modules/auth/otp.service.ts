import { Pool } from 'pg';
import crypto from 'crypto';
import { OtpProvider } from './otp.provider';

const CODE_TTL_MINUTES = 5;
const RESEND_COOLDOWN_SECONDS = 60;
const MAX_VERIFY_ATTEMPTS = 5;

function hashCode(code: string) {
  return crypto.createHash('sha256').update(code).digest('hex');
}

function generateCode(): string {
  // 6-digit numeric code, zero-padded (crypto.randomInt is CSPRNG-backed —
  // Math.random() is not acceptable for anything auth-adjacent).
  return crypto.randomInt(0, 1_000_000).toString().padStart(6, '0');
}

export class OtpService {
  constructor(private db: Pool, private provider: OtpProvider) {}

  async requestCode(phone: string): Promise<{ cooldownSeconds: number } | { sent: true }> {
    const { rows: [recent] } = await this.db.query(
      `SELECT created_at FROM otp_codes WHERE phone = $1 AND consumed_at IS NULL
       ORDER BY created_at DESC LIMIT 1`,
      [phone]
    );
    if (recent) {
      const secondsSince = (Date.now() - new Date(recent.created_at).getTime()) / 1000;
      if (secondsSince < RESEND_COOLDOWN_SECONDS) {
        return { cooldownSeconds: Math.ceil(RESEND_COOLDOWN_SECONDS - secondsSince) };
      }
    }

    const code = generateCode();
    await this.db.query(
      `INSERT INTO otp_codes (phone, code_hash, expires_at)
       VALUES ($1, $2, now() + interval '${CODE_TTL_MINUTES} minutes')`,
      [phone, hashCode(code)]
    );
    await this.provider.send(phone, code);
    return { sent: true };
  }

  async verifyCode(phone: string, code: string): Promise<boolean> {
    const { rows: [record] } = await this.db.query(
      `SELECT id, code_hash, attempts, expires_at FROM otp_codes
       WHERE phone = $1 AND consumed_at IS NULL ORDER BY created_at DESC LIMIT 1`,
      [phone]
    );
    if (!record) return false;
    if (new Date(record.expires_at).getTime() < Date.now()) return false;
    if (record.attempts >= MAX_VERIFY_ATTEMPTS) return false;

    const isMatch = record.code_hash === hashCode(code);
    if (!isMatch) {
      await this.db.query(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1`, [record.id]);
      return false;
    }

    await this.db.query(`UPDATE otp_codes SET consumed_at = now() WHERE id = $1`, [record.id]);
    return true;
  }
}
