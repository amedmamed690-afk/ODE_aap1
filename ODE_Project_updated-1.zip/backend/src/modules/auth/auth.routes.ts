import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import jwt from 'jsonwebtoken';
import { OtpService } from './otp.service';
import { getOtpProvider } from './otp.provider';
import { authenticate } from '../../common/auth.middleware';
import { assertPhoneNotRegisteredAsPartner, PhoneAlreadyPartnerError } from '../../common/customer-registration-guard';

/**
 * Shared phone+OTP auth for all three apps (item 13).
 *
 * IMPORTANT (reconciled against the pre-existing driver/partner providers):
 * driver_auth_provider.dart and partner_auth_provider.dart both read
 * `data['token']` straight out of /otp/verify's response and use it
 * *immediately* as a real Bearer token to call their onboarding
 * endpoints — they never expect a separate "pending" exchange step. So a
 * bare `users` row (role='customer', full_name=null) is created right
 * here on first verify for ANY new phone, regardless of which app it came
 * from. Partner/driver onboarding-submit later promotes that same row's
 * `role` once their application is accepted for submission (see
 * onboarding.routes.ts / driver-onboarding.routes.ts) — nobody gets a
 * second, different account.
 */
export function authRouter(db: Pool) {
  const router = Router();
  const otp = new OtpService(db, getOtpProvider());

  const phoneSchema = z.object({ phone: z.string().min(8).max(20) });

  router.post('/otp/request', async (req, res) => {
    const parsed = phoneSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const result = await otp.requestCode(parsed.data.phone);
    if ('cooldownSeconds' in result) {
      return res.status(429).json({ error: 'otp_cooldown', cooldownSeconds: result.cooldownSeconds });
    }
    res.json({ message: 'تم إرسال رمز التحقق' });
  });

  const verifySchema = z.object({
    phone: z.string().min(8).max(20),
    code: z.string().length(6),
  });

  router.post('/otp/verify', async (req, res) => {
    const parsed = verifySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { phone, code } = parsed.data;

    const isValid = await otp.verifyCode(phone, code);
    if (!isValid) return res.status(401).json({ error: 'invalid_or_expired_code' });

    let existingUser = (await db.query(
      `SELECT u.id, u.role, u.is_blocked, u.full_name,
              p.id AS partner_id, d.id AS driver_id
       FROM users u
       LEFT JOIN partners p ON p.owner_user_id = u.id
       LEFT JOIN drivers d ON d.user_id = u.id
       WHERE u.phone = $1`,
      [phone]
    )).rows[0];

    if (!existingUser) {
      // رقم جديد كليًا: نرفض فورًا لو نفس الرقم مسجّل كهاتف تواصل رئيسي
      // لشريك (partners.primary_phone قد يختلف عن أي صف بجدول users).
      try {
        await assertPhoneNotRegisteredAsPartner(db, phone);
      } catch (e) {
        if (e instanceof PhoneAlreadyPartnerError) {
          return res.status(409).json({ error: e.message, message: e.userMessage });
        }
        throw e;
      }
      const { rows: [created] } = await db.query(
        `INSERT INTO users (phone, role, is_verified) VALUES ($1, 'customer', true)
         RETURNING id, role, full_name`,
        [phone]
      );
      existingUser = created;
    }

    if (existingUser.is_blocked) return res.status(403).json({ error: 'account_blocked' });

    const payload = {
      userId: existingUser.id,
      role: existingUser.role,
      partnerId: existingUser.partner_id ?? undefined,
      driverId: existingUser.driver_id ?? undefined,
    };
    const token = jwt.sign(payload, process.env.JWT_SECRET!, { expiresIn: '30d' });

    res.json({
      token,
      isNewUser: !existingUser.full_name,
      user: { id: existingUser.id, phone, role: existingUser.role, fullName: existingUser.full_name ?? null },
    });
  });

  // يُستخدم من register_screen.dart (تطبيق العميل فقط) لإكمال البيانات
  // بعد أول تسجيل دخول — توكن حقيقي فعلي (مو مؤقت) لأنه صادر من نفس
  // /otp/verify اللي بالأعلى.
  const completeProfileSchema = z.object({
    fullName: z.string().min(2),
    countryId: z.number(),
  });

  router.patch('/complete-profile', authenticate(db), async (req, res) => {
    const parsed = completeProfileSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    await db.query(
      `UPDATE users SET full_name = $1, country_id = $2 WHERE id = $3`,
      [parsed.data.fullName, parsed.data.countryId, req.auth!.userId]
    );
    res.json({ message: 'تم تحديث البيانات' });
  });

  // يُستخدم من شاشة splash بكل التطبيقات للتحقق من صلاحية التوكن المخزّن.
  router.get('/verify', async (req, res) => {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) return res.status(401).json({ error: 'missing_token' });
    try {
      const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET!) as any;
      res.json({ userId: payload.userId, role: payload.role });
    } catch {
      res.status(401).json({ error: 'invalid_token' });
    }
  });

  return router;
}
