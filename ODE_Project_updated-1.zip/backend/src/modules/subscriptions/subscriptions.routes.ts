import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * Item 17: ODE Plus / ODE Pro. `benefits` is a free-form JSONB array
 * fully owned by Admin (subscription_plans.benefits) — nothing here
 * hard-codes what either tier includes. Payment is deducted from the
 * customer wallet already built for item 11; a real external payment
 * provider integration point is where `payWithWallet` below is called
 * from, so swapping in card payment later doesn't touch plan logic.
 */
export function subscriptionsRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/plans', async (req, res) => {
    const { rows } = await db.query(
      `SELECT sp.id, sp.code, sp.name_ar, sp.price, c.code AS currency_code, sp.duration_days, sp.benefits
       FROM subscription_plans sp JOIN currencies c ON c.id = sp.currency_id
       WHERE sp.is_active = true ORDER BY sp.price`
    );
    res.json(rows);
  });

  router.get('/me', async (req, res) => {
    const { rows: [sub] } = await db.query(
      `SELECT us.id, sp.code, sp.name_ar, us.starts_at, us.ends_at, us.status
       FROM user_subscriptions us JOIN subscription_plans sp ON sp.id = us.plan_id
       WHERE us.user_id = $1 AND us.status = 'active' AND us.ends_at > now()
       ORDER BY us.ends_at DESC LIMIT 1`,
      [req.auth!.userId]
    );
    res.json(sub ?? null);
  });

  const subscribeSchema = z.object({ planId: z.string().uuid() });

  router.post('/subscribe', async (req, res) => {
    const parsed = subscribeSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [plan] } = await client.query(
        `SELECT price, duration_days FROM subscription_plans WHERE id = $1 AND is_active = true`,
        [parsed.data.planId]
      );
      if (!plan) throw new Error('plan_not_found');

      const { rows: [wallet] } = await client.query(
        `INSERT INTO customer_wallets (user_id, balance) VALUES ($1, 0)
         ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id
         RETURNING balance`,
        [req.auth!.userId]
      );
      if (Number(wallet.balance) < Number(plan.price)) throw new Error('insufficient_wallet_balance');

      const { rows: [updatedWallet] } = await client.query(
        `UPDATE customer_wallets SET balance = balance - $1 WHERE user_id = $2 RETURNING balance`,
        [plan.price, req.auth!.userId]
      );
      await client.query(
        `INSERT INTO customer_wallet_transactions (user_id, type, amount, balance_after, reference_type, reference_id)
         VALUES ($1, 'subscription', $2, $3, 'subscription_plan', $4)`,
        [req.auth!.userId, -plan.price, updatedWallet.balance, parsed.data.planId]
      );

      // أي اشتراك سابق نشط يُلغى — لا يوجد تراكم لمدد متعددة بنفس الوقت.
      await client.query(`UPDATE user_subscriptions SET status = 'cancelled' WHERE user_id = $1 AND status = 'active'`, [req.auth!.userId]);
      const { rows: [sub] } = await client.query(
        `INSERT INTO user_subscriptions (user_id, plan_id, ends_at)
         VALUES ($1, $2, now() + ($3 || ' days')::interval) RETURNING id, ends_at`,
        [req.auth!.userId, parsed.data.planId, plan.duration_days]
      );

      await client.query('COMMIT');
      res.status(201).json({ message: 'تم الاشتراك بنجاح', subscriptionId: sub.id, endsAt: sub.ends_at });
    } catch (e: any) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  return router;
}
