import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';
import { writeAuditLog } from '../admin/audit-log.service';

/**
 * Item 2: "موظفو خدمة العملاء لا يحصلون على صلاحيات لوحة التحكم
 * الرئيسية." This is a genuinely narrower surface than /admin/* — a
 * support agent can look a customer/order/ride up and leave a note,
 * nothing more. They authenticate through the same /admin/auth/login
 * (role can be 'support', not just 'admin') but every route here is
 * gated on the 'support.access' permission specifically, which a
 * regular admin's permission set need not include either.
 */
export function supportRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin', 'support'), requirePermission('support.access'));

  router.get('/customers', async (req, res) => {
    const phone = req.query.phone as string;
    if (!phone) return res.status(400).json({ error: 'phone_required' });
    const { rows: [customer] } = await db.query(
      `SELECT id, full_name, phone, email, is_blocked, created_at FROM users WHERE phone = $1`, [phone]
    );
    if (!customer) return res.status(404).json({ error: 'customer_not_found' });

    const { rows: recentOrders } = await db.query(
      `SELECT id, order_number, status, total, created_at FROM orders WHERE customer_id = $1 ORDER BY created_at DESC LIMIT 10`,
      [customer.id]
    );
    const { rows: recentRides } = await db.query(
      `SELECT id, status, estimated_fare, requested_at FROM rides WHERE customer_id = $1 ORDER BY requested_at DESC LIMIT 10`,
      [customer.id]
    );
    res.json({ customer, recentOrders, recentRides });
  });

  router.get('/orders/:id', async (req, res) => {
    const { rows: [order] } = await db.query(
      `SELECT o.*, u.full_name AS customer_name, u.phone AS customer_phone
       FROM orders o JOIN users u ON u.id = o.customer_id WHERE o.id = $1`,
      [req.params.id]
    );
    if (!order) return res.status(404).json({ error: 'order_not_found' });
    const { rows: history } = await db.query(
      `SELECT status, note, created_at FROM order_status_history WHERE order_id = $1 ORDER BY created_at`,
      [req.params.id]
    );
    res.json({ order, history });
  });

  // ملاحظة داخلية فقط — ما تغيّر حالة الطلب، توثيق للمتابعة بين الفريق.
  router.post('/orders/:id/note', async (req, res) => {
    const note = req.body?.note;
    if (!note) return res.status(400).json({ error: 'note_required' });
    await db.query(
      `INSERT INTO order_status_history (order_id, status, changed_by_user_id, note)
       SELECT $1, status, $2, $3 FROM orders WHERE id = $1`,
      [req.params.id, req.auth!.userId, `[ملاحظة دعم فني] ${note}`]
    );
    await writeAuditLog(db, req.auth!.adminId!, 'support_note_added', 'order', req.params.id);
    res.json({ message: 'تمت إضافة الملاحظة' });
  });

  return router;
}
