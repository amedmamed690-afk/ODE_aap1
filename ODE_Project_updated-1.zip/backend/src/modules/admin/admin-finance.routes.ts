import { Router } from 'express';
import { z } from 'zod';
import crypto from 'crypto';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';
import { writeAuditLog } from './audit-log.service';

/**
 * Commissions and fees (items 9/10) are deliberately NOT their own
 * tables — they're rows in the `app_settings` key/value store that
 * config.routes.ts's GET /config/bootstrap already serves to every app.
 * That keeps "nothing hard-coded, all admin-editable" (item 31) true
 * without yet another table per fee type.
 */
export function adminFinanceRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'));

  router.get('/settings', requirePermission('finance.review'), async (req, res) => {
    const { rows } = await db.query(`SELECT key, value, country_id FROM app_settings WHERE key = ANY($1)`, [[
      'commission_restaurants', 'commission_stores', 'commission_delivery', 'commission_passenger',
      'fee_driver_registration', 'fee_store_registration', 'fee_page_creation', 'fee_delivery_base',
      'driver_timeout_minutes', 'order_cancellation_grace_minutes',
    ]]);
    res.json(Object.fromEntries(rows.map(r => [r.key, r.value])));
  });

  // طلب صريح (بند 2/3/4/9 — نظام إعدادات مركزي بقسم واضح منفصل باسم
  // "إعدادات النظام"): قراءة منفصلة عن قراءة "المالية" أعلاه، لكن نفس
  // PUT /settings العام بالأسفل هو مصدر الكتابة الوحيد للاثنين معًا —
  // بدون أي تكرار لمنطق الكتابة.
  router.get('/system-settings', requirePermission('finance.review'), async (req, res) => {
    const { rows } = await db.query(`SELECT key, value FROM app_settings WHERE key = ANY($1)`, [[
      'services.restaurants.enabled', 'services.stores.enabled', 'services.home_services.enabled',
      'services.rides.enabled', 'services.parcel.enabled', 'services.wallet.enabled',
      'payment.cash.enabled', 'payment.gateway.enabled',
    ]]);
    res.json(Object.fromEntries(rows.map(r => [r.key, r.value])));
  });

  const settingSchema = z.object({ key: z.string(), value: z.any(), countryId: z.number().optional() });
  router.put('/settings', requirePermission('finance.review'), async (req, res) => {
    const parsed = settingSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    await db.query(
      `INSERT INTO app_settings (key, value, country_id, updated_by) VALUES ($1,$2,$3,$4)
       ON CONFLICT (key) DO UPDATE SET value = $2, country_id = $3, updated_by = $4, updated_at = now()`,
      [parsed.data.key, JSON.stringify(parsed.data.value), parsed.data.countryId ?? null, req.auth!.userId]
    );
    await writeAuditLog(db, req.auth!.adminId!, 'update_service_availability', 'app_setting', parsed.data.key, { value: parsed.data.value });
    res.json({ message: 'تم التحديث' });
  });

  // -------- Top-up codes (item 12) --------
  router.get('/topup-codes', requirePermission('finance.review'), async (req, res) => {
    res.json((await db.query(`SELECT * FROM topup_codes ORDER BY created_at DESC LIMIT 200`)).rows);
  });

  const batchSchema = z.object({ count: z.number().int().min(1).max(1000), value: z.number().positive(), expiresAt: z.string().optional() });
  router.post('/topup-codes/batch', requirePermission('finance.review'), async (req, res) => {
    const parsed = batchSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const codes = Array.from({ length: parsed.data.count }, () => crypto.randomBytes(6).toString('hex').toUpperCase());

    const values = codes.map((_, i) => `($${i * 3 + 1}, $${i * 3 + 2}, $${i * 3 + 3})`).join(',');
    const params = codes.flatMap(code => [code, parsed.data.value, parsed.data.expiresAt ?? null]);
    await db.query(`INSERT INTO topup_codes (code, value, expires_at) VALUES ${values}`, params);

    await writeAuditLog(db, req.auth!.adminId!, 'generate_topup_codes', 'topup_batch', undefined, { count: parsed.data.count, value: parsed.data.value });
    res.status(201).json({ codes });
  });

  router.patch('/topup-codes/:id/cancel', requirePermission('finance.review'), async (req, res) => {
    await db.query(`UPDATE topup_codes SET status = 'cancelled' WHERE id = $1 AND status = 'active'`, [req.params.id]);
    res.json({ message: 'تم الإلغاء' });
  });

  // -------- Driver withdrawal requests (item 12/11) --------
  router.get('/withdrawals', requirePermission('finance.review'), async (req, res) => {
    const status = (req.query.status as string) || 'pending';
    const { rows } = await db.query(
      `SELECT w.id, w.amount, w.payout_details, w.status, w.created_at, u.full_name, u.phone
       FROM driver_withdrawal_requests w JOIN drivers d ON d.id = w.driver_id JOIN users u ON u.id = d.user_id
       WHERE w.status = $1 ORDER BY w.created_at`,
      [status]
    );
    res.json(rows);
  });

  router.patch('/withdrawals/:id/mark-paid', requirePermission('finance.review'), async (req, res) => {
    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [request] } = await client.query(
        `SELECT driver_id, amount FROM driver_withdrawal_requests WHERE id = $1 AND status = 'pending' FOR UPDATE`,
        [req.params.id]
      );
      if (!request) throw new Error('withdrawal_not_pending');

      await client.query(`UPDATE driver_withdrawal_requests SET status = 'paid' WHERE id = $1`, [req.params.id]);
      const { rows: [driver] } = await client.query(
        `UPDATE drivers SET balance = balance - $1 WHERE id = $2 RETURNING balance`,
        [request.amount, request.driver_id]
      );
      await client.query(
        `INSERT INTO driver_wallet_transactions (driver_id, type, amount, balance_after, reference_type, reference_id)
         VALUES ($1, 'withdrawal', $2, $3, 'withdrawal_request', $4)`,
        [request.driver_id, -request.amount, driver.balance, req.params.id]
      );
      await client.query('COMMIT');
      await writeAuditLog(db, req.auth!.adminId!, 'mark_withdrawal_paid', 'withdrawal_request', req.params.id);
      res.json({ message: 'تم تعليمه كمدفوع' });
    } catch (e: any) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  // -------- Partner settlement batches (already generated by
  // partner-balance.service.ts; admin just reviews/marks paid) --------
  router.get('/settlements', requirePermission('finance.review'), async (req, res) => {
    const status = (req.query.status as string) || 'pending';
    const { rows } = await db.query(
      `SELECT s.*, p.owner_full_name FROM settlement_batches s JOIN partners p ON p.id = s.partner_id
       WHERE s.status = $1 ORDER BY s.created_at`,
      [status]
    );
    res.json(rows);
  });

  router.patch('/settlements/:id/mark-paid', requirePermission('finance.review'), async (req, res) => {
    await db.query(`UPDATE settlement_batches SET status = 'paid' WHERE id = $1 AND status = 'pending'`, [req.params.id]);
    await writeAuditLog(db, req.auth!.adminId!, 'mark_withdrawal_paid', 'settlement_batch', req.params.id);
    res.json({ message: 'تم' });
  });

  return router;
}
