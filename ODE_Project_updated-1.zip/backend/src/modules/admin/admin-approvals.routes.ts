import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';
import { writeAuditLog } from './audit-log.service';
import { NotificationsService } from '../notifications/notifications.service';

/**
 * The single biggest launch blocker this whole build had: drivers and
 * partners could already submit full applications, but nothing existed
 * for an admin to actually approve one. Every table/status this touches
 * (drivers.approval_status, partners.status) was built in earlier
 * phases specifically expecting this endpoint to exist.
 */
export function adminApprovalsRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'));
  const notifications = new NotificationsService(db);

  // ---------------- DRIVERS ----------------
  router.get('/drivers', requirePermission('drivers.review'), async (req, res) => {
    const status = (req.query.status as string) || 'pending';
    const { rows } = await db.query(
      `SELECT d.id, u.full_name, u.phone, d.vehicle_type, d.plate_number, d.license_doc_url,
              d.approval_status, d.rejected_reason, d.created_at
       FROM drivers d JOIN users u ON u.id = d.user_id
       WHERE d.approval_status = $1 ORDER BY d.created_at`,
      [status]
    );
    res.json(rows);
  });

  router.patch('/drivers/:id/approve', requirePermission('drivers.review'), async (req, res) => {
    const { rows: [driver] } = await db.query(
      `UPDATE drivers SET approval_status = 'active' WHERE id = $1 AND approval_status = 'pending'
       RETURNING user_id`,
      [req.params.id]
    );
    if (!driver) return res.status(409).json({ error: 'driver_not_pending' });
    await writeAuditLog(db, req.auth!.adminId!, 'approve_driver', 'driver', req.params.id);
    await notifications.send(driver.user_id, { type: 'driver', titleAr: 'تم قبول طلبك 🎉', bodyAr: 'يمكنك الآن بدء استقبال الطلبات' });
    res.json({ message: 'تم القبول' });
  });

  const rejectSchema = z.object({ reason: z.string().min(2) });
  router.patch('/drivers/:id/reject', requirePermission('drivers.review'), async (req, res) => {
    const parsed = rejectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { rows: [driver] } = await db.query(
      `UPDATE drivers SET approval_status = 'rejected', rejected_reason = $1
       WHERE id = $2 AND approval_status = 'pending' RETURNING user_id`,
      [parsed.data.reason, req.params.id]
    );
    if (!driver) return res.status(409).json({ error: 'driver_not_pending' });
    await writeAuditLog(db, req.auth!.adminId!, 'reject_driver', 'driver', req.params.id, { reason: parsed.data.reason });
    await notifications.send(driver.user_id, { type: 'driver', titleAr: 'لم تتم الموافقة على طلبك', bodyAr: parsed.data.reason });
    res.json({ message: 'تم الرفض' });
  });

  router.patch('/drivers/:id/suspend', requirePermission('drivers.review'), async (req, res) => {
    const parsed = rejectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { rows: [driver] } = await db.query(
      `UPDATE drivers SET approval_status = 'suspended', rejected_reason = $1 WHERE id = $2 RETURNING user_id`,
      [parsed.data.reason, req.params.id]
    );
    if (!driver) return res.status(404).json({ error: 'driver_not_found' });
    await writeAuditLog(db, req.auth!.adminId!, 'suspend_user_via_anomaly', 'driver', req.params.id, { reason: parsed.data.reason });
    await notifications.send(driver.user_id, { type: 'driver', titleAr: 'تم إيقاف حسابك', bodyAr: parsed.data.reason });
    res.json({ message: 'تم الإيقاف' });
  });

  router.patch('/drivers/:id/reinstate', requirePermission('drivers.review'), async (req, res) => {
    const { rows: [driver] } = await db.query(
      `UPDATE drivers SET approval_status = 'active', rejected_reason = NULL
       WHERE id = $1 AND approval_status = 'suspended' RETURNING user_id`,
      [req.params.id]
    );
    if (!driver) return res.status(409).json({ error: 'driver_not_suspended' });
    await writeAuditLog(db, req.auth!.adminId!, 'clear_anomaly_flag', 'driver', req.params.id);
    res.json({ message: 'تم رفع الإيقاف' });
  });

  // ---------------- PARTNERS ----------------
  router.get('/partners', requirePermission('partners.review'), async (req, res) => {
    const status = (req.query.status as string) || 'pending';
    const { rows } = await db.query(
      `SELECT p.id, p.owner_full_name, p.primary_phone, p.account_type, p.digital_subtype_id,
              p.activity_category_id, p.status, p.rejected_reason, p.created_at
       FROM partners p WHERE p.status = $1 ORDER BY p.created_at`,
      [status]
    );
    res.json(rows);
  });

  router.get('/partners/:id/documents', requirePermission('partners.review'), async (req, res) => {
    const { rows } = await db.query(`SELECT doc_type, file_url, uploaded_at FROM partner_documents WHERE partner_id = $1`, [req.params.id]);
    res.json(rows);
  });

  router.patch('/partners/:id/approve', requirePermission('partners.review'), async (req, res) => {
    const { rows: [partner] } = await db.query(
      `UPDATE partners SET status = 'active', dashboard_unlocked = true
       WHERE id = $1 AND status = 'pending' RETURNING owner_user_id`,
      [req.params.id]
    );
    if (!partner) return res.status(409).json({ error: 'partner_not_pending' });
    await writeAuditLog(db, req.auth!.adminId!, 'approve_partner', 'partner', req.params.id);
    await notifications.send(partner.owner_user_id, { type: 'partner', titleAr: 'تم قبول صفحتك 🎉', bodyAr: 'يمكنك الآن استقبال الطلبات' });
    res.json({ message: 'تم القبول' });
  });

  router.patch('/partners/:id/reject', requirePermission('partners.review'), async (req, res) => {
    const parsed = rejectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { rows: [partner] } = await db.query(
      `UPDATE partners SET status = 'rejected', rejected_reason = $1
       WHERE id = $2 AND status = 'pending' RETURNING owner_user_id`,
      [parsed.data.reason, req.params.id]
    );
    if (!partner) return res.status(409).json({ error: 'partner_not_pending' });
    await writeAuditLog(db, req.auth!.adminId!, 'reject_partner', 'partner', req.params.id, { reason: parsed.data.reason });
    await notifications.send(partner.owner_user_id, { type: 'partner', titleAr: 'لم تتم الموافقة على صفحتك', bodyAr: parsed.data.reason });
    res.json({ message: 'تم الرفض' });
  });

  router.patch('/partners/:id/suspend', requirePermission('partners.review'), async (req, res) => {
    const parsed = rejectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { rows: [partner] } = await db.query(
      `UPDATE partners SET status = 'suspended', rejected_reason = $1 WHERE id = $2 RETURNING owner_user_id`,
      [parsed.data.reason, req.params.id]
    );
    if (!partner) return res.status(404).json({ error: 'partner_not_found' });
    await writeAuditLog(db, req.auth!.adminId!, 'suspend_user_via_anomaly', 'partner', req.params.id, { reason: parsed.data.reason });
    res.json({ message: 'تم الإيقاف' });
  });

  router.patch('/partners/:id/products/:productId/block', requirePermission('partners.review'), async (req, res) => {
    await db.query(`UPDATE products SET is_active = false WHERE id = $1 AND partner_id = $2`, [req.params.productId, req.params.id]);
    await writeAuditLog(db, req.auth!.adminId!, 'block_partner_product', 'product', req.params.productId, { partnerId: req.params.id });
    res.json({ message: 'تم حظر المنتج' });
  });

  return router;
}
