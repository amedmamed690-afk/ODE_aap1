import { Router } from 'express';
import { z } from 'zod';
import crypto from 'crypto';
import bcrypt from 'bcrypt';
import { Pool } from 'pg';
import { authenticate, requireRole, requireSuperAdmin } from '../../common/auth.middleware';
import { writeAuditLog } from './audit-log.service';

/** Matches AdminUsers.jsx's api.getAdmins/createAdmin/deactivateAdmin
 *  exactly. Super Admin only — was a real security gap before (no way
 *  to add an admin except directly in the database). */
export function adminUsersRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'), requireSuperAdmin);

  router.get('/', async (req, res) => {
    const { rows } = await db.query(
      `SELECT a.id, u.email, a.permissions, a.is_super_admin, a.is_active, a.totp_enabled
       FROM admin_users a JOIN users u ON u.id = a.user_id
       ORDER BY u.created_at`
    );
    res.json(rows);
  });

  const createSchema = z.object({ email: z.string().email(), permissions: z.array(z.string()) });

  router.post('/', async (req, res) => {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const tempPassword = crypto.randomBytes(9).toString('base64url'); // يُعرض مرة وحدة، ما يُخزَّن نصًا صريحًا أبدًا
    const passwordHash = await bcrypt.hash(tempPassword, 12);

    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [user] } = await client.query(
        `INSERT INTO users (email, password_hash, role, is_verified) VALUES ($1, $2, 'admin', true) RETURNING id`,
        [parsed.data.email, passwordHash]
      );
      const { rows: [admin] } = await client.query(
        `INSERT INTO admin_users (user_id, permissions) VALUES ($1, $2) RETURNING id`,
        [user.id, JSON.stringify(parsed.data.permissions)]
      );
      await client.query('COMMIT');

      await writeAuditLog(db, req.auth!.adminId!, 'create_admin_user', 'admin_user', admin.id, { email: parsed.data.email });
      res.status(201).json({ id: admin.id, tempPassword });
    } catch (e: any) {
      await client.query('ROLLBACK');
      if (e.code === '23505') return res.status(409).json({ error: 'email_already_exists' });
      throw e;
    } finally {
      client.release();
    }
  });

  router.patch('/:id/deactivate', async (req, res) => {
    const { rows: [admin] } = await db.query(
      `UPDATE admin_users SET is_active = false WHERE id = $1 AND is_super_admin = false RETURNING id`,
      [req.params.id]
    );
    if (!admin) return res.status(400).json({ error: 'cannot_deactivate_this_account' });
    await writeAuditLog(db, req.auth!.adminId!, 'deactivate_admin_user', 'admin_user', req.params.id);
    res.json({ message: 'تم التعطيل' });
  });

  return router;
}
