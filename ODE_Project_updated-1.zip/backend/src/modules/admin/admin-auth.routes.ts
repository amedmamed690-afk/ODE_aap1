import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcrypt';
import { authenticator } from 'otplib';
import jwt from 'jsonwebtoken';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';
import { OtpService } from '../auth/otp.service';
import { getOtpProvider } from '../auth/otp.provider';

/**
 * Admin login is deliberately its own surface: email + password (+ TOTP
 * once enabled), never the phone-OTP flow every other app uses. This is
 * what item 8's "الإدارة" needs and item 22's "Secure authentication" /
 * "Password hashing" apply to directly — nothing else in this codebase
 * hashes a password because nothing else needs one.
 *
 * طلب صريح (بند 5/6/7): أُضيف معالج تهيئة أمان إجباري لأول استخدام
 * (بريد + هاتفان يُتحقق منهما بـOTP حقيقي — بإعادة استخدام OtpService
 * الموجود أصلاً بدل نظام مواز — + 3 كلمات مرور منفصلة مُشفّرة كل واحدة
 * بشكل مستقل + اسم مستخدم)، وتتبّع/إبطال جلسات حقيقي. `bootstrap-super-
 * admin` القديم يبقى كما هو (لا كسر لأي مسار طوارئ CLI موجود).
 */
export function adminAuthRouter(db: Pool) {
  const router = Router();
  const otpService = new OtpService(db, getOtpProvider());

  const loginSchema = z.object({ email: z.string().email(), password: z.string(), totpCode: z.string().optional() });

  router.post('/login', async (req, res) => {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { email, password, totpCode } = parsed.data;

    const { rows: [row] } = await db.query(
      `SELECT u.id AS user_id, u.password_hash, u.is_blocked,
              a.id AS admin_id, a.is_super_admin, a.is_active, a.permissions,
              a.totp_secret, a.totp_enabled, a.must_change_password
       FROM users u JOIN admin_users a ON a.user_id = u.id
       WHERE u.email = $1 AND u.role IN ('admin','support')`,
      [email]
    );
    if (!row || row.is_blocked || !row.is_active) return res.status(401).json({ error: 'invalid_credentials' });

    const passwordOk = row.password_hash && await bcrypt.compare(password, row.password_hash);
    if (!passwordOk) return res.status(401).json({ error: 'invalid_credentials' });

    if (row.totp_enabled) {
      if (!totpCode) return res.status(401).json({ error: 'totp_required' });
      const totpOk = authenticator.verify({ token: totpCode, secret: row.totp_secret });
      if (!totpOk) return res.status(401).json({ error: 'invalid_totp' });
    }

    // طلب صريح (بند 6): جلسة حقيقية قابلة للإبطال — مو فقط توقيع JWT صالح.
    // "من أجهزة مختلفة" يعني عدة صفوف admin_sessions بنفس admin_user_id
    // بنفس الوقت، وهذا يعمل تلقائيًا لأننا لا نحذف الجلسات القديمة عند
    // إنشاء واحدة جديدة.
    const sessionExpiresAt = new Date(Date.now() + 12 * 60 * 60 * 1000);
    const { rows: [session] } = await db.query(
      `INSERT INTO admin_sessions (admin_user_id, device_label, ip_address, expires_at)
       VALUES ($1, $2, $3, $4) RETURNING id`,
      [row.admin_id, (req.headers['user-agent'] as string)?.slice(0, 200) ?? null, req.ip, sessionExpiresAt]
    );

    const token = jwt.sign(
      { userId: row.user_id, role: 'admin', adminId: row.admin_id, isSuperAdmin: row.is_super_admin,
        permissions: row.permissions, sessionId: session.id },
      process.env.JWT_SECRET!,
      { expiresIn: '12h' } // جلسة أقصر من التطبيقات العادية — لوحة تحكم حساسة
    );

    res.json({ token, mustChangePassword: row.must_change_password, permissions: row.permissions, isSuperAdmin: row.is_super_admin });
  });

  // طلب صريح (بند 6): تسجيل خروج حقيقي — يُبطل الجلسة فعليًا بالسيرفر،
  // مو فقط حذف التوكن من المتصفح (اللي كان يبقى صالحًا تقنيًا لو سُرق).
  router.post('/logout', authenticate(db), async (req, res) => {
    if (req.auth!.sessionId) {
      await db.query(`UPDATE admin_sessions SET revoked_at = now() WHERE id = $1`, [req.auth!.sessionId]);
    }
    res.json({ message: 'تم تسجيل الخروج' });
  });

  // طلب صريح (بند 6): "الدخول من جهاز آخر" — يشوف الأدمن كل جلساته
  // النشطة الحالية (بلا كشف التوكن نفسه، فقط جهاز/IP/وقت آخر ظهور).
  router.get('/sessions', authenticate(db), async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, device_label, ip_address, created_at, last_seen_at,
              (id = $2) AS is_current
       FROM admin_sessions
       WHERE admin_user_id = $1 AND revoked_at IS NULL AND expires_at > now()
       ORDER BY last_seen_at DESC`,
      [req.auth!.adminId, req.auth!.sessionId ?? null]
    );
    res.json(rows);
  });

  // إبطال جلسة معيّنة (مثلاً جهاز مفقود) — تحقّق ملكية صريح: لا يقدر أي
  // أدمن يُبطل جلسة أدمن آخر عبر هذا المسار.
  router.post('/sessions/:id/revoke', authenticate(db), async (req, res) => {
    const { rows: [revoked] } = await db.query(
      `UPDATE admin_sessions SET revoked_at = now()
       WHERE id = $1 AND admin_user_id = $2 AND revoked_at IS NULL
       RETURNING id`,
      [req.params.id, req.auth!.adminId]
    );
    if (!revoked) return res.status(404).json({ error: 'session_not_found' });
    res.json({ message: 'تم إبطال الجلسة' });
  });

  router.post('/change-password', authenticate(db), async (req, res) => {
    const schema = z.object({ currentPassword: z.string(), newPassword: z.string().min(8) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const { rows: [user] } = await db.query(`SELECT password_hash FROM users WHERE id = $1`, [req.auth!.userId]);
    if (!(await bcrypt.compare(parsed.data.currentPassword, user.password_hash))) {
      return res.status(401).json({ error: 'wrong_current_password' });
    }
    const newHash = await bcrypt.hash(parsed.data.newPassword, 12);
    await db.query(`UPDATE users SET password_hash = $1 WHERE id = $2`, [newHash, req.auth!.userId]);
    await db.query(`UPDATE admin_users SET must_change_password = false WHERE user_id = $1`, [req.auth!.userId]);
    res.json({ message: 'تم تحديث كلمة المرور' });
  });

  // بند 22: 2FA — الأدمن يفعّلها اختياريًا (مو إجباري، لكن متاحة بالكامل)
  router.post('/totp/setup', authenticate(db), async (req, res) => {
    const secret = authenticator.generateSecret();
    await db.query(`UPDATE admin_users SET totp_secret = $1, totp_enabled = false WHERE user_id = $2`, [secret, req.auth!.userId]);
    const { rows: [user] } = await db.query(`SELECT email FROM users WHERE id = $1`, [req.auth!.userId]);
    const otpauthUrl = authenticator.keyuri(user.email, 'ODE Admin', secret);
    res.json({ secret, otpauthUrl }); // الواجهة تحوّل otpauthUrl لـQR code
  });

  router.post('/totp/confirm', authenticate(db), async (req, res) => {
    const { code } = req.body;
    const { rows: [admin] } = await db.query(`SELECT totp_secret FROM admin_users WHERE user_id = $1`, [req.auth!.userId]);
    if (!admin?.totp_secret || !authenticator.verify({ token: code, secret: admin.totp_secret })) {
      return res.status(400).json({ error: 'invalid_totp' });
    }
    await db.query(`UPDATE admin_users SET totp_enabled = true WHERE user_id = $1`, [req.auth!.userId]);
    res.json({ message: 'تم تفعيل التحقق بخطوتين' });
  });

  // ===================================================================
  // طلب صريح (بند 5): معالج التهيئة الأمنية الإجباري لأول استخدام —
  // بريد → هاتف أول + OTP → هاتف ثانٍ + OTP → 3 كلمات مرور → اسم مستخدم.
  // كل خطوة تتحقق من إكمال ما قبلها؛ لا يمكن تخطي أي خطوة (بند 5: "جميع
  // هذه البيانات مطلوبة ولا يمكن تخطي أي خطوة منها").
  // ===================================================================

  // الواجهة تستدعي هذا أول ما تُفتح — لو true تعرض المعالج الإجباري
  // بدل شاشة الدخول العادية، تمامًا كما طُلب.
  router.get('/setup-status', async (req, res) => {
    const { rows: [{ count }] } = await db.query(
      `SELECT COUNT(*) FROM admin_users WHERE is_super_admin = true AND security_setup_completed_at IS NOT NULL`
    );
    res.json({ needsSetup: Number(count) === 0 });
  });

  const setupStartSchema = z.object({ email: z.string().email(), bootstrapSecret: z.string() });
  router.post('/setup/start', async (req, res) => {
    const parsed = setupStartSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    if (!process.env.ADMIN_BOOTSTRAP_SECRET || parsed.data.bootstrapSecret !== process.env.ADMIN_BOOTSTRAP_SECRET) {
      return res.status(403).json({ error: 'invalid_bootstrap_secret' });
    }
    const { rows: [{ count }] } = await db.query(
      `SELECT COUNT(*) FROM admin_users WHERE is_super_admin = true AND security_setup_completed_at IS NOT NULL`
    );
    if (Number(count) > 0) return res.status(409).json({ error: 'setup_already_completed' });

    const { rows: [session] } = await db.query(
      `INSERT INTO admin_setup_sessions (email) VALUES ($1) RETURNING id`,
      [parsed.data.email]
    );
    res.status(201).json({ setupSessionId: session.id });
  });

  async function loadValidSetupSession(setupSessionId: string) {
    const { rows: [session] } = await db.query(
      `SELECT * FROM admin_setup_sessions WHERE id = $1 AND consumed_at IS NULL AND expires_at > now()`,
      [setupSessionId]
    );
    return session ?? null;
  }

  const requestPhoneOtpSchema = z.object({
    setupSessionId: z.string().uuid(), which: z.union([z.literal(1), z.literal(2)]), phone: z.string().min(6),
  });
  router.post('/setup/phone/request-otp', async (req, res) => {
    const parsed = requestPhoneOtpSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const session = await loadValidSetupSession(parsed.data.setupSessionId);
    if (!session) return res.status(410).json({ error: 'setup_session_expired' });
    // الهاتف الثاني يجب أن يختلف عن الأول — الهدف عاملا تحقق مستقلان
    // فعليًا، لا نفس الرقم مرتين بشكل صوري.
    if (parsed.data.which === 2 && session.phone_1 === parsed.data.phone) {
      return res.status(400).json({ error: 'second_phone_must_differ' });
    }

    const column = parsed.data.which === 1 ? 'phone_1' : 'phone_2';
    await db.query(`UPDATE admin_setup_sessions SET ${column} = $1 WHERE id = $2`, [parsed.data.phone, session.id]);
    const result = await otpService.requestCode(parsed.data.phone);
    if ('cooldownSeconds' in result) return res.status(429).json({ error: 'otp_cooldown', ...result });
    res.json({ sent: true });
  });

  const verifyPhoneOtpSchema = z.object({
    setupSessionId: z.string().uuid(), which: z.union([z.literal(1), z.literal(2)]), code: z.string().length(6),
  });
  router.post('/setup/phone/verify-otp', async (req, res) => {
    const parsed = verifyPhoneOtpSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const session = await loadValidSetupSession(parsed.data.setupSessionId);
    if (!session) return res.status(410).json({ error: 'setup_session_expired' });

    const phone = parsed.data.which === 1 ? session.phone_1 : session.phone_2;
    if (!phone) return res.status(400).json({ error: 'phone_not_requested_yet' });
    const ok = await otpService.verifyCode(phone, parsed.data.code);
    if (!ok) return res.status(400).json({ error: 'invalid_or_expired_otp' });

    const column = parsed.data.which === 1 ? 'phone_1_verified_at' : 'phone_2_verified_at';
    await db.query(`UPDATE admin_setup_sessions SET ${column} = now() WHERE id = $1`, [session.id]);
    res.json({ verified: true });
  });

  const completeSetupSchema = z.object({
    setupSessionId: z.string().uuid(),
    username: z.string().min(3).max(50).regex(/^[a-zA-Z0-9_]+$/, 'أحرف/أرقام/شرطة سفلية فقط'),
    password: z.string().min(8),
    keyPassword: z.string().min(8),
    referencePassword: z.string().min(8),
  });
  router.post('/setup/complete', async (req, res) => {
    const parsed = completeSetupSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    const session = await loadValidSetupSession(d.setupSessionId);
    if (!session) return res.status(410).json({ error: 'setup_session_expired' });
    if (!session.phone_1_verified_at || !session.phone_2_verified_at) {
      return res.status(400).json({ error: 'both_phones_must_be_verified' });
    }
    // بند 5: "جميع هذه البيانات مطلوبة" — الثلاث كلمات لازم تكون مختلفة
    // عن بعض فعليًا، وإلا كانت مجرد نسخة مكررة من نفس السر بثلاثة أسماء.
    if (d.password === d.keyPassword || d.password === d.referencePassword || d.keyPassword === d.referencePassword) {
      return res.status(400).json({ error: 'passwords_must_be_distinct' });
    }
    const { rows: [existingUsername] } = await db.query(`SELECT 1 FROM admin_users WHERE username = $1`, [d.username]);
    if (existingUsername) return res.status(409).json({ error: 'username_taken' });

    // بند 7: Hashing قوي منفصل لكل سر — bcrypt بنفس القوة (12 rounds)
    // المستخدمة أصلاً بكل كلمات مرور الأدمن بالمشروع، بدون أي استثناء.
    const [passwordHash, keyPasswordHash, referencePasswordHash] = await Promise.all([
      bcrypt.hash(d.password, 12), bcrypt.hash(d.keyPassword, 12), bcrypt.hash(d.referencePassword, 12),
    ]);

    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [user] } = await client.query(
        `INSERT INTO users (phone, email, password_hash, role, is_verified) VALUES ($1,$2,$3,'admin',true) RETURNING id`,
        [session.phone_1, session.email, passwordHash]
      );
      await client.query(
        `INSERT INTO admin_users
           (user_id, permissions, is_super_admin, must_change_password,
            phone_2, username, key_password_hash, reference_password_hash, security_setup_completed_at)
         VALUES ($1,'[]',true,false,$2,$3,$4,$5,now())`,
        [user.id, session.phone_2, d.username, keyPasswordHash, referencePasswordHash]
      );
      await client.query(`UPDATE admin_setup_sessions SET consumed_at = now() WHERE id = $1`, [session.id]);
      await client.query('COMMIT');
      // بند 5: "تسجيل الدخول لاحقًا يعمل من أي مكان وفق بيانات الاعتماد
      // المهيَّأة" — لا نُرجع توكنًا هنا، الأدمن يسجّل دخوله من جديد
      // بالبريد وكلمة المرور تمامًا كأي مرة لاحقة (تدفق موحّد ومتوقّع).
      res.status(201).json({ message: 'اكتملت تهيئة الحساب — سجّل دخولك الآن بالبريد وكلمة المرور' });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  });

  // طلب صريح (بند 7 — استخدام فعلي لكلمتي المرور المفتاحية/المرجعية):
  // استرجاع الوصول لو نُسيت كلمة المرور الأساسية أو فُقد الهاتف، بدون
  // الحاجة لتدخل يدوي بقاعدة البيانات. إبطال كل الجلسات القائمة بعد أي
  // استرجاع ناجح — إجراء أمني قياسي (لو كان أحد سرق كلمة المرور القديمة
  // وجلسة نشطة، الاسترجاع يقطع وصوله فورًا).
  const recoverSchema = z.object({
    email: z.string().email(), keyPassword: z.string(), referencePassword: z.string(), newPassword: z.string().min(8),
  });
  router.post('/recover', async (req, res) => {
    const parsed = recoverSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    const { rows: [row] } = await db.query(
      `SELECT u.id AS user_id, a.id AS admin_id, a.key_password_hash, a.reference_password_hash
       FROM users u JOIN admin_users a ON a.user_id = u.id WHERE u.email = $1`,
      [d.email]
    );
    // نفس رسالة الخطأ سواء البريد غير موجود أو كلمتا المرور غلط — منع
    // تعداد البريد الإلكتروني (email enumeration).
    const genericError = () => res.status(401).json({ error: 'recovery_failed' });
    if (!row || !row.key_password_hash || !row.reference_password_hash) return genericError();

    const [keyOk, refOk] = await Promise.all([
      bcrypt.compare(d.keyPassword, row.key_password_hash),
      bcrypt.compare(d.referencePassword, row.reference_password_hash),
    ]);
    if (!keyOk || !refOk) return genericError();

    const newHash = await bcrypt.hash(d.newPassword, 12);
    await db.query(`UPDATE users SET password_hash = $1 WHERE id = $2`, [newHash, row.user_id]);
    await db.query(`UPDATE admin_sessions SET revoked_at = now() WHERE admin_user_id = $1 AND revoked_at IS NULL`, [row.admin_id]);
    res.json({ message: 'تم إعادة تعيين كلمة المرور — تم إبطال كل الجلسات النشطة السابقة' });
  });

  // إعداد أول Super Admin — يعمل مرة واحدة فقط (يرفض نفسه بمجرد وجود
  // أي Super Admin بالنظام) ومحمي بسر بيئي منفصل عن أي شيء آخر، عشان
  // ما يصير فيه مشكلة "بيضة ودجاجة" لإنشاء أول حساب بدون وصول مباشر
  // لقاعدة البيانات.
  //
  // ملاحظة (طلب صريح — بند 12: "لا تكسر النظام الحالي"): هذا المسار
  // القديم يبقى شغّالًا كما هو تمامًا لأي استخدام طارئ/CLI، لكن الواجهة
  // الآن تستخدم معالج /setup/* الإجباري أعلاه بدلاً منه لأي تهيئة عادية.
  // إصلاح (اكتشاف حقيقي أثناء هذه الجولة): users.phone هو NOT NULL UNIQUE
  // بالـschema — هذا الـendpoint كان يحاول الإدراج بدون قيمة لـphone
  // إطلاقًا، يعني كل استدعاء له كان سيفشل بخطأ قاعدة بيانات فعلي (NOT
  // NULL violation) قبل حتى الوصول لإنشاء admin_users. لم يُكتشف لأن
  // الـendpoint لم يُختبر فعليًا ضد قاعدة بيانات حقيقية بأي جولة سابقة.
  const bootstrapSchema = z.object({
    email: z.string().email(), phone: z.string().min(6), password: z.string().min(8), bootstrapSecret: z.string(),
  });
  router.post('/bootstrap-super-admin', async (req, res) => {
    const parsed = bootstrapSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    if (!process.env.ADMIN_BOOTSTRAP_SECRET || parsed.data.bootstrapSecret !== process.env.ADMIN_BOOTSTRAP_SECRET) {
      return res.status(403).json({ error: 'invalid_bootstrap_secret' });
    }
    const { rows: [{ count }] } = await db.query(`SELECT COUNT(*) FROM admin_users WHERE is_super_admin = true`);
    if (Number(count) > 0) return res.status(409).json({ error: 'super_admin_already_exists' });

    const passwordHash = await bcrypt.hash(parsed.data.password, 12);
    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [user] } = await client.query(
        `INSERT INTO users (phone, email, password_hash, role, is_verified) VALUES ($1,$2,$3,'admin',true) RETURNING id`,
        [parsed.data.phone, parsed.data.email, passwordHash]
      );
      await client.query(
        // security_setup_completed_at تُملأ هنا أيضًا (رغم تخطي المعالج
        // الكامل) وإلا ستُجبر الواجهة على معالج الإعداد من جديد كل مرة —
        // هذا المسار طوارئ صريح، فهو يتحمّل مسؤولية عدم وجود الهاتفين/
        // كلمتي المرور الإضافيتين (تبقى NULL، والاسترجاع بـ/recover غير
        // متاح لحساب أُنشئ بهذا المسار حتى تُضاف لاحقًا يدويًا).
        `INSERT INTO admin_users (user_id, permissions, is_super_admin, must_change_password, security_setup_completed_at)
         VALUES ($1,'[]',true,false,now())`,
        [user.id]
      );
      await client.query('COMMIT');
      res.status(201).json({ message: 'تم إنشاء حساب Super Admin الأول — سجّل دخولك الآن' });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  });

  return router;
}
