import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';

/** Read-mostly oversight (item 8: إدارة الطلبات/الرحلات) — the actual
 *  lifecycle transitions stay owned by order-flow.service.ts /
 *  rides.routes.ts; admin here can see everything and cancel when
 *  something needs manual intervention (a stuck order, a dispute). */
export function adminOrdersRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'), requirePermission('availability.write'));

  router.get('/orders', async (req, res) => {
    const status = req.query.status as string | undefined;
    const { rows } = await db.query(
      `SELECT o.id, o.order_number, o.status, o.total, o.created_at,
              u.full_name AS customer_name, p.owner_full_name AS partner_name
       FROM orders o JOIN users u ON u.id = o.customer_id LEFT JOIN partners p ON p.id = o.partner_id
       WHERE $1::text IS NULL OR o.status = $1
       ORDER BY o.created_at DESC LIMIT 100`,
      [status ?? null]
    );
    res.json(rows);
  });

  router.patch('/orders/:id/force-cancel', async (req, res) => {
    await db.query(
      `UPDATE orders SET status = 'cancelled', cancelled_by = 'admin', cancellation_reason = $1 WHERE id = $2`,
      [req.body?.reason ?? 'admin_intervention', req.params.id]
    );
    res.json({ message: 'تم الإلغاء' });
  });

  router.get('/rides', async (req, res) => {
    const status = req.query.status as string | undefined;
    const { rows } = await db.query(
      `SELECT r.id, r.status, r.estimated_fare, r.final_fare, r.requested_at,
              u.full_name AS customer_name, du.full_name AS driver_name
       FROM rides r JOIN users u ON u.id = r.customer_id
       LEFT JOIN drivers d ON d.id = r.driver_id LEFT JOIN users du ON du.id = d.user_id
       WHERE $1::text IS NULL OR r.status = $1
       ORDER BY r.requested_at DESC LIMIT 100`,
      [status ?? null]
    );
    res.json(rows);
  });

  return router;
}
