import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';
import { writeAuditLog } from './audit-log.service';

/**
 * Generic CRUD for every lookup table the customer/driver/partner apps
 * already read from but nothing could ever write to before this file:
 * countries, cities, currencies, ride categories, partner activity
 * categories, digital subtypes, ODE-brand categories, home services.
 * Without this, every one of those apps launches with empty pickers.
 */
export function adminCatalogRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'), requirePermission('catalog.write'));

  // -------- Countries / Cities / Currencies (item 24/25) --------
  router.get('/countries', async (_req, res) => res.json((await db.query(`SELECT * FROM countries ORDER BY name_ar`)).rows));
  router.post('/countries', async (req, res) => {
    const { isoCode, nameEn, nameAr, defaultCurrencyId } = req.body;
    const { rows: [c] } = await db.query(
      `INSERT INTO countries (iso_code, name_en, name_ar, default_currency_id) VALUES ($1,$2,$3,$4) RETURNING *`,
      [isoCode, nameEn, nameAr, defaultCurrencyId ?? null]
    );
    await writeAuditLog(db, req.auth!.adminId!, 'create_country', 'country', String(c.id));
    res.status(201).json(c);
  });
  router.patch('/countries/:id', async (req, res) => {
    const { nameEn, nameAr, isActive } = req.body;
    const { rows: [c] } = await db.query(
      `UPDATE countries SET name_en=COALESCE($1,name_en), name_ar=COALESCE($2,name_ar), is_active=COALESCE($3,is_active) WHERE id=$4 RETURNING *`,
      [nameEn, nameAr, isActive, req.params.id]
    );
    res.json(c);
  });

  router.get('/cities', async (req, res) => {
    const countryId = req.query.countryId;
    res.json((await db.query(`SELECT * FROM cities WHERE $1::int IS NULL OR country_id = $1 ORDER BY name_ar`, [countryId ?? null])).rows);
  });
  router.post('/cities', async (req, res) => {
    const { countryId, nameEn, nameAr } = req.body;
    const { rows: [c] } = await db.query(`INSERT INTO cities (country_id, name_en, name_ar) VALUES ($1,$2,$3) RETURNING *`, [countryId, nameEn, nameAr]);
    res.status(201).json(c);
  });

  router.get('/currencies', async (_req, res) => res.json((await db.query(`SELECT * FROM currencies ORDER BY code`)).rows));
  router.post('/currencies', async (req, res) => {
    const { code, symbol, nameEn, nameAr, exchangeRate } = req.body;
    const { rows: [c] } = await db.query(
      `INSERT INTO currencies (code, symbol, name_en, name_ar, exchange_rate_to_base) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [code, symbol, nameEn, nameAr, exchangeRate ?? 1]
    );
    res.status(201).json(c);
  });

  // -------- Ride categories (customer request UI + driver onboarding) --------
  router.get('/ride-categories', async (_req, res) => res.json((await db.query(`SELECT * FROM ride_categories ORDER BY sort_order`)).rows));
  router.post('/ride-categories', async (req, res) => {
    const { domain, groupType, nameAr, nameEn, capacityHint, baseFare, ratePerKm } = req.body;
    const { rows: [c] } = await db.query(
      `INSERT INTO ride_categories (domain, group_type, name_ar, name_en, capacity_hint, base_fare, rate_per_km)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [domain, groupType ?? null, nameAr, nameEn, capacityHint ?? null, baseFare ?? 0, ratePerKm ?? 0]
    );
    res.status(201).json(c);
  });
  router.patch('/ride-categories/:id', async (req, res) => {
    const { nameAr, nameEn, baseFare, ratePerKm, isActive, sortOrder } = req.body;
    const { rows: [c] } = await db.query(
      `UPDATE ride_categories SET name_ar=COALESCE($1,name_ar), name_en=COALESCE($2,name_en),
       base_fare=COALESCE($3,base_fare), rate_per_km=COALESCE($4,rate_per_km),
       is_active=COALESCE($5,is_active), sort_order=COALESCE($6,sort_order) WHERE id=$7 RETURNING *`,
      [nameAr, nameEn, baseFare, ratePerKm, isActive, sortOrder, req.params.id]
    );
    res.json(c);
  });

  // -------- Partner activity categories + digital subtypes (onboarding options) --------
  router.get('/partner-activity-categories', async (_req, res) => res.json((await db.query(`SELECT * FROM partner_activity_categories ORDER BY sort_order`)).rows));
  router.post('/partner-activity-categories', async (req, res) => {
    const { nameAr, nameEn } = req.body;
    const { rows: [c] } = await db.query(`INSERT INTO partner_activity_categories (name_ar, name_en) VALUES ($1,$2) RETURNING *`, [nameAr, nameEn]);
    res.status(201).json(c);
  });

  router.get('/partner-digital-subtypes', async (_req, res) => res.json((await db.query(`SELECT * FROM partner_digital_subtypes ORDER BY sort_order`)).rows));
  router.post('/partner-digital-subtypes', async (req, res) => {
    const { nameAr, nameEn } = req.body;
    const { rows: [c] } = await db.query(`INSERT INTO partner_digital_subtypes (name_ar, name_en) VALUES ($1,$2) RETURNING *`, [nameAr, nameEn]);
    res.status(201).json(c);
  });

  // -------- ODE Brand categories + products (item 7) --------
  router.get('/ode-brand/categories', async (_req, res) => res.json((await db.query(`SELECT * FROM ode_brand_categories ORDER BY sort_order`)).rows));
  router.post('/ode-brand/categories', async (req, res) => {
    const { nameAr, nameEn } = req.body;
    const { rows: [c] } = await db.query(`INSERT INTO ode_brand_categories (name_ar, name_en) VALUES ($1,$2) RETURNING *`, [nameAr, nameEn]);
    res.status(201).json(c);
  });
  router.post('/ode-brand/products', async (req, res) => {
    const { categoryId, nameAr, nameEn, description, price, currencyId, imageUrl, stockQty } = req.body;
    const { rows: [p] } = await db.query(
      `INSERT INTO ode_brand_products (category_id, name_ar, name_en, description, price, currency_id, image_url, stock_qty)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [categoryId ?? null, nameAr, nameEn, description ?? null, price, currencyId, imageUrl ?? null, stockQty ?? 0]
    );
    res.status(201).json(p);
  });
  router.patch('/ode-brand/products/:id', async (req, res) => {
    const { price, stockQty, isActive } = req.body;
    const { rows: [p] } = await db.query(
      `UPDATE ode_brand_products SET price=COALESCE($1,price), stock_qty=COALESCE($2,stock_qty), is_active=COALESCE($3,is_active)
       WHERE id=$4 RETURNING *`,
      [price, stockQty, isActive, req.params.id]
    );
    res.json(p);
  });

  // -------- Home services (item 4) --------
  router.get('/home-services', async (_req, res) => res.json((await db.query(`SELECT * FROM home_services ORDER BY name_ar`)).rows));
  router.post('/home-services', async (req, res) => {
    const { countryId, nameAr, nameEn, basePrice, currencyId, iconUrl } = req.body;
    const { rows: [s] } = await db.query(
      `INSERT INTO home_services (country_id, name_ar, name_en, base_price, currency_id, icon_url) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [countryId, nameAr, nameEn, basePrice ?? 0, currencyId, iconUrl ?? null]
    );
    res.status(201).json(s);
  });

  return router;
}
