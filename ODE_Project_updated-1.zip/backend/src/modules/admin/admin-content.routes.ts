import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';
import { writeAuditLog } from './audit-log.service';
import { NotificationsService } from '../notifications/notifications.service';

export function adminContentRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'));
  const notifications = new NotificationsService(db);

  // -------- Banners (item 16's ad slots + item 26 marketing) --------
  router.get('/banners', requirePermission('marketing.write'), async (_req, res) =>
    res.json((await db.query(`SELECT * FROM banners ORDER BY sort_order`)).rows));

  router.post('/banners', requirePermission('marketing.write'), async (req, res) => {
    const { titleAr, titleEn, imageUrl, targetType, targetId, countryId, placement } = req.body;
    const { rows: [b] } = await db.query(
      `INSERT INTO banners (title_ar, title_en, image_url, target_type, target_id, country_id, placement)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [titleAr, titleEn ?? null, imageUrl, targetType ?? null, targetId ?? null, countryId ?? null, placement ?? 'home_top']
    );
    res.status(201).json(b);
  });

  router.delete('/banners/:id', requirePermission('marketing.write'), async (req, res) => {
    await db.query(`UPDATE banners SET is_active = false WHERE id = $1`, [req.params.id]);
    res.json({ message: 'تم الحذف' });
  });

  // -------- Promotions / coupons (item 8) --------
  router.get('/promotions', requirePermission('marketing.write'), async (_req, res) =>
    res.json((await db.query(`SELECT * FROM promotions ORDER BY starts_at DESC NULLS LAST`)).rows));

  router.post('/promotions', requirePermission('marketing.write'), async (req, res) => {
    const { code, partnerId, discountType, discountValue, countryId, startsAt, endsAt, maxRedemptions } = req.body;
    const { rows: [p] } = await db.query(
      `INSERT INTO promotions (code, partner_id, discount_type, discount_value, country_id, starts_at, ends_at, max_redemptions)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [code, partnerId ?? null, discountType, discountValue, countryId ?? null, startsAt ?? null, endsAt ?? null, maxRedemptions ?? null]
    );
    res.status(201).json(p);
  });

  // -------- Points rewards (item 18) --------
  router.get('/point-rewards', requirePermission('marketing.write'), async (_req, res) =>
    res.json((await db.query(`SELECT * FROM point_rewards ORDER BY points_cost`)).rows));

  router.post('/point-rewards', requirePermission('marketing.write'), async (req, res) => {
    const { nameAr, pointsCost, stockQty, imageUrl } = req.body;
    const { rows: [r] } = await db.query(
      `INSERT INTO point_rewards (name_ar, points_cost, stock_qty, image_url) VALUES ($1,$2,$3,$4) RETURNING *`,
      [nameAr, pointsCost, stockQty ?? 0, imageUrl ?? null]
    );
    res.status(201).json(r);
  });

  router.put('/point-rules', requirePermission('finance.review'), async (req, res) => {
    const { pointsPerCurrency } = req.body;
    await db.query(`UPDATE point_rules SET points_per_currency = $1 WHERE id = 1`, [pointsPerCurrency]);
    res.json({ message: 'تم التحديث' });
  });

  // -------- Invite settings (item 19) --------
  router.get('/invite-settings', requirePermission('marketing.write'), async (_req, res) =>
    res.json((await db.query(`SELECT * FROM invite_settings WHERE id = 1`)).rows[0]));

  router.put('/invite-settings', requirePermission('marketing.write'), async (req, res) => {
    const { completionWindowDays, inviterRewardPoints, inviteeRewardPoints } = req.body;
    const { rows: [s] } = await db.query(
      `UPDATE invite_settings SET
        completion_window_days = COALESCE($1, completion_window_days),
        inviter_reward_points = COALESCE($2, inviter_reward_points),
        invitee_reward_points = COALESCE($3, invitee_reward_points)
       WHERE id = 1 RETURNING *`,
      [completionWindowDays, inviterRewardPoints, inviteeRewardPoints]
    );
    res.json(s);
  });

  // -------- Subscription plans: ODE Plus / Pro (item 17) --------
  router.get('/subscription-plans', requirePermission('marketing.write'), async (_req, res) =>
    res.json((await db.query(`SELECT * FROM subscription_plans ORDER BY price`)).rows));

  router.post('/subscription-plans', requirePermission('marketing.write'), async (req, res) => {
    const { code, nameAr, price, currencyId, durationDays, benefits } = req.body;
    const { rows: [p] } = await db.query(
      `INSERT INTO subscription_plans (code, name_ar, price, currency_id, duration_days, benefits)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [code, nameAr, price, currencyId, durationDays ?? 30, JSON.stringify(benefits ?? [])]
    );
    res.status(201).json(p);
  });

  router.patch('/subscription-plans/:id', requirePermission('marketing.write'), async (req, res) => {
    const { price, benefits, isActive } = req.body;
    const { rows: [p] } = await db.query(
      `UPDATE subscription_plans SET price=COALESCE($1,price), benefits=COALESCE($2,benefits), is_active=COALESCE($3,is_active)
       WHERE id=$4 RETURNING *`,
      [price, benefits ? JSON.stringify(benefits) : null, isActive, req.params.id]
    );
    res.json(p);
  });

  // -------- Broadcast notifications (item 15) --------
  const broadcastSchema = z.object({
    audience: z.enum(['all_customers', 'all_drivers', 'all_partners']),
    titleAr: z.string().min(2), bodyAr: z.string().optional(),
  });

  router.post('/broadcast', requirePermission('marketing.write'), async (req, res) => {
    const parsed = broadcastSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const roleMap = { all_customers: 'customer', all_drivers: 'driver', all_partners: 'partner_owner' } as const;
    const { rows: recipients } = await db.query(`SELECT id FROM users WHERE role = $1 AND is_blocked = false`, [roleMap[parsed.data.audience]]);

    // متسلسل عمدًا وليس Promise.all — قاعدة بيانات واحدة، وعدد كبير من
    // المستخدمين يعني ضغط أقل دفعة واحدة أفضل من طلب واحد ضخم متزامن.
    for (const user of recipients) {
      await notifications.send(user.id, { type: 'promotion', titleAr: parsed.data.titleAr, bodyAr: parsed.data.bodyAr });
    }

    const { rows: [broadcast] } = await db.query(
      `INSERT INTO broadcast_notifications (sent_by, audience, title_ar, body_ar, recipient_count)
       VALUES ($1,$2,$3,$4,$5) RETURNING id`,
      [req.auth!.adminId, parsed.data.audience, parsed.data.titleAr, parsed.data.bodyAr ?? null, recipients.length]
    );
    await writeAuditLog(db, req.auth!.adminId!, 'send_broadcast_notification', 'broadcast', broadcast.id, { audience: parsed.data.audience, recipientCount: recipients.length });
    res.status(201).json({ message: `تم الإرسال لـ${recipients.length} مستخدم` });
  });

  return router;
}
