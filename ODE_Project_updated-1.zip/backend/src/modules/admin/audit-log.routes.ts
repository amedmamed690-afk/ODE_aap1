import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole, requireSuperAdmin } from '../../common/auth.middleware';

export function auditLogRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('admin'), requireSuperAdmin);

  router.get('/', async (req, res) => {
    const { rows } = await db.query(
      `SELECT al.id, al.action, al.target_type, al.target_id, al.metadata, al.created_at, u.email
       FROM audit_logs al LEFT JOIN admin_users a ON a.id = al.admin_user_id
       LEFT JOIN users u ON u.id = a.user_id
       ORDER BY al.created_at DESC LIMIT 200`
    );
    res.json(rows);
  });

  return router;
}
