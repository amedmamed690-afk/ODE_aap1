import { Pool } from 'pg';

/** Append-only by convention: no route anywhere calls UPDATE/DELETE on
 *  this table. Every sensitive admin action (item 22) calls this. */
export async function writeAuditLog(
  db: Pool, adminUserId: string, action: string,
  targetType?: string, targetId?: string, metadata: object = {}
) {
  await db.query(
    `INSERT INTO audit_logs (admin_user_id, action, target_type, target_id, metadata)
     VALUES ($1, $2, $3, $4, $5)`,
    [adminUserId, action, targetType ?? null, targetId ?? null, JSON.stringify(metadata)]
  );
}
