import { Router } from 'express';
import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { authenticate, requireRole } from '../../common/auth.middleware';
import { NegotiationService } from './negotiation.service';

export function negotiationRouter(db: Pool, io: SocketServer) {
  const router = Router();
  const service = new NegotiationService(db, io);
  router.use(authenticate(db));

  router.post('/:rideId/offers', requireRole('customer'), async (req, res) => {
    const { offeredPrice, categoryId } = req.body;
    try {
      const offer = await service.proposeInitialOffer(req.params.rideId, offeredPrice, categoryId);
      res.status(201).json(offer);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  router.post('/offers/:offerId/accept', requireRole('driver'), async (req, res) => {
    try {
      await service.acceptOffer(req.params.offerId, req.auth!.driverId!);
      res.status(204).send();
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  router.post('/offers/:offerId/counter', requireRole('driver'), async (req, res) => {
    const { counterPrice } = req.body;
    try {
      const counter = await service.counterOffer(req.params.offerId, req.auth!.driverId!, counterPrice);
      res.json(counter);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  router.get('/:rideId/offers', requireRole('customer'), async (req, res) => {
    const offers = await service.listOffersForRide(req.params.rideId);
    res.json(offers);
  });

  router.post('/:rideId/offers/:offerId/select', requireRole('customer'), async (req, res) => {
    try {
      await service.selectOffer(req.params.rideId, req.params.offerId);
      res.status(204).send();
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  return router;
}
