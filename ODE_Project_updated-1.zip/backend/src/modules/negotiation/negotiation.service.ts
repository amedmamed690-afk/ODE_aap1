import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';

/**
 * نظام "أودي ماكس" (بند 3) — التفاوض على السعر:
 *
 * 1) الراكب يطلب رحلة بـ pricingMode='negotiated' — نحسب سعر عادل
 *    (نفس معادلة estimateFare العادية) ونعرضه كنقطة بداية.
 * 2) الراكب يقدر يرفع/يخفض السعر المقترح -> proposeInitialOffer().
 * 3) العرض يُبث لكل السائقين القريبين اللي بيخدموا نفس فئة المركبة
 *    (مش سائق واحد بس، عكس الرحلة العادية) — كل واحد فيهم يقدر:
 *    - يقبل بالسعر المعروض -> acceptOffer()
 *    - يرفض
 *    - يقدّم عرض مضاد بسعر مختلف -> counterOffer()
 * 4) الراكب يشوف كل العروض الواردة (سعر + تقييم السائق + نوع السيارة)
 *    ويختار — بمجرد ما يختار، باقي العروض تتلغى تلقائياً والسائق
 *    المختار يتعيّن على الرحلة زي التدفق العادي.
 *
 * كل عرض له مهلة صلاحية قصيرة (expires_at) عشان ما يفضل الراكب معلّق.
 */
export class NegotiationService {
  constructor(private db: Pool, private io: SocketServer) {}

  async proposeInitialOffer(rideId: string, offeredPrice: number, categoryId: string) {
    const { rows: [ride] } = await this.db.query(`SELECT pickup_lat, pickup_lng FROM rides WHERE id = $1`, [rideId]);
    if (!ride) throw new Error('ride_not_found');

    const { rows: [offer] } = await this.db.query(
      `INSERT INTO ride_price_offers (ride_id, proposed_by, offered_price, status, expires_at)
       VALUES ($1, 'customer', $2, 'pending', now() + interval '90 seconds')
       RETURNING *`,
      [rideId, offeredPrice]
    );

    // نبث العرض لكل السائقين المتاحين القريبين واللي يخدموا نفس فئة
    // المركبة — مش سائق واحد فقط، عكس التوصيل العادي (نموذج مزاد مصغّر).
    const { rows: nearbyDrivers } = await this.db.query(
      `SELECT d.id FROM drivers d
       JOIN driver_ride_categories drc ON drc.driver_id = d.id
       WHERE drc.ride_category_id = $1 AND d.status = 'available' AND d.approval_status = 'active' AND d.capability IN ('ride','both')
       ORDER BY ((d.current_lat - $2)^2 + (d.current_lng - $3)^2) ASC
       LIMIT 15`,
      [categoryId, ride.pickup_lat, ride.pickup_lng]
    );

    for (const driver of nearbyDrivers) {
      this.io.to(`driver:${driver.id}`).emit('ride_offer:new', { rideId, offerId: offer.id, offeredPrice });
    }

    return offer;
  }

  /** سائق يقبل السعر المعروض مباشرة */
  async acceptOffer(offerId: string, driverId: string) {
    const { rows: [offer] } = await this.db.query(`SELECT * FROM ride_price_offers WHERE id = $1`, [offerId]);
    if (!offer || offer.status !== 'pending') throw new Error('offer_no_longer_available');
    if (new Date(offer.expires_at) < new Date()) throw new Error('offer_expired');

    // القبول لا يُنهي الرحلة فوراً — لازم الراكب يختار من قائمة كل
    // العروض المقبولة/المضادة (بند: "تظهر للراكب قائمة العروض ليختار
    // الأنسب")، فقط نسجّل قبول هذا السائق تحديداً كخيار متاح.
    await this.db.query(
      `INSERT INTO ride_price_offers (ride_id, proposed_by, driver_id, offered_price, status, expires_at)
       VALUES ($1, 'driver', $2, $3, 'accepted', now() + interval '60 seconds')`,
      [offer.ride_id, driverId, offer.offered_price]
    );

    const { rows: [ride] } = await this.db.query(`SELECT customer_id FROM rides WHERE id = $1`, [offer.ride_id]);
    this.io.to(`user:${ride.customer_id}`).emit('ride_offer:driver_responded', { rideId: offer.ride_id });
  }

  /** سائق يقدّم عرض مضاد بسعر مختلف */
  async counterOffer(offerId: string, driverId: string, counterPrice: number) {
    const { rows: [offer] } = await this.db.query(`SELECT * FROM ride_price_offers WHERE id = $1`, [offerId]);
    if (!offer) throw new Error('offer_not_found');

    const { rows: [counter] } = await this.db.query(
      `INSERT INTO ride_price_offers (ride_id, proposed_by, driver_id, offered_price, status, expires_at)
       VALUES ($1, 'driver', $2, $3, 'countered', now() + interval '60 seconds')
       RETURNING *`,
      [offer.ride_id, driverId, counterPrice]
    );

    const { rows: [ride] } = await this.db.query(`SELECT customer_id FROM rides WHERE id = $1`, [offer.ride_id]);
    this.io.to(`user:${ride.customer_id}`).emit('ride_offer:driver_responded', { rideId: offer.ride_id });
    return counter;
  }

  /** الراكب يشوف كل العروض الواردة (المقبولة + المضادة) مع بيانات السائق */
  async listOffersForRide(rideId: string) {
    const { rows } = await this.db.query(
      `SELECT o.id, o.offered_price, o.status, o.driver_id,
              d.rating_avg, d.vehicle_type, u.full_name AS driver_name
       FROM ride_price_offers o
       LEFT JOIN drivers d ON d.id = o.driver_id
       LEFT JOIN users u ON u.id = d.user_id
       WHERE o.ride_id = $1 AND o.driver_id IS NOT NULL
         AND o.status IN ('accepted','countered') AND o.expires_at > now()
       ORDER BY o.offered_price ASC`,
      [rideId]
    );
    return rows;
  }

  /** الراكب يختار عرض معيّن — يعيّن السائق فوراً ويلغي باقي العروض */
  async selectOffer(rideId: string, offerId: string) {
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [offer] } = await client.query(`SELECT * FROM ride_price_offers WHERE id = $1 AND ride_id = $2`, [offerId, rideId]);
      if (!offer || !offer.driver_id) throw new Error('invalid_offer');

      await client.query(
        `UPDATE rides SET driver_id = $1, status = 'driver_assigned', estimated_fare = $2 WHERE id = $3`,
        [offer.driver_id, offer.offered_price, rideId]
      );
      await client.query(`UPDATE drivers SET status = 'busy' WHERE id = $1`, [offer.driver_id]);
      // كل العروض التانية على نفس الرحلة تتلغى — الراكب اختار، خلاص
      await client.query(`UPDATE ride_price_offers SET status = 'rejected' WHERE ride_id = $1 AND id != $2`, [rideId, offerId]);

      await client.query('COMMIT');
      this.io.to(`driver:${offer.driver_id}`).emit('ride_offer:selected', { rideId });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }
}
