import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * "المشاريع المنزلية" / home businesses booking (item 4 domain). Table
 * shapes and validation here match home_services_controller.dart's
 * createBooking exactly (it already enforces full_name/primary_phone/
 * alt_phone client-side "same as server" — this is that server side).
 */
export function homeServicesRouter(db: Pool) {
  const router = Router();

  router.get('/', async (req, res) => {
    const countryId = Number(req.query.countryId);
    const { rows } = await db.query(
      `SELECT hs.id, hs.name_ar, hs.base_price, c.code AS currency_code, hs.icon_url
       FROM home_services hs JOIN currencies c ON c.id = hs.currency_id
       WHERE hs.country_id = $1 AND hs.is_active = true`,
      [countryId]
    );
    res.json(rows);
  });

  router.get('/:serviceId/providers', async (req, res) => {
    const date = req.query.date as string;
    // اليوم المطلوب لازم يكون بمدى دوام مزود الخدمة، ولا يوجد له حجز
    // آخر بنفس التاريخ (فحص تعارض بسيط — يمنع الحجز المزدوج).
    const { rows } = await db.query(
      `SELECT p.id, p.bio, p.rating_avg, p.custom_price, p.start_time, p.end_time
       FROM home_service_providers p
       WHERE p.service_id = $1 AND p.is_active = true
       AND p.id NOT IN (
         SELECT provider_id FROM home_service_bookings
         WHERE provider_id IS NOT NULL AND status IN ('pending','confirmed')
         AND scheduled_at::date = $2::date
       )`,
      [req.params.serviceId, date]
    );
    res.json(rows);
  });

  const bookingSchema = z.object({
    serviceId: z.string().uuid(),
    providerId: z.string().uuid().optional().nullable(),
    fullName: z.string().min(2),
    primaryPhone: z.string().min(8),
    altPhone: z.string().min(8),
    addressId: z.string().uuid(),
    scheduledAt: z.string(),
  });

  router.post('/bookings', authenticate(db), async (req, res) => {
    const parsed = bookingSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    const { rows: [booking] } = await db.query(
      `INSERT INTO home_service_bookings
        (service_id, provider_id, customer_id, full_name, primary_phone, alt_phone, address_id, scheduled_at, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'pending') RETURNING id`,
      [d.serviceId, d.providerId ?? null, req.auth!.userId, d.fullName, d.primaryPhone, d.altPhone, d.addressId, d.scheduledAt]
    );
    res.status(201).json({ id: booking.id, message: 'تم إرسال طلب الحجز' });
  });

  return router;
}
