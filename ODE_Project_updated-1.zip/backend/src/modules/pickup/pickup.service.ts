import { Pool } from 'pg';
import { randomBytes } from 'crypto';
import { Server as SocketServer } from 'socket.io';

/**
 * نظام رمز الاستلام (Pickup QR) — يمنع الالتباس في مين استلم أي طلب:
 *
 * 1) لحظة ما الطلب يصير 'ready_for_pickup' ويُعيَّن سائق (نفس اللحظة
 *    بـ order-flow.service.ts)، نولّد رمز سري عشوائي (32 بايت، غير قابل
 *    للتخمين) ونربطه بالطلب + السائق المعيَّن تحديداً.
 * 2) الشريك يطبع الوصل، والوصل فيه صورة QR تشفّر (orderId + secretCode).
 *    الرمز السري نفسه لا يظهر كنص أبداً على الوصل ولا بأي API عام —
 *    فقط داخل بيانات QR المشفّرة.
 * 3) لما السائق يمسح QR بتطبيقه، نتحقق: (أ) الرمز صحيح ومطابق للطلب،
 *    (ب) السائق الماسح هو نفسه السائق المعيَّن على الطلب (يمنع سائق
 *    غلط يمسح وصل مو بتاعه)، (ج) لسه ما انمسح قبل كذا.
 * 4) لو التحقق نجح: الطلب ينتقل لـ 'picked_up' تلقائياً، وتُحسب عمولة
 *    الشركة والسائق فوراً — وده اللي بيربط الاستلام بحساب السائق لاحقاً.
 */
export class PickupVerificationService {
  constructor(private db: Pool, private io: SocketServer) {}

  async generateCodeForOrder(orderId: string, driverId: string) {
    const secretCode = randomBytes(24).toString('hex'); // 48 حرف، عشوائي تماماً

    const { rows: [code] } = await this.db.query(
      `INSERT INTO order_pickup_codes (order_id, secret_code, expected_driver_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (order_id) DO UPDATE SET secret_code = $2, expected_driver_id = $3, is_scanned = false
       RETURNING *`,
      [orderId, secretCode, driverId]
    );
    return code;
  }

  /** يبني نص QR — يُستهلك بواجهة الطباعة عند الشريك لتوليد صورة QR منه */
  buildQrPayload(orderId: string, secretCode: string) {
    return JSON.stringify({ orderId, code: secretCode });
  }

  async verifyScan(orderId: string, scannedCode: string, scanningDriverId: string) {
    const { rows: [pickup] } = await this.db.query(
      `SELECT * FROM order_pickup_codes WHERE order_id = $1`, [orderId]
    );

    const logAttempt = async (success: boolean, reason?: string) => {
      await this.db.query(
        `INSERT INTO order_pickup_scan_attempts (order_id, driver_id, was_successful, failure_reason)
         VALUES ($1,$2,$3,$4)`,
        [orderId, scanningDriverId, success, reason ?? null]
      );
    };

    if (!pickup) { await logAttempt(false, 'invalid_code'); throw new Error('pickup_code_not_found'); }
    if (pickup.is_scanned) { await logAttempt(false, 'already_scanned'); throw new Error('order_already_picked_up'); }
    if (pickup.secret_code !== scannedCode) { await logAttempt(false, 'invalid_code'); throw new Error('invalid_qr_code'); }
    if (pickup.expected_driver_id !== scanningDriverId) {
      // هذا هو المنطق الأهم: سائق تاني (مو المعيَّن) حاول يمسح — يُرفض
      // ويُسجَّل، عشان الشريك يقدر يشوف لو صار محاولة اختلاس/التباس.
      await logAttempt(false, 'wrong_driver');
      throw new Error('this_order_is_assigned_to_a_different_driver');
    }

    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `UPDATE order_pickup_codes SET is_scanned = true, scanned_by_driver_id = $1, scanned_at = now() WHERE order_id = $2`,
        [scanningDriverId, orderId]
      );
      await client.query(`UPDATE orders SET status = 'picked_up', updated_at = now() WHERE id = $1`, [orderId]);
      await client.query(
        `INSERT INTO order_status_history (order_id, status, changed_by_user_id, note)
         VALUES ($1, 'picked_up', $2, 'confirmed via QR pickup scan')`,
        [orderId, scanningDriverId]
      );
      await logAttempt(true);
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }

    const { rows: [order] } = await this.db.query(`SELECT customer_id, partner_id FROM orders WHERE id = $1`, [orderId]);
    this.io.to(`user:${order.customer_id}`).emit('order:status', { orderId, status: 'picked_up' });
    this.io.to(`partner:${order.partner_id}`).emit('order:pickup_confirmed', { orderId, driverId: scanningDriverId });

    return { orderId, status: 'picked_up', scannedBy: scanningDriverId };
  }
}
