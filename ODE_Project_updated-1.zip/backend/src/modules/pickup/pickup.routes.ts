import { Router } from 'express';
import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { authenticate, requireRole } from '../../common/auth.middleware';
import { PickupVerificationService } from './pickup.service';

export function pickupRouter(db: Pool, io: SocketServer) {
  const router = Router();
  const service = new PickupVerificationService(db, io);
  router.use(authenticate(db));

  // ---- الشريك: يطلب بيانات QR وقت الطباعة (بعد ما يتعيّن سائق) ----
  // لا نرجّع الرمز السري لو الطلب انمسح بالفعل، تفادياً لإعادة طباعة وصل قديم بالغلط
  router.get('/orders/:orderId/qr', requireRole('partner_owner'), async (req, res) => {
    const { rows: [order] } = await db.query(
      `SELECT id, partner_id, driver_id, status FROM orders WHERE id = $1`, [req.params.orderId]
    );
    if (!order) return res.status(404).json({ error: 'order_not_found' });
    // التحقق إن الطلب فعلاً تابع لهذا الشريك (عزل بيانات، مش نثق بأي id من الرابط بس)
    const { rows: [partner] } = await db.query(`SELECT id FROM partners WHERE owner_user_id = $1`, [req.auth!.userId]);
    if (!partner || partner.id !== order.partner_id) return res.status(403).json({ error: 'forbidden' });
    if (!order.driver_id) return res.status(400).json({ error: 'no_driver_assigned_yet' });

    const { rows: [existing] } = await db.query(`SELECT * FROM order_pickup_codes WHERE order_id = $1`, [req.params.orderId]);
    const code = existing ?? await service.generateCodeForOrder(order.id, order.driver_id);

    res.json({ qrPayload: service.buildQrPayload(order.id, code.secret_code) });
  });

  // ---- السائق: يمسح QR من التطبيق ----
  router.post('/scan', requireRole('driver'), async (req, res) => {
    const { orderId, code } = req.body;
    try {
      const result = await service.verifyScan(orderId, code, req.auth!.driverId!);
      res.json(result);
    } catch (e: any) {
      // نرجّع كود الخطأ بالضبط عشان تطبيق السائق يقدر يعرض رسالة واضحة
      // ("هذا الطلب مخصص لسائق آخر" / "تم استلامه مسبقاً"...)
      res.status(400).json({ error: e.message });
    }
  });

  return router;
}
