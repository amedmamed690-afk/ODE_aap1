import { Pool } from 'pg';

/**
 * Item 15: every notification is recorded in-app regardless of whether the
 * push itself succeeds — a missing/invalid FCM credential must never mean
 * the user silently gets nothing (that would violate item 32's "no silent
 * failure" rule). Push is best-effort on top of that guaranteed record.
 *
 * إصلاح (Audit — بند 8): كان الكود يستخدم FCM Legacy HTTP API
 * (`fcm.googleapis.com/fcm/send` مع `key=FCM_SERVER_KEY`) — هذه الواجهة
 * أوقفتها Google بالكامل بيونيو 2024، فأي استدعاء لها الآن يفشل 404/410
 * دائمًا بغض النظر عن صحة المفتاح. استُبدلت بـFirebase Admin SDK (HTTP v1
 * API الحالية)، التي تتطلب Service Account JSON بدل مفتاح نصي بسيط — وهي
 * الطريقة الموصى بها رسميًا من Google/Firebase حاليًا (تُدير تجديد
 * OAuth token تلقائيًا، بدل تنفيذ JWT signing يدويًا هنا).
 */

// Lazy singleton — لا نُهيّئ firebase-admin إطلاقًا لو الـcredential غير
// مضبوط (بيئة تطوير بدون Firebase)، بنفس فلسفة "dev mode: لا محاولة إرسال"
// الأصلية.
let fcmApp: import('firebase-admin').app.App | null | undefined;

function getFcmApp() {
  if (fcmApp !== undefined) return fcmApp;
  const encoded = process.env.FIREBASE_SERVICE_ACCOUNT_JSON_BASE64;
  if (!encoded) { fcmApp = null; return fcmApp; }
  try {
    const admin = require('firebase-admin');
    const serviceAccount = JSON.parse(Buffer.from(encoded, 'base64').toString('utf-8'));
    fcmApp = admin.apps.length
      ? admin.app()
      : admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
  } catch (e) {
    console.error('Failed to initialize Firebase Admin SDK — check FIREBASE_SERVICE_ACCOUNT_JSON_BASE64:', e);
    fcmApp = null;
  }
  return fcmApp;
}

export class NotificationsService {
  constructor(private db: Pool) {}

  async send(userId: string, params: {
    type: 'order' | 'driver' | 'partner' | 'payment' | 'promotion' | 'system';
    titleAr: string; bodyAr?: string; referenceType?: string; referenceId?: string;
  }) {
    await this.db.query(
      `INSERT INTO notifications (user_id, type, title_ar, body_ar, reference_type, reference_id)
       VALUES ($1,$2,$3,$4,$5,$6)`,
      [userId, params.type, params.titleAr, params.bodyAr ?? null, params.referenceType ?? null, params.referenceId ?? null]
    );

    const app = getFcmApp();
    if (!app) return; // dev mode / Firebase not configured: in-app row only, no push attempted

    const { rows: [user] } = await this.db.query(`SELECT fcm_token FROM users WHERE id = $1`, [userId]);
    if (!user?.fcm_token) return;

    try {
      const admin = require('firebase-admin');
      await admin.messaging(app).send({
        token: user.fcm_token,
        notification: { title: params.titleAr, body: params.bodyAr ?? '' },
      });
    } catch (e: any) {
      // توكن منتهي/محذوف من الجهاز — لا نعتبره خطأ خطير، ننظّفه فقط حتى لا
      // نعيد المحاولة عليه كل مرة (foreground/background handling الحقيقي
      // بجانب العميل يُحدّث fcm_token من جديد أول ما يُشغَّل التطبيق).
      if (e?.code === 'messaging/registration-token-not-registered') {
        await this.db.query(`UPDATE users SET fcm_token = NULL WHERE id = $1`, [userId]);
      } else {
        console.error('FCM push failed (in-app notification was still saved):', e?.message ?? e);
      }
    }
  }
}
