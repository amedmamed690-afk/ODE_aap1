import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

export function notificationsRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/', async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, type, title_ar, body_ar, reference_type, reference_id, is_read, created_at
       FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [req.auth!.userId]
    );
    res.json(rows);
  });

  router.patch('/:id/read', async (req, res) => {
    await db.query(`UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2`, [req.params.id, req.auth!.userId]);
    res.json({ message: 'تم' });
  });

  router.patch('/read-all', async (req, res) => {
    await db.query(`UPDATE notifications SET is_read = true WHERE user_id = $1 AND is_read = false`, [req.auth!.userId]);
    res.json({ message: 'تم' });
  });

  return router;
}
