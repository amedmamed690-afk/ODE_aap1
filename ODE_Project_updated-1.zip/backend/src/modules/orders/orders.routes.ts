import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { authenticate, requireRole } from '../../common/auth.middleware';
import { OrderFlowService } from '../order-flow/order-flow.service';

export function ordersRouter(db: Pool, io: SocketServer) {
  const router = Router();
  const flow = new OrderFlowService(db, io);
  router.use(authenticate(db));

  // ---- Customer: place a new order ----
  const placeOrderSchema = z.object({
    orderType: z.enum(['food', 'store', 'pharmacy', 'parcel']),
    partnerId: z.string().uuid(),
    branchId: z.string().uuid(),
    addressId: z.string().uuid(),
    currencyId: z.number(),
    items: z.array(z.object({ productId: z.string().uuid(), qty: z.number().min(1) })).min(1),
    idempotencyKey: z.string().min(8).optional(),
    // طلب صريح (نظام الدفع Cash + Payment Gateway): إجباري الآن — لا قيمة
    // افتراضية صامتة، العميل يختار فعليًا.
    paymentMethod: z.enum(['wallet', 'cash', 'card']),
  });

  router.post('/', requireRole('customer'), async (req, res) => {
    const parsed = placeOrderSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    try {
      const order = await flow.placeOrder(req.auth!.userId, parsed.data);
      res.status(201).json(order);
    } catch (e: any) {
      // طلب صريح: رسائل خطأ واضحة ومحددة للعميل حسب السبب الفعلي — بدل
      // 400 عام لكل شيء — تحديدًا لحالات تعطيل الخدمة/وسيلة الدفع، حتى
      // تعرض الواجهة رسالة دقيقة بدل "حدث خطأ" عامة.
      const policyErrors = ['service_unavailable', 'wallet_payment_disabled', 'cash_payment_disabled', 'payment_gateway_not_configured'];
      const status = policyErrors.includes(e.message) ? 403 : 400;
      res.status(status).json({ error: e.message });
    }
  });

  // ---- Customer: view own orders only ----
  router.get('/mine', requireRole('customer'), async (req, res) => {
    const { rows } = await db.query(
      `SELECT * FROM orders WHERE customer_id = $1 ORDER BY placed_at DESC`,
      [req.auth!.userId]
    );
    res.json(rows);
  });

  // ---- Partner: view only orders belonging to their own partner account ----
  router.get('/partner', requireRole('partner_owner'), async (req, res) => {
    const { rows } = await db.query(
      `SELECT * FROM orders WHERE partner_id = $1 ORDER BY placed_at DESC`,
      [req.auth!.partnerId]
    );
    res.json(rows);
  });

  // ---- Partner: accept / reject / mark preparing / mark ready ----
  router.patch('/:id/status', requireRole('partner_owner', 'driver'), async (req, res) => {
    const { status } = req.body as { status: string };
    try {
      // Ownership check happens inside transition() via order.partner_id / driver_id
      // matching req.auth — but we double-check here for partner-only statuses.
      const result = await flow.transition(req.params.id, status, req.auth!.userId);
      res.json(result);
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  // ---- Driver: view only jobs assigned to them ----
  router.get('/driver', requireRole('driver'), async (req, res) => {
    const { rows } = await db.query(
      `SELECT * FROM orders WHERE driver_id = $1 AND status NOT IN ('delivered','cancelled') ORDER BY placed_at DESC`,
      [req.auth!.driverId]
    );
    res.json(rows);
  });

  // ---- Driver: view a single assigned order's full detail (item 6:
  // "رؤية تفاصيل الطلب") ----
  router.get('/:id', requireRole('driver', 'customer', 'partner_owner'), async (req, res) => {
    const { rows: [order] } = await db.query(
      `SELECT o.*, p.owner_full_name AS partner_name, pb.address_line AS pickup_address, pb.lat AS pickup_lat, pb.lng AS pickup_lng
       FROM orders o LEFT JOIN partners p ON p.id = o.partner_id LEFT JOIN partner_branches pb ON pb.id = o.branch_id
       WHERE o.id = $1 AND (o.customer_id = $2 OR o.partner_id = $3 OR o.driver_id = $4)`,
      [req.params.id, req.auth!.userId, req.auth!.partnerId ?? null, req.auth!.driverId ?? null]
    );
    if (!order) return res.status(404).json({ error: 'order_not_found' });
    res.json(order);
  });

  // ---- Driver: decline an assigned job (item 6: "قبول/رفض الطلب") —
  // assignNearestDriver() only ever auto-assigns the single nearest
  // driver; without this endpoint a decline had nowhere to go and the
  // order would just sit stuck on that one driver forever.
  router.patch('/:id/decline', requireRole('driver'), async (req, res) => {
    try {
      await flow.declineAndReassign(req.params.id, req.auth!.driverId!, req.auth!.userId, req.body?.reason);
      res.json({ message: 'تم الرفض وإعادة التعيين' });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  // ---- Cancel (item 20): real rules enforced inside cancelOrder() —
  // grace period for customers, mandatory reason for partner/driver,
  // automatic wallet refund if the order was already paid.
  router.post('/:id/cancel', async (req, res) => {
    try {
      const result = await flow.cancelOrder(req.params.id, req.auth!.userId, req.auth!.role, req.body?.reason);
      res.json(result);
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  return router;
}
