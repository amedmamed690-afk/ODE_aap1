import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * Item 18: earn rate (`point_rules.points_per_currency`) and every reward
 * (`point_rewards`) are fully admin-controlled rows, never hard-coded here.
 * Earning itself is triggered from order-flow.service.ts when an order
 * reaches 'delivered' (see the hook there), not from this file.
 */
export function pointsRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/me', async (req, res) => {
    const { rows: [points] } = await db.query(
      `INSERT INTO customer_points (user_id, balance) VALUES ($1, 0)
       ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id
       RETURNING balance`,
      [req.auth!.userId]
    );
    res.json({ balance: points.balance });
  });

  router.get('/transactions', async (req, res) => {
    const { rows } = await db.query(
      `SELECT type, points, created_at AS "createdAt" FROM point_transactions
       WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [req.auth!.userId]
    );
    res.json(rows);
  });

  router.get('/rewards', async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, name_ar, points_cost, image_url FROM point_rewards
       WHERE is_active = true AND stock_qty > 0 ORDER BY points_cost`
    );
    res.json(rows);
  });

  router.post('/redeem/:rewardId', async (req, res) => {
    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [reward] } = await client.query(
        `SELECT points_cost, stock_qty FROM point_rewards WHERE id = $1 AND is_active = true FOR UPDATE`,
        [req.params.rewardId]
      );
      if (!reward) throw new Error('reward_not_found');
      if (reward.stock_qty <= 0) throw new Error('reward_out_of_stock');

      const { rows: [points] } = await client.query(
        `INSERT INTO customer_points (user_id, balance) VALUES ($1, 0)
         ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id
         RETURNING balance`,
        [req.auth!.userId]
      );
      if (points.balance < reward.points_cost) throw new Error('insufficient_points');

      const { rows: [updated] } = await client.query(
        `UPDATE customer_points SET balance = balance - $1 WHERE user_id = $2 RETURNING balance`,
        [reward.points_cost, req.auth!.userId]
      );
      await client.query(
        `INSERT INTO point_transactions (user_id, type, points, balance_after, reference_type, reference_id)
         VALUES ($1, 'redeem', $2, $3, 'reward', $4)`,
        [req.auth!.userId, -reward.points_cost, updated.balance, req.params.rewardId]
      );
      await client.query(`UPDATE point_rewards SET stock_qty = stock_qty - 1 WHERE id = $1`, [req.params.rewardId]);

      await client.query('COMMIT');
      res.json({ message: 'تم استبدال النقاط', newBalance: updated.balance });
    } catch (e: any) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  return router;
}
