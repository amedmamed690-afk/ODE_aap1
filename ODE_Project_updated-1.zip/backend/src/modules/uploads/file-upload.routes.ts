import { Router } from 'express';
import multer from 'multer';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import crypto from 'crypto';
import { authenticate } from '../../common/auth.middleware';
import { Pool } from 'pg';

/**
 * رفع الملفات الحقيقي — كانت أكبر فجوة متبقية: كل مكان بالكود (صور
 * منتجات، مستندات تسجيل، صور شورتس) كان يفترض وجود رابط جاهز، بدون
 * أي endpoint فعلي يستقبل الملف الخام ويحوّله لرابط.
 *
 * التصميم: العميل (Flutter/React) يرفع الملف هنا أولاً، يرجعله رابط
 * دائم، وبعدين يستخدم هذا الرابط بأي endpoint تاني (تسجيل منتج،
 * تسجيل شريك...) — بدل ما يبعث الملف الخام مع كل طلب.
 *
 * AUDIT FIXES (items 8, 33, 34):
 *  - item 8: مستندات الهوية الحساسة (جواز، رخصة قيادة، سجل تجاري) الآن
 *    تُرفع لـ bucket منفصل تمامًا عن bucket الصور العامة (S3_DOCUMENTS_BUCKET)،
 *    مش نفس الـbucket بـACL مختلف بس — لو تسرّب مفتاح وصول لصور المنتجات
 *    العامة، ما يكشف مستندات الهوية إطلاقًا لأنها بحساب/bucket مختلف كليًا.
 *    الـfallback لنفس bucket العام مسموح بالتطوير فقط (تحذير واضح بالـconsole)
 *    — بالإنتاج ممنوع تمامًا (انظر الحارس بالأسفل)، إضافة لكون server.ts
 *    أصلاً يرفض الإقلاع كليًا بدون S3_DOCUMENTS_BUCKET بالإنتاج (بند 17).
 *  - item 33/34: الفيديو (Shorts) كان مرفوض بالكامل — نوع MIME غير
 *    مسموح، وما كان فيه حد حجم منفصل عنه. أضفت أنواع فيديو محددة وحد
 *    حجم أكبر بكثير له فقط (الصور تفضل محدودة بـ8 ميجا زي ما كانت).
 */

const S3_BUCKET = process.env.S3_BUCKET || 'PLACEHOLDER_BUCKET_NAME';
if (process.env.NODE_ENV === 'production' && !process.env.S3_DOCUMENTS_BUCKET) {
  // حارس إضافي مباشرة بمكان الاستخدام — دفاع مضاعف بجانب
  // validateProductionSecrets() بـserver.ts، حتى لو استُدعي هذا الموديول
  // من أي مسار آخر مستقبلًا بدون المرور بذلك الفحص.
  throw new Error('S3_DOCUMENTS_BUCKET is required in production — refusing to fall back to the public bucket for sensitive documents.');
}
const S3_DOCUMENTS_BUCKET = process.env.S3_DOCUMENTS_BUCKET || S3_BUCKET;
if (!process.env.S3_DOCUMENTS_BUCKET) {
  console.warn('⚠️  S3_DOCUMENTS_BUCKET not set — sensitive documents (ID photos, licenses) are sharing the public bucket. This fallback only works because NODE_ENV !== production; set a separate bucket before deploying.');
}
const S3_REGION = process.env.S3_REGION || 'us-east-1';
const S3_PUBLIC_BASE_URL = process.env.S3_PUBLIC_BASE_URL || 'https://PLACEHOLDER_BUCKET_NAME.s3.amazonaws.com';

const s3 = new S3Client({
  region: S3_REGION,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID || 'PLACEHOLDER_ACCESS_KEY',
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || 'PLACEHOLDER_SECRET_KEY',
  },
});

const IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
const VIDEO_MIME_TYPES = ['video/mp4', 'video/quicktime', 'video/webm'];
const ALL_ALLOWED_MIME_TYPES = [...IMAGE_MIME_TYPES, ...VIDEO_MIME_TYPES];

const IMAGE_MAX_BYTES = 8 * 1024 * 1024;    // 8MB
const VIDEO_MAX_BYTES = 80 * 1024 * 1024;   // 80MB — Shorts are short (~60s) but still far bigger than any photo/PDF

// purposes that are allowed to be video and that get the sensitive bucket
const VIDEO_PURPOSES = new Set(['short_video']);
const DOCUMENT_PURPOSES = new Set(['driver_document', 'partner_document']);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: VIDEO_MAX_BYTES }, // multer's own cap must allow the larger case; per-purpose cap enforced below
  fileFilter: (req, file, cb) => {
    if (!ALL_ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return cb(new Error('unsupported_file_type'));
    }
    cb(null, true);
  },
});

export function fileUploadRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  // purpose يحدد المجلد المنطقي بالتخزين + أي bucket + أي حد حجم:
  // 'product_image' | 'partner_document' | 'driver_document' | 'short_video'
  router.post('/', upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'no_file_provided' });
    const purpose = (req.body.purpose || 'general').replace(/[^a-z_]/g, ''); // تنظيف بسيط يمنع Path Traversal بالمجلد

    const isVideo = VIDEO_MIME_TYPES.includes(req.file.mimetype);
    if (isVideo && !VIDEO_PURPOSES.has(purpose)) {
      return res.status(400).json({ error: 'video_not_allowed_for_this_purpose' });
    }
    if (!isVideo && req.file.size > IMAGE_MAX_BYTES) {
      return res.status(413).json({ error: 'file_too_large_max_8mb' });
    }
    if (isVideo && req.file.size > VIDEO_MAX_BYTES) {
      return res.status(413).json({ error: 'video_too_large_max_80mb' });
    }

    const isDocument = DOCUMENT_PURPOSES.has(purpose);
    const bucket = isDocument ? S3_DOCUMENTS_BUCKET : S3_BUCKET;

    const fileExtension = req.file.mimetype.split('/')[1];
    const randomName = crypto.randomBytes(16).toString('hex');
    const key = `${purpose}/${req.auth!.userId}/${randomName}.${fileExtension}`;

    try {
      await s3.send(new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        Body: req.file.buffer,
        ContentType: req.file.mimetype,
        // مستندات الهوية دايمًا private (bucket منفصل أصلًا + ACL خاص —
        // دفاع مزدوج)، وكل شيء آخر (صور منتجات، فيديوهات Shorts) عام
        // للقراءة لأنها أصلًا معروضة بالتطبيق.
        ACL: isDocument ? 'private' : 'public-read',
      }));

      // مستند حساس: ما نرجع رابط عام مباشر إطلاقًا — بس المفتاح، والعرض
      // يصير حصرًا عبر /document-view-url بتوكن مؤقت (الأدمن فقط).
      if (isDocument) {
        return res.status(201).json({ key, bucket });
      }
      const url = `${S3_PUBLIC_BASE_URL}/${key}`;
      res.status(201).json({ url, key });
    } catch (e: any) {
      res.status(500).json({ error: 'upload_failed', details: e.message });
    }
  });

  // مستندات خاصة (جواز، رخصة قيادة) مخزّنة بـ bucket منفصل + ACL خاص —
  // الأدمن بس يقدر يشوفها، عبر رابط مؤقت الصلاحية (Presigned URL) بدل ما
  // تكون متاحة للعامة زي صور المنتجات. صلاحية الرابط 10 دقائق بس.
  router.get('/document-view-url', async (req, res) => {
    if (req.auth!.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
    const { key } = req.query;
    if (!key) return res.status(400).json({ error: 'missing_key' });

    try {
      const url = await getSignedUrl(
        s3,
        new GetObjectCommand({ Bucket: S3_DOCUMENTS_BUCKET, Key: key as string }),
        { expiresIn: 600 }
      );
      res.json({ url });
    } catch (e: any) {
      res.status(500).json({ error: 'failed_to_generate_url' });
    }
  });

  // multer يرمي أخطاءه (حجم/نوع الملف) كـ exception قبل ما يوصل الـ
  // handler فوق — بدون هذا الـ middleware، الطلب كان يفضل معلّق أو
  // يرجع خطأ 500 عام بدل رسالة واضحة للمستخدم. لازم يكون آخر حاجة
  // بالراوتر عشان Express يتعرف عليه كـ error handler صح.
  router.use((err: any, req: any, res: any, next: any) => {
    if (err?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'file_too_large' });
    if (err?.message === 'unsupported_file_type') return res.status(415).json({ error: 'unsupported_file_type' });
    res.status(400).json({ error: 'upload_error' });
  });

  return router;
}
