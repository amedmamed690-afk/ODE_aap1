import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * Customer wallet (item 11): usable inside ODE only — never transferable
 * between users, never cashable out. home_controller.dart already calls
 * GET /wallet/me expecting {balance}.
 */
export function walletRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/me', async (req, res) => {
    // upsert-on-read: أول مرة يفتح فيها العميل محفظته بننشئ الصف تلقائيًا
    // برصيد صفر بدل الحاجة لخطوة تسجيل منفصلة.
    const { rows: [wallet] } = await db.query(
      `INSERT INTO customer_wallets (user_id, balance) VALUES ($1, 0)
       ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id
       RETURNING balance`,
      [req.auth!.userId]
    );
    res.json({ balance: Number(wallet.balance) });
  });

  router.get('/transactions', async (req, res) => {
    const { rows } = await db.query(
      `SELECT type, amount, created_at AS "createdAt" FROM customer_wallet_transactions
       WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [req.auth!.userId]
    );
    res.json(rows.map(r => ({ ...r, amount: Number(r.amount) })));
  });

  // item 12: نظام شحن الرصيد بالأكواد — استخدام واحد فقط، يفشل بوضوح
  // لو منتهي أو ملغى أو مستخدم من قبل.
  const redeemSchema = z.object({ code: z.string().min(4) });
  router.post('/redeem-code', async (req, res) => {
    const parsed = redeemSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [code] } = await client.query(
        `SELECT id, value, status, expires_at FROM topup_codes WHERE code = $1 FOR UPDATE`,
        [parsed.data.code]
      );
      if (!code) throw new Error('code_not_found');
      if (code.status !== 'active') throw new Error(`code_${code.status}`); // code_used / code_cancelled
      if (code.expires_at && new Date(code.expires_at) < new Date()) {
        await client.query(`UPDATE topup_codes SET status = 'expired' WHERE id = $1`, [code.id]);
        throw new Error('code_expired');
      }

      await client.query(
        `INSERT INTO customer_wallets (user_id, balance) VALUES ($1, 0) ON CONFLICT DO NOTHING`,
        [req.auth!.userId]
      );
      const { rows: [wallet] } = await client.query(
        `UPDATE customer_wallets SET balance = balance + $1 WHERE user_id = $2 RETURNING balance`,
        [code.value, req.auth!.userId]
      );
      await client.query(
        `INSERT INTO customer_wallet_transactions (user_id, type, amount, balance_after, reference_type, reference_id)
         VALUES ($1, 'topup_code', $2, $3, 'topup_code', $4)`,
        [req.auth!.userId, code.value, wallet.balance, code.id]
      );
      await client.query(
        `UPDATE topup_codes SET status = 'used', used_by = $1, used_at = now() WHERE id = $2`,
        [req.auth!.userId, code.id]
      );

      await client.query('COMMIT');
      res.json({ message: 'تم شحن رصيدك بنجاح', newBalance: Number(wallet.balance) });
    } catch (e: any) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  return router;
}
