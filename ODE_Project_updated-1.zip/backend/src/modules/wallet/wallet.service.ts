import { Pool, PoolClient } from 'pg';

/**
 * Item 11 (audit): wallet.routes.ts had top-up/redeem logic inline but no
 * reusable debit()/credit() — meaning order-flow.service.ts had nowhere
 * correct to call into for spending a customer's balance, which is
 * exactly why that debit never happened at all (item 1/12).
 *
 * Every method here accepts a `client` — NOT the pool — so callers can
 * run it inside their own transaction (e.g. order creation + wallet debit
 * must commit or roll back together, never one without the other).
 */
export class InsufficientBalanceError extends Error {
  constructor() { super('insufficient_balance'); }
}

export class WalletService {
  /** Locks the row (FOR UPDATE) so two concurrent debits on the same
   *  wallet can't both read a stale balance and both succeed. */
  async debit(
    client: PoolClient, userId: string, amount: number,
    referenceType: string, referenceId: string
  ): Promise<{ balanceAfter: number }> {
    await client.query(
      `INSERT INTO customer_wallets (user_id, balance) VALUES ($1, 0) ON CONFLICT DO NOTHING`,
      [userId]
    );
    const { rows: [wallet] } = await client.query(
      `SELECT balance FROM customer_wallets WHERE user_id = $1 FOR UPDATE`,
      [userId]
    );
    if (Number(wallet.balance) < amount) throw new InsufficientBalanceError();

    const { rows: [updated] } = await client.query(
      `UPDATE customer_wallets SET balance = balance - $1 WHERE user_id = $2 RETURNING balance`,
      [amount, userId]
    );
    await client.query(
      `INSERT INTO customer_wallet_transactions (user_id, type, amount, balance_after, reference_type, reference_id)
       VALUES ($1, 'order_payment', $2, $3, $4, $5)`,
      [userId, -amount, updated.balance, referenceType, referenceId]
    );
    return { balanceAfter: Number(updated.balance) };
  }

  async credit(
    client: PoolClient, userId: string, amount: number, type: string,
    referenceType: string, referenceId: string
  ): Promise<{ balanceAfter: number }> {
    await client.query(
      `INSERT INTO customer_wallets (user_id, balance) VALUES ($1, 0) ON CONFLICT DO NOTHING`,
      [userId]
    );
    const { rows: [updated] } = await client.query(
      `UPDATE customer_wallets SET balance = balance + $1 WHERE user_id = $2 RETURNING balance`,
      [amount, userId]
    );
    await client.query(
      `INSERT INTO customer_wallet_transactions (user_id, type, amount, balance_after, reference_type, reference_id)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, type, amount, updated.balance, referenceType, referenceId]
    );
    return { balanceAfter: Number(updated.balance) };
  }

  /** Read-only balance check outside a transaction — fine for display,
   *  never for a "can they afford it" gate (that must use debit() itself,
   *  since balance can change between check and charge). */
  async getBalance(db: Pool, userId: string): Promise<number> {
    const { rows: [wallet] } = await db.query(
      `SELECT balance FROM customer_wallets WHERE user_id = $1`, [userId]
    );
    return wallet ? Number(wallet.balance) : 0;
  }
}
