import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate, requireRole } from '../../common/auth.middleware';

/**
 * Public marketing surfaces the customer home screen reads on launch
 * (home_controller.dart / splash_controller.dart already assumed these
 * three exact paths). All public — no login needed before seeing ads.
 */
export function marketingRouter(db: Pool) {
  const router = Router();

  // pageKey maps onto the existing `banners.placement` column (e.g.
  // 'home' -> 'home_top') rather than adding a duplicate column.
  router.get('/ads', async (req, res) => {
    const pageKey = (req.query.pageKey as string) || 'home';
    const placement = pageKey === 'home' ? 'home_top' : pageKey;
    const countryId = req.query.countryId ? Number(req.query.countryId) : null;

    const { rows } = await db.query(
      `SELECT id, title_ar, image_url, target_type AS link_type, target_id AS link_value
       FROM banners
       WHERE placement = $1 AND is_active = true
       AND (country_id IS NULL OR country_id = $2)
       AND (starts_at IS NULL OR starts_at <= now())
       AND (ends_at IS NULL OR ends_at >= now())
       ORDER BY sort_order`,
      [placement, countryId]
    );
    res.json(rows);
  });

  router.get('/shorts', async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, video_url, thumbnail_url, caption_ar, view_count, like_count,
              sponsorship_id, sponsored_product_id, sponsored_partner_id
       FROM shorts WHERE is_published = true
       ORDER BY sponsorship_id NULLS LAST, created_at DESC LIMIT 30`
    );
    res.json(rows);
  });

  router.get('/splash', async (req, res) => {
    const countryId = req.query.countryId ? Number(req.query.countryId) : null;
    const { rows: [config] } = await db.query(
      `SELECT video_url, min_duration_ms FROM splash_config
       WHERE id = 1 AND (country_id IS NULL OR country_id = $1)`,
      [countryId]
    );
    res.json(config ?? { video_url: null, min_duration_ms: 1500 });
  });

  // إضافة (Audit — بند 1): الشاشات التالية بـcustomer_app/partner_app كانت
  // تستدعي هذه الثلاثة مسبقًا (home_controller.dart، shorts_controller.dart،
  // partner_upload_short_screen.dart) بدون أن تكون موجودة أصلاً بالـBackend.
  // نفس paths/request-response format المستخدمة فعليًا بالتطبيقات، بدون
  // أي تكرار لِـ GET /shorts الموجود أعلاه.

  // مشاهدة (View) — عامة بدون تسجيل دخول، تطابق registerView() بالعميل
  // (لا Authorization header تُرسل أصلاً بالطلب).
  router.post('/shorts/:shortId/view', async (req, res) => {
    const { rows: [updated] } = await db.query(
      `UPDATE shorts SET view_count = view_count + 1 WHERE id = $1 AND is_published = true
       RETURNING id, view_count`,
      [req.params.shortId]
    );
    if (!updated) return res.status(404).json({ error: 'short_not_found' });
    res.json(updated);
  });

  // إعجاب (Like) — يتطلب مصادقة (toggleLike() بالعميل ترسل Bearer token).
  // ملاحظة تصميم ضرورية: الجدول الأصلي `shorts` عنده `like_count` رقمي فقط
  // بدون أي جدول يربط كل إعجاب بمستخدم معيّن — لو نفّذنا "+1 دائمًا" بدون
  // هذا الربط، كان أي مستخدم يقدر يضغط الزر لا نهائيًا ويضخّم العداد
  // (وهذا فعليًا Bug لوظيفة "toggle" اللي يفترضها اسم الدالة بالعميل: لا
  // يوجد طريقة معرفة هل أعجب بها من قبل ليُلغي الإعجاب). أضفنا جدول ربط
  // بسيط `short_likes` (schema_additions.sql) بدل تكرار عمود أو منطق جديد.
  router.post('/shorts/:shortId/like', authenticate(db), async (req, res) => {
    const userId = req.auth!.userId;
    const shortId = req.params.shortId;
    const client = await db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [existingLike] } = await client.query(
        `SELECT 1 FROM short_likes WHERE user_id = $1 AND short_id = $2`, [userId, shortId]
      );
      let liked: boolean;
      let likeCountRow;
      if (existingLike) {
        await client.query(`DELETE FROM short_likes WHERE user_id = $1 AND short_id = $2`, [userId, shortId]);
        ({ rows: [likeCountRow] } = await client.query(
          `UPDATE shorts SET like_count = GREATEST(like_count - 1, 0) WHERE id = $1 RETURNING id, like_count`, [shortId]
        ));
        liked = false;
      } else {
        const { rows: [short] } = await client.query(`SELECT id FROM shorts WHERE id = $1 AND is_published = true`, [shortId]);
        if (!short) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'short_not_found' }); }
        await client.query(`INSERT INTO short_likes (user_id, short_id) VALUES ($1, $2)`, [userId, shortId]);
        ({ rows: [likeCountRow] } = await client.query(
          `UPDATE shorts SET like_count = like_count + 1 WHERE id = $1 RETURNING id, like_count`, [shortId]
        ));
        liked = true;
      }
      await client.query('COMMIT');
      res.json({ liked, likeCount: likeCountRow.like_count });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  });

  // نشر Short جديد — partner_owner فقط، مطابق لنمط /partners/me/products
  // (partnerId يُشتق من التوكن مو من الـbody، لمنع انتحال شريك آخر).
  const createShortSchema = z.object({
    videoUrl: z.string().url(),
    captionAr: z.string().max(500).optional(),
    thumbnailUrl: z.string().url().optional(),
  });
  router.post('/shorts', authenticate(db), requireRole('partner_owner'), async (req, res) => {
    const parsed = createShortSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { rows: [partner] } = await db.query(`SELECT id FROM partners WHERE owner_user_id = $1`, [req.auth!.userId]);
    if (!partner) return res.status(403).json({ error: 'no_partner_account' });

    const { rows: [short] } = await db.query(
      `INSERT INTO shorts (partner_id, video_url, thumbnail_url, caption_ar)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [partner.id, parsed.data.videoUrl, parsed.data.thumbnailUrl ?? null, parsed.data.captionAr ?? null]
    );
    res.status(201).json(short);
  });

  return router;
}
