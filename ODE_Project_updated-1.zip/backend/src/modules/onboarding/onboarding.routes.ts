import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import jwt from 'jsonwebtoken';
import { authenticate, requireRole } from '../../common/auth.middleware';

/**
 * تدفق التسجيل الكامل (بند 1-4):
 * 1) GET /partner-onboarding/options — يجيب القوائم اللي يختار منها المستخدم
 *    (تصنيفات النشاط، الأنواع الفرعية الإلكترونية) — كلها من لوحة الأدمن.
 * 2) POST /partner-onboarding/submit — يستقبل كل البيانات الإجبارية دفعة
 *    واحدة (الاسم الثلاثي، الرقم الوطني، الهاتفين، الموقع، التصنيف...)
 *    + روابط المستندات المرفوعة مسبقاً (رفع الملفات نفسها يمر بخدمة تخزين
 *    خارجية زي S3، والـ endpoint هنا يستقبل الروابط الناتجة فقط).
 * 3) الحالة تبقى 'pending' — الشريك ما يقدر يستخدم أي شيء لحد ما يوافق الأدمن.
 */
export function partnerOnboardingRouter(db: Pool) {
  const router = Router();

  router.get('/options', async (req, res) => {
    const [categories, digitalSubtypes] = await Promise.all([
      db.query(`SELECT * FROM partner_activity_categories WHERE is_active = true ORDER BY sort_order`),
      db.query(`SELECT * FROM partner_digital_subtypes WHERE is_active = true ORDER BY sort_order`),
    ]);
    res.json({ activityCategories: categories.rows, digitalSubtypes: digitalSubtypes.rows });
  });

  const submitSchema = z.object({
    businessType: z.enum(['restaurant', 'store']),
    accountType: z.enum(['physical', 'digital']),
    digitalSubtypeId: z.string().uuid().optional(), // إجباري فقط لو accountType = digital (نتحقق تحت)
    ownerFullName: z.string().min(6),               // الاسم الثلاثي
    nationalIdNumber: z.string().min(5),
    primaryPhone: z.string().min(8),                // نفس الرقم المربوط بالوطني
    secondaryPhone: z.string().min(8),
    storeName: z.string().min(2),
    gpsLat: z.number(),
    gpsLng: z.number(),
    activityCategoryId: z.string().uuid(),
    countryId: z.number(),
    passportImageUrl: z.string().min(3),              // مفتاح تخزين داخلي (bucket منفصل غير عام) — بند 8
    businessLicenseUrl: z.string().min(3).optional(),
  });

  router.post('/submit', authenticate(db), async (req, res) => {
    const parsed = submitSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    if (d.accountType === 'digital' && !d.digitalSubtypeId) {
      return res.status(400).json({ error: 'digital_subtype_required_for_digital_accounts' });
    }
    // الترخيص التجاري إجباري لحساب "أرض الواقع" فقط — الحساب الإلكتروني
    // (أسرة منتجة، نشاط رقمي بدون محل) معفى منه لأنه أصلاً مالوش محل مرخّص.
    if (d.accountType === 'physical' && !d.businessLicenseUrl) {
      return res.status(400).json({ error: 'business_license_required_for_physical_accounts' });
    }

    const client = await db.connect();
    try {
      await client.query('BEGIN');

      // منع تسجيل نفس المستخدم مرتين كشريك
      const { rows: [existing] } = await client.query(`SELECT id FROM partners WHERE owner_user_id = $1`, [req.auth!.userId]);
      if (existing) throw new Error('partner_account_already_exists');

      const { rows: [partner] } = await client.query(
        `INSERT INTO partners
          (owner_user_id, type, name_en, name_ar, country_id, status, account_type, digital_subtype_id,
           owner_full_name, national_id_number, primary_phone, secondary_phone, activity_category_id,
           gps_lat, gps_lng)
         VALUES ($1,$2,$3,$3,$4,'pending',$5,$6,$7,$8,$9,$10,$11,$12,$13)
         RETURNING *`,
        [req.auth!.userId, d.businessType, d.storeName, d.countryId, d.accountType, d.digitalSubtypeId ?? null,
         d.ownerFullName, d.nationalIdNumber, d.primaryPhone, d.secondaryPhone, d.activityCategoryId, d.gpsLat, d.gpsLng]
      );

      await client.query(
        `INSERT INTO partner_documents (partner_id, doc_type, file_url) VALUES ($1,'passport',$2)`,
        [partner.id, d.passportImageUrl]
      );
      if (d.businessLicenseUrl) {
        await client.query(
          `INSERT INTO partner_documents (partner_id, doc_type, file_url) VALUES ($1,'business_license',$2)`,
          [partner.id, d.businessLicenseUrl]
        );
      }

      // ترقية الحساب من customer إلى partner_owner (نفس منطق driver-onboarding) —
      // بدون هذا التحديث، requireRole('partner_owner') بمسارات partners.routes.ts
      // ما راح تعدي أبداً حتى بعد موافقة الأدمن.
      await client.query(`UPDATE users SET role = 'partner_owner' WHERE id = $1`, [req.auth!.userId]);

      await client.query('COMMIT');

      // item 28 (audit): same stale-token issue as driver-onboarding —
      // ship a fresh token reflecting the role upgrade immediately.
      const freshToken = jwt.sign(
        { userId: req.auth!.userId, role: 'partner_owner', partnerId: partner.id },
        process.env.JWT_SECRET!, { expiresIn: '30d' }
      );

      res.status(201).json({
        message: 'تم تقديم طلبك بنجاح، وهو الآن في انتظار موافقة الإدارة',
        partnerId: partner.id,
        status: 'pending',
        token: freshToken,
      });
    } catch (e: any) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  // الشريك يتابع حالة طلبه (pending / active / rejected) قبل ما تُفتح لوحته
  router.get('/my-status', authenticate(db), async (req, res) => {
    const { rows: [partner] } = await db.query(
      `SELECT status, rejected_reason, dashboard_unlocked FROM partners WHERE owner_user_id = $1`,
      [req.auth!.userId]
    );
    if (!partner) return res.status(404).json({ error: 'no_application_found' });
    res.json(partner);
  });

  return router;
}
