import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate, requireRole, requirePermission } from '../../common/auth.middleware';
import { writeAuditLog } from '../admin/audit-log.service';

/**
 * تحكّم الأدمن الكامل بمظهر التطبيقات الثلاثة (طلب صريح) — بدون أي حاجة
 * لتعديل كود أو إعادة نشر التطبيقات: الشعار، اللون الأساسي والثانوي،
 * حجم الخط، استدارة الأزرار، الوضع الافتراضي (فاتح/داكن)، ورابط "خدمة
 * العملاء" (يبدأ فارغًا عمدًا — الأدمن يضيفه بنفسه من اللوحة، لا قيمة
 * وهمية بالكود مطلقًا).
 *
 * GET عام بدون مصادقة عمدًا: يُستدعى من splash_screen.dart بكل تطبيق قبل
 * حتى تسجيل الدخول، فلازم يشتغل لمستخدم غير مسجّل دخول أصلاً.
 */
export function appAppearanceRouter(db: Pool) {
  const router = Router();

  router.get('/', async (_req, res) => {
    const { rows: [row] } = await db.query(`SELECT * FROM app_appearance WHERE id = 1`);
    res.json(row);
  });

  const hexColor = z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'يجب أن يكون لون Hex صالح مثل #6A0DAD');
  const updateSchema = z.object({
    logoUrl: z.string().url().nullable().optional(),
    primaryColor: hexColor.optional(),
    secondaryColor: hexColor.optional(),
    fontScale: z.number().min(0.8).max(1.4).optional(),
    buttonRadius: z.number().int().min(0).max(32).optional(),
    defaultThemeMode: z.enum(['light', 'dark', 'system']).optional(),
    // سلسلة فارغة صراحة تُقبل (يعني "أفرغ الرابط")، مو فقط undefined
    customerSupportUrl: z.string().url().nullable().optional().or(z.literal('')),
  });

  router.patch(
    '/',
    authenticate(db),
    requireRole('admin'),
    requirePermission('appearance.write'),
    async (req, res) => {
      const parsed = updateSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
      const d = parsed.data;

      const { rows: [updated] } = await db.query(
        `UPDATE app_appearance SET
           logo_url = COALESCE($1, logo_url),
           primary_color = COALESCE($2, primary_color),
           secondary_color = COALESCE($3, secondary_color),
           font_scale = COALESCE($4, font_scale),
           button_radius = COALESCE($5, button_radius),
           default_theme_mode = COALESCE($6, default_theme_mode),
           customer_support_url = CASE WHEN $7::text IS NULL THEN customer_support_url
                                       WHEN $7 = '' THEN NULL ELSE $7 END,
           updated_at = now()
         WHERE id = 1
         RETURNING *`,
        [
          d.logoUrl ?? null, d.primaryColor ?? null, d.secondaryColor ?? null,
          d.fontScale ?? null, d.buttonRadius ?? null, d.defaultThemeMode ?? null,
          d.customerSupportUrl === undefined ? null : d.customerSupportUrl,
        ]
      );

      // إصلاح: كانت userId هنا خطأً — audit_logs.admin_user_id مرجعه
      // جدول admin_users، مو users (نفس اتفاقية باقي admin-*.routes.ts).
      // بدون هذا الإصلاح، كل حفظ للمظهر كان سيفشل بخطأ foreign key فعليًا.
      // اسم الإجراء 'update_theme' كان معرّفًا مسبقًا بقائمة AuditLog.jsx
      // (ACTION_LABELS) قبل حتى بناء هذه الميزة — استخدمته كما هو بدل
      // اختراع اسم جديد لنفس الإجراء بالضبط.
      await writeAuditLog(db, req.auth!.adminId!, 'update_theme', undefined, undefined, { changes: d });
      res.json(updated);
    }
  );

  return router;
}
