/**
 * Pluggable payment gateway (item 35: never lock the whole system to one
 * provider). Stripe Checkout is the concrete implementation because it's
 * the one gateway that works identically from a plain WebView on every
 * platform without a native SDK — swapping to a local gateway later only
 * means implementing this same interface.
 */
export interface CheckoutSession {
  providerReference: string;
  checkoutUrl: string;
}

export interface PaymentProvider {
  createCheckoutSession(params: {
    amount: number; currencyCode: string; paymentId: string;
    successUrl: string; cancelUrl: string;
  }): Promise<CheckoutSession>;
  // طلب صريح (نظام الدفع الكامل): إلغاء طلب مدفوع ببوابة دفع حقيقية
  // يحتاج استرجاعًا فعليًا عند المزود نفسه، مو بس تحديث حالة محلية —
  // بخلاف المحفظة اللي استرجاعها داخلي بالكامل (wallet.credit).
  refundPayment(providerReference: string): Promise<void>;
}

class StripeCheckoutProvider implements PaymentProvider {
  async createCheckoutSession(params: {
    amount: number; currencyCode: string; paymentId: string; successUrl: string; cancelUrl: string;
  }): Promise<CheckoutSession> {
    // Loaded lazily so the backend still boots without `stripe` installed
    // when no provider is configured yet (dev mode below handles that).
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: params.currencyCode.toLowerCase(),
          product_data: { name: 'شحن محفظة ODE' },
          unit_amount: Math.round(params.amount * 100), // smallest currency unit
        },
        quantity: 1,
      }],
      client_reference_id: params.paymentId,
      success_url: params.successUrl,
      cancel_url: params.cancelUrl,
    });

    return { providerReference: session.id, checkoutUrl: session.url! };
  }

  async refundPayment(providerReference: string): Promise<void> {
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
    // providerReference هنا هو checkout session id — نحتاج payment_intent
    // المرتبط فعليًا به لعمل استرجاع حقيقي.
    const session = await stripe.checkout.sessions.retrieve(providerReference);
    if (typeof session.payment_intent === 'string') {
      await stripe.refunds.create({ payment_intent: session.payment_intent });
    }
  }
}

/** Dev fallback so the wallet top-up screen is fully testable end-to-end
 *  before real Stripe keys exist — "succeeds" instantly via a local page
 *  that calls our own webhook simulator instead of a real card form. */
class DevMockPaymentProvider implements PaymentProvider {
  async createCheckoutSession(params: {
    amount: number; currencyCode: string; paymentId: string; successUrl: string; cancelUrl: string;
  }): Promise<CheckoutSession> {
    return {
      providerReference: `dev_${params.paymentId}`,
      checkoutUrl: `${process.env.PUBLIC_BACKEND_URL || 'http://localhost:4000'}/payments/dev-checkout?paymentId=${params.paymentId}&successUrl=${encodeURIComponent(params.successUrl)}`,
    };
  }

  async refundPayment(_providerReference: string): Promise<void> {
    // وضع تجريبي بدون مزود حقيقي — لا يوجد شيء فعلي يُسترجع، ينجح بصمت
    // فقط ليطابق سلوك الواجهة (dev mode بالكامل، متوقّع ومُوثَّق).
  }
}

export function getPaymentProvider(): PaymentProvider {
  return process.env.STRIPE_SECRET_KEY ? new StripeCheckoutProvider() : new DevMockPaymentProvider();
}
