import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { authenticate } from '../../common/auth.middleware';
import { getPaymentProvider } from './payment.provider';
import { PaymentsService } from './payments.service';

/**
 * Only the checkout-initiation endpoint lives behind normal auth here.
 * The actual /payments/webhook route is wired directly in server.ts with
 * express.raw() instead of express.json() — Stripe's signature check
 * needs the untouched request body, which a JSON-parsed route no longer
 * has by the time it reaches this router.
 *
 * `io` (اختياري) يُمرَّر الآن لأن تأكيد دفع طلب حقيقي (purpose=
 * 'order_payment') يحتاج إشعار الشريك لحظيًا — راجع PaymentsService.
 */
export function paymentsRouter(db: Pool, io?: SocketServer) {
  const router = Router();
  const provider = getPaymentProvider();

  const initiateSchema = z.object({ amount: z.number().positive(), currencyId: z.number() });

  router.post('/wallet-topup/initiate', authenticate(db), async (req, res) => {
    const parsed = initiateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const { rows: [currency] } = await db.query(`SELECT code FROM currencies WHERE id = $1`, [parsed.data.currencyId]);
    if (!currency) return res.status(404).json({ error: 'currency_not_found' });

    const { rows: [payment] } = await db.query(
      `INSERT INTO payments (user_id, provider, amount, currency_id, status, purpose)
       VALUES ($1, $2, $3, $4, 'pending', 'wallet_topup') RETURNING id`,
      [req.auth!.userId, process.env.STRIPE_SECRET_KEY ? 'stripe' : 'dev_mock', parsed.data.amount, parsed.data.currencyId]
    );

    const session = await provider.createCheckoutSession({
      amount: parsed.data.amount,
      currencyCode: currency.code,
      paymentId: payment.id,
      successUrl: 'ode://payment-success',
      cancelUrl: 'ode://payment-cancelled',
    });

    await db.query(`UPDATE payments SET provider_reference = $1 WHERE id = $2`, [session.providerReference, payment.id]);
    res.json({ checkoutUrl: session.checkoutUrl, paymentId: payment.id });
  });

  // للتحقق اليدوي من WebView (fallback لو الـdeep link ما اشتغل على جهاز
  // معيّن) — يقرأ الحالة الحالية بس، ما يغيّرها.
  router.get('/wallet-topup/:paymentId/status', authenticate(db), async (req, res) => {
    const { rows: [payment] } = await db.query(
      `SELECT status FROM payments WHERE id = $1 AND user_id = $2`,
      [req.params.paymentId, req.auth!.userId]
    );
    if (!payment) return res.status(404).json({ error: 'payment_not_found' });
    res.json(payment);
  });

  // item 5 (audit): this must be completely unreachable once a real
  // payment provider is configured — previously it had no guard at all,
  // meaning anyone who knew/guessed a paymentId could credit arbitrary
  // wallets for free, even in production. Two independent checks: the
  // route 404s outright when STRIPE_SECRET_KEY is set, and even in dev
  // mode it only ever confirms payments that were themselves created
  // through the dev_mock provider.
  router.get('/dev-checkout', async (req, res) => {
    if (process.env.STRIPE_SECRET_KEY) {
      return res.status(404).send('Not found');
    }
    const paymentId = req.query.paymentId as string;
    const successUrl = req.query.successUrl as string;
    const { rows: [payment] } = await db.query(
      `SELECT provider_reference FROM payments WHERE id = $1 AND provider = 'dev_mock' AND status = 'pending'`,
      [paymentId]
    );
    if (!payment) return res.status(404).send('Not found');
    await new PaymentsService(db, io).confirmPaymentByReference(payment.provider_reference);
    res.send(`<html dir="rtl"><body style="font-family:sans-serif;text-align:center;padding-top:60px">
      <h2>✅ تم الدفع بنجاح (وضع تجريبي — لا يوجد مزود دفع حقيقي بعد)</h2>
      <a href="${successUrl}">العودة للتطبيق</a>
    </body></html>`);
  });

  return router;
}
