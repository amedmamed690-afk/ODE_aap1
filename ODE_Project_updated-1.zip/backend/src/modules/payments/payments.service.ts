import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { NotificationsService } from '../notifications/notifications.service';

/**
 * Shared by both the authenticated /initiate route and the raw (no-auth,
 * signature-verified) /webhook route — a webhook call has no user
 * session, so it can only ever act through providerReference lookup.
 *
 * طلب صريح (نظام الدفع Cash + Payment Gateway، بند 1): كانت هذه الدالة
 * تفترض دائمًا "شحن محفظة" بغض النظر عن `purpose` الفعلي بالسجل — أي دفع
 * طلب عبر بوابة (order_payment) كان سيُحسب خطأً كشحن رصيد بدل تحديث حالة
 * الطلب نفسه. الآن تتفرّع فعليًا حسب `purpose`، بدون تكرار منطق التحقق من
 * الـwebhook أو الـidempotency (نفس القفل FOR UPDATE ونفس فحص succeeded
 * مشترك للاثنين).
 */
export class PaymentsService {
  private notifications: NotificationsService;
  constructor(private db: Pool, private io?: SocketServer) {
    this.notifications = new NotificationsService(db);
  }

  async confirmPaymentByReference(providerReference: string) {
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [payment] } = await client.query(
        `SELECT id, user_id, amount, status, purpose, order_id FROM payments WHERE provider_reference = $1 FOR UPDATE`,
        [providerReference]
      );
      if (!payment) throw new Error('payment_not_found');
      if (payment.status === 'succeeded') { await client.query('COMMIT'); return; } // idempotent: webhooks can repeat

      await client.query(`UPDATE payments SET status = 'succeeded' WHERE id = $1`, [payment.id]);

      if (payment.purpose === 'order_payment') {
        await this._confirmOrderPayment(client, payment);
      } else {
        await this._confirmWalletTopup(client, payment);
      }

      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  /** يبقى بنفس الاسم القديم كاسم بديل — أي كود قديم يستدعيه لسا يشتغل. */
  async confirmTopUpByReference(providerReference: string) {
    return this.confirmPaymentByReference(providerReference);
  }

  private async _confirmWalletTopup(client: any, payment: any) {
    await client.query(
      `INSERT INTO customer_wallets (user_id, balance) VALUES ($1, 0)
       ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id`,
      [payment.user_id]
    );
    const { rows: [wallet] } = await client.query(
      `UPDATE customer_wallets SET balance = balance + $1 WHERE user_id = $2 RETURNING balance`,
      [payment.amount, payment.user_id]
    );
    await client.query(
      `INSERT INTO customer_wallet_transactions (user_id, type, amount, balance_after, reference_type, reference_id)
       VALUES ($1, 'topup_card', $2, $3, 'payment', $4)`,
      [payment.user_id, payment.amount, wallet.balance, payment.id]
    );

    await this.notifications.send(payment.user_id, {
      type: 'payment', titleAr: 'تم شحن رصيدك',
      bodyAr: `تمت إضافة ${payment.amount} لمحفظتك`, referenceType: 'payment', referenceId: payment.id,
    });
  }

  private async _confirmOrderPayment(client: any, payment: any) {
    if (!payment.order_id) return; // دفاعي — لا يُفترض حدوثه أبدًا لسجل purpose='order_payment'
    const { rows: [order] } = await client.query(
      `UPDATE orders SET payment_status = 'paid' WHERE id = $1 RETURNING id, order_number, partner_id, customer_id`,
      [payment.order_id]
    );
    if (!order) return;

    await this.notifications.send(order.customer_id, {
      type: 'payment', titleAr: 'تم تأكيد الدفع',
      bodyAr: `تم دفع طلبك رقم ${order.order_number} بنجاح`, referenceType: 'order', referenceId: order.id,
    });
    // الشريك ينتظر هذا التأكيد قبل البدء الفعلي بتحضير الطلب — نفس حدث
    // order:new المُستخدم أصلاً بـplaceOrder، لأن الطلب بحالة 'placed'
    // من البداية بغض النظر عن وسيلة الدفع.
    this.io?.to(`partner:${order.partner_id}`).emit('order:payment_confirmed', { orderId: order.id });
  }
}
