import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { NotificationsService } from '../notifications/notifications.service';
import { InvitesService } from '../invites/invites.service';
import { WalletService, InsufficientBalanceError } from '../wallet/wallet.service';
import { getAppSettingBool, serviceSettingKeyForOrderType } from '../../common/app-settings.service';
import { getPaymentProvider } from '../payments/payment.provider';

/**
 * ORDER FLOW — customer app -> partner app -> driver app
 *
 * 1) placeOrder()          customer creates order -> status = 'placed'
 *                           -> emit to partner's room: order:new
 * 2) partnerAcceptOrder()  partner accepts/rejects -> status = 'accepted_by_partner' | 'rejected'
 *                           -> emit to customer: order:status
 * 3) markReady()           partner marks food/items ready -> status = 'ready_for_pickup'
 *                           -> triggers driver matching -> assignDriver()
 * 4) assignDriver()        nearest available driver found -> status = 'driver_assigned'
 *                           -> emit to driver app: order:assigned
 *                           -> emit to customer: order:status
 * 5) driver updates: picked_up -> on_the_way -> delivered
 *                           -> each transition emits to BOTH customer and partner rooms
 *
 * Every transition is written to order_status_history for audit + support.
 * Sockets rooms are named `user:{id}`, `partner:{id}`, `driver:{id}` so each
 * party only receives events relevant to them.
 *
 * SECURITY AUDIT FIXES (external review, batch 1-20) applied in this file:
 *  - #1/#12: wallet debit now actually happens, inside the same DB
 *    transaction as order creation — either both commit or neither does.
 *  - #13: idempotencyKey makes a retried request return the original
 *    order instead of creating a duplicate.
 *  - #14: every product must belong to the partnerId/branchId the client
 *    claims — not just "exists and is active".
 *  - #15: addressId must belong to the requesting customer.
 *  - #16: branchId must belong to partnerId and be currently open.
 *  - #17: delivery fee is now a real distance-based calculation using an
 *    admin-configurable rate (app_settings), not a hardcoded 10.
 *  - #18: order numbers come from a DB sequence — collision-proof by
 *    construction instead of "unlikely" with Math.random().
 *  - #19: the no-driver-available event now targets the partner's own
 *    room, not a room keyed by the order id (that was a plain bug).
 *  - #20: cancelOrder() implements real rules — who cancelled, required
 *    reason from partner/driver, a grace-period cutoff for the customer,
 *    and a wallet refund when payment was made from the wallet.
 */

const VALID_TRANSITIONS: Record<string, string[]> = {
  placed: ['accepted_by_partner', 'rejected', 'cancelled'],
  accepted_by_partner: ['preparing', 'cancelled'],
  preparing: ['ready_for_pickup', 'cancelled'],
  ready_for_pickup: ['driver_assigned'],
  driver_assigned: ['picked_up', 'cancelled'],
  picked_up: ['on_the_way'],
  on_the_way: ['delivered'],
};

// item 20: normal customer cancellation window after a partner has
// already accepted and started working the order.
const CUSTOMER_CANCEL_GRACE_MINUTES = 5;

export class OrderFlowService {
  private notifications: NotificationsService;
  private invites: InvitesService;
  private wallet: WalletService;

  constructor(private db: Pool, private io: SocketServer) {
    this.notifications = new NotificationsService(db);
    this.invites = new InvitesService(db, this.notifications);
    this.wallet = new WalletService();
  }

  async placeOrder(customerId: string, input: {
    orderType: string; partnerId: string; branchId: string;
    addressId: string; items: { productId: string; qty: number }[];
    currencyId: number; idempotencyKey?: string;
    // طلب صريح (نظام الدفع Cash + Payment Gateway): كانت 'wallet' ثابتة
    // بالكود بغض النظر عمّا يرسله العميل — الآن اختيار حقيقي، يُتحقق منه
    // ويُنفَّذ فعليًا بالباك إند، لا مجرد قيمة تُسجَّل بدون أثر.
    paymentMethod: 'wallet' | 'cash' | 'card';
  }) {
    // #13: a retried request with the same key returns the order that
    // already exists instead of creating a second one.
    if (input.idempotencyKey) {
      const { rows: [existing] } = await this.db.query(
        `SELECT * FROM orders WHERE customer_id = $1 AND idempotency_key = $2`,
        [customerId, input.idempotencyKey]
      );
      if (existing) return existing;
    }

    // طلب صريح (بند 2): التحقق من توفر الخدمة بالباك إند نفسه — لا يكفي
    // إخفاء الزر بالواجهة، لازم رفض الطلب حتى لو استُدعي الـAPI مباشرة.
    const serviceKey = serviceSettingKeyForOrderType(input.orderType);
    const serviceEnabled = await getAppSettingBool(this.db, serviceKey, true);
    if (!serviceEnabled) throw new Error('service_unavailable');

    // طلب صريح (بند 1 و3): نفس المبدأ لوسيلة الدفع نفسها — يُرفض الطلب لو
    // اختار العميل وسيلة معطّلة من لوحة الإدارة، بغض النظر عمّا تعرضه
    // الواجهة (تحقّق مستقل بالباك إند، لا اعتماد على إخفاء الخيار بفلاتر).
    if (input.paymentMethod === 'wallet') {
      const walletEnabled = await getAppSettingBool(this.db, 'services.wallet.enabled', true);
      if (!walletEnabled) throw new Error('wallet_payment_disabled');
    } else if (input.paymentMethod === 'cash') {
      const cashEnabled = await getAppSettingBool(this.db, 'payment.cash.enabled', true);
      if (!cashEnabled) throw new Error('cash_payment_disabled');
    } else if (input.paymentMethod === 'card') {
      const gatewayEnabled = await getAppSettingBool(this.db, 'payment.gateway.enabled', false);
      // طلب صريح: "يجب ألا يتسبب عدم وجود بيانات البوابة الحقيقية حاليًا
      // في تعطيل التطبيق أو بقية طرق الدفع" — يعني نرفض بوضوح هنا فقط،
      // وليس نحاول الاتصال بمزود غير مهيّأ ونفشل بطريقة مبهمة لاحقًا.
      if (!gatewayEnabled) throw new Error('payment_gateway_not_configured');
    }

    const client = await this.db.connect();
    try {
      await client.query('BEGIN');

      // #16: branch must belong to the claimed partner AND be open —
      // previously only branchId's mere existence was implied.
      const { rows: [branch] } = await client.query(
        `SELECT id, lat, lng, is_active, is_open_now FROM partner_branches
         WHERE id = $1 AND partner_id = $2 FOR UPDATE`,
        [input.branchId, input.partnerId]
      );
      if (!branch) throw new Error('branch_does_not_belong_to_partner');
      if (!branch.is_active || !branch.is_open_now) throw new Error('branch_closed');

      // #15: address must belong to the customer placing the order —
      // previously any addressId (even another customer's) was accepted
      // as-is.
      const { rows: [address] } = await client.query(
        `SELECT id, lat, lng FROM addresses WHERE id = $1 AND user_id = $2`,
        [input.addressId, customerId]
      );
      if (!address) throw new Error('address_does_not_belong_to_customer');

      // #14: every product must belong to this exact partner — previously
      // only existence + is_active was checked, so a client could mix
      // productIds from a different partner into the same order.
      const productIds = input.items.map(i => i.productId);
      const { rows: products } = await client.query(
        `SELECT id, price FROM products WHERE id = ANY($1) AND partner_id = $2 AND is_active = true`,
        [productIds, input.partnerId]
      );
      if (products.length !== input.items.length) {
        throw new Error('one_or_more_products_unavailable_or_not_from_this_partner');
      }

      const priceMap = new Map(products.map(p => [p.id, Number(p.price)]));
      const subtotal = input.items.reduce(
        (sum, i) => sum + priceMap.get(i.productId)! * i.qty, 0
      );

      // #17: real distance-based delivery fee, rate configurable by
      // admin via app_settings (same table admin-finance.routes.ts
      // already manages commissions/fees through) — not a bare constant.
      const deliveryFee = await this.calculateDeliveryFee(client, branch, address);
      const total = subtotal + deliveryFee;

      // #18: sequence-backed, guaranteed-unique order number.
      const { rows: [{ nextval }] } = await client.query(`SELECT nextval('order_number_seq')`);
      const orderNumber = `ODE-${new Date().getFullYear()}-${nextval}`;

      const { rows: [order] } = await client.query(
        `INSERT INTO orders
          (order_number, order_type, customer_id, partner_id, branch_id,
           delivery_address_id, status, subtotal, delivery_fee, total, currency_id,
           idempotency_key, payment_method, payment_status)
         VALUES ($1,$2,$3,$4,$5,$6,'placed',$7,$8,$9,$10,$11,$12,'unpaid')
         RETURNING *`,
        [orderNumber, input.orderType, customerId, input.partnerId, input.branchId,
         input.addressId, subtotal, deliveryFee, total, input.currencyId,
         input.idempotencyKey ?? null, input.paymentMethod]
      );

      for (const item of input.items) {
        await client.query(
          `INSERT INTO order_items (order_id, product_id, quantity, unit_price)
           VALUES ($1,$2,$3,$4)`,
          [order.id, item.productId, item.qty, priceMap.get(item.productId)]
        );
      }

      // طلب صريح: ثلاث وسائل دفع حقيقية، كل وحدة بمسارها الصحيح فعليًا —
      // لا مجرد نص مسجَّل بدون أثر:
      //  - wallet: خصم فوري داخل نفس الـtransaction (سلوك #1/#12 الأصلي).
      //  - cash: يبقى unpaid إلى أن يُسلَّم الطلب فعليًا (يُحصَّل نقدًا من
      //    السائق/بالمتجر وقتها) — لا خصم أي رصيد إطلاقًا.
      //  - card: يُنشأ الطلب unpaid، ونبدأ جلسة دفع حقيقية عبر نفس
      //    PaymentProvider المستخدم أصلاً لشحن المحفظة (بدون تكرار أي
      //    كود) — الطلب يتأكد "مدفوع" فقط بعد تأكيد الـwebhook الحقيقي.
      let checkoutUrl: string | undefined;
      if (input.paymentMethod === 'wallet') {
        await this.wallet.debit(client, customerId, total, 'order', order.id);
        await client.query(`UPDATE orders SET payment_status = 'paid' WHERE id = $1`, [order.id]);
      } else if (input.paymentMethod === 'card') {
        const { rows: [currency] } = await client.query(`SELECT code FROM currencies WHERE id = $1`, [input.currencyId]);
        const { rows: [payment] } = await client.query(
          `INSERT INTO payments (user_id, provider, amount, currency_id, status, purpose, order_id)
           VALUES ($1, $2, $3, $4, 'pending', 'order_payment', $5) RETURNING id`,
          [customerId, process.env.STRIPE_SECRET_KEY ? 'stripe' : 'dev_mock', total, input.currencyId, order.id]
        );
        const session = await getPaymentProvider().createCheckoutSession({
          amount: total, currencyCode: currency.code, paymentId: payment.id,
          successUrl: 'ode://payment-success', cancelUrl: 'ode://payment-cancelled',
        });
        await client.query(`UPDATE payments SET provider_reference = $1 WHERE id = $2`, [session.providerReference, payment.id]);
        checkoutUrl = session.checkoutUrl;
      }
      // cash: لا شيء يُنفَّذ هنا عمدًا — يبقى unpaid لحد التسليم.

      await this.logStatus(client, order.id, 'placed', customerId);
      await client.query('COMMIT');

      // Notify the partner's app in real time — this is the "hop" from
      // customer app to partner app.
      this.io.to(`partner:${input.partnerId}`).emit('order:new', { orderId: order.id, orderNumber });

      const paidNow = input.paymentMethod === 'wallet';
      return { ...order, payment_status: paidNow ? 'paid' : 'unpaid', checkout_url: checkoutUrl };
    } catch (err) {
      await client.query('ROLLBACK');
      if (err instanceof InsufficientBalanceError) {
        throw new Error('insufficient_balance');
      }
      throw err;
    } finally {
      client.release();
    }
  }

  /**
   * #17: haversine distance (same approach already used in
   * rides.routes.ts's fare estimate) times an admin-configurable rate.
   * Falls back to a documented default only if the admin hasn't set one
   * yet — never a silent hardcoded business number.
   */
  private async calculateDeliveryFee(client: any, branch: { lat: number; lng: number }, address: { lat: number; lng: number }) {
    const { rows: [setting] } = await client.query(
      `SELECT value FROM app_settings WHERE key = 'fee_delivery_base'`
    );
    const config = setting?.value ?? { base: 5, perKm: 1.5 };

    const R = 6371;
    const dLat = (address.lat - branch.lat) * Math.PI / 180;
    const dLng = (address.lng - branch.lng) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(branch.lat * Math.PI / 180) * Math.cos(address.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
    const distanceKm = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return Number((Number(config.base) + distanceKm * Number(config.perKm)).toFixed(2));
  }

  async transition(orderId: string, nextStatus: string, actingUserId: string) {
    const { rows: [order] } = await this.db.query(`SELECT * FROM orders WHERE id = $1`, [orderId]);
    if (!order) throw new Error('order_not_found');

    const allowed = VALID_TRANSITIONS[order.status] ?? [];
    if (!allowed.includes(nextStatus)) {
      throw new Error(`invalid_transition_${order.status}_to_${nextStatus}`);
    }

    await this.db.query(`UPDATE orders SET status = $1, updated_at = now() WHERE id = $2`, [nextStatus, orderId]);
    await this.logStatus(this.db, orderId, nextStatus, actingUserId);

    // Fan out to whichever parties care about this transition.
    this.io.to(`user:${order.customer_id}`).emit('order:status', { orderId, status: nextStatus });
    this.io.to(`partner:${order.partner_id}`).emit('order:status', { orderId, status: nextStatus });
    if (order.driver_id) {
      this.io.to(`driver:${order.driver_id}`).emit('order:status', { orderId, status: nextStatus });
    }

    // The moment a partner marks the order ready, kick off driver matching —
    // this is the "hop" from partner app to driver app.
    if (nextStatus === 'ready_for_pickup') {
      await this.assignNearestDriver(orderId, order.branch_id, order.partner_id);
    }

    if (nextStatus === 'delivered') {
      await this.onOrderDelivered(order);
    }

    return { orderId, status: nextStatus };
  }

  /**
   * Item 18 (points earned per delivered order) and item 19 (invite
   * reward, but only once the invitee's own first delivered order lands)
   * both hang off this single moment — neither was wired to anything
   * before this, despite both having full schema + endpoints already.
   */
  private async onOrderDelivered(order: any) {
    // طلب صريح: طلب الكاش يبقى unpaid طوال رحلته — يُحصَّل السائق/المتجر
    // المبلغ نقدًا لحظة التسليم الفعلي، وهذه هي اللحظة الصحيحة الوحيدة
    // لتحديث حالة الدفع، لا وقت إنشاء الطلب.
    if (order.payment_method === 'cash' && order.payment_status === 'unpaid') {
      await this.db.query(`UPDATE orders SET payment_status = 'paid' WHERE id = $1`, [order.id]);
    }

    await this.notifications.send(order.customer_id, {
      type: 'order', titleAr: 'تم توصيل طلبك',
      bodyAr: `طلبك رقم ${order.order_number} وصل بنجاح`,
      referenceType: 'order', referenceId: order.id,
    });

    const { rows: [rule] } = await this.db.query(`SELECT points_per_currency FROM point_rules WHERE id = 1`);
    const earnedPoints = Math.floor(Number(order.total) * Number(rule.points_per_currency));
    if (earnedPoints > 0) {
      const { rows: [pts] } = await this.db.query(
        `INSERT INTO customer_points (user_id, balance) VALUES ($1, 0)
         ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id RETURNING balance`,
        [order.customer_id]
      );
      const { rows: [updated] } = await this.db.query(
        `UPDATE customer_points SET balance = balance + $1 WHERE user_id = $2 RETURNING balance`,
        [earnedPoints, order.customer_id]
      );
      await this.db.query(
        `INSERT INTO point_transactions (user_id, type, points, balance_after, reference_type, reference_id)
         VALUES ($1, 'earn', $2, $3, 'order', $4)`,
        [order.customer_id, earnedPoints, updated.balance, order.id]
      );
    }

    // best-effort: an invite issue must never block the order itself
    // from being marked delivered.
    try {
      await this.invites.checkAndCompleteForCustomer(order.customer_id);
    } catch (e) {
      console.error('invite completion check failed:', e);
    }
  }

  private async assignNearestDriver(orderId: string, branchId: string, partnerId: string, excludeDriverIds: string[] = []) {
    const { rows: [branch] } = await this.db.query(
      `SELECT lat, lng FROM partner_branches WHERE id = $1`, [branchId]
    );

    // PostGIS-style nearest-available-driver query (simplified distance calc
    // shown here via Pythagorean approx; production should use ST_Distance).
    const { rows: [driver] } = await this.db.query(
      `SELECT id FROM drivers
       WHERE status = 'available' AND capability IN ('delivery','both')
       AND NOT (id = ANY($3::uuid[]))
       ORDER BY ((current_lat - $1)^2 + (current_lng - $2)^2) ASC
       LIMIT 1`,
      [branch.lat, branch.lng, excludeDriverIds]
    );

    if (!driver) {
      // #19: this used to emit to `partner:${orderId}` — a room keyed by
      // the order's id, which no partner socket ever joins. The partner
      // app would silently never learn that matching failed.
      this.io.to(`partner:${partnerId}`).emit('order:no_driver_available', { orderId });
      return;
    }

    await this.db.query(`UPDATE orders SET driver_id = $1, status = 'driver_assigned' WHERE id = $2`, [driver.id, orderId]);
    await this.db.query(`UPDATE drivers SET status = 'busy' WHERE id = $1`, [driver.id]);
    await this.logStatus(this.db, orderId, 'driver_assigned', driver.id);

    this.io.to(`driver:${driver.id}`).emit('order:assigned', { orderId });
  }

  /**
   * Item 6/20: the driver-facing half of an assignment that
   * assignNearestDriver() never provided before — without this, a
   * driver declining meant the order just sat stuck on them forever.
   * Reassignment excludes every driver who already declined this
   * specific order, so it never loops back to the same person.
   */
  async declineAndReassign(orderId: string, declinedByDriverId: string, declinedByUserId: string, reason?: string) {
    const { rows: [order] } = await this.db.query(
      `SELECT branch_id, driver_id, partner_id FROM orders WHERE id = $1`, [orderId]
    );
    if (!order || order.driver_id !== declinedByDriverId) {
      throw new Error('order_not_assigned_to_this_driver');
    }

    await this.db.query(
      `INSERT INTO order_status_history (order_id, status, changed_by_user_id, note)
       VALUES ($1, 'driver_declined', $2, $3)`,
      [orderId, declinedByUserId, reason ?? null]
    );
    await this.db.query(`UPDATE drivers SET status = 'available' WHERE id = $1`, [declinedByDriverId]);
    await this.db.query(`UPDATE orders SET driver_id = NULL, status = 'ready_for_pickup' WHERE id = $1`, [orderId]);

    const { rows: previousDeclineEvents } = await this.db.query(
      `SELECT d.id AS driver_id FROM order_status_history h
       JOIN users u ON u.id = h.changed_by_user_id JOIN drivers d ON d.user_id = u.id
       WHERE h.order_id = $1 AND h.status = 'driver_declined'`,
      [orderId]
    );
    await this.assignNearestDriver(orderId, order.branch_id, order.partner_id, previousDeclineEvents.map(r => r.driver_id));
  }

  /**
   * Item 20: real cancellation rules.
   *  - customer: allowed any time before the partner accepts; after
   *    acceptance, only within CUSTOMER_CANCEL_GRACE_MINUTES of that
   *    acceptance (checked via order_status_history, not just "now").
   *  - partner/driver: allowed but a reason is mandatory (audited).
   *  - a wallet-paid order that's cancelled gets refunded to the wallet
   *    it was charged from — money already taken must not just vanish.
   */
  async cancelOrder(orderId: string, actingUserId: string, actingRole: string, reason?: string) {
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [order] } = await client.query(
        `SELECT * FROM orders WHERE id = $1 FOR UPDATE`, [orderId]
      );
      if (!order) throw new Error('order_not_found');
      if (['delivered', 'cancelled', 'rejected'].includes(order.status)) {
        throw new Error('order_already_finalized');
      }

      const isCustomer = actingRole === 'customer';
      const isPartner = actingRole === 'partner_owner';
      const isDriver = actingRole === 'driver';

      if (isPartner || isDriver) {
        if (!reason) throw new Error('reason_required_for_partner_or_driver_cancellation');
      }

      if (isCustomer) {
        if (order.status !== 'placed') {
          const { rows: [acceptedEvent] } = await client.query(
            `SELECT created_at FROM order_status_history
             WHERE order_id = $1 AND status = 'accepted_by_partner' ORDER BY created_at LIMIT 1`,
            [orderId]
          );
          const minutesSinceAccepted = acceptedEvent
            ? (Date.now() - new Date(acceptedEvent.created_at).getTime()) / 60000
            : Infinity;
          if (minutesSinceAccepted > CUSTOMER_CANCEL_GRACE_MINUTES) {
            throw new Error('cancellation_grace_period_expired');
          }
        }
      }

      const cancelledBy = isCustomer ? 'customer' : isPartner ? 'partner' : 'driver';
      await client.query(
        `UPDATE orders SET status = 'cancelled', cancelled_by = $1, cancellation_reason = $2 WHERE id = $3`,
        [cancelledBy, reason ?? null, orderId]
      );
      await client.query(
        `INSERT INTO order_status_history (order_id, status, changed_by_user_id, note) VALUES ($1,'cancelled',$2,$3)`,
        [orderId, actingUserId, reason ?? null]
      );

      // money was already taken at placeOrder() time — give it back.
      // طلب صريح: نفس منطق الاسترجاع الآن يغطي الثلاث وسائل — المحفظة
      // استرجاعها داخلي بالكامل، والبطاقة تحتاج استرجاعًا فعليًا عند
      // المزود (Stripe) نفسه، والكاش أصلاً ما يُحصَّل إلا عند التسليم
      // فما فيه شيء يُسترجع لو أُلغي الطلب قبل ذلك.
      if (order.payment_method === 'wallet' && order.payment_status === 'paid') {
        await this.wallet.credit(client, order.customer_id, Number(order.total), 'refund', 'order', orderId);
        await client.query(`UPDATE orders SET payment_status = 'refunded' WHERE id = $1`, [orderId]);
      } else if (order.payment_method === 'card' && order.payment_status === 'paid') {
        const { rows: [payment] } = await client.query(
          `SELECT provider_reference FROM payments WHERE order_id = $1 AND status = 'succeeded'`, [orderId]
        );
        if (payment?.provider_reference) {
          await getPaymentProvider().refundPayment(payment.provider_reference);
        }
        await client.query(`UPDATE orders SET payment_status = 'refunded' WHERE id = $1`, [orderId]);
      }

      if (order.driver_id) {
        await client.query(`UPDATE drivers SET status = 'available' WHERE id = $1`, [order.driver_id]);
      }

      await client.query('COMMIT');

      this.io.to(`user:${order.customer_id}`).emit('order:status', { orderId, status: 'cancelled' });
      this.io.to(`partner:${order.partner_id}`).emit('order:status', { orderId, status: 'cancelled' });
      if (order.driver_id) this.io.to(`driver:${order.driver_id}`).emit('order:status', { orderId, status: 'cancelled' });

      return { orderId, status: 'cancelled' };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  private async logStatus(dbOrClient: Pool | any, orderId: string, status: string, byUserId: string) {
    await dbOrClient.query(
      `INSERT INTO order_status_history (order_id, status, changed_by_user_id) VALUES ($1,$2,$3)`,
      [orderId, status, byUserId]
    );
  }
}
