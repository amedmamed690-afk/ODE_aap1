import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';

/**
 * Group & Guardian Relay (بند 1، الميزة الثالثة) — ربط رحلتين أو أكثر
 * كـ "موكب واحد" مع تنبيه فوري لو أي سيارة انحرفت عن باقي الموكب.
 *
 * منطق الكشف: كل ما سائق يبعث تحديث موقعه (نفس RidesService.updateDriverLocation
 * الموجود مسبقاً)، لو رحلته جزء من موكب، نحسب المسافة بينه وبين "مركز
 * ثقل" باقي سيارات نفس الموكب (متوسط إحداثيات باقي السيارات النشطة).
 * لو تجاوزت threshold المحدد (افتراضياً 500 متر) نسجّل تنبيه ونبثه
 * لكل ركاب الموكب فوراً. هذا تقريب عملي وواقعي (مش أفضل خوارزمية جغرافية
 * ممكنة، لكنه دقيق كفاية لهدف "لاحظنا سيارة ابتعدت") — لو احتجنا دقة
 * أعلى لاحقاً نقدر نستبدلها بمسافة فعلية على الطريق عبر Directions API.
 */
export class ConvoyService {
  constructor(private db: Pool, private io: SocketServer) {}

  async createConvoy(customerId: string, rideIds: string[], deviationThresholdMeters = 500) {
    if (rideIds.length < 2) throw new Error('convoy_requires_at_least_two_rides');

    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [convoy] } = await client.query(
        `INSERT INTO ride_convoys (created_by_customer_id, deviation_threshold_meters) VALUES ($1,$2) RETURNING *`,
        [customerId, deviationThresholdMeters]
      );
      await client.query(`UPDATE rides SET convoy_id = $1 WHERE id = ANY($2)`, [convoy.id, rideIds]);
      await client.query('COMMIT');

      for (const rideId of rideIds) {
        this.io.to(`ride:${rideId}`).emit('convoy:created', { convoyId: convoy.id });
      }
      return convoy;
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  /** يُستدعى من داخل updateDriverLocation() كل ما سائق ضمن موكب يحدّث موقعه */
  async checkDeviation(rideId: string, driverLat: number, driverLng: number) {
    const { rows: [ride] } = await this.db.query(`SELECT convoy_id FROM rides WHERE id = $1`, [rideId]);
    if (!ride?.convoy_id) return; // مش جزء من موكب، تجاهل

    const { rows: otherCars } = await this.db.query(
      `SELECT d.current_lat, d.current_lng
       FROM rides r JOIN drivers d ON d.id = r.driver_id
       WHERE r.convoy_id = $1 AND r.id != $2 AND r.status IN ('driver_assigned','in_progress')
         AND d.current_lat IS NOT NULL`,
      [ride.convoy_id, rideId]
    );
    if (otherCars.length === 0) return;

    const avgLat = otherCars.reduce((s, c) => s + Number(c.current_lat), 0) / otherCars.length;
    const avgLng = otherCars.reduce((s, c) => s + Number(c.current_lng), 0) / otherCars.length;
    const distanceMeters = this.haversineMeters(driverLat, driverLng, avgLat, avgLng);

    const { rows: [convoy] } = await this.db.query(`SELECT deviation_threshold_meters FROM ride_convoys WHERE id = $1`, [ride.convoy_id]);
    if (distanceMeters > convoy.deviation_threshold_meters) {
      await this.db.query(
        `INSERT INTO convoy_deviation_alerts (convoy_id, ride_id, distance_meters) VALUES ($1,$2,$3)`,
        [ride.convoy_id, rideId, Math.round(distanceMeters)]
      );

      // نبث التنبيه لكل ركاب الموكب (كل الرحلات المرتبطة)، مش بس صاحب
      // السيارة المنحرفة — عشان الكل يعرف حالة الموكب لحظياً.
      const { rows: convoyRides } = await this.db.query(`SELECT id, customer_id FROM rides WHERE convoy_id = $1`, [ride.convoy_id]);
      for (const r of convoyRides) {
        this.io.to(`user:${r.customer_id}`).emit('convoy:deviation_alert', {
          convoyId: ride.convoy_id, deviatedRideId: rideId, distanceMeters: Math.round(distanceMeters),
        });
      }
    }
  }

  private haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number) {
    const R = 6371000;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }
}
