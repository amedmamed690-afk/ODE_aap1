import { Router } from 'express';
import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { authenticate, requireRole } from '../../common/auth.middleware';
import { ConvoyService } from './convoy.service';

export function convoyRouter(db: Pool, io: SocketServer) {
  const router = Router();
  const service = new ConvoyService(db, io);
  router.use(authenticate(db));

  router.post('/', requireRole('customer'), async (req, res) => {
    const { rideIds, deviationThresholdMeters } = req.body;
    try {
      const convoy = await service.createConvoy(req.auth!.userId, rideIds, deviationThresholdMeters);
      res.status(201).json(convoy);
    } catch (e: any) { res.status(400).json({ error: e.message }); }
  });

  return router;
}
