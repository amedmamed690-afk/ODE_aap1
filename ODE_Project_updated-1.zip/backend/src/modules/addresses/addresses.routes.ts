import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * إضافة (Audit — تقرير الجولة الأولى، بند D): جدول `addresses` وعمود
 * `orders.delivery_address_id` موجودان بالـDB، و`order-flow.service.ts`
 * يفترض وجود `addressId` صالح مسبقًا (ويتحقق أنه يخص نفس العميل — بند 15)،
 * لكن لم يكن هناك أي endpoint فعلي لإنشاء/عرض/حذف عنوان. تطبيق العميل
 * كان يرسل 'PLACEHOLDER_ADDRESS_ID' ثابت لعدم وجود شيء حقيقي يختاره.
 *
 * هذا الملف يسد الفجوة بالكامل من طرف الـBackend: CRUD كامل، كل عملية
 * مقيّدة بـ user_id من التوكن (IDOR-safe)، وعنوان افتراضي واحد فقط لكل
 * مستخدم (is_default) يُدار تلقائيًا.
 */
export function addressesRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/', async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, label, city_id, line1, building_no, lat, lng, is_default, created_at
       FROM addresses WHERE user_id = $1 ORDER BY is_default DESC, created_at DESC`,
      [req.auth!.userId]
    );
    res.json(rows);
  });

  const addressSchema = z.object({
    label: z.string().min(1).max(50).optional(),
    cityId: z.number().int().optional(),
    line1: z.string().min(1),
    buildingNo: z.string().max(20).optional(),
    lat: z.number().min(-90).max(90),
    lng: z.number().min(-180).max(180),
    isDefault: z.boolean().optional(),
  });

  router.post('/', async (req, res) => {
    const parsed = addressSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;
    const userId = req.auth!.userId;

    const client = await db.connect();
    try {
      await client.query('BEGIN');
      // أول عنوان للمستخدم يصير افتراضي تلقائيًا حتى لو ما طلب ذلك صراحة.
      const { rows: [{ count }] } = await client.query(
        `SELECT count(*)::int FROM addresses WHERE user_id = $1`, [userId]
      );
      const shouldBeDefault = d.isDefault === true || Number(count) === 0;
      if (shouldBeDefault) {
        await client.query(`UPDATE addresses SET is_default = false WHERE user_id = $1`, [userId]);
      }
      const { rows: [created] } = await client.query(
        `INSERT INTO addresses (user_id, label, city_id, line1, building_no, lat, lng, is_default)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
         RETURNING id, label, city_id, line1, building_no, lat, lng, is_default, created_at`,
        [userId, d.label ?? null, d.cityId ?? null, d.line1, d.buildingNo ?? null, d.lat, d.lng, shouldBeDefault]
      );
      await client.query('COMMIT');
      res.status(201).json(created);
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  });

  const updateSchema = addressSchema.partial();
  router.patch('/:id', async (req, res) => {
    const parsed = updateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;
    const userId = req.auth!.userId;

    // ownership check أولًا — نفس مبدأ order-flow.service.ts (بند 15):
    // لا نفترض أن :id يخص صاحب التوكن لمجرد إرساله بالـURL.
    const { rows: [existing] } = await db.query(
      `SELECT id FROM addresses WHERE id = $1 AND user_id = $2`, [req.params.id, userId]
    );
    if (!existing) return res.status(404).json({ error: 'address_not_found' });

    const client = await db.connect();
    try {
      await client.query('BEGIN');
      if (d.isDefault === true) {
        await client.query(`UPDATE addresses SET is_default = false WHERE user_id = $1`, [userId]);
      }
      const { rows: [updated] } = await client.query(
        `UPDATE addresses SET
           label = COALESCE($1, label), city_id = COALESCE($2, city_id),
           line1 = COALESCE($3, line1), building_no = COALESCE($4, building_no),
           lat = COALESCE($5, lat), lng = COALESCE($6, lng),
           is_default = COALESCE($7, is_default)
         WHERE id = $8 AND user_id = $9
         RETURNING id, label, city_id, line1, building_no, lat, lng, is_default, created_at`,
        [d.label ?? null, d.cityId ?? null, d.line1 ?? null, d.buildingNo ?? null,
         d.lat ?? null, d.lng ?? null, d.isDefault ?? null, req.params.id, userId]
      );
      await client.query('COMMIT');
      res.json(updated);
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  });

  router.delete('/:id', async (req, res) => {
    const userId = req.auth!.userId;
    const { rows: [deleted] } = await db.query(
      `DELETE FROM addresses WHERE id = $1 AND user_id = $2 RETURNING id, is_default`,
      [req.params.id, userId]
    );
    if (!deleted) return res.status(404).json({ error: 'address_not_found' });

    // لو كان العنوان المحذوف هو الافتراضي، نجعل أقدم عنوان متبقٍّ (إن وجد)
    // هو الافتراضي الجديد — بدل ما يبقى المستخدم بلا عنوان افتراضي إطلاقًا.
    if (deleted.is_default) {
      await db.query(
        `UPDATE addresses SET is_default = true WHERE id = (
           SELECT id FROM addresses WHERE user_id = $1 ORDER BY created_at ASC LIMIT 1
         )`,
        [userId]
      );
    }
    res.json({ message: 'تم حذف العنوان' });
  });

  return router;
}
