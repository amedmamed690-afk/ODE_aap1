import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole } from '../../common/auth.middleware';

export function partnersRouter(db: Pool) {
  const router = Router();

  // GET /partners?type=restaurant&accountType=digital&countryId=&categoryId=&search=
  // accountType و categoryId اختياريان — يُستخدموا بشاشات "مطاعم/متاجر إلكترونية"
  router.get('/', async (req, res) => {
    const { type, accountType, countryId, categoryId, search } = req.query;
    const conditions = [`status = 'active'`];
    const params: any[] = [];

    if (type) { params.push(type); conditions.push(`type = $${params.length}`); }
    if (accountType) { params.push(accountType); conditions.push(`account_type = $${params.length}`); }
    if (countryId) { params.push(countryId); conditions.push(`country_id = $${params.length}`); }
    if (categoryId) { params.push(categoryId); conditions.push(`activity_category_id = $${params.length}`); }
    if (search) { params.push(`%${search}%`); conditions.push(`name_ar ILIKE $${params.length}`); }

    const { rows } = await db.query(
      `SELECT id, type, account_type, name_en, name_ar, logo_url, cover_url, rating_avg, activity_category_id
       FROM partners WHERE ${conditions.join(' AND ')} ORDER BY rating_avg DESC`,
      params
    );
    res.json(rows);
  });

  router.get('/:id/products', async (req, res) => {
    const branchId = req.query.branchId as string | undefined;
    const params: any[] = [req.params.id];
    let branchFilter = '';
    if (branchId) { params.push(branchId); branchFilter = `AND p.branch_id = $${params.length}`; }
    // إصلاح (بند حرج جديد بالجولة الثالثة): كانت `SELECT * FROM products`
    // بدون أي JOIN — أي أن `currency_id` (رقمي) يرجع بدون `currency_code`
    // النصي (SAR/AED..) اللي يتوقعه ProductModel بتطبيق العميل. كان يظهر
    // فارغًا بكل شاشة منتج لأي مطعم/متجر شريك (خلافًا لمنتجات ODE Brand
    // اللي عندها JOIN منفصل صحيح أصلاً).
    const { rows } = await db.query(
      `SELECT p.*, c.code AS currency_code
       FROM products p JOIN currencies c ON c.id = p.currency_id
       WHERE p.partner_id = $1 AND p.is_active = true AND p.is_blocked_by_admin = false ${branchFilter}
       ORDER BY p.category_id`,
      params
    );
    res.json(rows);
  });

  // إضافة (بند D جديد بالجولة الثالثة): لم يكن هناك أي endpoint عام لعرض
  // فروع الشريك — عمود products.branch_id وorders.branch_id كانا موجودين
  // ويُستخدمان بالفعل بالـBackend (order-flow.service.ts، بند 16: التحقق
  // أن الفرع مفتوح ويخص الشريك)، لكن تطبيق العميل لم يكن يملك أي طريقة
  // لمعرفة فروع شريك مُعيّن أو أيها مفتوح الآن.
  router.get('/:id/branches', async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, city_id, address_line, lat, lng, is_open_now, opens_at, closes_at
       FROM partner_branches WHERE partner_id = $1 AND is_active = true ORDER BY is_open_now DESC`,
      [req.params.id]
    );
    res.json(rows);
  });

  router.use(authenticate(db));

  router.get('/me', requireRole('partner_owner'), async (req, res) => {
    const { rows: [partner] } = await db.query(`SELECT * FROM partners WHERE owner_user_id = $1`, [req.auth!.userId]);
    res.json(partner);
  });

  router.post('/me/products', requireRole('partner_owner'), async (req, res) => {
    const { branchId, categoryId, nameEn, nameAr, price, currencyId, stockQty, imageUrl } = req.body;
    const { rows: [partner] } = await db.query(`SELECT id FROM partners WHERE owner_user_id = $1`, [req.auth!.userId]);
    if (!partner) return res.status(403).json({ error: 'no_partner_account' });

    const { rows: [product] } = await db.query(
      `INSERT INTO products (partner_id, branch_id, category_id, name_en, name_ar, price, currency_id, stock_qty, image_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [partner.id, branchId, categoryId, nameEn, nameAr, price, currencyId, stockQty, imageUrl]
    );
    res.status(201).json(product);
  });

  return router;
}
