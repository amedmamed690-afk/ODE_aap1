import { Pool } from 'pg';

/**
 * كل شيء يخص رصيد الشريك ودينه السالب (بند 6 و7) يمر من هنا فقط —
 * نفس فلسفة WalletService بمحفظة العميل: مصدر حقيقة واحد، بمعاملات
 * محمية (FOR UPDATE) عشان ما يصير سباق (Race Condition) لو طلبين
 * وصلوا بنفس اللحظة.
 */
export class PartnerBalanceService {
  constructor(private db: Pool) {}

  /** يُستدعى قبل السماح لأي طلب يوصل الشريك — يمنعه لو تجاوز حد الدين */
  async canReceiveOrders(partnerId: string): Promise<{ allowed: boolean; balance: number; limit: number }> {
    const { rows: [partner] } = await this.db.query(
      `SELECT balance, negative_balance_limit, status FROM partners WHERE id = $1`, [partnerId]
    );
    if (!partner || partner.status !== 'active') return { allowed: false, balance: 0, limit: 0 };

    const balance = Number(partner.balance);
    const limit = Number(partner.negative_balance_limit);
    // limit سالب (مثلاً -100) — لو الرصيد أقل منه (أكثر ديناً) يُمنع
    return { allowed: balance >= limit, balance, limit };
  }

  /** خصم عمولة المنصة تلقائياً عند إتمام كل طلب (بند 7) */
  async deductCommission(partnerId: string, orderId: string, orderTotal: number, commissionPercent: number) {
    const commissionAmount = Math.round(orderTotal * (commissionPercent / 100) * 100) / 100;
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [partner] } = await client.query(`SELECT balance FROM partners WHERE id = $1 FOR UPDATE`, [partnerId]);
      const newBalance = Number(partner.balance) - commissionAmount;

      await client.query(`UPDATE partners SET balance = $1 WHERE id = $2`, [newBalance, partnerId]);
      await client.query(
        `INSERT INTO partner_balance_transactions (partner_id, type, amount, balance_after, reference_type, reference_id)
         VALUES ($1, 'commission_deduction', $2, $3, 'order', $4)`,
        [partnerId, -commissionAmount, newBalance, orderId]
      );
      await client.query('COMMIT');
      return { commissionAmount, newBalance };
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  /** شحن رصيد الشريك (تسديد الدين) — نفس مبدأ topUp بمحفظة العميل */
  async topUp(partnerId: string, amount: number) {
    if (amount <= 0) throw new Error('invalid_amount');
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const { rows: [partner] } = await client.query(`SELECT balance FROM partners WHERE id = $1 FOR UPDATE`, [partnerId]);
      const newBalance = Number(partner.balance) + amount;
      await client.query(`UPDATE partners SET balance = $1 WHERE id = $2`, [newBalance, partnerId]);
      await client.query(
        `INSERT INTO partner_balance_transactions (partner_id, type, amount, balance_after, reference_type)
         VALUES ($1, 'topup', $2, $3, 'manual')`,
        [partnerId, amount, newBalance]
      );
      await client.query('COMMIT');
      return { balance: newBalance };
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  /**
   * توليد دفعة تسوية لشريك عن فترة معينة (بند 7) — تُستدعى من مهمة
   * مجدولة (Cron) بلوحة الأدمن حسب settlement_period لكل شريك
   * (أسبوعي/شهري)، أو يدوياً من الأدمن. تحسب صافي المستحق للشريك
   * بعد خصم العمولات، وتُصفّر ما تم تسويته من رصيده.
   */
  async generateSettlement(partnerId: string, periodStart: Date, periodEnd: Date) {
    const { rows: [totals] } = await this.db.query(
      `SELECT
         COALESCE(SUM(o.subtotal), 0) AS gross_sales,
         COALESCE(SUM(o.platform_commission), 0) AS commission_amount
       FROM orders o
       WHERE o.partner_id = $1 AND o.status = 'delivered'
         AND o.placed_at BETWEEN $2 AND $3`,
      [partnerId, periodStart, periodEnd]
    );

    const grossSales = Number(totals.gross_sales);
    const commissionAmount = Number(totals.commission_amount);
    const netPayable = grossSales - commissionAmount;

    const { rows: [batch] } = await this.db.query(
      `INSERT INTO settlement_batches (partner_id, period_start, period_end, gross_sales, commission_amount, net_payable, status)
       VALUES ($1,$2,$3,$4,$5,$6,'pending') RETURNING *`,
      [partnerId, periodStart, periodEnd, grossSales, commissionAmount, netPayable]
    );
    return batch;
  }
}
