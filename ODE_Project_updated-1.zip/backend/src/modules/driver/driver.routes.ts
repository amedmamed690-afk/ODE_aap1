import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole } from '../../common/auth.middleware';

/**
 * Driver's own profile — the counterpart to partners.routes.ts's GET /me.
 * DriverAuthProvider.verifyOtp calls this right after confirming
 * approval_status is clear of pending/rejected/suspended, purely to get
 * the driverId to store locally (matches how PartnerAuthProvider does the
 * same via GET /partners/me).
 */
export function driverRouter(db: Pool) {
  const router = Router();

  router.get('/me', authenticate(db), requireRole('driver'), async (req, res) => {
    const { rows: [driver] } = await db.query(
      `SELECT d.id, d.capability, d.vehicle_type, d.plate_number, d.status, d.approval_status,
              d.rating_avg, u.full_name, u.phone
       FROM drivers d JOIN users u ON u.id = d.user_id
       WHERE d.user_id = $1`,
      [req.auth!.userId]
    );
    if (!driver) return res.status(404).json({ error: 'driver_not_found' });
    res.json(driver);
  });

  // بند 6: تشغيل/إيقاف حالة Active — الوضع بيبدأ 'offline' بعد التفعيل.
  router.patch('/status', authenticate(db), requireRole('driver'), async (req, res) => {
    const status = req.body?.status;
    if (!['offline', 'available'].includes(status)) {
      return res.status(400).json({ error: 'invalid_status' });
    }
    const { rows: [driver] } = await db.query(
      `UPDATE drivers SET status = $1
       WHERE user_id = $2 AND approval_status = 'active'
       RETURNING id, status`,
      [status, req.auth!.userId]
    );
    if (!driver) return res.status(403).json({ error: 'driver_not_active' });
    res.json(driver);
  });

  return router;
}
