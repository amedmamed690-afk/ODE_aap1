import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate, requireRole } from '../../common/auth.middleware';

/**
 * Driver wallet/earnings (item 11, driver side). Mirrors the shape
 * partner_balance_transactions already established (append-only ledger +
 * running balance_after), but credits instead of only debits, plus a
 * withdrawal-request flow gated by admin review (item 12: no direct cash
 * payout without an admin step).
 *
 * This is exactly the contract earnings_screen.dart already expects:
 * fetchWallet / fetchSummary / fetchTransactions / requestWithdrawal.
 */
export function driverEarningsRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db), requireRole('driver'));

  router.get('/wallet', async (req, res) => {
    const { rows: [driver] } = await db.query(
      `SELECT d.balance, d.total_earned FROM drivers d WHERE d.user_id = $1`,
      [req.auth!.userId]
    );
    if (!driver) return res.status(404).json({ error: 'driver_not_found' });
    res.json({ balance: Number(driver.balance), totalEarned: Number(driver.total_earned) });
  });

  router.get('/summary', async (req, res) => {
    const period = (req.query.period as string) || 'today';
    const interval = period === 'week' ? '7 days' : period === 'month' ? '30 days' : '1 day';

    const { rows: [driver] } = await db.query(`SELECT id FROM drivers WHERE user_id = $1`, [req.auth!.userId]);
    if (!driver) return res.status(404).json({ error: 'driver_not_found' });

    const { rows: [summary] } = await db.query(
      `SELECT
         COALESCE(SUM(amount) FILTER (WHERE amount > 0), 0) AS total_earnings,
         COUNT(*) FILTER (WHERE type IN ('order_earning','ride_earning')) AS completed_trips
       FROM driver_wallet_transactions
       WHERE driver_id = $1 AND created_at >= now() - interval '${interval}'`,
      [driver.id]
    );
    res.json({ total_earnings: Number(summary.total_earnings), completed_trips: Number(summary.completed_trips) });
  });

  router.get('/transactions', async (req, res) => {
    const { rows: [driver] } = await db.query(`SELECT id FROM drivers WHERE user_id = $1`, [req.auth!.userId]);
    if (!driver) return res.status(404).json({ error: 'driver_not_found' });

    const { rows } = await db.query(
      `SELECT type, amount, created_at AS "createdAt" FROM driver_wallet_transactions
       WHERE driver_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [driver.id]
    );
    res.json(rows.map(r => ({ ...r, amount: Number(r.amount) })));
  });

  const withdrawSchema = z.object({
    amount: z.number().positive(),
    payoutDetails: z.record(z.any()),
  });

  router.post('/withdraw', async (req, res) => {
    const parsed = withdrawSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const { rows: [driver] } = await db.query(`SELECT id, balance FROM drivers WHERE user_id = $1`, [req.auth!.userId]);
    if (!driver) return res.status(404).json({ error: 'driver_not_found' });
    if (Number(driver.balance) < parsed.data.amount) {
      return res.status(400).json({ error: 'insufficient_balance' });
    }

    const { rows: [request] } = await db.query(
      `INSERT INTO driver_withdrawal_requests (driver_id, amount, payout_details, status)
       VALUES ($1, $2, $3, 'pending') RETURNING id`,
      [driver.id, parsed.data.amount, JSON.stringify(parsed.data.payoutDetails)]
    );
    // الرصيد ما يتخصم إلا بعد موافقة الأدمن الفعلية على السحب (بند 12) —
    // هذا فقط يسجّل الطلب.
    res.status(201).json({ message: 'تم إرسال طلب السحب، بانتظار مراجعة الإدارة', requestId: request.id });
  });

  return router;
}
