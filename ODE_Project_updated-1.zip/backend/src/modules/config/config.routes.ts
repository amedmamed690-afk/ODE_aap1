import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate, requireRole } from '../../common/auth.middleware';

/**
 * REMOTE CONFIG — powers the "live control without app update" requirement.
 * Clients call GET /config/bootstrap once at app start (and can poll or
 * subscribe via socket for near-instant updates). Everything here is cached
 * client-side with a short TTL (e.g. 5 min) to avoid hammering the DB.
 */
export function configRouter(db: Pool) {
  const router = Router();

  // ---- Public: every client app calls this on launch ----
  router.get('/bootstrap', async (req, res) => {
    const countryId = Number(req.query.countryId);

    const [settings, banners, sections, currencies] = await Promise.all([
      db.query(
        `SELECT key, value FROM app_settings WHERE country_id = $1 OR country_id IS NULL`,
        [countryId]
      ),
      db.query(
        `SELECT * FROM banners
         WHERE is_active = true AND (country_id = $1 OR country_id IS NULL)
           AND (starts_at IS NULL OR starts_at <= now())
           AND (ends_at IS NULL OR ends_at >= now())
         ORDER BY sort_order ASC`,
        [countryId]
      ),
      db.query(
        `SELECT * FROM home_sections
         WHERE is_active = true AND (country_id = $1 OR country_id IS NULL)
         ORDER BY sort_order ASC`,
        [countryId]
      ),
      db.query(`SELECT * FROM currencies WHERE is_active = true`),
    ]);

    res.json({
      settings: Object.fromEntries(settings.rows.map(r => [r.key, r.value])),
      banners: banners.rows,
      homeSections: sections.rows,
      currencies: currencies.rows,
    });
  });

  // ---- Admin only: everything below requires an admin JWT ----
  router.use(authenticate(db), requireRole('admin'));

  router.put('/banners/:id', async (req, res) => {
    const { title_en, title_ar, image_url, is_active, sort_order } = req.body;
    const { rows: [banner] } = await db.query(
      `UPDATE banners SET title_en=$1, title_ar=$2, image_url=$3, is_active=$4, sort_order=$5
       WHERE id=$6 RETURNING *`,
      [title_en, title_ar, image_url, is_active, sort_order, req.params.id]
    );
    res.json(banner);
  });

  router.put('/currencies/:id/rate', async (req, res) => {
    const { exchange_rate_to_base } = req.body;
    const { rows: [currency] } = await db.query(
      `UPDATE currencies SET exchange_rate_to_base = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [exchange_rate_to_base, req.params.id]
    );
    res.json(currency);
  });

  router.put('/sections/:id/reorder', async (req, res) => {
    const { sort_order, is_active } = req.body;
    const { rows: [section] } = await db.query(
      `UPDATE home_sections SET sort_order = $1, is_active = $2 WHERE id = $3 RETURNING *`,
      [sort_order, is_active, req.params.id]
    );
    res.json(section);
  });

  return router;
}
