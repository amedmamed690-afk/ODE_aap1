import { Router } from 'express';
import { z } from 'zod';
import crypto from 'crypto';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

export function invitesRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  // كود دعوة واحد ثابت لكل مستخدم — يُنشأ أول مرة يُطلب فيها.
  router.get('/my-code', async (req, res) => {
    const { rows: [existing] } = await db.query(`SELECT code FROM invites WHERE inviter_id = $1`, [req.auth!.userId]);
    if (existing) return res.json({ code: existing.code });

    const code = crypto.randomBytes(4).toString('hex').toUpperCase();
    const { rows: [created] } = await db.query(
      `INSERT INTO invites (inviter_id, code) VALUES ($1, $2) RETURNING code`,
      [req.auth!.userId, code]
    );
    res.json({ code: created.code });
  });

  const redeemSchema = z.object({ code: z.string().min(4) });

  // بند 19: لا يُحتسب أي شيء الآن — فقط يربط المدعو بصاحب الكود.
  // المكافأة تُمنح لاحقًا تلقائيًا من order-flow.service.ts عند التوصيل.
  router.post('/redeem', async (req, res) => {
    const parsed = redeemSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const { rows: [invite] } = await db.query(`SELECT id, inviter_id FROM invites WHERE code = $1`, [parsed.data.code]);
    if (!invite) return res.status(404).json({ error: 'invalid_code' });
    if (invite.inviter_id === req.auth!.userId) return res.status(400).json({ error: 'cannot_use_own_code' });

    const { rows: [alreadyOrdered] } = await db.query(
      `SELECT 1 FROM orders WHERE customer_id = $1 AND status = 'delivered' LIMIT 1`,
      [req.auth!.userId]
    );
    if (alreadyOrdered) return res.status(400).json({ error: 'invite_code_must_be_entered_before_first_delivered_order' });

    try {
      await db.query(
        `INSERT INTO invite_redemptions (invite_id, invitee_id, status) VALUES ($1, $2, 'pending')`,
        [invite.id, req.auth!.userId]
      );
      res.status(201).json({ message: 'تم تفعيل كود الدعوة — أكمل أول طلب لك للحصول على المكافأة' });
    } catch (e: any) {
      if (e.code === '23505') return res.status(409).json({ error: 'already_redeemed_a_code' }); // unique(invitee_id)
      throw e;
    }
  });

  return router;
}
