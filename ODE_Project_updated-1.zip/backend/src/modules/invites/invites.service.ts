import { Pool } from 'pg';
import { NotificationsService } from '../notifications/notifications.service';

/**
 * Item 19: the reward is never credited at redeem time — only after the
 * invitee completes a *delivered* order, inside an admin-configurable
 * window (invite_settings.completion_window_days). This service is called
 * from order-flow.service.ts's 'delivered' transition, not from
 * invites.routes.ts, since redemption and completion are genuinely two
 * different moments.
 */
export class InvitesService {
  constructor(private db: Pool, private notifications: NotificationsService) {}

  async checkAndCompleteForCustomer(customerId: string) {
    const { rows: [settings] } = await this.db.query(`SELECT * FROM invite_settings WHERE id = 1`);

    const { rows: [redemption] } = await this.db.query(
      `SELECT ir.id, ir.redeemed_at, ir.invite_id, i.inviter_id
       FROM invite_redemptions ir JOIN invites i ON i.id = ir.invite_id
       WHERE ir.invitee_id = $1 AND ir.status = 'pending'`,
      [customerId]
    );
    if (!redemption) return; // ما دخل كود دعوة أصلاً، أو أُنجزت/انتهت مسبقًا

    const deadline = new Date(redemption.redeemed_at);
    deadline.setDate(deadline.getDate() + settings.completion_window_days);
    if (new Date() > deadline) {
      await this.db.query(`UPDATE invite_redemptions SET status = 'expired' WHERE id = $1`, [redemption.id]);
      return;
    }

    // هذا أول طلب توصيل مكتمل للمدعو فعلاً؟ (وليس أي طلب لاحق بعد الإكمال)
    const { rows: [{ count }] } = await this.db.query(
      `SELECT COUNT(*) FROM orders WHERE customer_id = $1 AND status = 'delivered'`,
      [customerId]
    );
    if (Number(count) !== 1) return;

    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      await client.query(`UPDATE invite_redemptions SET status = 'completed', completed_at = now() WHERE id = $1`, [redemption.id]);

      for (const [userId, points] of [
        [redemption.inviter_id, settings.inviter_reward_points],
        [customerId, settings.invitee_reward_points],
      ] as const) {
        const { rows: [pts] } = await client.query(
          `INSERT INTO customer_points (user_id, balance) VALUES ($1, 0)
           ON CONFLICT (user_id) DO UPDATE SET user_id = EXCLUDED.user_id RETURNING balance`,
          [userId]
        );
        const { rows: [updated] } = await client.query(
          `UPDATE customer_points SET balance = balance + $1 WHERE user_id = $2 RETURNING balance`,
          [points, userId]
        );
        await client.query(
          `INSERT INTO point_transactions (user_id, type, points, balance_after, reference_type, reference_id)
           VALUES ($1, 'earn', $2, $3, 'invite', $4)`,
          [userId, points, updated.balance, redemption.invite_id]
        );
      }
      await client.query('COMMIT');

      await this.notifications.send(redemption.inviter_id, {
        type: 'promotion', titleAr: 'مكافأة الدعوة!',
        bodyAr: `صديقك أكمل أول طلب له — حصلت على ${settings.inviter_reward_points} نقطة`,
      });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }
}
