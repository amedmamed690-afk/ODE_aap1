import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { Server as SocketServer } from 'socket.io';
import { authenticate, requireRole } from '../../common/auth.middleware';
import { NotificationsService } from '../notifications/notifications.service';

const haversineKm = (lat1: number, lng1: number, lat2: number, lng2: number) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

/**
 * Core ride request + lifecycle (item 5). This is a different concern
 * from every other rides-adjacent module already in this codebase:
 * ride-sharing.routes.ts only does live-tracking links + emergency
 * contacts; negotiation.routes.ts only does the "أودي ماكس" price-offer
 * flow on top of a ride that already exists here; convoy.routes.ts only
 * groups already-created rides together. None of them create a ride or
 * drive it through pending -> ... -> completed, so nothing here
 * duplicates them.
 */
export function ridesRouter(db: Pool, io: SocketServer) {
  const router = Router();
  const notifications = new NotificationsService(db);

  router.get('/categories', async (req, res) => {
    const group = req.query.group as string | undefined;
    const { rows } = await db.query(
      `SELECT id, name_ar, name_en, group_type, capacity_hint, base_fare, rate_per_km
       FROM ride_categories WHERE domain = 'ride' AND is_active = true
       ${group ? 'AND group_type = $1' : ''} ORDER BY sort_order`,
      group ? [group] : []
    );
    res.json(rows);
  });

  const pointSchema = z.object({ lat: z.number(), lng: z.number() });
  const estimateSchema = z.object({
    pickup: pointSchema, dropoff: pointSchema,
    categoryId: z.string().uuid(), routePreference: z.enum(['fastest', 'cheapest']).optional(),
  });

  router.post('/estimate', authenticate(db), async (req, res) => {
    const parsed = estimateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const { pickup, dropoff, categoryId } = parsed.data;

    const { rows: [category] } = await db.query(
      `SELECT base_fare, rate_per_km FROM ride_categories WHERE id = $1`, [categoryId]
    );
    if (!category) return res.status(404).json({ error: 'category_not_found' });

    const distanceKm = haversineKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
    const estimatedFare = Number(category.base_fare) + distanceKm * Number(category.rate_per_km);
    res.json({ distanceKm: Number(distanceKm.toFixed(2)), estimatedFare: Number(estimatedFare.toFixed(2)) });
  });

  const requestSchema = z.object({
    pickup: pointSchema, dropoff: pointSchema,
    currencyId: z.number(), categoryId: z.string().uuid(),
    isFocusMode: z.boolean().default(false),
    routePreference: z.enum(['fastest', 'cheapest']).default('fastest'),
    pricingMode: z.enum(['fixed', 'negotiated']).default('fixed'),
  });

  router.post('/', authenticate(db), requireRole('customer'), async (req, res) => {
    const parsed = requestSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    const { rows: [category] } = await db.query(
      `SELECT base_fare, rate_per_km FROM ride_categories WHERE id = $1`, [d.categoryId]
    );
    if (!category) return res.status(404).json({ error: 'category_not_found' });
    const distanceKm = haversineKm(d.pickup.lat, d.pickup.lng, d.dropoff.lat, d.dropoff.lng);
    const estimatedFare = Number(category.base_fare) + distanceKm * Number(category.rate_per_km);

    const { rows: [ride] } = await db.query(
      `INSERT INTO rides
        (customer_id, status, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
         estimated_fare, currency_id, category_id, is_focus_mode, route_preference, pricing_mode)
       VALUES ($1,'requested',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       RETURNING id`,
      [req.auth!.userId, d.pickup.lat, d.pickup.lng, d.dropoff.lat, d.dropoff.lng,
       estimatedFare, d.currencyId, d.categoryId, d.isFocusMode, d.routePreference, d.pricingMode]
    );

    // negotiated (أودي ماكس) rides wait for the customer to open the
    // negotiation flow themselves — nothing to broadcast yet.
    if (d.pricingMode === 'fixed') {
      const { rows: nearbyDrivers } = await db.query(
        `SELECT d.id FROM drivers d
         JOIN driver_ride_categories drc ON drc.driver_id = d.id
         WHERE drc.ride_category_id = $1 AND d.status = 'available' AND d.approval_status = 'active'
         ORDER BY ((d.current_lat - $2)^2 + (d.current_lng - $3)^2) ASC
         LIMIT 10`,
        [d.categoryId, d.pickup.lat, d.pickup.lng]
      );
      for (const driver of nearbyDrivers) {
        io.to(`driver:${driver.id}`).emit('ride:new_request', { rideId: ride.id, estimatedFare });
      }
    }

    res.status(201).json({ id: ride.id, estimatedFare });
  });

  router.get('/:id', authenticate(db), async (req, res) => {
    const { rows: [ride] } = await db.query(
      `SELECT r.*, d.plate_number, d.vehicle_type, d.current_lat AS driver_lat, d.current_lng AS driver_lng,
              u.full_name AS driver_name, d.rating_avg
       FROM rides r
       LEFT JOIN drivers d ON d.id = r.driver_id
       LEFT JOIN users u ON u.id = d.user_id
       WHERE r.id = $1 AND (r.customer_id = $2 OR d.user_id = $2)`,
      [req.params.id, req.auth!.userId]
    );
    if (!ride) return res.status(404).json({ error: 'ride_not_found' });
    res.json(ride);
  });

  router.get('/', authenticate(db), requireRole('customer'), async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, status, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
              estimated_fare, final_fare, requested_at, completed_at
       FROM rides WHERE customer_id = $1 ORDER BY requested_at DESC LIMIT 50`,
      [req.auth!.userId]
    );
    res.json(rows);
  });

  router.patch('/:id/accept', authenticate(db), requireRole('driver'), async (req, res) => {
    const { rows: [driver] } = await db.query(`SELECT id FROM drivers WHERE user_id = $1`, [req.auth!.userId]);
    const { rows: [ride] } = await db.query(
      `UPDATE rides SET status = 'driver_assigned', driver_id = $1
       WHERE id = $2 AND status = 'requested' RETURNING customer_id`,
      [driver.id, req.params.id]
    );
    if (!ride) return res.status(409).json({ error: 'ride_already_taken_or_not_found' });
    await db.query(`UPDATE drivers SET status = 'busy' WHERE id = $1`, [driver.id]);
    io.to(`user:${ride.customer_id}`).emit('ride:driver_assigned', { rideId: req.params.id });
    await notifications.send(ride.customer_id, {
      type: 'driver', titleAr: 'تم تعيين سائق لرحلتك', referenceType: 'ride', referenceId: req.params.id,
    });
    res.json({ message: 'تم قبول الرحلة' });
  });

  const lifecycleStep = (from: string, to: string, event: string) =>
    async (req: any, res: any) => {
      const { rows: [ride] } = await db.query(
        `UPDATE rides SET status = $1 WHERE id = $2 AND status = $3
         RETURNING customer_id, driver_id, estimated_fare`,
        [to, req.params.id, from]
      );
      if (!ride) return res.status(409).json({ error: `ride_not_in_${from}_status` });
      io.to(`user:${ride.customer_id}`).emit(event, { rideId: req.params.id });

      if (to === 'completed') {
        await db.query(`UPDATE rides SET final_fare = estimated_fare, completed_at = now() WHERE id = $1`, [req.params.id]);
        await db.query(`UPDATE drivers SET status = 'available' WHERE id = $1`, [ride.driver_id]);
        const fare = Number(ride.estimated_fare) || 0;
        const { rows: [driver] } = await db.query(
          `UPDATE drivers SET balance = balance + $1, total_earned = total_earned + $1
           WHERE id = $2 RETURNING balance`,
          [fare, ride.driver_id]
        );
        await db.query(
          `INSERT INTO driver_wallet_transactions (driver_id, type, amount, balance_after, reference_type, reference_id)
           VALUES ($1, 'ride_earning', $2, $3, 'ride', $4)`,
          [ride.driver_id, fare, driver.balance, req.params.id]
        );
        await notifications.send(ride.customer_id, {
          type: 'order', titleAr: 'انتهت رحلتك', bodyAr: 'نتمنى إنك وصلت بسلامة — قيّم السائق الآن',
          referenceType: 'ride', referenceId: req.params.id,
        });
      }
      res.json({ message: 'تم التحديث' });
    };

  router.patch('/:id/arrived', authenticate(db), requireRole('driver'), lifecycleStep('driver_assigned', 'driver_arrived', 'ride:driver_arrived'));
  router.patch('/:id/start', authenticate(db), requireRole('driver'), lifecycleStep('driver_arrived', 'in_progress', 'ride:started'));
  router.patch('/:id/complete', authenticate(db), requireRole('driver'), lifecycleStep('in_progress', 'completed', 'ride:completed'));

  // بند 20: بعد مرور 5 دقائق من قبول السائق، الإلغاء العادي يتطلب سبب
  // ويُسجَّل — القيمة قابلة للتعديل من Admin لاحقًا (config module).
  const cancelSchema = z.object({ reason: z.string().optional() });
  router.post('/:id/cancel', authenticate(db), async (req, res) => {
    const parsed = cancelSchema.safeParse(req.body);
    const isCustomer = req.auth!.role === 'customer';
    const { rows: [ride] } = await db.query(
      `UPDATE rides SET status = 'cancelled', cancelled_by = $1, cancellation_reason = $2
       WHERE id = $3 AND status NOT IN ('completed','cancelled')
       AND (customer_id = $4 OR driver_id IN (SELECT id FROM drivers WHERE user_id = $4))
       RETURNING driver_id, customer_id`,
      [isCustomer ? 'customer' : 'driver', parsed.data?.reason ?? null, req.params.id, req.auth!.userId]
    );
    if (!ride) return res.status(409).json({ error: 'cannot_cancel_this_ride' });
    if (ride.driver_id) await db.query(`UPDATE drivers SET status = 'available' WHERE id = $1`, [ride.driver_id]);

    const targetRoom = isCustomer ? `driver:${ride.driver_id}` : `user:${ride.customer_id}`;
    io.to(targetRoom).emit('ride:cancelled', { rideId: req.params.id });
    res.json({ message: 'تم إلغاء الرحلة' });
  });

  const rateSchema = z.object({ rating: z.number().int().min(1).max(5) });
  router.post('/:id/rate', authenticate(db), requireRole('customer'), async (req, res) => {
    const parsed = rateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

    const { rows: [ride] } = await db.query(
      `UPDATE rides SET rating = $1 WHERE id = $2 AND customer_id = $3 AND status = 'completed'
       RETURNING driver_id`,
      [parsed.data.rating, req.params.id, req.auth!.userId]
    );
    if (!ride) return res.status(409).json({ error: 'ride_not_completed_or_not_found' });

    await db.query(
      `UPDATE drivers SET rating_avg = (SELECT AVG(rating) FROM rides WHERE driver_id = $1 AND rating IS NOT NULL)
       WHERE id = $1`,
      [ride.driver_id]
    );
    res.json({ message: 'تم إرسال التقييم' });
  });

  return router;
}
