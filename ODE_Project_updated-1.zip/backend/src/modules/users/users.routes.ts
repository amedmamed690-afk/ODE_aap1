import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/** Generic "my profile" endpoints — profile_screen.dart needs this and
 *  nothing in the codebase provided it yet. */
export function usersRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/me', async (req, res) => {
    const { rows: [user] } = await db.query(
      `SELECT id, phone, email, full_name, role, preferred_language, avatar_url
       FROM users WHERE id = $1`,
      [req.auth!.userId]
    );
    if (!user) return res.status(404).json({ error: 'user_not_found' });
    res.json(user);
  });

  const updateSchema = z.object({
    fullName: z.string().min(2).optional(),
    avatarUrl: z.string().url().optional(),
    preferredLanguage: z.enum(['ar', 'en']).optional(),
    fcmToken: z.string().optional(),
  });

  router.patch('/me', async (req, res) => {
    const parsed = updateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    await db.query(
      `UPDATE users SET
         full_name = COALESCE($1, full_name),
         avatar_url = COALESCE($2, avatar_url),
         preferred_language = COALESCE($3, preferred_language),
         fcm_token = COALESCE($4, fcm_token)
       WHERE id = $5`,
      [d.fullName ?? null, d.avatarUrl ?? null, d.preferredLanguage ?? null, d.fcmToken ?? null, req.auth!.userId]
    );
    res.json({ message: 'تم تحديث الملف الشخصي' });
  });

  return router;
}
