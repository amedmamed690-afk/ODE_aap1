import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * Item 14: "لا تجعل Google Maps API Key مكتوبًا مباشرة داخل Source Code".
 * There are actually TWO different Google Maps keys in a real app, and
 * they get different treatment:
 *
 *  1. The *mobile SDK* key (renders map tiles on-device) — this one
 *     unavoidably lives in native config (AndroidManifest.xml /
 *     AppDelegate.swift), because that's how the Google Maps SDK works.
 *     It's made safe by *restricting* it (Android package name + SHA-1,
 *     iOS bundle ID) in Google Cloud Console — never by hiding it.
 *  2. The *server-side* key (Places Autocomplete, Directions, Geocoding)
 *     — THIS is the one the spec item is really about, and it never
 *     touches the Flutter apps at all. Every proxy route below adds it
 *     server-side from GOOGLE_MAPS_API_KEY; the client only ever talks
 *     to our own backend.
 *
 * MAPS_PROVIDER stays swappable (item 35) — swapping to Mapbox/HERE
 * later only means changing the fetch calls in this one file.
 */
export function mapsRouter(db: Pool) {
  const router = Router();
  router.use(authenticate(db));

  router.get('/autocomplete', async (req, res) => {
    const input = req.query.input as string;
    const sessionToken = req.query.sessionToken as string | undefined;
    if (!input) return res.status(400).json({ error: 'input_required' });

    const url = new URL('https://maps.googleapis.com/maps/api/place/autocomplete/json');
    url.searchParams.set('input', input);
    url.searchParams.set('language', 'ar');
    url.searchParams.set('key', process.env.GOOGLE_MAPS_API_KEY!);
    if (sessionToken) url.searchParams.set('sessiontoken', sessionToken);

    const response = await fetch(url.toString());
    const data = await response.json();
    res.json((data.predictions || []).map((p: any) => ({ placeId: p.place_id, description: p.description })));
  });

  router.get('/place-details', async (req, res) => {
    const placeId = req.query.placeId as string;
    if (!placeId) return res.status(400).json({ error: 'placeId_required' });

    const url = new URL('https://maps.googleapis.com/maps/api/place/details/json');
    url.searchParams.set('place_id', placeId);
    url.searchParams.set('fields', 'geometry,formatted_address');
    url.searchParams.set('key', process.env.GOOGLE_MAPS_API_KEY!);

    const response = await fetch(url.toString());
    const data = await response.json();
    if (!data.result) return res.status(404).json({ error: 'place_not_found' });
    res.json({
      lat: data.result.geometry.location.lat,
      lng: data.result.geometry.location.lng,
      address: data.result.formatted_address,
    });
  });

  router.get('/reverse-geocode', async (req, res) => {
    const lat = req.query.lat as string;
    const lng = req.query.lng as string;
    const url = new URL('https://maps.googleapis.com/maps/api/geocode/json');
    url.searchParams.set('latlng', `${lat},${lng}`);
    url.searchParams.set('language', 'ar');
    url.searchParams.set('key', process.env.GOOGLE_MAPS_API_KEY!);

    const response = await fetch(url.toString());
    const data = await response.json();
    res.json({ address: data.results?.[0]?.formatted_address ?? null });
  });

  router.get('/directions', async (req, res) => {
    const { originLat, originLng, destLat, destLng } = req.query;
    const url = new URL('https://maps.googleapis.com/maps/api/directions/json');
    url.searchParams.set('origin', `${originLat},${originLng}`);
    url.searchParams.set('destination', `${destLat},${destLng}`);
    url.searchParams.set('key', process.env.GOOGLE_MAPS_API_KEY!);

    const response = await fetch(url.toString());
    const data = await response.json();
    const route = data.routes?.[0];
    if (!route) return res.status(404).json({ error: 'no_route_found' });
    res.json({
      polyline: route.overview_polyline.points, // مُرمّز — يُفكّ بالتطبيق عبر flutter_polyline_points أو مكتبة مشابهة
      distanceMeters: route.legs[0].distance.value,
      durationSeconds: route.legs[0].duration.value,
    });
  });

  return router;
}
