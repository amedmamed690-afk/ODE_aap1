import { Router } from 'express';
import { Pool } from 'pg';
import { authenticate } from '../../common/auth.middleware';

/**
 * ODE's own first-party store (item 7's "ODE براند" tile) — distinct
 * from the third-party `products` table (those belong to `partners`).
 * Matches ode_brand_screen.dart's paging/search/category-filter UI and
 * home_controller.dart's simpler `?limit=` call on the same endpoint.
 */
export function odeBrandRouter(db: Pool) {
  const router = Router();

  router.get('/categories', async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, name_ar AS "nameAr" FROM ode_brand_categories WHERE is_active = true ORDER BY sort_order`
    );
    res.json(rows);
  });

  router.get('/products', authenticate(db), async (req, res) => {
    const { categoryId, search, page, limit } = req.query;
    const pageSize = limit ? Number(limit) : 20;
    const offset = page ? (Number(page) - 1) * pageSize : 0;

    const conditions = ['p.is_active = true', 'p.stock_qty > 0'];
    const params: any[] = [];
    if (categoryId) { params.push(categoryId); conditions.push(`p.category_id = $${params.length}`); }
    if (search) { params.push(`%${search}%`); conditions.push(`p.name_ar ILIKE $${params.length}`); }
    params.push(pageSize, offset);

    const { rows } = await db.query(
      `SELECT p.id, p.name_ar, p.price, c.code AS currency_code, p.image_url, 'ODE' AS store_name
       FROM ode_brand_products p JOIN currencies c ON c.id = p.currency_id
       WHERE ${conditions.join(' AND ')}
       ORDER BY p.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    res.json(rows);
  });

  router.get('/products/:id', authenticate(db), async (req, res) => {
    const { rows: [product] } = await db.query(
      `SELECT p.*, c.code AS currency_code FROM ode_brand_products p
       JOIN currencies c ON c.id = p.currency_id WHERE p.id = $1`,
      [req.params.id]
    );
    if (!product) return res.status(404).json({ error: 'product_not_found' });
    res.json(product);
  });

  return router;
}
