import { Router } from 'express';
import { z } from 'zod';
import { Pool } from 'pg';
import jwt from 'jsonwebtoken';
import { authenticate } from '../../common/auth.middleware';

/**
 * Driver-side equivalent of partner-onboarding (that module already
 * existed; this one didn't, even though the driver Flutter app has full
 * screens for it — vehicle_category_screen.dart / category_picker_screen.dart
 * / driver_onboarding_controller.dart all call these exact paths).
 *
 * Auth model matches partner-onboarding exactly: the caller already has a
 * real (if role='customer') JWT from /auth/otp/verify — driver
 * registration promotes that same account rather than minting a second
 * one, same as partner-onboarding does for `partner_owner`.
 *
 * Table shapes follow what negotiation.service.ts already assumes
 * elsewhere in this codebase (`d.approval_status = 'active'`,
 * `driver_ride_categories drc ON drc.driver_id = d.id` as a many-to-many
 * pivot) rather than inventing a new shape.
 */
export function driverOnboardingRouter(db: Pool) {
  const router = Router();

  // domain: 'delivery' | 'ride' — matches vehicle_category_screen.dart
  router.get('/options', async (req, res) => {
    const domain = req.query.domain as string | undefined;
    if (domain !== 'delivery' && domain !== 'ride') {
      return res.status(400).json({ error: 'domain_must_be_delivery_or_ride' });
    }
    const { rows } = await db.query(
      `SELECT id, name_ar AS "nameAr", name_en AS "nameEn" FROM ride_categories
       WHERE domain = $1 AND is_active = true ORDER BY sort_order`,
      [domain]
    );
    res.json(rows);
  });

  const submitSchema = z.object({
    categoryId: z.string().uuid(),
    vehicleType: z.enum(['motorbike', 'car', 'van', 'tow_truck', 'moving_truck']),
    plateNumber: z.string().min(2),
    countryId: z.number(),
    licenseDocUrl: z.string().min(3), // مفتاح تخزين داخلي (bucket منفصل غير عام) — بند 8، مش رابط عام
  });

  router.post('/submit', authenticate(db), async (req, res) => {
    const parsed = submitSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    const d = parsed.data;

    const client = await db.connect();
    try {
      await client.query('BEGIN');

      const { rows: [existingDriver] } = await client.query(
        `SELECT id FROM drivers WHERE user_id = $1`, [req.auth!.userId]
      );
      if (existingDriver) throw new Error('driver_application_already_exists');

      const { rows: [category] } = await client.query(
        `SELECT domain FROM ride_categories WHERE id = $1`, [d.categoryId]
      );
      if (!category) throw new Error('invalid_category');

      const { rows: [driver] } = await client.query(
        `INSERT INTO drivers
          (user_id, country_id, capability, vehicle_type, plate_number, license_doc_url, status, approval_status)
         VALUES ($1,$2,$3,$4,$5,$6,'offline','pending')
         RETURNING id`,
        [req.auth!.userId, d.countryId, category.domain === 'ride' ? 'ride' : 'delivery', d.vehicleType, d.plateNumber, d.licenseDocUrl]
      );

      await client.query(
        `INSERT INTO driver_ride_categories (driver_id, ride_category_id) VALUES ($1, $2)`,
        [driver.id, d.categoryId]
      );

      // ترقية الحساب من customer إلى driver.
      await client.query(`UPDATE users SET role = 'driver' WHERE id = $1`, [req.auth!.userId]);

      await client.query('COMMIT');

      // item 28 (audit): the OLD token in the client's hand still says
      // role='customer' with no driverId claim — every driver-only route
      // (requireRole('driver')) would 403 it immediately after this call
      // succeeds. Ship a fresh token reflecting the upgrade right here
      // instead of making the client silently hold a now-wrong token
      // until their next full login.
      const freshToken = jwt.sign(
        { userId: req.auth!.userId, role: 'driver', driverId: driver.id },
        process.env.JWT_SECRET!, { expiresIn: '30d' }
      );

      res.status(201).json({
        message: 'تم تقديم طلبك بنجاح، وهو الآن في انتظار موافقة الإدارة',
        driverId: driver.id,
        status: 'pending',
        token: freshToken,
      });
    } catch (e: any) {
      await client.query('ROLLBACK');
      res.status(400).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  // driver_auth_provider.dart calls this right after OTP verify — 404 means
  // "no application yet" (-> newRegistration), otherwise the current status.
  router.get('/my-status', authenticate(db), async (req, res) => {
    const { rows: [driver] } = await db.query(
      `SELECT approval_status, rejected_reason FROM drivers WHERE user_id = $1`,
      [req.auth!.userId]
    );
    if (!driver) return res.status(404).json({ error: 'no_application_found' });
    res.json({ approval_status: driver.approval_status, rejected_reason: driver.rejected_reason });
  });

  return router;
}
