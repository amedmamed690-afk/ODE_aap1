import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { Pool } from 'pg';

// Every JWT issued at login encodes role + the scoping id(s) needed to
// restrict data access. This payload is the single source of truth for
// "who can see what" — endpoints never trust an id sent in the request body.
export interface AuthPayload {
  userId: string;
  role: 'customer' | 'partner_owner' | 'driver' | 'admin' | 'support';
  partnerId?: string;   // present only for partner_owner tokens
  driverId?: string;    // present only for driver tokens
  adminId?: string;     // present only for admin/support tokens
  isSuperAdmin?: boolean;
  permissions?: string[];
  sessionId?: string;   // طلب صريح (بند 6): معرّف جلسة admin_sessions — يسمح بإبطالها فعليًا
}

declare global {
  namespace Express {
    interface Request {
      auth?: AuthPayload;
    }
  }
}

/**
 * authenticate(db) — factory, not a bare middleware.
 *
 * NOTE (Phase 2 fix): 7 of the 9 route modules in this codebase already
 * called `authenticate(db)`, but the auth middleware that shipped with the
 * project exported a plain no-arg function — meaning most routes would have
 * failed to compile against it. This now matches the convention the
 * majority of call sites already use.
 *
 * Why db is needed at all: trusting the JWT payload alone means a user
 * blocked *after* their token was issued keeps full access until the token
 * expires. We re-check live status on every request instead — the extra
 * query is cheap (indexed PK lookup) and it's the only way "إيقاف الحسابات"
 * (blocking an account from Admin) takes effect immediately.
 */
export function authenticate(db: Pool) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'missing_token' });
    }

    let payload: AuthPayload;
    try {
      const token = header.slice(7);
      payload = jwt.verify(token, process.env.JWT_SECRET!) as AuthPayload;
    } catch {
      return res.status(401).json({ error: 'invalid_token' });
    }

    try {
      const { rows: [user] } = await db.query(
        `SELECT is_blocked FROM users WHERE id = $1`,
        [payload.userId]
      );
      if (!user || user.is_blocked) {
        return res.status(403).json({ error: 'account_blocked' });
      }

      if (payload.role === 'driver' && payload.driverId) {
        // item 29 (audit): this was checking `status` (offline/available/
        // busy/suspended — an *operational* flag) instead of
        // `approval_status` (pending/active/rejected/suspended — the
        // actual admin gate). A driver who was never approved, or was
        // explicitly rejected, still defaults to status='offline' and
        // would have sailed straight through this check.
        const { rows: [driver] } = await db.query(
          `SELECT approval_status FROM drivers WHERE id = $1`,
          [payload.driverId]
        );
        if (!driver || driver.approval_status === 'suspended' || driver.approval_status === 'rejected') {
          return res.status(403).json({ error: 'driver_suspended' });
        }
      }

      if (payload.role === 'partner_owner' && payload.partnerId) {
        const { rows: [partner] } = await db.query(
          `SELECT status FROM partners WHERE id = $1`,
          [payload.partnerId]
        );
        if (!partner || partner.status === 'suspended' || partner.status === 'rejected') {
          return res.status(403).json({ error: 'partner_suspended' });
        }
      }

      // طلب صريح (بند 6): "إمكانية إبطال الجلسات عند الحاجة من النظام" —
      // توقيع JWT الصحيح وحده غير كافٍ لجلسة أدمن؛ لازم صفها بـ
      // admin_sessions لا يزال فعّالاً (غير مُبطَل، غير منتهي الصلاحية).
      // تسجيل الخروج أو إبطال جلسة من جهاز آخر يصير نافذًا فورًا بهذا،
      // بعكس التوكن العادي اللي يبقى صالحًا حتى انتهاء صلاحيته الطبيعية.
      if (payload.role === 'admin' && payload.sessionId) {
        const { rows: [session] } = await db.query(
          `SELECT revoked_at, expires_at FROM admin_sessions WHERE id = $1`,
          [payload.sessionId]
        );
        if (!session || session.revoked_at || new Date(session.expires_at).getTime() < Date.now()) {
          return res.status(401).json({ error: 'session_revoked' });
        }
        // تحديث "آخر ظهور" بأفضل جهد — لا نمنع الطلب لو فشل هذا التحديث لأي سبب
        db.query(`UPDATE admin_sessions SET last_seen_at = now() WHERE id = $1`, [payload.sessionId]).catch(() => {});
      }

      req.auth = payload;
      next();
    } catch (e) {
      next(e);
    }
  };
}

// Restricts a route to one or more roles, e.g. requireRole('admin')
export function requireRole(...roles: AuthPayload['role'][]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth || !roles.includes(req.auth.role)) {
      return res.status(403).json({ error: 'forbidden' });
    }
    next();
  };
}

// بند 8: "لا تجعل كل موظف يمتلك صلاحيات Super Admin" — صلاحية محددة
// واحدة على الأقل مطلوبة، إلا لو كان الحساب Super Admin (كل الصلاحيات
// ضمنيًا). يُستخدم بعد requireRole('admin') دايمًا، مو بدلاً عنه.
export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.auth?.isSuperAdmin) return next();
    if (!req.auth?.permissions?.includes(permission)) {
      return res.status(403).json({ error: 'missing_permission', required: permission });
    }
    next();
  };
}

export function requireSuperAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.auth?.isSuperAdmin) return res.status(403).json({ error: 'super_admin_only' });
  next();
}
