import { Pool } from 'pg';

/**
 * يُستدعى من endpoint تسجيل العميل (auth/register/complete) قبل إنشاء
 * حساب عميل عادي — يمنع أي رقم مسجّل مسبقاً كشريك (partner_owner) من
 * فتح حساب عميل عادي بنفس الرقم، ويرجّع رسالة واضحة بدل خطأ عام.
 *
 * ملاحظة: نتحقق من partners.primary_phone (رقم التسجيل الرسمي) وليس
 * فقط users.phone، لأن بعض الحقول بتفاصيل التسجيل (كالرقم الوطني)
 * ممكن تُدخل بأرقام مختلفة شوي عن رقم الدخول العادي.
 */
export async function assertPhoneNotRegisteredAsPartner(db: Pool, phone: string) {
  const { rows: [existingPartnerUser] } = await db.query(
    `SELECT p.id FROM partners p
     JOIN users u ON u.id = p.owner_user_id
     WHERE u.phone = $1 OR p.primary_phone = $1`,
    [phone]
  );

  if (existingPartnerUser) {
    throw new PhoneAlreadyPartnerError();
  }
}

export class PhoneAlreadyPartnerError extends Error {
  constructor() {
    super('phone_already_registered_as_partner');
  }

  get userMessage() {
    return 'هذا الرقم مسجّل بالفعل في قائمة الشركاء بـ ODE';
  }
}
