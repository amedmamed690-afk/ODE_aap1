/**
 * "مغلق تلقائياً خارج أوقات العمل" (بند 8) — بدل ما نعتمد على مهمة
 * مجدولة (Cron) تحدّث is_open_now كل دقيقة (بطيء ومكلف)، نحسبها لحظياً
 * وقت أي طلب فعلي (فتح المتجر، أو محاولة إنشاء طلب) — نتيجة دايماً
 * دقيقة، وبدون أي بنية تحتية إضافية للجدولة.
 */
export function isBranchOpenNow(opensAt: string | null, closesAt: string | null, now: Date = new Date()): boolean {
  if (!opensAt || !closesAt) return true; // لو ما حددش أوقات عمل، نعتبره مفتوح دايماً

  const [openH, openM] = opensAt.split(':').map(Number);
  const [closeH, closeM] = closesAt.split(':').map(Number);
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const openMinutes = openH * 60 + openM;
  const closeMinutes = closeH * 60 + closeM;

  // يدعم أوقات عمل تتخطى منتصف الليل (مثلاً يفتح 4 عصراً ويقفل 2 فجراً)
  if (closeMinutes < openMinutes) {
    return nowMinutes >= openMinutes || nowMinutes < closeMinutes;
  }
  return nowMinutes >= openMinutes && nowMinutes < closeMinutes;
}
