import { Pool, PoolClient } from 'pg';

/**
 * قراءة موحّدة لإعدادات app_settings — طلب صريح (نظام إعدادات مركزي، بند
 * 4): "لا تستخدم Boolean محلي داخل Flutter فقط... يجب أن تكون هذه
 * الإعدادات محفوظة بشكل دائم في قاعدة البيانات". هذه الدالة هي نقطة
 * القراءة الوحيدة المستخدمة من نقاط التحقق الحرجة بالباك إند (order-flow،
 * orders.routes) — تُقرأ من نفس الجدول اللي GET /config/bootstrap
 * يقدّمه أصلاً لكل تطبيق، فلا يوجد أي احتمال لتعارض القيم بين ما يقرأه
 * العميل وما يتحقق منه الباك إند فعليًا.
 */
export async function getAppSettingBool(
  dbOrClient: Pool | PoolClient, key: string, defaultValue: boolean
): Promise<boolean> {
  const { rows: [row] } = await dbOrClient.query(`SELECT value FROM app_settings WHERE key = $1`, [key]);
  if (!row) return defaultValue;
  // value مخزّنة JSONB — قد ترجع true/false مباشرة أو كنص، نتعامل مع الاثنين
  return row.value === true || row.value === 'true';
}

/** خريطة orderType → مفتاح إعداد الخدمة المقابل له — مكان واحد للتعديل
 *  لو أُضيف نوع طلب جديد مستقبلًا. */
export function serviceSettingKeyForOrderType(orderType: string): string {
  switch (orderType) {
    case 'food': return 'services.restaurants.enabled';
    case 'store': return 'services.stores.enabled';
    case 'pharmacy': return 'services.stores.enabled'; // الصيدليات جزء من نفس فئة المتاجر بالـschema الحالي
    case 'parcel': return 'services.parcel.enabled';
    default: return `services.${orderType}.enabled`;
  }
}
