import express from 'express';
import http from 'http';
import { Server as SocketServer } from 'socket.io';
import { Pool } from 'pg';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';

import { ordersRouter } from './modules/orders/orders.routes';
import { configRouter } from './modules/config/config.routes';
import { partnersRouter } from './modules/partners/partners.routes';
import { partnerOnboardingRouter } from './modules/onboarding/onboarding.routes';
import { pickupRouter } from './modules/pickup/pickup.routes';
import { rideSharingRouter } from './modules/ride-sharing/ride-sharing.routes';
import { negotiationRouter } from './modules/negotiation/negotiation.routes';
import { convoyRouter } from './modules/convoy/convoy.routes';
import { fileUploadRouter } from './modules/uploads/file-upload.routes';
import { authRouter } from './modules/auth/auth.routes';
import { driverOnboardingRouter } from './modules/driver-onboarding/driver-onboarding.routes';
import { driverRouter } from './modules/driver/driver.routes';
import { driverEarningsRouter } from './modules/driver-earnings/driver-earnings.routes';
import { ridesRouter } from './modules/rides/rides.routes';
import { homeServicesRouter } from './modules/home-services/home-services.routes';
import { marketingRouter } from './modules/marketing/marketing.routes';
import { odeBrandRouter } from './modules/ode-brand/ode-brand.routes';
import { walletRouter } from './modules/wallet/wallet.routes';
import { usersRouter } from './modules/users/users.routes';
import { addressesRouter } from './modules/addresses/addresses.routes';
import { appAppearanceRouter } from './modules/appearance/app-appearance.routes';
import { notificationsRouter } from './modules/notifications/notifications.routes';
import { pointsRouter } from './modules/points/points.routes';
import { invitesRouter } from './modules/invites/invites.routes';
import { subscriptionsRouter } from './modules/subscriptions/subscriptions.routes';
import { mapsRouter } from './modules/maps/maps.routes';
import { paymentsRouter } from './modules/payments/payments.routes';
import { PaymentsService } from './modules/payments/payments.service';
import { adminAuthRouter } from './modules/admin/admin-auth.routes';
import { adminUsersRouter } from './modules/admin/admin-users.routes';
import { auditLogRouter } from './modules/admin/audit-log.routes';
import { adminApprovalsRouter } from './modules/admin/admin-approvals.routes';
import { adminCatalogRouter } from './modules/admin/admin-catalog.routes';
import { adminFinanceRouter } from './modules/admin/admin-finance.routes';
import { adminContentRouter } from './modules/admin/admin-content.routes';
import { adminOrdersRouter } from './modules/admin/admin-orders.routes';
import { supportRouter } from './modules/support/support.routes';

dotenv.config();

/**
 * Item 6/7/10 (audit): fail loudly instead of silently running with
 * placeholder/dev secrets once this is actually a production deploy.
 * Every one of these has a working dev-mode fallback (console OTP, mock
 * checkout, etc.) — the danger is only ever running those fallbacks
 * *unintentionally* in production. This is the single place that decides
 * "unintentionally" vs "chosen".
 */
function validateProductionSecrets() {
  if (process.env.NODE_ENV !== 'production') return;

  const missing: string[] = [];
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET === 'replace_with_a_long_random_string') missing.push('JWT_SECRET');
  if (!process.env.DATABASE_URL) missing.push('DATABASE_URL');
  if (!process.env.ADMIN_BOOTSTRAP_SECRET || process.env.ADMIN_BOOTSTRAP_SECRET.startsWith('replace_with')) missing.push('ADMIN_BOOTSTRAP_SECRET');
  if (!process.env.STRIPE_SECRET_KEY) missing.push('STRIPE_SECRET_KEY (payments will run in dev-mock mode)');
  if (!process.env.STRIPE_WEBHOOK_SECRET) missing.push('STRIPE_WEBHOOK_SECRET (webhook signature verification will reject every event)');
  if (!process.env.GOOGLE_MAPS_API_KEY) missing.push('GOOGLE_MAPS_API_KEY (maps proxy will fail)');
  if (!process.env.S3_BUCKET || process.env.S3_BUCKET === 'PLACEHOLDER_BUCKET_NAME') missing.push('S3_BUCKET (public uploads will fail)');
  if (!process.env.S3_ACCESS_KEY_ID || process.env.S3_ACCESS_KEY_ID === 'PLACEHOLDER_ACCESS_KEY') missing.push('S3_ACCESS_KEY_ID (uploads will fail)');
  if (!process.env.S3_SECRET_ACCESS_KEY || process.env.S3_SECRET_ACCESS_KEY === 'PLACEHOLDER_SECRET_KEY') missing.push('S3_SECRET_ACCESS_KEY (uploads will fail)');
  // بند 8 (Audit): FCM_SERVER_KEY (Legacy HTTP API) أوقفتها Google تمامًا
  // منذ يونيو 2024 — لم تعد متغيرًا فعليًا. استُبدلت بـService Account
  // JSON عبر Firebase Admin SDK (انظر notifications.service.ts).
  if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON_BASE64) missing.push('FIREBASE_SERVICE_ACCOUNT_JSON_BASE64 (push notifications will silently no-op — FCM_SERVER_KEY is deprecated by Google and no longer used)');
  if (!process.env.OTP_PROVIDER) missing.push('OTP_PROVIDER (OTP codes will only be logged to console, never sent)');
  // بند 2/17 (Audit): بدون هذا، fallback الافتراضي بالأسفل هو '*' — أخطر
  // إعداد CORS ممكن بالإنتاج (أي موقع بالعالم يقدر يفتح اتصال Socket أو
  // طلب HTTP للـAPI). لا يوجد قيمة افتراضية آمنة معقولة نخمّنها، فيجب
  // ضبطها صراحة.
  if (!process.env.SOCKET_ALLOWED_ORIGINS) missing.push('SOCKET_ALLOWED_ORIGINS (CORS would fall back to \'*\')');
  // بند 5 (Audit): مستندات حساسة (هوية/رخصة/سجل تجاري) يجب ألا تسقط أبدًا
  // بصمت بنفس bucket الصور العامة بالإنتاج.
  if (!process.env.S3_DOCUMENTS_BUCKET) missing.push('S3_DOCUMENTS_BUCKET (sensitive documents would fall back to the public bucket)');

  if (missing.length > 0) {
    console.error('⚠️  NODE_ENV=production but these secrets are missing or still placeholders:');
    missing.forEach(m => console.error('   - ' + m));
    console.error('Refusing to boot in production with incomplete configuration. Set them in your environment, or run with NODE_ENV unset/development to use dev-mode fallbacks intentionally.');
    process.exit(1);
  }
}
validateProductionSecrets();

const app = express();
const db = new Pool({ connectionString: process.env.DATABASE_URL });

// بند 2 (Audit): كان Socket.IO يستخدم origin: '*' — أي موقع بالعالم يقدر
// يفتح اتصال Socket فعليًا مصادَق عليه (المصادقة نفسها كانت سليمة، لكن
// CORS الواسع يسهّل هجمات مثل CSRF-كخدمة أو استنزاف الاتصالات). نفس القائمة
// نستخدمها لِـCORS الخاص بالـHTTP API أيضًا — كانت غائبة تمامًا بالمشروع
// (لا يوجد أي CORS middleware على الإطلاق)، وهو ما كان سيمنع admin_dashboard
// (تطبيق متصفح على origin مختلف) من الاتصال بالـAPI إطلاقًا بالإنتاج
// (المتصفح يحجب الطلب من طرفه قبل حتى وصوله للسيرفر).
const allowedOrigins = (process.env.SOCKET_ALLOWED_ORIGINS || '')
  .split(',').map(o => o.trim()).filter(Boolean);
const isDev = process.env.NODE_ENV !== 'production';
function isOriginAllowed(origin: string | undefined): boolean {
  if (!origin) return true; // same-origin / server-to-server / mobile apps (no Origin header)
  if (allowedOrigins.includes(origin)) return true;
  // بدون أي origin مضبوط بالتطوير فقط، نسمح بكل شيء حتى لا نكسر التطوير
  // المحلي — لكن هذا مستحيل بالإنتاج لأن validateProductionSecrets() أعلاه
  // يرفض الإقلاع أصلاً بدون SOCKET_ALLOWED_ORIGINS.
  return isDev && allowedOrigins.length === 0;
}

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (isOriginAllowed(origin) && origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});


// بند 22: Rate limiting. عام أولاً كخط دفاع أساسي، وأشد بكثير على
// /auth/otp/request تحديدًا — أكثر endpoint عرضة لإساءة استخدام (spam
// أو محاولة استنزاف رصيد مزود الـSMS/WhatsApp).
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
const otpRequestLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false,
  message: { error: 'too_many_otp_requests' } });

// بند أمني (اكتشاف بجولة المراجعة الحالية): /admin/auth/login كان محميًا
// فقط بالحد العام (300 طلب/15 دقيقة) — يسمح بحوالي 20 محاولة كلمة مرور
// بالدقيقة على حساب أدمن واحد، وهذا كافٍ عمليًا لهجوم تخمين كلمات مرور
// حقيقي رغم وجود bcrypt (bcrypt يبطئ الخادم نفسه، لا يمنع المهاجم من
// المحاولة). حد صارم مخصص لهذا المسار تحديدًا، بنفس نمط otpRequestLimiter.
const adminLoginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'too_many_login_attempts' } });

// MUST be registered before express.json() — Stripe's signature check
// needs the raw, untouched request body. Every other route in this file
// gets JSON parsing; this one deliberately doesn't.
app.post('/payments/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    let providerReference: string;
    if (process.env.STRIPE_WEBHOOK_SECRET) {
      const Stripe = (await import('stripe')).default;
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
      const event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'] as string, process.env.STRIPE_WEBHOOK_SECRET);
      if (event.type !== 'checkout.session.completed') return res.json({ received: true });
      providerReference = (event.data.object as any).id;
    } else {
      // dev mode: /payments/dev-checkout already confirmed it directly —
      // this branch only exists so a stray webhook call doesn't 500.
      return res.json({ received: true, note: 'dev_mode_no_webhook_secret_configured' });
    }
    // ملاحظة: `io` يُشار إليه هنا رغم إنشائه بسطر لاحق بهذا الملف — آمن
    // تمامًا لأن هذا الكود دالة callback تُنفَّذ فقط وقت وصول طلب webhook
    // فعلي، بعد اكتمال تحميل الموديول بالكامل (io يكون مُهيَّأ حينها).
    await new PaymentsService(db, io).confirmPaymentByReference(providerReference);
    res.json({ received: true });
  } catch (e) {
    console.error('payment webhook error:', e);
    res.status(400).json({ error: 'webhook_verification_failed' });
  }
});

app.use(express.json());
const httpServer = http.createServer(app);
const io = new SocketServer(httpServer, {
  cors: {
    origin: isDev && allowedOrigins.length === 0 ? '*' : allowedOrigins,
    credentials: true,
  },
});

// Each connected client joins a room scoped to its identity, so
// io.to(`user:{id}`) / `partner:{id}` / `driver:{id}` reaches only them.
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    const payload = jwt.verify(token, process.env.JWT_SECRET!) as any;
    (socket as any).auth = payload;
    next();
  } catch {
    next(new Error('unauthorized'));
  }
});

io.on('connection', (socket) => {
  const auth = (socket as any).auth;
  socket.join(`user:${auth.userId}`);
  if (auth.role === 'partner_owner') socket.join(`partner:${auth.partnerId}`);
  if (auth.role === 'driver') socket.join(`driver:${auth.driverId}`);

  // Driver app emits this every few seconds while on an active ride —
  // this is what live_tracking_screen.dart's map marker actually moves
  // off of. We persist it (so a REST poll also works as a fallback) and
  // relay it only to that ride's customer, never broadcast wide.
  socket.on('driver:location', async ({ lat, lng }: { lat: number; lng: number }) => {
    if (auth.role !== 'driver' || !auth.driverId) return;
    await db.query(`UPDATE drivers SET current_lat = $1, current_lng = $2 WHERE id = $3`, [lat, lng, auth.driverId]);

    const { rows: [activeRide] } = await db.query(
      `SELECT customer_id FROM rides WHERE driver_id = $1 AND status IN ('driver_assigned','driver_arrived','in_progress')
       ORDER BY requested_at DESC LIMIT 1`,
      [auth.driverId]
    );
    if (activeRide) {
      io.to(`user:${activeRide.customer_id}`).emit('ride:driver_location', { lat, lng });
    }
  });
});

// Public / low-privilege first
app.use('/auth/otp/request', otpRequestLimiter);
app.use('/auth', authRouter(db));
app.use('/config', configRouter(db));
app.use('/marketing', marketingRouter(db));

// Everything else requires a valid token (each router applies
// authenticate(db) / requireRole internally on its own routes)
app.use('/orders', ordersRouter(db, io));
app.use('/partners', partnersRouter(db));
app.use('/partner-onboarding', partnerOnboardingRouter(db));
app.use('/driver-onboarding', driverOnboardingRouter(db));
app.use('/driver-app', driverRouter(db));
app.use('/driver-earnings', driverEarningsRouter(db));
app.use('/pickup', pickupRouter(db, io));
app.use('/rides', ridesRouter(db, io));
app.use('/rides/negotiation', negotiationRouter(db, io));
app.use('/rides/convoy', convoyRouter(db, io));
app.use('/ride-sharing', rideSharingRouter(db));
app.use('/home-services', homeServicesRouter(db));
app.use('/ode-brand', odeBrandRouter(db));
app.use('/wallet', walletRouter(db));
app.use('/users', usersRouter(db));
// إضافة (Audit — بند D): كان موجودًا بالـDB ويُفترض ضمنيًا بـorder-flow
// (delivery_address_id) بدون أي endpoint فعلي — انظر addresses.routes.ts.
app.use('/addresses', addressesRouter(db));
// طلب صريح: تحكّم الأدمن الكامل بمظهر التطبيقات الثلاثة بدون كود —
// GET عام (بدون توكن) لأن splash_screen بكل تطبيق يستدعيه قبل تسجيل الدخول.
app.use('/app-appearance', appAppearanceRouter(db));
app.use('/notifications', notificationsRouter(db));
app.use('/points', pointsRouter(db));
app.use('/invites', invitesRouter(db));
app.use('/subscriptions', subscriptionsRouter(db));
app.use('/maps', mapsRouter(db));
app.use('/payments', paymentsRouter(db, io));
// singular /upload — matches upload_service.dart's `$baseUrl/upload` used
// by all three Flutter apps (not /uploads).
app.use('/upload', fileUploadRouter(db));

// -------- لوحة تحكم الإدارة (بند 8) --------
app.use('/admin/auth/login', adminLoginLimiter);
app.use('/admin/auth', adminAuthRouter(db));
app.use('/admin/admins', adminUsersRouter(db));
app.use('/admin/audit-log', auditLogRouter(db));
app.use('/admin', adminApprovalsRouter(db));
app.use('/admin/catalog', adminCatalogRouter(db));
app.use('/admin/finance', adminFinanceRouter(db));
app.use('/admin/content', adminContentRouter(db));
app.use('/admin', adminOrdersRouter(db));
app.use('/support', supportRouter(db));

// Centralized error handler — no endpoint above should ever crash the
// process on an unexpected error (spec item 32).
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ error: 'internal_error' });
});

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => console.log(`ODE backend running on :${PORT}`));
