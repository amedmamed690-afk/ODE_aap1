# AWS S3 — Least-Privilege IAM Policy (Audit item 6)

ODE's backend needs exactly two S3 buckets and four actions on them — nothing
else. Do **not** attach `AdministratorAccess`, `AmazonS3FullAccess`, or any
policy using `"s3:*"`. Use the policy below instead, replacing the two bucket
names with your real ones (the same values you set as `S3_BUCKET` and
`S3_DOCUMENTS_BUCKET` in the backend's environment).

## 1. IAM Policy JSON

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "OdeListBuckets",
      "Effect": "Allow",
      "Action": "s3:ListBucket",
      "Resource": [
        "arn:aws:s3:::REPLACE_WITH_S3_BUCKET",
        "arn:aws:s3:::REPLACE_WITH_S3_DOCUMENTS_BUCKET"
      ]
    },
    {
      "Sid": "OdeObjectReadWrite",
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
      "Resource": [
        "arn:aws:s3:::REPLACE_WITH_S3_BUCKET/*",
        "arn:aws:s3:::REPLACE_WITH_S3_DOCUMENTS_BUCKET/*"
      ]
    }
  ]
}
```

This explicitly **cannot**: create or delete buckets, modify IAM, modify
bucket policies, modify public-access-block settings, or touch any bucket
other than the two ARNs listed. There is no `"Resource": "*"` anywhere.

## 2. Bucket-level settings (console or Terraform, not IAM)

- `REPLACE_WITH_S3_DOCUMENTS_BUCKET`: **Block all public access = ON**.
  Objects are only ever reached via the backend's presigned URLs
  (`file-upload.routes.ts` already implements this — see item 5).
- `REPLACE_WITH_S3_BUCKET`: public-read is acceptable *only* if this bucket
  is used purely for already-public content (product photos, ad banners).
  If you'd rather keep it private too and always serve via presigned/CDN
  URLs, that also works with the same IAM policy above — no code change
  needed, since the backend already always returns whatever URL it
  generates.

## 3. Credentials: prefer an IAM Role over long-lived Access Keys

- **Backend running on AWS** (EC2, ECS, EKS, Lambda, App Runner): attach
  this policy to an **IAM Role** and assign that role to the compute
  resource. Do not set `S3_ACCESS_KEY_ID`/`S3_SECRET_ACCESS_KEY` at all in
  this case — the AWS SDK picks up the role's temporary credentials
  automatically, which is strictly more secure (no long-lived secret to
  leak or rotate).
- **Backend running outside AWS** (e.g. a non-AWS VPS): create a dedicated
  **IAM User** with *only* the policy above attached, generate an access
  key pair for it, and set `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` in
  the backend's environment. Never reuse a personal/root AWS account's
  keys for this.

## 4. What you need to do (external to this codebase)

1. Create the two buckets (or confirm their existing names).
2. Turn on "Block all public access" for the documents bucket.
3. Create the IAM policy above (Console → IAM → Policies → Create policy →
   JSON tab → paste, after replacing the bucket names).
4. Attach it to a Role (if on AWS compute) or a dedicated IAM User
   (if not), per section 3.
5. Set `S3_BUCKET`, `S3_DOCUMENTS_BUCKET`, `S3_REGION`, and — only if using
   an IAM User — `S3_ACCESS_KEY_ID`/`S3_SECRET_ACCESS_KEY` in the backend's
   production environment.

No part of this can be done from inside the code — it's genuinely AWS
console/IAM configuration, which is why it's documented here rather than
implemented as a script.
