-- =====================================================================
-- ODE SUPER APP — DATABASE SCHEMA (PostgreSQL 15+)
-- Domains covered: Customers, Partners (restaurants/stores/pharmacies),
-- Drivers, Orders (food/store/pharmacy/parcel/ride), Shorts (video),
-- Multi-country / multi-currency / multi-language, Remote Config (Admin)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. EXTENSIONS
-- ---------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis"; -- for geo queries (driver matching, radius search)

-- ---------------------------------------------------------------------
-- 1. GLOBAL / LOCALIZATION TABLES
--    (this is what lets the same app run in multiple countries)
-- ---------------------------------------------------------------------

CREATE TABLE countries (
    id              SERIAL PRIMARY KEY,
    iso_code        CHAR(2) NOT NULL UNIQUE,        -- 'SA', 'EG', 'AE'...
    name_en         VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100) NOT NULL,
    default_currency_id INT,                        -- FK set after currencies table
    default_language_code VARCHAR(5) DEFAULT 'ar',
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE currencies (
    id              SERIAL PRIMARY KEY,
    code            CHAR(3) NOT NULL UNIQUE,         -- 'SAR', 'EGP', 'USD'
    symbol          VARCHAR(10) NOT NULL,             -- 'ر.س', '$'
    name_en         VARCHAR(50) NOT NULL,
    name_ar         VARCHAR(50) NOT NULL,
    -- exchange rate relative to a base currency (e.g. USD), updated by admin or a cron job
    exchange_rate_to_base NUMERIC(18,6) NOT NULL DEFAULT 1,
    is_active       BOOLEAN DEFAULT true,
    updated_at      TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE countries
    ADD CONSTRAINT fk_country_currency
    FOREIGN KEY (default_currency_id) REFERENCES currencies(id);

CREATE TABLE languages (
    code            VARCHAR(5) PRIMARY KEY,           -- 'ar', 'en', 'fr'
    name_native     VARCHAR(50) NOT NULL,
    direction       VARCHAR(3) NOT NULL CHECK (direction IN ('ltr','rtl')),
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE cities (
    id              SERIAL PRIMARY KEY,
    country_id      INT NOT NULL REFERENCES countries(id),
    name_en         VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100) NOT NULL,
    is_active       BOOLEAN DEFAULT true
);

-- ---------------------------------------------------------------------
-- 2. USERS (CUSTOMERS) — single identity table shared by all user types
--    to simplify auth; role-specific data lives in satellite tables.
-- ---------------------------------------------------------------------

CREATE TYPE user_role AS ENUM ('customer','partner_owner','driver','admin','support');

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone           VARCHAR(20) NOT NULL UNIQUE,
    email           VARCHAR(150) UNIQUE,
    password_hash   TEXT,                              -- null if OTP-only auth
    full_name       VARCHAR(150),
    role            user_role NOT NULL DEFAULT 'customer',
    preferred_language VARCHAR(5) REFERENCES languages(code) DEFAULT 'ar',
    preferred_currency_id INT REFERENCES currencies(id),
    country_id      INT REFERENCES countries(id),
    avatar_url      TEXT,
    is_verified     BOOLEAN DEFAULT false,
    is_blocked      BOOLEAN DEFAULT false,
    fcm_token       TEXT,                               -- push notifications
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE addresses (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label           VARCHAR(50),                        -- 'Home','Work'
    city_id         INT REFERENCES cities(id),
    line1           TEXT NOT NULL,
    building_no     VARCHAR(20),
    lat             NUMERIC(10,7) NOT NULL,
    lng             NUMERIC(10,7) NOT NULL,
    is_default      BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 3. PARTNERS (restaurants / stores / pharmacies) — polymorphic via `type`
-- ---------------------------------------------------------------------

CREATE TYPE partner_type AS ENUM ('restaurant','store','pharmacy');
CREATE TYPE partner_status AS ENUM ('pending','active','suspended','rejected');

CREATE TABLE partners (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id   UUID NOT NULL REFERENCES users(id),   -- role = partner_owner
    type            partner_type NOT NULL,
    name_en         VARCHAR(150) NOT NULL,
    name_ar         VARCHAR(150) NOT NULL,
    logo_url        TEXT,
    cover_url       TEXT,
    country_id      INT NOT NULL REFERENCES countries(id),
    commission_percent NUMERIC(5,2) DEFAULT 15.00,        -- platform commission
    status          partner_status NOT NULL DEFAULT 'pending',
    -- pharmacy-specific compliance fields kept nullable so the same table serves all types
    license_number  VARCHAR(100),
    requires_prescription_default BOOLEAN DEFAULT false,
    rating_avg      NUMERIC(3,2) DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE partner_branches (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id      UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    city_id         INT REFERENCES cities(id),
    address_line    TEXT,
    lat             NUMERIC(10,7) NOT NULL,
    lng             NUMERIC(10,7) NOT NULL,
    is_open_now     BOOLEAN DEFAULT true,
    opens_at        TIME,
    closes_at       TIME,
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE categories (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id      UUID REFERENCES partners(id) ON DELETE CASCADE, -- null = global admin category
    name_en         VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100) NOT NULL,
    sort_order      INT DEFAULT 0
);

CREATE TABLE products (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id      UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    branch_id       UUID REFERENCES partner_branches(id),
    category_id     UUID REFERENCES categories(id),
    name_en         VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200) NOT NULL,
    description_en  TEXT,
    description_ar  TEXT,
    price           NUMERIC(12,2) NOT NULL,
    currency_id     INT NOT NULL REFERENCES currencies(id),
    requires_prescription BOOLEAN DEFAULT false,     -- used when partner.type = 'pharmacy'
    stock_qty       INT,                              -- null = unlimited (e.g. restaurant items)
    image_url       TEXT,
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 4. DRIVERS (delivery + ride-hailing use the same driver pool)
-- ---------------------------------------------------------------------

CREATE TYPE driver_status AS ENUM ('offline','available','busy','suspended');
CREATE TYPE service_capability AS ENUM ('delivery','ride','both');

CREATE TABLE drivers (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL UNIQUE REFERENCES users(id),  -- role = driver
    country_id      INT NOT NULL REFERENCES countries(id),
    capability      service_capability NOT NULL DEFAULT 'delivery',
    vehicle_type    VARCHAR(30),                       -- 'motorbike','car','van'
    plate_number    VARCHAR(20),
    license_doc_url TEXT,
    status          driver_status NOT NULL DEFAULT 'offline',
    current_lat     NUMERIC(10,7),
    current_lng     NUMERIC(10,7),
    last_location_at TIMESTAMPTZ,
    rating_avg      NUMERIC(3,2) DEFAULT 0,
    is_verified     BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 5. ORDERS — one polymorphic table for food/store/pharmacy/parcel,
--    plus a dedicated `rides` table for passenger trips (different
--    lifecycle: no cart, no partner, pickup/dropoff instead).
-- ---------------------------------------------------------------------

CREATE TYPE order_type AS ENUM ('food','store','pharmacy','parcel');
CREATE TYPE order_status AS ENUM (
    'pending_payment','placed','accepted_by_partner','preparing',
    'ready_for_pickup','driver_assigned','picked_up','on_the_way',
    'delivered','cancelled','rejected'
);

CREATE TABLE orders (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number    VARCHAR(20) NOT NULL UNIQUE,        -- human-readable, e.g. ODE-2026-000123
    order_type      order_type NOT NULL,
    customer_id     UUID NOT NULL REFERENCES users(id),
    partner_id      UUID REFERENCES partners(id),        -- null not expected for these types, kept nullable defensively
    branch_id       UUID REFERENCES partner_branches(id),
    driver_id       UUID REFERENCES drivers(id),
    delivery_address_id UUID REFERENCES addresses(id),
    status          order_status NOT NULL DEFAULT 'placed',
    subtotal        NUMERIC(12,2) NOT NULL,
    delivery_fee    NUMERIC(12,2) NOT NULL DEFAULT 0,
    platform_commission NUMERIC(12,2) NOT NULL DEFAULT 0,
    discount_amount NUMERIC(12,2) DEFAULT 0,
    total           NUMERIC(12,2) NOT NULL,
    currency_id     INT NOT NULL REFERENCES currencies(id),
    coupon_id       UUID,                                 -- FK added below (promotions table)
    payment_method  VARCHAR(30),                          -- 'card','cash','wallet'
    payment_status  VARCHAR(20) DEFAULT 'unpaid',
    prescription_image_url TEXT,                          -- pharmacy orders requiring Rx
    placed_at       TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE order_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id      UUID NOT NULL REFERENCES products(id),
    quantity        INT NOT NULL DEFAULT 1,
    unit_price      NUMERIC(12,2) NOT NULL,               -- snapshot at order time (price may change later)
    notes           TEXT
);

-- full audit trail of every status change — critical for the customer -> partner -> driver flow
CREATE TABLE order_status_history (
    id              BIGSERIAL PRIMARY KEY,
    order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    status          order_status NOT NULL,
    changed_by_user_id UUID REFERENCES users(id),
    note            TEXT,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 6. RIDES (passenger transport — separate lifecycle from orders)
-- ---------------------------------------------------------------------

CREATE TYPE ride_status AS ENUM (
    'requested','driver_assigned','driver_arrived','in_progress','completed','cancelled'
);

CREATE TABLE rides (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id     UUID NOT NULL REFERENCES users(id),
    driver_id       UUID REFERENCES drivers(id),
    status          ride_status NOT NULL DEFAULT 'requested',
    pickup_lat      NUMERIC(10,7) NOT NULL,
    pickup_lng      NUMERIC(10,7) NOT NULL,
    dropoff_lat     NUMERIC(10,7) NOT NULL,
    dropoff_lng     NUMERIC(10,7) NOT NULL,
    estimated_fare  NUMERIC(12,2),
    final_fare      NUMERIC(12,2),
    currency_id     INT NOT NULL REFERENCES currencies(id),
    requested_at    TIMESTAMPTZ DEFAULT now(),
    completed_at    TIMESTAMPTZ
);

-- ---------------------------------------------------------------------
-- 7. SHORTS (TikTok-style videos linked to products/partners)
-- ---------------------------------------------------------------------

CREATE TABLE shorts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id      UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    video_url       TEXT NOT NULL,
    thumbnail_url   TEXT,
    caption_en      TEXT,
    caption_ar      TEXT,
    view_count      BIGINT DEFAULT 0,
    like_count      BIGINT DEFAULT 0,
    is_published    BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE short_products (          -- which products a short promotes (many-to-many)
    short_id        UUID NOT NULL REFERENCES shorts(id) ON DELETE CASCADE,
    product_id      UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    PRIMARY KEY (short_id, product_id)
);

-- ---------------------------------------------------------------------
-- 8. PROMOTIONS / COUPONS
-- ---------------------------------------------------------------------

CREATE TABLE promotions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code            VARCHAR(30) UNIQUE,
    partner_id      UUID REFERENCES partners(id),        -- null = platform-wide coupon
    discount_type   VARCHAR(10) CHECK (discount_type IN ('percent','fixed')),
    discount_value  NUMERIC(12,2) NOT NULL,
    country_id      INT REFERENCES countries(id),
    starts_at       TIMESTAMPTZ,
    ends_at         TIMESTAMPTZ,
    max_redemptions INT,
    is_active       BOOLEAN DEFAULT true
);

ALTER TABLE orders
    ADD CONSTRAINT fk_order_coupon FOREIGN KEY (coupon_id) REFERENCES promotions(id);

-- ---------------------------------------------------------------------
-- 9. REVIEWS
-- ---------------------------------------------------------------------

CREATE TABLE reviews (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id        UUID REFERENCES orders(id),
    ride_id         UUID REFERENCES rides(id),
    customer_id     UUID NOT NULL REFERENCES users(id),
    partner_id      UUID REFERENCES partners(id),
    driver_id       UUID REFERENCES drivers(id),
    rating          SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment         TEXT,
    created_at      TIMESTAMPTZ DEFAULT now(),
    CHECK (order_id IS NOT NULL OR ride_id IS NOT NULL)
);

-- ---------------------------------------------------------------------
-- 10. REMOTE CONFIG / ADMIN-CONTROLLED CONTENT
--     This is what lets you change sections, banners, ads and currencies
--     LIVE from the admin panel, with no app store release.
-- ---------------------------------------------------------------------

-- generic key/value config, read by all clients on app start (cached, short TTL)
CREATE TABLE app_settings (
    key             VARCHAR(100) PRIMARY KEY,   -- e.g. 'home_sections_order', 'min_app_version'
    value           JSONB NOT NULL,
    country_id      INT REFERENCES countries(id), -- null = global default, overridden per-country if set
    updated_by      UUID REFERENCES users(id),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE banners (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_en        VARCHAR(150),
    title_ar        VARCHAR(150),
    image_url       TEXT NOT NULL,
    target_type     VARCHAR(20),        -- 'partner','product','url','category'
    target_id       TEXT,               -- generic pointer, resolved client-side by target_type
    country_id      INT REFERENCES countries(id), -- null = shown in all countries
    placement       VARCHAR(30) DEFAULT 'home_top', -- 'home_top','food_tab','store_tab'...
    sort_order      INT DEFAULT 0,
    starts_at       TIMESTAMPTZ,
    ends_at         TIMESTAMPTZ,
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE home_sections (           -- lets admin reorder/toggle whole sections of the home screen
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key             VARCHAR(50) NOT NULL,     -- 'featured_restaurants','shorts_feed','pharmacy_banner'
    title_en        VARCHAR(100),
    title_ar        VARCHAR(100),
    country_id      INT REFERENCES countries(id),
    sort_order      INT DEFAULT 0,
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE admin_users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL UNIQUE REFERENCES users(id), -- role = admin
    permissions     JSONB NOT NULL DEFAULT '[]', -- e.g. ["banners.write","currencies.write"]
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 11. INDEXES (performance-critical paths)
-- ---------------------------------------------------------------------

CREATE INDEX idx_products_partner ON products(partner_id);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_partner ON orders(partner_id);
CREATE INDEX idx_orders_driver ON orders(driver_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_drivers_status_location ON drivers(status, current_lat, current_lng);
CREATE INDEX idx_rides_driver ON rides(driver_id);
CREATE INDEX idx_shorts_partner ON shorts(partner_id);
CREATE INDEX idx_banners_country_placement ON banners(country_id, placement);

-- =====================================================================
-- RELATIONSHIP / ISOLATION SUMMARY (how each party sees only their data)
-- =====================================================================
-- customer  -> orders.customer_id = users.id            (sees only own orders/rides)
-- partner   -> orders.partner_id  = partners.owner_user_id-linked partner  (sees only own orders/products)
-- driver    -> orders.driver_id / rides.driver_id = drivers.id            (sees only assigned jobs)
-- admin     -> admin_users.permissions gates access to banners/app_settings/currencies
-- This isolation is enforced at the API layer (see backend/) via
-- role-based middleware + row-level WHERE clauses scoped to the JWT's
-- user_id/partner_id/driver_id — never trust a client-supplied ID.
