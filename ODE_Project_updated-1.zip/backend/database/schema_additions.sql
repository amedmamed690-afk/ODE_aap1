-- =====================================================================
-- ODE — SCHEMA ADDITIONS (Phase 2)
-- Non-destructive migration: every backend module in this codebase
-- queries tables/columns that schema.sql never defined. This file adds
-- exactly what the existing TypeScript services need to run, in the
-- order their foreign keys require. Run this AFTER schema.sql.
-- =====================================================================

-- ---------------------------------------------------------------------
-- AUTH (new module — otp.service.ts)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS otp_codes (
    id              BIGSERIAL PRIMARY KEY,
    phone           VARCHAR(20) NOT NULL,
    code_hash       TEXT NOT NULL,
    attempts        INT NOT NULL DEFAULT 0,
    expires_at      TIMESTAMPTZ NOT NULL,
    consumed_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_otp_codes_phone ON otp_codes(phone);

-- ---------------------------------------------------------------------
-- PARTNER ONBOARDING (onboarding.routes.ts references all of this)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS partner_activity_categories (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_en         VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100) NOT NULL,
    sort_order      INT DEFAULT 0,
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS partner_digital_subtypes (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_en         VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100) NOT NULL,
    sort_order      INT DEFAULT 0,
    is_active       BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS partner_documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id      UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    doc_type        VARCHAR(40) NOT NULL,  -- 'passport','business_license',...
    file_url        TEXT NOT NULL,
    uploaded_at     TIMESTAMPTZ DEFAULT now()
);

-- partners: onboarding.routes.ts / partners.routes.ts / partner-balance.service.ts
-- all read+write columns schema.sql never created.
ALTER TABLE partners ADD COLUMN IF NOT EXISTS account_type VARCHAR(20) DEFAULT 'physical'; -- 'physical' | 'digital'
ALTER TABLE partners ADD COLUMN IF NOT EXISTS digital_subtype_id UUID REFERENCES partner_digital_subtypes(id);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS activity_category_id UUID REFERENCES partner_activity_categories(id);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS owner_full_name VARCHAR(150);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS national_id_number VARCHAR(50);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS primary_phone VARCHAR(20);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS secondary_phone VARCHAR(20);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS gps_lat NUMERIC(10,7);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS gps_lng NUMERIC(10,7);
ALTER TABLE partners ADD COLUMN IF NOT EXISTS rejected_reason TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS dashboard_unlocked BOOLEAN DEFAULT false;
-- wallet-style fields used by partner-balance.service.ts (item 11: Partner Wallet)
ALTER TABLE partners ADD COLUMN IF NOT EXISTS balance NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS negative_balance_limit NUMERIC(12,2) NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_partners_primary_phone ON partners(primary_phone);

CREATE TABLE IF NOT EXISTS partner_balance_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id      UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    type            VARCHAR(30) NOT NULL, -- 'commission_deduction','topup','settlement',...
    amount          NUMERIC(12,2) NOT NULL, -- negative = debit, positive = credit
    balance_after   NUMERIC(12,2) NOT NULL,
    reference_type  VARCHAR(30),  -- 'order','manual','settlement'
    reference_id    UUID,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settlement_batches (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id          UUID NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
    period_start        TIMESTAMPTZ NOT NULL,
    period_end          TIMESTAMPTZ NOT NULL,
    gross_sales         NUMERIC(12,2) NOT NULL DEFAULT 0,
    commission_amount   NUMERIC(12,2) NOT NULL DEFAULT 0,
    net_payable         NUMERIC(12,2) NOT NULL DEFAULT 0,
    status              VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/paid
    created_at          TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- DRIVER ONBOARDING (new module — driver-onboarding.routes.ts)
-- negotiation.service.ts already assumed `d.approval_status = 'active'`
-- and a `driver_ride_categories` pivot table before either existed —
-- this section fills exactly that gap rather than inventing a new shape.
-- ---------------------------------------------------------------------
-- Postgres has no native "CREATE TYPE IF NOT EXISTS" — guard it manually
-- so this migration file stays safe to re-run.
DO $$ BEGIN
    CREATE TYPE driver_approval_status AS ENUM ('pending','active','rejected','suspended');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE drivers ADD COLUMN IF NOT EXISTS approval_status driver_approval_status NOT NULL DEFAULT 'pending';
ALTER TABLE drivers ADD COLUMN IF NOT EXISTS rejected_reason TEXT;
-- capability currently only allows 'delivery'/'ride'/'both' per schema.sql —
-- driver-onboarding.routes.ts writes 'ride' for domain='ride' applicants.

CREATE TABLE IF NOT EXISTS ride_categories (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    domain        VARCHAR(10) NOT NULL CHECK (domain IN ('delivery','ride')),
    group_type    VARCHAR(20), -- 'passenger' | 'heavy_transport' — rides_controller.dart groups by this
    name_ar       VARCHAR(100) NOT NULL,
    name_en       VARCHAR(100) NOT NULL,
    capacity_hint VARCHAR(50), -- e.g. 'حتى 4 ركاب', 'حتى 2 طن' — display-only
    base_fare     NUMERIC(10,2) NOT NULL DEFAULT 0,
    rate_per_km   NUMERIC(10,2) NOT NULL DEFAULT 0,
    sort_order    INT DEFAULT 0,
    is_active     BOOLEAN DEFAULT true
);

-- pivot, not a lookup: a driver can serve more than one category
-- (e.g. both "regular taxi" and "VIP taxi") — matches the JOIN already
-- written in negotiation.service.ts.
CREATE TABLE IF NOT EXISTS driver_ride_categories (
    driver_id         UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    ride_category_id  UUID NOT NULL REFERENCES ride_categories(id),
    PRIMARY KEY (driver_id, ride_category_id)
);

-- ---------------------------------------------------------------------
-- HOME SERVICES / HOME BUSINESSES BOOKING (item 4 domain: "خدمة توصيل" /
-- home_services_controller.dart + booking_form_screen.dart already
-- assumed this exact shape)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_services (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    country_id    INT NOT NULL REFERENCES countries(id),
    name_ar       VARCHAR(150) NOT NULL,
    name_en       VARCHAR(150) NOT NULL,
    base_price    NUMERIC(10,2) NOT NULL DEFAULT 0,
    currency_id   INT NOT NULL REFERENCES currencies(id),
    icon_url      TEXT,
    is_active     BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS home_service_providers (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_id    UUID NOT NULL REFERENCES home_services(id) ON DELETE CASCADE,
    user_id       UUID REFERENCES users(id),
    bio           TEXT,
    rating_avg    NUMERIC(3,2) DEFAULT 0,
    custom_price  NUMERIC(10,2),
    start_time    TIME NOT NULL DEFAULT '09:00',
    end_time      TIME NOT NULL DEFAULT '18:00',
    is_active     BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS home_service_bookings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_id      UUID NOT NULL REFERENCES home_services(id),
    provider_id     UUID REFERENCES home_service_providers(id),
    customer_id     UUID NOT NULL REFERENCES users(id),
    full_name       VARCHAR(150) NOT NULL,
    primary_phone   VARCHAR(20) NOT NULL,
    alt_phone       VARCHAR(20) NOT NULL,
    address_id      UUID REFERENCES addresses(id),
    scheduled_at    TIMESTAMPTZ NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/confirmed/completed/cancelled
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- MARKETING (ads / shorts feed / splash) — home_controller.dart +
-- splash_controller.dart already assumed these exact paths.
-- `banners` already has everything marketing.routes.ts needs
-- (title_ar, image_url, target_type, target_id, placement, country_id) —
-- only the splash video config was genuinely missing.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS splash_config (
    id            INT PRIMARY KEY DEFAULT 1,
    country_id    INT REFERENCES countries(id),
    video_url     TEXT,
    min_duration_ms INT DEFAULT 1500,
    CHECK (id = 1)
);


-- item 16: نظام Promotion للفيديوهات (شورت مُروَّج من الإدارة، منفصل عن
-- short_products العضوي الموجود بالفعل بـschema.sql)
CREATE TABLE IF NOT EXISTS short_promotions (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id      UUID NOT NULL REFERENCES shorts(id) ON DELETE CASCADE,
    starts_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    ends_at       TIMESTAMPTZ,
    is_active     BOOLEAN DEFAULT true
);
ALTER TABLE shorts ADD COLUMN IF NOT EXISTS sponsorship_id UUID REFERENCES short_promotions(id);
ALTER TABLE shorts ADD COLUMN IF NOT EXISTS sponsored_product_id UUID REFERENCES products(id);
ALTER TABLE shorts ADD COLUMN IF NOT EXISTS sponsored_partner_id UUID REFERENCES partners(id);

 — item 7's "ODE براند" tile,
-- distinct from third-party `products` already in schema.sql)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ode_brand_categories (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_ar       VARCHAR(100) NOT NULL,
    name_en       VARCHAR(100) NOT NULL,
    sort_order    INT DEFAULT 0,
    is_active     BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS ode_brand_products (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id   UUID REFERENCES ode_brand_categories(id),
    name_ar       VARCHAR(150) NOT NULL,
    name_en       VARCHAR(150) NOT NULL,
    description   TEXT,
    price         NUMERIC(10,2) NOT NULL,
    currency_id   INT NOT NULL REFERENCES currencies(id),
    image_url     TEXT,
    stock_qty     INT NOT NULL DEFAULT 0,
    is_active     BOOLEAN DEFAULT true,
    created_at    TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- PAYMENTS (item 30/35 — external card top-up via a pluggable gateway;
-- distinct from topup_codes, which is the admin-issued-code path)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider            VARCHAR(20) NOT NULL, -- 'stripe' | 'dev_mock' | future gateways
    provider_reference  VARCHAR(150), -- checkout session id — what the webhook looks up by
    amount              NUMERIC(12,2) NOT NULL,
    currency_id         INT NOT NULL REFERENCES currencies(id),
    status              VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/succeeded/failed
    purpose             VARCHAR(30) NOT NULL DEFAULT 'wallet_topup',
    created_at          TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_payments_provider_ref ON payments(provider_reference);

-- طلب صريح (نظام الدفع Cash + Payment Gateway): يربط دفعة بوابة دفع
-- بالطلب الذي تدفعه تحديدًا — كانت `payments` مبنية لشحن المحفظة فقط
-- (purpose='wallet_topup') بدون أي طريقة لربطها بطلب. NULL لأي دفعة
-- ليست دفع طلب (شحن محفظة مثلاً).
ALTER TABLE payments ADD COLUMN IF NOT EXISTS order_id UUID REFERENCES orders(id);

-- ---------------------------------------------------------------------
-- CENTRALIZED SERVICE / PAYMENT AVAILABILITY (طلب صريح — بند 2/3/4):
-- إعادة استخدام app_settings الموجود أصلاً (يُقرأ فعليًا من كل تطبيق عبر
-- GET /config/bootstrap الموجود من قبل) بدل جدول جديد. القيم الافتراضية
-- أدناه محافظة: كل الخدمات ووسيلتي الدفع الحقيقيتين (Cash/Wallet) مفعّلتان
-- افتراضيًا حتى لا تتعطل أي وظيفة تعمل حاليًا. Payment Gateway معطّلة
-- افتراضيًا عمدًا لأنه لا توجد بيانات مزود حقيقية بعد — بالضبط كما طُلب.
-- ---------------------------------------------------------------------
-- ADMIN SECURITY SETUP + SESSIONS (طلب صريح — بند 5/6/7): تهيئة أمان
-- إجبارية عند أول استخدام للوحة الإدارة (بريد + هاتفان يُتحقق منهما
-- بـOTP حقيقي + 3 كلمات مرور منفصلة + اسم مستخدم)، وتتبّع/إبطال الجلسات.
-- ---------------------------------------------------------------------
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS phone_2 VARCHAR(20);
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS username VARCHAR(50) UNIQUE;
-- ثلاث كلمات مرور منفصلة كما طُلب صراحة — كل واحدة بـhash مستقل (bcrypt)،
-- ولا تُخزَّن أي منها كنص صريح إطلاقًا (بند 7).
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS key_password_hash TEXT;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS reference_password_hash TEXT;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS security_setup_completed_at TIMESTAMPTZ;

-- حالة مؤقتة أثناء معالج الإعداد فقط (قبل وجود حساب admin_users فعلي) —
-- صف واحد لكل محاولة إعداد، تنتهي صلاحيته خلال 30 دقيقة إن لم تُكمَل.
CREATE TABLE IF NOT EXISTS admin_setup_sessions (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email                 VARCHAR(150) NOT NULL,
    phone_1               VARCHAR(20),
    phone_1_verified_at   TIMESTAMPTZ,
    phone_2               VARCHAR(20),
    phone_2_verified_at   TIMESTAMPTZ,
    created_at            TIMESTAMPTZ DEFAULT now(),
    expires_at            TIMESTAMPTZ DEFAULT now() + interval '30 minutes',
    consumed_at           TIMESTAMPTZ
);

-- تتبّع جلسات الأدمن الفعلية (بند 6: "دعم تسجيل الدخول من أجهزة مختلفة،
-- Sessions آمنة، إبطال الجلسات عند الحاجة"). كل توكن أدمن يُصدَر يحمل
-- jti فريدًا مطابقًا لسجل هنا — تسجيل الخروج/الإبطال يعطّل الصف، ويرفضه
-- authenticate() بغض النظر عن صلاحية توقيع الـJWT نفسه.
CREATE TABLE IF NOT EXISTS admin_sessions (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_user_id     UUID NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
    device_label      TEXT,
    ip_address        TEXT,
    created_at        TIMESTAMPTZ DEFAULT now(),
    last_seen_at      TIMESTAMPTZ DEFAULT now(),
    expires_at        TIMESTAMPTZ NOT NULL,
    revoked_at        TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_admin ON admin_sessions(admin_user_id);

INSERT INTO app_settings (key, value) VALUES
  ('services.restaurants.enabled', 'true'),
  ('services.stores.enabled', 'true'),
  ('services.home_services.enabled', 'true'),
  ('services.rides.enabled', 'true'),
  ('services.parcel.enabled', 'true'),
  ('services.wallet.enabled', 'true'),
  ('payment.cash.enabled', 'true'),
  ('payment.gateway.enabled', 'false')
ON CONFLICT (key) DO NOTHING;


 — home_controller.dart already calls
-- GET /wallet/me expecting {balance})
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS customer_wallets (
    user_id       UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    balance       NUMERIC(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS customer_wallet_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type            VARCHAR(30) NOT NULL, -- 'topup_code' | 'order_payment' | 'refund' | 'points_redeem'
    amount          NUMERIC(12,2) NOT NULL, -- negative = debit
    balance_after   NUMERIC(12,2) NOT NULL,
    reference_type  VARCHAR(30),
    reference_id    UUID,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- item 12: نظام شحن الرصيد بالأكواد
CREATE TABLE IF NOT EXISTS topup_codes (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code          VARCHAR(20) NOT NULL UNIQUE,
    value         NUMERIC(10,2) NOT NULL,
    status        VARCHAR(20) NOT NULL DEFAULT 'active', -- active/used/cancelled/expired
    used_by       UUID REFERENCES users(id),
    used_at       TIMESTAMPTZ,
    expires_at    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT now()
);


-- distinct from ride-sharing.routes.ts which only handles live-tracking
-- share links + emergency contacts, and from negotiation.routes.ts which
-- only handles the "أودي ماكس" price-offer flow on top of a ride that
-- already exists)
-- ---------------------------------------------------------------------
ALTER TABLE rides ADD COLUMN IF NOT EXISTS category_id UUID REFERENCES ride_categories(id);
ALTER TABLE rides ADD COLUMN IF NOT EXISTS is_focus_mode BOOLEAN DEFAULT false;
ALTER TABLE rides ADD COLUMN IF NOT EXISTS route_preference VARCHAR(20) DEFAULT 'fastest'; -- 'fastest' | 'cheapest'
ALTER TABLE rides ADD COLUMN IF NOT EXISTS pricing_mode VARCHAR(20) NOT NULL DEFAULT 'fixed'; -- 'fixed' | 'negotiated' (أودي ماكس)
ALTER TABLE rides ADD COLUMN IF NOT EXISTS cancelled_by VARCHAR(20); -- 'customer' | 'driver'
ALTER TABLE rides ADD COLUMN IF NOT EXISTS cancellation_reason TEXT;
ALTER TABLE rides ADD COLUMN IF NOT EXISTS rating INT CHECK (rating BETWEEN 1 AND 5);


CREATE TABLE IF NOT EXISTS ride_convoys (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_by_customer_id      UUID NOT NULL REFERENCES users(id),
    deviation_threshold_meters  INT NOT NULL DEFAULT 500,
    created_at                  TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE rides ADD COLUMN IF NOT EXISTS convoy_id UUID REFERENCES ride_convoys(id);

CREATE TABLE IF NOT EXISTS convoy_deviation_alerts (
    id              BIGSERIAL PRIMARY KEY,
    convoy_id       UUID NOT NULL REFERENCES ride_convoys(id) ON DELETE CASCADE,
    ride_id         UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
    distance_meters NUMERIC(10,2) NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ride_price_offers (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ride_id         UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
    proposed_by     VARCHAR(20) NOT NULL, -- 'customer' | 'driver'
    driver_id       UUID REFERENCES drivers(id),
    offered_price   NUMERIC(12,2) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/accepted/rejected/expired
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ride_share_links (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ride_id         UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
    public_token    VARCHAR(64) NOT NULL UNIQUE,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_emergency_contacts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name            VARCHAR(100) NOT NULL,
    phone           VARCHAR(20) NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ride_emergency_notifications (
    id              BIGSERIAL PRIMARY KEY,
    ride_id         UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
    contact_id      UUID NOT NULL REFERENCES user_emergency_contacts(id),
    sent_at         TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- DRIVER WALLET / EARNINGS (item 11 — driver side; partner side already
-- existed as partner_balance_transactions/settlement_batches)
-- ---------------------------------------------------------------------
ALTER TABLE drivers ADD COLUMN IF NOT EXISTS balance NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE drivers ADD COLUMN IF NOT EXISTS total_earned NUMERIC(12,2) NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS driver_wallet_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id       UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    type            VARCHAR(30) NOT NULL, -- 'order_earning' | 'ride_earning' | 'tip' | 'commission_deduction' | 'withdrawal'
    amount          NUMERIC(12,2) NOT NULL, -- negative = debit (withdrawal/commission), positive = credit
    balance_after   NUMERIC(12,2) NOT NULL,
    reference_type  VARCHAR(30),
    reference_id    UUID,
    created_at      TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_driver_wallet_txn_driver ON driver_wallet_transactions(driver_id, created_at DESC);

CREATE TABLE IF NOT EXISTS driver_withdrawal_requests (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    driver_id       UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    amount          NUMERIC(12,2) NOT NULL,
    payout_details  JSONB NOT NULL,   -- {'account': '...'} — شكل حر لحد ما تُحدد وسيلة السحب النهائية (بند 12)
    status          VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/approved/rejected/paid
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- NOTIFICATIONS (item 15 — in-app center; push itself goes out via
-- Firebase using users.fcm_token, already present in schema.sql)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type            VARCHAR(30) NOT NULL, -- order/driver/partner/payment/promotion/system
    title_ar        VARCHAR(150) NOT NULL,
    body_ar         TEXT,
    reference_type  VARCHAR(30),
    reference_id    UUID,
    is_read         BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);

-- ---------------------------------------------------------------------
-- POINTS (item 18)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS point_rules (
    id                  INT PRIMARY KEY DEFAULT 1,
    points_per_currency NUMERIC(6,2) NOT NULL DEFAULT 1, -- نقاط لكل وحدة عملة يُنفقها العميل بطلب مكتمل
    CHECK (id = 1)
);
INSERT INTO point_rules (id, points_per_currency) VALUES (1, 1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS customer_points (
    user_id       UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    balance       INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS point_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type            VARCHAR(20) NOT NULL, -- 'earn' | 'redeem'
    points          INT NOT NULL, -- negative for redeem
    balance_after   INT NOT NULL,
    reference_type  VARCHAR(30),
    reference_id    UUID,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS point_rewards (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_ar       VARCHAR(150) NOT NULL,
    points_cost   INT NOT NULL,
    stock_qty     INT NOT NULL DEFAULT 0,
    image_url     TEXT,
    is_active     BOOLEAN DEFAULT true
);

-- ---------------------------------------------------------------------
-- INVITES (item 19 — reward only after the invitee completes a
-- delivered order, inside an admin-configurable window)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invite_settings (
    id                    INT PRIMARY KEY DEFAULT 1,
    completion_window_days INT NOT NULL DEFAULT 30,
    inviter_reward_points  INT NOT NULL DEFAULT 100,
    invitee_reward_points  INT NOT NULL DEFAULT 50,
    CHECK (id = 1)
);
INSERT INTO invite_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS invites (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    inviter_id    UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    code          VARCHAR(20) NOT NULL UNIQUE,
    created_at    TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invite_redemptions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invite_id       UUID NOT NULL REFERENCES invites(id) ON DELETE CASCADE,
    invitee_id      UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/completed/expired
    redeemed_at     TIMESTAMPTZ DEFAULT now(),
    completed_at    TIMESTAMPTZ
);

-- ---------------------------------------------------------------------
-- SUBSCRIPTIONS: ODE Plus / ODE Pro (item 17)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS subscription_plans (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code          VARCHAR(10) NOT NULL UNIQUE, -- 'plus' | 'pro'
    name_ar       VARCHAR(100) NOT NULL,
    price         NUMERIC(10,2) NOT NULL,
    currency_id   INT NOT NULL REFERENCES currencies(id),
    duration_days INT NOT NULL DEFAULT 30,
    benefits      JSONB NOT NULL DEFAULT '[]', -- ["priority_service","bigger_discounts",...] — يديره الأدمن كليًا
    is_active     BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS user_subscriptions (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_id       UUID NOT NULL REFERENCES subscription_plans(id),
    starts_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    ends_at       TIMESTAMPTZ NOT NULL,
    status        VARCHAR(20) NOT NULL DEFAULT 'active' -- active/expired/cancelled
);


-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_pickup_codes (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id                UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    secret_code             VARCHAR(10) NOT NULL,
    expected_driver_id      UUID REFERENCES drivers(id),
    is_scanned              BOOLEAN DEFAULT false,
    scanned_by_driver_id    UUID REFERENCES drivers(id),
    scanned_at              TIMESTAMPTZ,
    created_at              TIMESTAMPTZ DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_pickup_codes_order ON order_pickup_codes(order_id);

CREATE TABLE IF NOT EXISTS order_pickup_scan_attempts (
    id              BIGSERIAL PRIMARY KEY,
    order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    driver_id       UUID REFERENCES drivers(id),
    was_successful  BOOLEAN NOT NULL,
    failure_reason  VARCHAR(50),
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ---------------------------------------------------------------------
-- ADMIN DASHBOARD (item 8 — auth, roles, audit log). Admin login is
-- email+password+optional TOTP, NOT phone OTP — a different surface
-- entirely from every other app.
-- ---------------------------------------------------------------------
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS is_super_admin BOOLEAN DEFAULT false;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS totp_secret TEXT;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN DEFAULT false;
ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT true;

-- Append-only by convention (enforced at the API layer: no UPDATE/DELETE
-- route is ever exposed for this table).
CREATE TABLE IF NOT EXISTS audit_logs (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_user_id UUID REFERENCES admin_users(id),
    action        VARCHAR(60) NOT NULL,
    target_type   VARCHAR(30),
    target_id     TEXT,
    metadata      JSONB DEFAULT '{}',
    created_at    TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS broadcast_notifications (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sent_by       UUID REFERENCES admin_users(id),
    audience      VARCHAR(20) NOT NULL, -- 'all_customers' | 'all_drivers' | 'all_partners'
    title_ar      VARCHAR(150) NOT NULL,
    body_ar       TEXT,
    recipient_count INT DEFAULT 0,
    created_at    TIMESTAMPTZ DEFAULT now()
);

-- item 20: توثيق سبب إلغاء الشريك/السائق (كان مفقود — orders.routes.ts
-- ما يخزّن سبب الإلغاء حاليًا لأوامر التوصيل، فقط rides.routes.ts يفعل)
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancelled_by VARCHAR(20);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancellation_reason TEXT;

-- item 21: مهلة السائق قبل التنبيه — قابلة للتعديل من الأدمن عبر
-- app_settings (key='driver_timeout_minutes')، لا حاجة لعمود مخصص.

-- rate limiting (item 22) لا يحتاج جدول — يُطبّق بذاكرة العملية مباشرة
-- بمكتبة express-rate-limit.

-- item 6/20: driver decline needs its own distinguishable history entry
-- (was impossible before — order_status enum never had this value).
ALTER TYPE order_status ADD VALUE IF NOT EXISTS 'driver_declined';

-- ---------------------------------------------------------------------
-- SECURITY/CORRECTNESS AUDIT FIXES (external review, batch 1-20)
-- ---------------------------------------------------------------------

-- item 18: Math.random() order numbers can collide against the existing
-- UNIQUE constraint on orders.order_number — a real sequence removes the
-- possibility entirely instead of just making it "unlikely".
CREATE SEQUENCE IF NOT EXISTS order_number_seq START 100000;

-- item 13: idempotency — a client retry (weak connection double-submit)
-- must never create two orders. One key per customer, enforced at the DB
-- level so even a race between two near-simultaneous requests can't slip
-- through a check-then-insert gap in application code.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(64);
CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_customer_idempotency
  ON orders(customer_id, idempotency_key) WHERE idempotency_key IS NOT NULL;

-- item 20: cancellation needs to know who cancelled and why, same shape
-- already used on rides.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancelled_by VARCHAR(20);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancellation_reason TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS cancellation_fee NUMERIC(12,2) DEFAULT 0;

-- ride-sharing.service.ts already reads this column (night-ride emergency
-- auto-notify) — it never existed, so that feature silently matched zero
-- contacts every single time.
ALTER TABLE user_emergency_contacts ADD COLUMN IF NOT EXISTS notify_on_night_rides BOOLEAN DEFAULT true;

-- Audit (بند 3): تسجيل حالة إرسال إشعار الطوارئ فعليًا (نجح/فشل + سبب
-- الفشل) بدل مجرد تسجيل النية بالإرسال بدون أي دليل هل وصلت الرسالة فعلًا.
ALTER TABLE ride_emergency_notifications ADD COLUMN IF NOT EXISTS delivery_status VARCHAR(10) DEFAULT 'sent';
ALTER TABLE ride_emergency_notifications ADD COLUMN IF NOT EXISTS error_message TEXT;

-- Audit (بند 1، شورتس): shorts.like_count كان رقمًا بدون أي جدول ربط
-- بمستخدم — استحال معرفة هل أعجب المستخدم بفيديو معيّن من قبل، فكان
-- toggleLike() بتطبيق العميل سيضخّم العداد بلا حدود بدل تبديل حقيقي.
CREATE TABLE IF NOT EXISTS short_likes (
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    short_id    UUID NOT NULL REFERENCES shorts(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (user_id, short_id)
);

-- ---------------------------------------------------------------------
-- APP APPEARANCE (طلب صريح: تحكّم الأدمن بمظهر التطبيقات الثلاثة بدون أي
-- تعديل كود — شعار، ألوان، حجم الخط، استدارة الأزرار، الوضع الافتراضي
-- (فاتح/داكن)، ورابط "خدمة العملاء" الذي يُفتح من الملف الشخصي بكل تطبيق.
-- صف واحد فقط (id=1) — إعداد عام مشترك لعلامة ODE بكل التطبيقات، مو لكل
-- تطبيق إعداد منفصل، لأنها نفس الهوية البصرية للعلامة الواحدة.
-- صلاحية 'appearance.write' كانت موجودة بقائمة صلاحيات لوحة الإدارة من
-- البداية (AdminUsers.jsx) لكن بدون أي جدول أو route يستخدمها فعليًا —
-- هذا الجدول والراوت يسدّان تلك الفجوة بالضبط.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS app_appearance (
    id                      INT PRIMARY KEY DEFAULT 1,
    logo_url                TEXT,
    primary_color           VARCHAR(7)  NOT NULL DEFAULT '#6A0DAD',
    secondary_color         VARCHAR(7)  NOT NULL DEFAULT '#9B4DE0',
    font_scale              NUMERIC(3,2) NOT NULL DEFAULT 1.00,
    button_radius           INT NOT NULL DEFAULT 16,
    default_theme_mode      VARCHAR(10) NOT NULL DEFAULT 'dark',  -- 'light' | 'dark' | 'system'
    -- فارغ عمدًا افتراضيًا — الأدمن يضيف الرابط الحقيقي بنفسه من اللوحة،
    -- ما يوضع رابط وهمي بالكود مطلقًا (طلب صريح).
    customer_support_url    TEXT,
    updated_at              TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT single_row CHECK (id = 1)
);
INSERT INTO app_appearance (id) VALUES (1) ON CONFLICT (id) DO NOTHING;


